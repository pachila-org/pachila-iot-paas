-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : iotpass
-- 
-- Part : #1
-- Date : 2016-05-04 10:19:20
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `iot_action`
-- -----------------------------
DROP TABLE IF EXISTS `iot_action`;
CREATE TABLE `iot_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `module` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `iot_action`
-- -----------------------------
INSERT INTO `iot_action` VALUES ('1', 'reg', '用户注册', '用户注册', '', '', '1', '1', '1426070545', '');
INSERT INTO `iot_action` VALUES ('2', 'input_password', '输入密码', '记录输入密码的次数。', '', '', '1', '1', '1426122119', '');
INSERT INTO `iot_action` VALUES ('3', 'user_login', '用户登录', '积分+10，每天一次', 'a:1:{i:0;a:5:{s:5:\"table\";s:6:\"member\";s:5:\"field\";s:1:\"1\";s:4:\"rule\";s:2:\"10\";s:5:\"cycle\";s:2:\"24\";s:3:\"max\";s:1:\"1\";}}', '[user|get_nickname]在[time|time_format]登录了账号', '1', '1', '1428397656', '');
INSERT INTO `iot_action` VALUES ('4', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988', '');
INSERT INTO `iot_action` VALUES ('5', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057', '');
INSERT INTO `iot_action` VALUES ('6', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963', '');
INSERT INTO `iot_action` VALUES ('7', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301', '');
INSERT INTO `iot_action` VALUES ('8', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392', '');
INSERT INTO `iot_action` VALUES ('9', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765', '');

-- -----------------------------
-- Table structure for `iot_action_limit`
-- -----------------------------
DROP TABLE IF EXISTS `iot_action_limit`;
CREATE TABLE `iot_action_limit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `frequency` int(11) NOT NULL,
  `time_number` int(11) NOT NULL,
  `time_unit` varchar(50) NOT NULL,
  `punish` text NOT NULL,
  `if_message` tinyint(4) NOT NULL,
  `message_content` text NOT NULL,
  `action_list` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `module` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_action_limit`
-- -----------------------------
INSERT INTO `iot_action_limit` VALUES ('1', 'reg', '注册限制', '1', '1', 'minute', 'warning', '0', '', '[reg]', '1', '0', '');
INSERT INTO `iot_action_limit` VALUES ('2', 'input_password', '输密码', '3', '1', 'minute', 'warning', '0', '', '[input_password]', '1', '0', '');

-- -----------------------------
-- Table structure for `iot_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_action_log`;
CREATE TABLE `iot_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=514 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `iot_action_log`
-- -----------------------------
INSERT INTO `iot_action_log` VALUES ('1', '3', '1', '0', 'member', '1', 'admin在2015-12-14 15:55登录了账号【积分：10分】', '1', '1450079708');
INSERT INTO `iot_action_log` VALUES ('2', '3', '1', '0', 'member', '1', 'admin在2015-12-14 16:44登录了账号', '1', '1450082676');
INSERT INTO `iot_action_log` VALUES ('3', '3', '1', '0', 'member', '1', 'admin在2015-12-14 17:14登录了账号', '1', '1450084499');
INSERT INTO `iot_action_log` VALUES ('4', '3', '1', '0', 'member', '1', 'admin在2015-12-14 20:42登录了账号', '1', '1450096960');
INSERT INTO `iot_action_log` VALUES ('5', '4', '1', '0', 'config', '20', '操作url：/opencenter/index.php?s=/Admin/Config/edit.html', '1', '1450097812');
INSERT INTO `iot_action_log` VALUES ('6', '3', '1', '0', 'member', '1', 'admin在2015-12-16 08:41登录了账号【积分：10分】', '1', '1450226476');
INSERT INTO `iot_action_log` VALUES ('7', '4', '1', '0', 'config', '47', '操作url：/opencenter/index.php?s=/Admin/Config/edit.html', '1', '1450234484');
INSERT INTO `iot_action_log` VALUES ('8', '3', '1', '0', 'member', '1', 'admin在2015-12-17 10:17登录了账号【积分：10分】', '1', '1450318632');
INSERT INTO `iot_action_log` VALUES ('9', '3', '1', '0', 'member', '1', 'admin在2015-12-17 10:20登录了账号', '1', '1450318842');
INSERT INTO `iot_action_log` VALUES ('10', '3', '1', '0', 'member', '1', 'admin在2015-12-17 14:12登录了账号', '1', '1450332735');
INSERT INTO `iot_action_log` VALUES ('11', '3', '1', '0', 'member', '1', 'admin在2015-12-18 16:26登录了账号【积分：10分】', '1', '1450427195');
INSERT INTO `iot_action_log` VALUES ('12', '2', '1', '0', 'ucenter_member', '1', '操作url：/opencenter/index.php?s=/Admin/Public/login.html', '1', '1450514650');
INSERT INTO `iot_action_log` VALUES ('13', '3', '1', '0', 'member', '1', 'admin在2015-12-19 16:44登录了账号【积分：10分】', '1', '1450514657');
INSERT INTO `iot_action_log` VALUES ('14', '8', '1', '0', 'Menu', '220', '操作url：/opencenter/index.php?s=/Admin/Menu/edit.html', '1', '1450609158');
INSERT INTO `iot_action_log` VALUES ('15', '8', '1', '0', 'Menu', '219', '操作url：/opencenter/index.php?s=/Admin/Menu/edit.html', '1', '1450609190');
INSERT INTO `iot_action_log` VALUES ('16', '4', '1', '0', 'config', '5', '操作url：/opencenter/index.php?s=/Admin/Config/edit.html', '1', '1450669835');
INSERT INTO `iot_action_log` VALUES ('17', '8', '1', '0', 'Menu', '229', '操作url：/opencenter/admin.php?s=/Menu/add.html', '1', '1450685471');
INSERT INTO `iot_action_log` VALUES ('18', '1', '1', '0', 'ucenter_member', '1', '操作url：/opencenter/admin.php?s=/User/addNewAdmin.html', '1', '1450703702');
INSERT INTO `iot_action_log` VALUES ('19', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:15登录了账号【积分：10分】', '1', '1450703744');
INSERT INTO `iot_action_log` VALUES ('20', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:16登录了账号【积分：10分】', '1', '1450703766');
INSERT INTO `iot_action_log` VALUES ('21', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:17登录了账号', '1', '1450703821');
INSERT INTO `iot_action_log` VALUES ('22', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:17登录了账号', '1', '1450703829');
INSERT INTO `iot_action_log` VALUES ('23', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:18登录了账号', '1', '1450703890');
INSERT INTO `iot_action_log` VALUES ('24', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:18登录了账号', '1', '1450703916');
INSERT INTO `iot_action_log` VALUES ('25', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:20登录了账号', '1', '1450704027');
INSERT INTO `iot_action_log` VALUES ('26', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:23登录了账号', '1', '1450704195');
INSERT INTO `iot_action_log` VALUES ('27', '1', '1', '0', 'ucenter_member', '1', '操作url：/opencenter/admin.php?s=/User/addNewAdmin.html', '1', '1450704396');
INSERT INTO `iot_action_log` VALUES ('28', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:31登录了账号', '1', '1450704710');
INSERT INTO `iot_action_log` VALUES ('29', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:32登录了账号', '1', '1450704737');
INSERT INTO `iot_action_log` VALUES ('30', '8', '1', '0', 'Menu', '210', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450704763');
INSERT INTO `iot_action_log` VALUES ('31', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:33登录了账号', '1', '1450704780');
INSERT INTO `iot_action_log` VALUES ('32', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:33登录了账号', '1', '1450704800');
INSERT INTO `iot_action_log` VALUES ('33', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:33登录了账号', '1', '1450704837');
INSERT INTO `iot_action_log` VALUES ('34', '3', '100', '0', 'member', '100', 'test在2015-12-21 22:27登录了账号', '1', '1450708058');
INSERT INTO `iot_action_log` VALUES ('35', '3', '1', '0', 'member', '1', 'admin在2015-12-21 22:27登录了账号', '1', '1450708075');
INSERT INTO `iot_action_log` VALUES ('36', '8', '1', '0', 'Menu', '212', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708107');
INSERT INTO `iot_action_log` VALUES ('37', '8', '1', '0', 'Menu', '211', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708119');
INSERT INTO `iot_action_log` VALUES ('38', '8', '1', '0', 'Menu', '213', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708134');
INSERT INTO `iot_action_log` VALUES ('39', '8', '1', '0', 'Menu', '214', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708146');
INSERT INTO `iot_action_log` VALUES ('40', '8', '1', '0', 'Menu', '215', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708156');
INSERT INTO `iot_action_log` VALUES ('41', '8', '1', '0', 'Menu', '216', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708171');
INSERT INTO `iot_action_log` VALUES ('42', '8', '1', '0', 'Menu', '218', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708184');
INSERT INTO `iot_action_log` VALUES ('43', '8', '1', '0', 'Menu', '219', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708194');
INSERT INTO `iot_action_log` VALUES ('44', '8', '1', '0', 'Menu', '220', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708203');
INSERT INTO `iot_action_log` VALUES ('45', '8', '1', '0', 'Menu', '221', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708214');
INSERT INTO `iot_action_log` VALUES ('46', '8', '1', '0', 'Menu', '224', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708231');
INSERT INTO `iot_action_log` VALUES ('47', '8', '1', '0', 'Menu', '226', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708242');
INSERT INTO `iot_action_log` VALUES ('48', '8', '1', '0', 'Menu', '228', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708258');
INSERT INTO `iot_action_log` VALUES ('49', '3', '1', '0', 'member', '1', 'admin在2015-12-22 14:42登录了账号', '1', '1450766536');
INSERT INTO `iot_action_log` VALUES ('50', '3', '100', '0', 'member', '100', 'test在2015-12-22 17:11登录了账号', '1', '1450775512');
INSERT INTO `iot_action_log` VALUES ('51', '3', '1', '0', 'member', '1', 'admin在2015-12-22 17:12登录了账号', '1', '1450775529');
INSERT INTO `iot_action_log` VALUES ('52', '3', '1', '0', 'member', '1', 'admin在2015-12-24 16:44登录了账号【积分：10分】', '1', '1450946687');
INSERT INTO `iot_action_log` VALUES ('53', '3', '1', '0', 'member', '1', 'admin在2015-12-24 16:45登录了账号', '1', '1450946747');
INSERT INTO `iot_action_log` VALUES ('54', '3', '1', '0', 'member', '1', 'admin在2015-12-24 16:54登录了账号', '1', '1450947272');
INSERT INTO `iot_action_log` VALUES ('55', '3', '1', '0', 'member', '1', 'admin在2015-12-24 17:02登录了账号', '1', '1450947728');
INSERT INTO `iot_action_log` VALUES ('56', '3', '1', '0', 'member', '1', 'admin在2015-12-24 17:04登录了账号', '1', '1450947887');
INSERT INTO `iot_action_log` VALUES ('57', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:03登录了账号', '1', '1451009020');
INSERT INTO `iot_action_log` VALUES ('58', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:05登录了账号', '1', '1451009155');
INSERT INTO `iot_action_log` VALUES ('59', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:07登录了账号', '1', '1451009240');
INSERT INTO `iot_action_log` VALUES ('60', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:11登录了账号', '1', '1451009491');
INSERT INTO `iot_action_log` VALUES ('61', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:15登录了账号', '1', '1451009743');
INSERT INTO `iot_action_log` VALUES ('62', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:19登录了账号', '1', '1451009997');
INSERT INTO `iot_action_log` VALUES ('63', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:21登录了账号', '1', '1451010103');
INSERT INTO `iot_action_log` VALUES ('64', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:23登录了账号', '1', '1451010208');
INSERT INTO `iot_action_log` VALUES ('65', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:25登录了账号', '1', '1451010305');
INSERT INTO `iot_action_log` VALUES ('66', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:26登录了账号', '1', '1451010418');
INSERT INTO `iot_action_log` VALUES ('67', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:32登录了账号', '1', '1451010733');
INSERT INTO `iot_action_log` VALUES ('68', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:11登录了账号', '1', '1451013064');
INSERT INTO `iot_action_log` VALUES ('69', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:12登录了账号', '1', '1451013148');
INSERT INTO `iot_action_log` VALUES ('70', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:13登录了账号', '1', '1451013234');
INSERT INTO `iot_action_log` VALUES ('71', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:16登录了账号', '1', '1451013415');
INSERT INTO `iot_action_log` VALUES ('72', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:17登录了账号', '1', '1451013442');
INSERT INTO `iot_action_log` VALUES ('73', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:19登录了账号', '1', '1451013598');
INSERT INTO `iot_action_log` VALUES ('74', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:21登录了账号', '1', '1451013690');
INSERT INTO `iot_action_log` VALUES ('75', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:27登录了账号', '1', '1451014028');
INSERT INTO `iot_action_log` VALUES ('76', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:28登录了账号', '1', '1451014133');
INSERT INTO `iot_action_log` VALUES ('77', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:30登录了账号', '1', '1451014257');
INSERT INTO `iot_action_log` VALUES ('78', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:31登录了账号', '1', '1451014281');
INSERT INTO `iot_action_log` VALUES ('79', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:53登录了账号', '1', '1451015583');
INSERT INTO `iot_action_log` VALUES ('80', '1', '1', '0', 'ucenter_member', '1', '操作url：/opencenter/api.php?s=/users/reg', '1', '1451026953');
INSERT INTO `iot_action_log` VALUES ('81', '3', '102', '0', 'member', '102', 'qinhao在2015-12-25 15:08登录了账号【积分：10分】', '1', '1451027282');
INSERT INTO `iot_action_log` VALUES ('82', '1', '1', '0', 'ucenter_member', '1', '操作url：/opencenter/api.php?s=/users/reg', '1', '1451027516');
INSERT INTO `iot_action_log` VALUES ('83', '3', '1', '0', 'member', '1', 'admin在2015-12-27 20:30登录了账号【积分：10分】', '1', '1451219403');
INSERT INTO `iot_action_log` VALUES ('84', '3', '1', '0', 'member', '1', 'admin在2015-12-28 10:07登录了账号', '1', '1451268469');
INSERT INTO `iot_action_log` VALUES ('85', '3', '1', '0', 'member', '1', 'admin在2015-12-28 16:31登录了账号', '1', '1451291483');
INSERT INTO `iot_action_log` VALUES ('86', '3', '1', '0', 'member', '1', 'admin在2015-12-31 09:31登录了账号【积分：10分】', '1', '1451525503');
INSERT INTO `iot_action_log` VALUES ('87', '3', '1', '0', 'member', '1', 'admin在2015-12-31 09:37登录了账号', '1', '1451525850');
INSERT INTO `iot_action_log` VALUES ('88', '3', '1', '0', 'member', '1', 'admin在2015-12-31 09:37登录了账号', '1', '1451525867');
INSERT INTO `iot_action_log` VALUES ('89', '3', '1', '0', 'member', '1', 'admin在2015-12-31 09:39登录了账号', '1', '1451525969');
INSERT INTO `iot_action_log` VALUES ('90', '3', '1', '0', 'member', '1', 'admin在2016-01-04 15:25登录了账号【积分：10分】', '1', '1451892351');
INSERT INTO `iot_action_log` VALUES ('91', '3', '1', '0', 'member', '1', 'admin在2016-01-04 15:26登录了账号', '1', '1451892390');
INSERT INTO `iot_action_log` VALUES ('92', '3', '1', '0', 'member', '1', 'admin在2016-01-04 16:04登录了账号', '1', '1451894657');
INSERT INTO `iot_action_log` VALUES ('93', '3', '1', '0', 'member', '1', 'admin在2016-01-05 14:42登录了账号', '1', '1451976148');
INSERT INTO `iot_action_log` VALUES ('94', '3', '1', '0', 'member', '1', 'admin在2016-01-05 14:57登录了账号', '1', '1451977024');
INSERT INTO `iot_action_log` VALUES ('95', '3', '1', '0', 'member', '1', 'admin在2016-01-05 15:00登录了账号', '1', '1451977225');
INSERT INTO `iot_action_log` VALUES ('96', '3', '1', '0', 'member', '1', 'admin在2016-01-07 09:40登录了账号【积分：10分】', '1', '1452130809');
INSERT INTO `iot_action_log` VALUES ('97', '3', '1', '0', 'member', '1', 'admin在2016-01-08 11:20登录了账号【积分：10分】', '1', '1452223202');
INSERT INTO `iot_action_log` VALUES ('98', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:37登录了账号【积分：10分】', '1', '1452404254');
INSERT INTO `iot_action_log` VALUES ('99', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:39登录了账号', '1', '1452404380');
INSERT INTO `iot_action_log` VALUES ('100', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:43登录了账号', '1', '1452404637');
INSERT INTO `iot_action_log` VALUES ('101', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:47登录了账号', '1', '1452404830');
INSERT INTO `iot_action_log` VALUES ('102', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:47登录了账号', '1', '1452404844');
INSERT INTO `iot_action_log` VALUES ('103', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:52登录了账号', '1', '1452405123');
INSERT INTO `iot_action_log` VALUES ('104', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:53登录了账号', '1', '1452405215');
INSERT INTO `iot_action_log` VALUES ('105', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:53登录了账号', '1', '1452405232');
INSERT INTO `iot_action_log` VALUES ('106', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:55登录了账号', '1', '1452405305');
INSERT INTO `iot_action_log` VALUES ('107', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:57登录了账号', '1', '1452405462');
INSERT INTO `iot_action_log` VALUES ('108', '3', '101', '1022852489', 'member', '101', 'luyuan在2016-01-11 11:24登录了账号【积分：10分】', '1', '1452482672');
INSERT INTO `iot_action_log` VALUES ('109', '3', '101', '1022852489', 'member', '101', 'luyuan在2016-01-11 11:25登录了账号', '1', '1452482740');
INSERT INTO `iot_action_log` VALUES ('110', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 12:06登录了账号', '1', '1452485171');
INSERT INTO `iot_action_log` VALUES ('111', '3', '100', '1022852494', 'member', '100', 'test在2016-01-11 12:06登录了账号【积分：10分】', '1', '1452485216');
INSERT INTO `iot_action_log` VALUES ('112', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 12:07登录了账号', '1', '1452485234');
INSERT INTO `iot_action_log` VALUES ('113', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 13:25登录了账号', '1', '1452489905');
INSERT INTO `iot_action_log` VALUES ('114', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:29登录了账号', '1', '1452493759');
INSERT INTO `iot_action_log` VALUES ('115', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:30登录了账号', '1', '1452493843');
INSERT INTO `iot_action_log` VALUES ('116', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:33登录了账号', '1', '1452493999');
INSERT INTO `iot_action_log` VALUES ('117', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:34登录了账号', '1', '1452494049');
INSERT INTO `iot_action_log` VALUES ('118', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:36登录了账号', '1', '1452494214');
INSERT INTO `iot_action_log` VALUES ('119', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:37登录了账号', '1', '1452494259');
INSERT INTO `iot_action_log` VALUES ('120', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 14:41登录了账号', '1', '1452494463');
INSERT INTO `iot_action_log` VALUES ('121', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:22登录了账号', '1', '1452496959');
INSERT INTO `iot_action_log` VALUES ('122', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:25登录了账号', '1', '1452497159');
INSERT INTO `iot_action_log` VALUES ('123', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:25登录了账号', '1', '1452497159');
INSERT INTO `iot_action_log` VALUES ('124', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:25登录了账号', '1', '1452497159');
INSERT INTO `iot_action_log` VALUES ('125', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497164');
INSERT INTO `iot_action_log` VALUES ('126', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497186');
INSERT INTO `iot_action_log` VALUES ('127', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('128', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('129', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('130', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('131', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('132', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('133', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497188');
INSERT INTO `iot_action_log` VALUES ('134', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497188');
INSERT INTO `iot_action_log` VALUES ('135', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497188');
INSERT INTO `iot_action_log` VALUES ('136', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497193');
INSERT INTO `iot_action_log` VALUES ('137', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 16:33登录了账号', '1', '1452501191');
INSERT INTO `iot_action_log` VALUES ('138', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:35登录了账号', '1', '1452501345');
INSERT INTO `iot_action_log` VALUES ('139', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:39登录了账号', '1', '1452501564');
INSERT INTO `iot_action_log` VALUES ('140', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:40登录了账号', '1', '1452501649');
INSERT INTO `iot_action_log` VALUES ('141', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:41登录了账号', '1', '1452501688');
INSERT INTO `iot_action_log` VALUES ('142', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:42登录了账号', '1', '1452501728');
INSERT INTO `iot_action_log` VALUES ('143', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:42登录了账号', '1', '1452501755');
INSERT INTO `iot_action_log` VALUES ('144', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:44登录了账号', '1', '1452501881');
INSERT INTO `iot_action_log` VALUES ('145', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:46登录了账号', '1', '1452501965');
INSERT INTO `iot_action_log` VALUES ('146', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:46登录了账号', '1', '1452501965');
INSERT INTO `iot_action_log` VALUES ('147', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:46登录了账号', '1', '1452501965');
INSERT INTO `iot_action_log` VALUES ('148', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:46登录了账号', '1', '1452501965');
INSERT INTO `iot_action_log` VALUES ('149', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:47登录了账号', '1', '1452502021');
INSERT INTO `iot_action_log` VALUES ('150', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:47登录了账号', '1', '1452502064');
INSERT INTO `iot_action_log` VALUES ('151', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:47登录了账号', '1', '1452502078');
INSERT INTO `iot_action_log` VALUES ('152', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:07登录了账号', '1', '1452503246');
INSERT INTO `iot_action_log` VALUES ('153', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:10登录了账号', '1', '1452503410');
INSERT INTO `iot_action_log` VALUES ('154', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 17:11登录了账号', '1', '1452503463');
INSERT INTO `iot_action_log` VALUES ('155', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:16登录了账号', '1', '1452503812');
INSERT INTO `iot_action_log` VALUES ('156', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:19登录了账号', '1', '1452503961');
INSERT INTO `iot_action_log` VALUES ('157', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:37登录了账号', '1', '1452505023');
INSERT INTO `iot_action_log` VALUES ('158', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:37登录了账号', '1', '1452505027');
INSERT INTO `iot_action_log` VALUES ('159', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:37登录了账号', '1', '1452505038');
INSERT INTO `iot_action_log` VALUES ('160', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-11 17:39登录了账号', '1', '1452505163');
INSERT INTO `iot_action_log` VALUES ('161', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-12 08:58登录了账号', '1', '1452560337');
INSERT INTO `iot_action_log` VALUES ('162', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-12 09:42登录了账号', '1', '1452562974');
INSERT INTO `iot_action_log` VALUES ('163', '3', '1', '1917976229', 'member', '1', 'admin在2016-01-12 11:08登录了账号', '1', '1452568117');
INSERT INTO `iot_action_log` VALUES ('164', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:10登录了账号', '1', '1452568219');
INSERT INTO `iot_action_log` VALUES ('165', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:10登录了账号', '1', '1452568234');
INSERT INTO `iot_action_log` VALUES ('166', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:12登录了账号', '1', '1452568331');
INSERT INTO `iot_action_log` VALUES ('167', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:13登录了账号', '1', '1452568423');
INSERT INTO `iot_action_log` VALUES ('168', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:13登录了账号', '1', '1452568433');
INSERT INTO `iot_action_log` VALUES ('169', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:18登录了账号', '1', '1452568697');
INSERT INTO `iot_action_log` VALUES ('170', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 13:17登录了账号', '1', '1452575859');
INSERT INTO `iot_action_log` VALUES ('171', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 13:38登录了账号', '1', '1452577110');
INSERT INTO `iot_action_log` VALUES ('172', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 13:38登录了账号', '1', '1452577115');
INSERT INTO `iot_action_log` VALUES ('173', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 13:38登录了账号', '1', '1452577127');
INSERT INTO `iot_action_log` VALUES ('174', '2', '1', '1022852489', 'ucenter_member', '1', '操作url：/opencenter/admin.php?s=/Public/login.html', '1', '1452583282');
INSERT INTO `iot_action_log` VALUES ('175', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-12 15:21登录了账号', '1', '1452583287');
INSERT INTO `iot_action_log` VALUES ('176', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:25登录了账号', '1', '1452583547');
INSERT INTO `iot_action_log` VALUES ('177', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:28登录了账号', '1', '1452583691');
INSERT INTO `iot_action_log` VALUES ('178', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:34登录了账号', '1', '1452584084');
INSERT INTO `iot_action_log` VALUES ('179', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:38登录了账号', '1', '1452584308');
INSERT INTO `iot_action_log` VALUES ('180', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:42登录了账号', '1', '1452584530');
INSERT INTO `iot_action_log` VALUES ('181', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:42登录了账号', '1', '1452584536');
INSERT INTO `iot_action_log` VALUES ('182', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:42登录了账号', '1', '1452584546');
INSERT INTO `iot_action_log` VALUES ('183', '3', '1', '2070349967', 'member', '1', 'admin在2016-01-12 16:11登录了账号', '1', '1452586263');
INSERT INTO `iot_action_log` VALUES ('184', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-13 11:07登录了账号', '1', '1452654466');
INSERT INTO `iot_action_log` VALUES ('185', '3', '1', '1022852491', 'member', '1', 'admin在2016-01-13 11:33登录了账号', '1', '1452656008');
INSERT INTO `iot_action_log` VALUES ('186', '3', '1', '1022852492', 'member', '1', 'admin在2016-01-13 13:56登录了账号', '1', '1452664615');
INSERT INTO `iot_action_log` VALUES ('187', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 14:12登录了账号', '1', '1452665522');
INSERT INTO `iot_action_log` VALUES ('188', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 14:35登录了账号', '1', '1452666901');
INSERT INTO `iot_action_log` VALUES ('189', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:15登录了账号', '1', '1452669320');
INSERT INTO `iot_action_log` VALUES ('190', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-13 15:16登录了账号', '1', '1452669364');
INSERT INTO `iot_action_log` VALUES ('191', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:20登录了账号', '1', '1452669641');
INSERT INTO `iot_action_log` VALUES ('192', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:20登录了账号', '1', '1452669644');
INSERT INTO `iot_action_log` VALUES ('193', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:20登录了账号', '1', '1452669646');
INSERT INTO `iot_action_log` VALUES ('194', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:23登录了账号', '1', '1452669804');
INSERT INTO `iot_action_log` VALUES ('195', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-13 15:30登录了账号', '1', '1452670250');
INSERT INTO `iot_action_log` VALUES ('196', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-13 15:31登录了账号', '1', '1452670280');
INSERT INTO `iot_action_log` VALUES ('197', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:33登录了账号', '1', '1452670385');
INSERT INTO `iot_action_log` VALUES ('198', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:33登录了账号', '1', '1452670385');
INSERT INTO `iot_action_log` VALUES ('199', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:34登录了账号', '1', '1452670440');
INSERT INTO `iot_action_log` VALUES ('200', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-13 15:45登录了账号', '1', '1452671113');
INSERT INTO `iot_action_log` VALUES ('201', '3', '1', '3026302676', 'member', '1', 'admin在2016-01-13 16:23登录了账号', '1', '1452673403');
INSERT INTO `iot_action_log` VALUES ('202', '3', '1', '1022852492', 'member', '1', 'admin在2016-01-13 18:03登录了账号', '1', '1452679390');
INSERT INTO `iot_action_log` VALUES ('203', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 17:33登录了账号', '1', '1452764008');
INSERT INTO `iot_action_log` VALUES ('204', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 17:33登录了账号', '1', '1452764015');
INSERT INTO `iot_action_log` VALUES ('205', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 17:33登录了账号', '1', '1452764021');
INSERT INTO `iot_action_log` VALUES ('206', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:02登录了账号', '1', '1452769347');
INSERT INTO `iot_action_log` VALUES ('207', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:03登录了账号', '1', '1452769439');
INSERT INTO `iot_action_log` VALUES ('208', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:04登录了账号', '1', '1452769457');
INSERT INTO `iot_action_log` VALUES ('209', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:05登录了账号', '1', '1452769500');
INSERT INTO `iot_action_log` VALUES ('210', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:05登录了账号', '1', '1452769538');
INSERT INTO `iot_action_log` VALUES ('211', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:19登录了账号', '1', '1452770385');
INSERT INTO `iot_action_log` VALUES ('212', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:19登录了账号', '1', '1452770388');
INSERT INTO `iot_action_log` VALUES ('213', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:21登录了账号', '1', '1452770512');
INSERT INTO `iot_action_log` VALUES ('214', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:22登录了账号', '1', '1452770572');
INSERT INTO `iot_action_log` VALUES ('215', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:29登录了账号', '1', '1452770997');
INSERT INTO `iot_action_log` VALUES ('216', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 20:38登录了账号', '1', '1452775084');
INSERT INTO `iot_action_log` VALUES ('217', '3', '1', '992823891', 'member', '1', 'admin在2016-01-14 21:46登录了账号', '1', '1452779210');
INSERT INTO `iot_action_log` VALUES ('218', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-15 09:32登录了账号', '1', '1452821533');
INSERT INTO `iot_action_log` VALUES ('219', '3', '1', '3026302644', 'member', '1', 'admin在2016-01-15 11:47登录了账号', '1', '1452829652');
INSERT INTO `iot_action_log` VALUES ('220', '3', '1', '3026302644', 'member', '1', 'admin在2016-01-15 11:47登录了账号', '1', '1452829653');
INSERT INTO `iot_action_log` VALUES ('221', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-15 13:06登录了账号', '1', '1452834409');
INSERT INTO `iot_action_log` VALUES ('222', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-15 14:12登录了账号', '1', '1452838357');
INSERT INTO `iot_action_log` VALUES ('223', '3', '1', '3026302629', 'member', '1', 'admin在2016-01-15 14:57登录了账号', '1', '1452841045');
INSERT INTO `iot_action_log` VALUES ('224', '2', '1', '1022852494', 'ucenter_member', '1', '操作url：/opencenter/admin.php?s=/Public/login.html', '1', '1452842108');
INSERT INTO `iot_action_log` VALUES ('225', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-15 15:15登录了账号', '1', '1452842113');
INSERT INTO `iot_action_log` VALUES ('226', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-16 19:43登录了账号【积分：10分】', '1', '1452944600');
INSERT INTO `iot_action_log` VALUES ('227', '3', '1', '1918707630', 'member', '1', 'admin在2016-01-17 20:23登录了账号【积分：10分】', '1', '1453033410');
INSERT INTO `iot_action_log` VALUES ('228', '3', '1', '0', 'member', '1', 'admin在2016-04-06 13:43登录了账号【积分：10分】', '1', '1459921388');
INSERT INTO `iot_action_log` VALUES ('229', '3', '1', '1918706815', 'member', '1', 'admin在2016-04-07 22:58登录了账号【积分：10分】', '1', '1460041094');
INSERT INTO `iot_action_log` VALUES ('230', '3', '1', '1022852504', 'member', '1', 'admin在2016-04-08 09:41登录了账号', '1', '1460079702');
INSERT INTO `iot_action_log` VALUES ('231', '1', '1', '1022852504', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/loginby3rd', '1', '1460081415');
INSERT INTO `iot_action_log` VALUES ('232', '3', '104', '1022852504', 'member', '104', 'testqq在2016-04-08 10:10登录了账号【积分：10分】', '1', '1460081415');
INSERT INTO `iot_action_log` VALUES ('233', '2', '1', '1875759426', 'ucenter_member', '1', '操作url：/iotpass/admin.php?s=/Public/login.html', '1', '1460477456');
INSERT INTO `iot_action_log` VALUES ('234', '2', '1', '1875759426', 'ucenter_member', '1', '操作url：/iotpass/admin.php?s=/Public/login.html', '1', '1460477463');
INSERT INTO `iot_action_log` VALUES ('235', '2', '1', '1875759426', 'ucenter_member', '1', '操作url：/iotpass/admin.php?s=/Public/login.html', '1', '1460477468');
INSERT INTO `iot_action_log` VALUES ('236', '2', '1', '1875759426', 'ucenter_member', '1', '操作url：/iotpass/admin.php?s=/Public/login.html', '1', '1460477537');
INSERT INTO `iot_action_log` VALUES ('237', '2', '1', '1875759426', 'ucenter_member', '1', '操作url：/iotpass/admin.php?s=/Public/login.html', '1', '1460477541');
INSERT INTO `iot_action_log` VALUES ('238', '2', '1', '1875759426', 'ucenter_member', '1', '操作url：/iotpass/admin.php?s=/Public/login.html', '1', '1460477546');
INSERT INTO `iot_action_log` VALUES ('239', '3', '1', '1875759426', 'member', '1', 'admin在2016-04-13 07:42登录了账号【积分：10分】', '1', '1460504534');
INSERT INTO `iot_action_log` VALUES ('240', '3', '1', '3732982275', 'member', '1', 'admin在2016-04-14 07:37登录了账号', '1', '1460590657');
INSERT INTO `iot_action_log` VALUES ('241', '3', '104', '3732982275', 'member', '104', 'testqq在2016-04-14 07:39登录了账号【积分：10分】', '1', '1460590792');
INSERT INTO `iot_action_log` VALUES ('242', '3', '1', '1918706815', 'member', '1', 'admin在2016-04-14 17:38登录了账号', '1', '1460626721');
INSERT INTO `iot_action_log` VALUES ('243', '2', '1', '1022848972', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/login', '1', '1460684649');
INSERT INTO `iot_action_log` VALUES ('244', '2', '1', '1022848972', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/login', '1', '1460684667');
INSERT INTO `iot_action_log` VALUES ('245', '3', '1', '1022848974', 'member', '1', 'admin在2016-04-15 10:05登录了账号', '1', '1460685953');
INSERT INTO `iot_action_log` VALUES ('246', '2', '1', '1022848972', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/login', '1', '1460685984');
INSERT INTO `iot_action_log` VALUES ('247', '2', '1', '1022848974', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/login', '1', '1460685994');
INSERT INTO `iot_action_log` VALUES ('248', '3', '1', '1022848974', 'member', '1', 'admin在2016-04-15 10:06登录了账号', '1', '1460686004');
INSERT INTO `iot_action_log` VALUES ('249', '3', '1', '1022848972', 'member', '1', 'admin在2016-04-15 10:06登录了账号', '1', '1460686008');
INSERT INTO `iot_action_log` VALUES ('250', '3', '1', '1022848972', 'member', '1', 'admin在2016-04-15 10:07登录了账号', '1', '1460686070');
INSERT INTO `iot_action_log` VALUES ('251', '2', '1', '1022848972', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/login', '1', '1460686119');
INSERT INTO `iot_action_log` VALUES ('252', '3', '1', '1022848972', 'member', '1', 'admin在2016-04-15 10:09登录了账号', '1', '1460686141');
INSERT INTO `iot_action_log` VALUES ('253', '3', '1', '1022848972', 'member', '1', 'admin在2016-04-15 10:11登录了账号', '1', '1460686264');
INSERT INTO `iot_action_log` VALUES ('254', '2', '1', '1022848972', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/login', '1', '1460686456');
INSERT INTO `iot_action_log` VALUES ('255', '2', '1', '1022848972', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/login', '1', '1460686475');
INSERT INTO `iot_action_log` VALUES ('256', '2', '1', '1022848972', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/login', '1', '1460686500');
INSERT INTO `iot_action_log` VALUES ('257', '3', '0', '1022848972', 'member', '0', '在2016-04-15 10:15登录了账号【积分：10分】', '1', '1460686510');
INSERT INTO `iot_action_log` VALUES ('258', '3', '1', '1022848972', 'member', '1', 'admin在2016-04-15 10:15登录了账号', '1', '1460686533');
INSERT INTO `iot_action_log` VALUES ('259', '3', '1', '1022848975', 'member', '1', 'admin在2016-04-15 10:21登录了账号', '1', '1460686882');
INSERT INTO `iot_action_log` VALUES ('260', '3', '1', '1022848972', 'member', '1', 'admin在2016-04-15 10:26登录了账号', '1', '1460687161');
INSERT INTO `iot_action_log` VALUES ('261', '3', '1', '1022848975', 'member', '1', 'admin在2016-04-15 10:29登录了账号', '1', '1460687389');
INSERT INTO `iot_action_log` VALUES ('262', '3', '1', '1022848972', 'member', '1', 'admin在2016-04-15 10:40登录了账号', '1', '1460688022');
INSERT INTO `iot_action_log` VALUES ('263', '1', '1', '1022848972', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/loginby3rd', '1', '1460689517');
INSERT INTO `iot_action_log` VALUES ('264', '3', '105', '1022848972', 'member', '105', '瓢虫235在2016-04-15 11:05登录了账号【积分：10分】', '1', '1460689517');
INSERT INTO `iot_action_log` VALUES ('265', '3', '1', '1022848970', 'member', '1', 'admin在2016-04-15 12:14登录了账号', '1', '1460693675');
INSERT INTO `iot_action_log` VALUES ('266', '3', '1', '1022848972', 'member', '1', 'admin在2016-04-15 15:40登录了账号', '1', '1460706024');
INSERT INTO `iot_action_log` VALUES ('267', '1', '1', '1022848972', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/reg', '1', '1460713722');
INSERT INTO `iot_action_log` VALUES ('268', '3', '106', '1022848972', 'member', '106', 'sicon在2016-04-15 17:48登录了账号【积分：10分】', '1', '1460713734');
INSERT INTO `iot_action_log` VALUES ('269', '3', '1', '1022848972', 'member', '1', 'admin在2016-04-15 17:49登录了账号', '1', '1460713792');
INSERT INTO `iot_action_log` VALUES ('270', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-18 12:11登录了账号【积分：10分】', '1', '1460952686');
INSERT INTO `iot_action_log` VALUES ('271', '3', '1', '1022848974', 'member', '1', 'admin在2016-04-18 13:37登录了账号', '1', '1460957827');
INSERT INTO `iot_action_log` VALUES ('272', '3', '1', '1022848974', 'member', '1', 'admin在2016-04-18 13:37登录了账号', '1', '1460957843');
INSERT INTO `iot_action_log` VALUES ('273', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-18 14:51登录了账号', '1', '1460962293');
INSERT INTO `iot_action_log` VALUES ('274', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-18 14:54登录了账号', '1', '1460962445');
INSERT INTO `iot_action_log` VALUES ('275', '3', '1', '1918706815', 'member', '1', 'admin在2016-04-18 17:20登录了账号', '1', '1460971227');
INSERT INTO `iot_action_log` VALUES ('276', '3', '1', '1918706815', 'member', '1', 'admin在2016-04-18 17:48登录了账号', '1', '1460972908');
INSERT INTO `iot_action_log` VALUES ('277', '3', '1', '1918706815', 'member', '1', 'admin在2016-04-18 17:57登录了账号', '1', '1460973426');
INSERT INTO `iot_action_log` VALUES ('278', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-18 18:03登录了账号', '1', '1460973787');
INSERT INTO `iot_action_log` VALUES ('279', '3', '1', '1918706815', 'member', '1', 'admin在2016-04-18 20:24登录了账号', '1', '1460982274');
INSERT INTO `iot_action_log` VALUES ('280', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-19 09:42登录了账号', '1', '1461030121');
INSERT INTO `iot_action_log` VALUES ('281', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-19 15:17登录了账号', '1', '1461050239');
INSERT INTO `iot_action_log` VALUES ('282', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-19 16:11登录了账号', '1', '1461053518');
INSERT INTO `iot_action_log` VALUES ('283', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-19 16:37登录了账号', '1', '1461055075');
INSERT INTO `iot_action_log` VALUES ('284', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-19 16:38登录了账号', '1', '1461055105');
INSERT INTO `iot_action_log` VALUES ('285', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-19 16:44登录了账号', '1', '1461055473');
INSERT INTO `iot_action_log` VALUES ('286', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-19 20:38登录了账号', '1', '1461069529');
INSERT INTO `iot_action_log` VALUES ('287', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 10:15登录了账号', '1', '1461118527');
INSERT INTO `iot_action_log` VALUES ('288', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 13:18登录了账号', '1', '1461129522');
INSERT INTO `iot_action_log` VALUES ('289', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 13:50登录了账号', '1', '1461131447');
INSERT INTO `iot_action_log` VALUES ('290', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 14:03登录了账号', '1', '1461132199');
INSERT INTO `iot_action_log` VALUES ('291', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 14:24登录了账号', '1', '1461133445');
INSERT INTO `iot_action_log` VALUES ('292', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 14:24登录了账号', '1', '1461133484');
INSERT INTO `iot_action_log` VALUES ('293', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 14:25登录了账号', '1', '1461133522');
INSERT INTO `iot_action_log` VALUES ('294', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 14:28登录了账号', '1', '1461133687');
INSERT INTO `iot_action_log` VALUES ('295', '3', '1', '1917976231', 'member', '1', 'admin在2016-04-20 14:30登录了账号', '1', '1461133843');
INSERT INTO `iot_action_log` VALUES ('296', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 14:37登录了账号', '1', '1461134228');
INSERT INTO `iot_action_log` VALUES ('297', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 15:44登录了账号', '1', '1461138248');
INSERT INTO `iot_action_log` VALUES ('298', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-20 16:54登录了账号', '1', '1461142487');
INSERT INTO `iot_action_log` VALUES ('299', '3', '105', '1917922468', 'member', '105', '瓢虫235在2016-04-21 08:19登录了账号【积分：10分】', '1', '1461197969');
INSERT INTO `iot_action_log` VALUES ('300', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 09:15登录了账号', '1', '1461201301');
INSERT INTO `iot_action_log` VALUES ('301', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 09:15登录了账号', '1', '1461201323');
INSERT INTO `iot_action_log` VALUES ('302', '4', '1', '3546230162', 'config', '88', '操作url：/iotpass/admin.php?s=/Config/edit.html', '1', '1461202747');
INSERT INTO `iot_action_log` VALUES ('303', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 09:42登录了账号', '1', '1461202961');
INSERT INTO `iot_action_log` VALUES ('304', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 10:12登录了账号', '1', '1461204778');
INSERT INTO `iot_action_log` VALUES ('305', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 10:16登录了账号', '1', '1461205018');
INSERT INTO `iot_action_log` VALUES ('306', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 10:39登录了账号', '1', '1461206343');
INSERT INTO `iot_action_log` VALUES ('307', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:26登录了账号', '1', '1461209174');
INSERT INTO `iot_action_log` VALUES ('308', '3', '105', '3546230162', 'member', '105', '瓢虫235在2016-04-21 11:29登录了账号', '1', '1461209353');
INSERT INTO `iot_action_log` VALUES ('309', '1', '1', '3546230162', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/reg', '1', '1461209391');
INSERT INTO `iot_action_log` VALUES ('310', '3', '107', '3546230162', 'member', '107', 'sicon001在2016-04-21 11:30登录了账号【积分：10分】', '1', '1461209407');
INSERT INTO `iot_action_log` VALUES ('311', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:31登录了账号', '1', '1461209470');
INSERT INTO `iot_action_log` VALUES ('312', '3', '1', '1918315473', 'member', '1', 'admin在2016-04-21 11:32登录了账号', '1', '1461209560');
INSERT INTO `iot_action_log` VALUES ('313', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:36登录了账号', '1', '1461209761');
INSERT INTO `iot_action_log` VALUES ('314', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 11:42登录了账号【积分：10分】', '1', '1461210166');
INSERT INTO `iot_action_log` VALUES ('315', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:42登录了账号', '1', '1461210171');
INSERT INTO `iot_action_log` VALUES ('316', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 11:46登录了账号', '1', '1461210415');
INSERT INTO `iot_action_log` VALUES ('317', '3', '100', '3546230162', 'member', '100', 'test在2016-04-21 11:49登录了账号【积分：10分】', '1', '1461210568');
INSERT INTO `iot_action_log` VALUES ('318', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:50登录了账号', '1', '1461210602');
INSERT INTO `iot_action_log` VALUES ('319', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 11:51登录了账号', '1', '1461210704');
INSERT INTO `iot_action_log` VALUES ('320', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 11:52登录了账号', '1', '1461210723');
INSERT INTO `iot_action_log` VALUES ('321', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:52登录了账号', '1', '1461210734');
INSERT INTO `iot_action_log` VALUES ('322', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 11:52登录了账号', '1', '1461210746');
INSERT INTO `iot_action_log` VALUES ('323', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:53登录了账号', '1', '1461210833');
INSERT INTO `iot_action_log` VALUES ('324', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 11:54登录了账号', '1', '1461210860');
INSERT INTO `iot_action_log` VALUES ('325', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 11:54登录了账号', '1', '1461210860');
INSERT INTO `iot_action_log` VALUES ('326', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:54登录了账号', '1', '1461210891');
INSERT INTO `iot_action_log` VALUES ('327', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 11:55登录了账号', '1', '1461210910');
INSERT INTO `iot_action_log` VALUES ('328', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 11:55登录了账号', '1', '1461210915');
INSERT INTO `iot_action_log` VALUES ('329', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:57登录了账号', '1', '1461211020');
INSERT INTO `iot_action_log` VALUES ('330', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:57登录了账号', '1', '1461211032');
INSERT INTO `iot_action_log` VALUES ('331', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 11:57登录了账号', '1', '1461211037');
INSERT INTO `iot_action_log` VALUES ('332', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 11:57登录了账号', '1', '1461211055');
INSERT INTO `iot_action_log` VALUES ('333', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 12:07登录了账号', '1', '1461211625');
INSERT INTO `iot_action_log` VALUES ('334', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 12:07登录了账号', '1', '1461211644');
INSERT INTO `iot_action_log` VALUES ('335', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 12:07登录了账号', '1', '1461211648');
INSERT INTO `iot_action_log` VALUES ('336', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 12:08登录了账号', '1', '1461211682');
INSERT INTO `iot_action_log` VALUES ('337', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 12:08登录了账号', '1', '1461211692');
INSERT INTO `iot_action_log` VALUES ('338', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 13:05登录了账号', '1', '1461215131');
INSERT INTO `iot_action_log` VALUES ('339', '3', '105', '3546230162', 'member', '105', '瓢虫235在2016-04-21 13:26登录了账号', '1', '1461216387');
INSERT INTO `iot_action_log` VALUES ('340', '3', '105', '3546230162', 'member', '105', '瓢虫235在2016-04-21 13:28登录了账号', '1', '1461216500');
INSERT INTO `iot_action_log` VALUES ('341', '3', '105', '3546230162', 'member', '105', '瓢虫235在2016-04-21 13:28登录了账号', '1', '1461216513');
INSERT INTO `iot_action_log` VALUES ('342', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 14:40登录了账号', '1', '1461220831');
INSERT INTO `iot_action_log` VALUES ('343', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 15:39登录了账号', '1', '1461224349');
INSERT INTO `iot_action_log` VALUES ('344', '3', '100', '3546230162', 'member', '100', 'test在2016-04-21 16:09登录了账号', '1', '1461226168');
INSERT INTO `iot_action_log` VALUES ('345', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:10登录了账号', '1', '1461226203');
INSERT INTO `iot_action_log` VALUES ('346', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:31登录了账号', '1', '1461227481');
INSERT INTO `iot_action_log` VALUES ('347', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:34登录了账号', '1', '1461227674');
INSERT INTO `iot_action_log` VALUES ('348', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:35登录了账号', '1', '1461227746');
INSERT INTO `iot_action_log` VALUES ('349', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 16:36登录了账号', '1', '1461227771');
INSERT INTO `iot_action_log` VALUES ('350', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 16:38登录了账号', '1', '1461227903');
INSERT INTO `iot_action_log` VALUES ('351', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 16:38登录了账号', '1', '1461227923');
INSERT INTO `iot_action_log` VALUES ('352', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:41登录了账号', '1', '1461228066');
INSERT INTO `iot_action_log` VALUES ('353', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:45登录了账号', '1', '1461228331');
INSERT INTO `iot_action_log` VALUES ('354', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:47登录了账号', '1', '1461228435');
INSERT INTO `iot_action_log` VALUES ('355', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:48登录了账号', '1', '1461228481');
INSERT INTO `iot_action_log` VALUES ('356', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:49登录了账号', '1', '1461228571');
INSERT INTO `iot_action_log` VALUES ('357', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:49登录了账号', '1', '1461228576');
INSERT INTO `iot_action_log` VALUES ('358', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:49登录了账号', '1', '1461228582');
INSERT INTO `iot_action_log` VALUES ('359', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:50登录了账号', '1', '1461228634');
INSERT INTO `iot_action_log` VALUES ('360', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:52登录了账号', '1', '1461228744');
INSERT INTO `iot_action_log` VALUES ('361', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:53登录了账号', '1', '1461228780');
INSERT INTO `iot_action_log` VALUES ('362', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:53登录了账号', '1', '1461228791');
INSERT INTO `iot_action_log` VALUES ('363', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:53登录了账号', '1', '1461228832');
INSERT INTO `iot_action_log` VALUES ('364', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 16:54登录了账号', '1', '1461228868');
INSERT INTO `iot_action_log` VALUES ('365', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:00登录了账号', '1', '1461229252');
INSERT INTO `iot_action_log` VALUES ('366', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:01登录了账号', '1', '1461229277');
INSERT INTO `iot_action_log` VALUES ('367', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:03登录了账号', '1', '1461229401');
INSERT INTO `iot_action_log` VALUES ('368', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:03登录了账号', '1', '1461229420');
INSERT INTO `iot_action_log` VALUES ('369', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:06登录了账号', '1', '1461229586');
INSERT INTO `iot_action_log` VALUES ('370', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:10登录了账号', '1', '1461229802');
INSERT INTO `iot_action_log` VALUES ('371', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:10登录了账号', '1', '1461229838');
INSERT INTO `iot_action_log` VALUES ('372', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:12登录了账号', '1', '1461229930');
INSERT INTO `iot_action_log` VALUES ('373', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:16登录了账号', '1', '1461230218');
INSERT INTO `iot_action_log` VALUES ('374', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:17登录了账号', '1', '1461230239');
INSERT INTO `iot_action_log` VALUES ('375', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:17登录了账号', '1', '1461230258');
INSERT INTO `iot_action_log` VALUES ('376', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:19登录了账号', '1', '1461230340');
INSERT INTO `iot_action_log` VALUES ('377', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:21登录了账号', '1', '1461230482');
INSERT INTO `iot_action_log` VALUES ('378', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:21登录了账号', '1', '1461230507');
INSERT INTO `iot_action_log` VALUES ('379', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:22登录了账号', '1', '1461230530');
INSERT INTO `iot_action_log` VALUES ('380', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:24登录了账号', '1', '1461230689');
INSERT INTO `iot_action_log` VALUES ('381', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:26登录了账号', '1', '1461230804');
INSERT INTO `iot_action_log` VALUES ('382', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:30登录了账号', '1', '1461231016');
INSERT INTO `iot_action_log` VALUES ('383', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:31登录了账号', '1', '1461231060');
INSERT INTO `iot_action_log` VALUES ('384', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:32登录了账号', '1', '1461231136');
INSERT INTO `iot_action_log` VALUES ('385', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:37登录了账号', '1', '1461231427');
INSERT INTO `iot_action_log` VALUES ('386', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:37登录了账号', '1', '1461231438');
INSERT INTO `iot_action_log` VALUES ('387', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:37登录了账号', '1', '1461231464');
INSERT INTO `iot_action_log` VALUES ('388', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:38登录了账号', '1', '1461231499');
INSERT INTO `iot_action_log` VALUES ('389', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:38登录了账号', '1', '1461231515');
INSERT INTO `iot_action_log` VALUES ('390', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:46登录了账号', '1', '1461231964');
INSERT INTO `iot_action_log` VALUES ('391', '3', '1', '1700473144', 'member', '1', 'admin在2016-04-21 17:46登录了账号', '1', '1461232017');
INSERT INTO `iot_action_log` VALUES ('392', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:50登录了账号', '1', '1461232222');
INSERT INTO `iot_action_log` VALUES ('393', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:51登录了账号', '1', '1461232269');
INSERT INTO `iot_action_log` VALUES ('394', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:52登录了账号', '1', '1461232321');
INSERT INTO `iot_action_log` VALUES ('395', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:52登录了账号', '1', '1461232372');
INSERT INTO `iot_action_log` VALUES ('396', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:54登录了账号', '1', '1461232448');
INSERT INTO `iot_action_log` VALUES ('397', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 17:58登录了账号', '1', '1461232709');
INSERT INTO `iot_action_log` VALUES ('398', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:06登录了账号', '1', '1461233204');
INSERT INTO `iot_action_log` VALUES ('399', '3', '1', '1918368506', 'member', '1', 'admin在2016-04-21 18:13登录了账号', '1', '1461233608');
INSERT INTO `iot_action_log` VALUES ('400', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:13登录了账号', '1', '1461233637');
INSERT INTO `iot_action_log` VALUES ('401', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:14登录了账号', '1', '1461233653');
INSERT INTO `iot_action_log` VALUES ('402', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:15登录了账号', '1', '1461233713');
INSERT INTO `iot_action_log` VALUES ('403', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:15登录了账号', '1', '1461233736');
INSERT INTO `iot_action_log` VALUES ('404', '3', '100', '1918368506', 'member', '100', 'test在2016-04-21 18:16登录了账号', '1', '1461233809');
INSERT INTO `iot_action_log` VALUES ('405', '3', '100', '3546230162', 'member', '100', 'test在2016-04-21 18:18登录了账号', '1', '1461233892');
INSERT INTO `iot_action_log` VALUES ('406', '3', '100', '3546230162', 'member', '100', 'test在2016-04-21 18:18登录了账号', '1', '1461233892');
INSERT INTO `iot_action_log` VALUES ('407', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:18登录了账号', '1', '1461233922');
INSERT INTO `iot_action_log` VALUES ('408', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:19登录了账号', '1', '1461233947');
INSERT INTO `iot_action_log` VALUES ('409', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:20登录了账号', '1', '1461234028');
INSERT INTO `iot_action_log` VALUES ('410', '3', '1', '1700473417', 'member', '1', 'admin在2016-04-21 18:21登录了账号', '1', '1461234104');
INSERT INTO `iot_action_log` VALUES ('411', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:24登录了账号', '1', '1461234241');
INSERT INTO `iot_action_log` VALUES ('412', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:24登录了账号', '1', '1461234284');
INSERT INTO `iot_action_log` VALUES ('413', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:25登录了账号', '1', '1461234349');
INSERT INTO `iot_action_log` VALUES ('414', '3', '1', '1700473417', 'member', '1', 'admin在2016-04-21 18:26登录了账号', '1', '1461234392');
INSERT INTO `iot_action_log` VALUES ('415', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:30登录了账号', '1', '1461234636');
INSERT INTO `iot_action_log` VALUES ('416', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:30登录了账号', '1', '1461234637');
INSERT INTO `iot_action_log` VALUES ('417', '2', '106', '3546230162', 'ucenter_member', '106', '操作url：/iotpass/api.php?s=/users/login', '1', '1461234833');
INSERT INTO `iot_action_log` VALUES ('418', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:34登录了账号', '1', '1461234849');
INSERT INTO `iot_action_log` VALUES ('419', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:34登录了账号', '1', '1461234876');
INSERT INTO `iot_action_log` VALUES ('420', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:34登录了账号', '1', '1461234892');
INSERT INTO `iot_action_log` VALUES ('421', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:35登录了账号', '1', '1461234928');
INSERT INTO `iot_action_log` VALUES ('422', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:35登录了账号', '1', '1461234939');
INSERT INTO `iot_action_log` VALUES ('423', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:35登录了账号', '1', '1461234945');
INSERT INTO `iot_action_log` VALUES ('424', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:37登录了账号', '1', '1461235033');
INSERT INTO `iot_action_log` VALUES ('425', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:38登录了账号', '1', '1461235115');
INSERT INTO `iot_action_log` VALUES ('426', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:39登录了账号', '1', '1461235151');
INSERT INTO `iot_action_log` VALUES ('427', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:39登录了账号', '1', '1461235167');
INSERT INTO `iot_action_log` VALUES ('428', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:39登录了账号', '1', '1461235169');
INSERT INTO `iot_action_log` VALUES ('429', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:40登录了账号', '1', '1461235205');
INSERT INTO `iot_action_log` VALUES ('430', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:40登录了账号', '1', '1461235232');
INSERT INTO `iot_action_log` VALUES ('431', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:40登录了账号', '1', '1461235232');
INSERT INTO `iot_action_log` VALUES ('432', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:44登录了账号', '1', '1461235492');
INSERT INTO `iot_action_log` VALUES ('433', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:45登录了账号', '1', '1461235505');
INSERT INTO `iot_action_log` VALUES ('434', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:45登录了账号', '1', '1461235506');
INSERT INTO `iot_action_log` VALUES ('435', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:47登录了账号', '1', '1461235673');
INSERT INTO `iot_action_log` VALUES ('436', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:50登录了账号', '1', '1461235828');
INSERT INTO `iot_action_log` VALUES ('437', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:50登录了账号', '1', '1461235831');
INSERT INTO `iot_action_log` VALUES ('438', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:50登录了账号', '1', '1461235855');
INSERT INTO `iot_action_log` VALUES ('439', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:52登录了账号', '1', '1461235928');
INSERT INTO `iot_action_log` VALUES ('440', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:54登录了账号', '1', '1461236048');
INSERT INTO `iot_action_log` VALUES ('441', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:54登录了账号', '1', '1461236076');
INSERT INTO `iot_action_log` VALUES ('442', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:55登录了账号', '1', '1461236134');
INSERT INTO `iot_action_log` VALUES ('443', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:58登录了账号', '1', '1461236303');
INSERT INTO `iot_action_log` VALUES ('444', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 18:58登录了账号', '1', '1461236319');
INSERT INTO `iot_action_log` VALUES ('445', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:59登录了账号', '1', '1461236342');
INSERT INTO `iot_action_log` VALUES ('446', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 18:59登录了账号', '1', '1461236343');
INSERT INTO `iot_action_log` VALUES ('447', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:02登录了账号', '1', '1461236549');
INSERT INTO `iot_action_log` VALUES ('448', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:04登录了账号', '1', '1461236676');
INSERT INTO `iot_action_log` VALUES ('449', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 19:07登录了账号', '1', '1461236848');
INSERT INTO `iot_action_log` VALUES ('450', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 19:07登录了账号', '1', '1461236870');
INSERT INTO `iot_action_log` VALUES ('451', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:15登录了账号', '1', '1461237315');
INSERT INTO `iot_action_log` VALUES ('452', '2', '106', '3546230162', 'ucenter_member', '106', '操作url：/iotpass/api.php?s=/users/login', '1', '1461237764');
INSERT INTO `iot_action_log` VALUES ('453', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:23登录了账号', '1', '1461237788');
INSERT INTO `iot_action_log` VALUES ('454', '2', '106', '3546230162', 'ucenter_member', '106', '操作url：/iotpass/api.php?s=/users/login', '1', '1461237831');
INSERT INTO `iot_action_log` VALUES ('455', '2', '106', '3546230162', 'ucenter_member', '106', '操作url：/iotpass/api.php?s=/users/login', '1', '1461237896');
INSERT INTO `iot_action_log` VALUES ('456', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:25登录了账号', '1', '1461237902');
INSERT INTO `iot_action_log` VALUES ('457', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:25登录了账号', '1', '1461237934');
INSERT INTO `iot_action_log` VALUES ('458', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:28登录了账号', '1', '1461238080');
INSERT INTO `iot_action_log` VALUES ('459', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:37登录了账号', '1', '1461238656');
INSERT INTO `iot_action_log` VALUES ('460', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:38登录了账号', '1', '1461238709');
INSERT INTO `iot_action_log` VALUES ('461', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:39登录了账号', '1', '1461238746');
INSERT INTO `iot_action_log` VALUES ('462', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:43登录了账号', '1', '1461238980');
INSERT INTO `iot_action_log` VALUES ('463', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:43登录了账号', '1', '1461239017');
INSERT INTO `iot_action_log` VALUES ('464', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-21 19:43登录了账号', '1', '1461239022');
INSERT INTO `iot_action_log` VALUES ('465', '3', '106', '3083047490', 'member', '106', 'sicon在2016-04-21 20:26登录了账号', '1', '1461241579');
INSERT INTO `iot_action_log` VALUES ('466', '3', '106', '3083047490', 'member', '106', 'sicon在2016-04-21 20:27登录了账号', '1', '1461241630');
INSERT INTO `iot_action_log` VALUES ('467', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 20:57登录了账号', '1', '1461243452');
INSERT INTO `iot_action_log` VALUES ('468', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 20:58登录了账号', '1', '1461243528');
INSERT INTO `iot_action_log` VALUES ('469', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 20:59登录了账号', '1', '1461243597');
INSERT INTO `iot_action_log` VALUES ('470', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 21:13登录了账号', '1', '1461244397');
INSERT INTO `iot_action_log` VALUES ('471', '3', '1', '1918361978', 'member', '1', 'admin在2016-04-21 21:22登录了账号', '1', '1461244968');
INSERT INTO `iot_action_log` VALUES ('472', '3', '1', '1918706815', 'member', '1', 'admin在2016-04-21 21:59登录了账号', '1', '1461247154');
INSERT INTO `iot_action_log` VALUES ('473', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-21 22:11登录了账号', '1', '1461247878');
INSERT INTO `iot_action_log` VALUES ('474', '3', '1', '1918706815', 'member', '1', 'admin在2016-04-21 22:17登录了账号', '1', '1461248248');
INSERT INTO `iot_action_log` VALUES ('475', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-22 08:59登录了账号', '1', '1461286778');
INSERT INTO `iot_action_log` VALUES ('476', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-22 10:17登录了账号', '1', '1461291432');
INSERT INTO `iot_action_log` VALUES ('477', '1', '1', '3748136431', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/loginby3rd', '1', '1461292334');
INSERT INTO `iot_action_log` VALUES ('478', '3', '108', '3748136431', 'member', '108', '瓢虫在2016-04-22 10:32登录了账号【积分：10分】', '1', '1461292334');
INSERT INTO `iot_action_log` VALUES ('479', '3', '106', '3748136431', 'member', '106', 'sicon在2016-04-22 10:32登录了账号', '1', '1461292354');
INSERT INTO `iot_action_log` VALUES ('480', '3', '1', '3546230162', 'member', '1', 'admin在2016-04-22 10:38登录了账号', '1', '1461292691');
INSERT INTO `iot_action_log` VALUES ('481', '3', '106', '3546230162', 'member', '106', 'sicon在2016-04-22 11:16登录了账号', '1', '1461294976');
INSERT INTO `iot_action_log` VALUES ('482', '3', '106', '3748136395', 'member', '106', 'sicon在2016-04-22 12:56登录了账号', '1', '1461300967');
INSERT INTO `iot_action_log` VALUES ('483', '3', '1', '1022848974', 'member', '1', 'admin在2016-04-22 13:10登录了账号', '1', '1461301822');
INSERT INTO `iot_action_log` VALUES ('484', '3', '1', '1022848974', 'member', '1', 'admin在2016-04-22 13:17登录了账号', '1', '1461302240');
INSERT INTO `iot_action_log` VALUES ('485', '3', '106', '3748136396', 'member', '106', 'sicon在2016-04-22 14:03登录了账号', '1', '1461305029');
INSERT INTO `iot_action_log` VALUES ('486', '3', '1', '3748136424', 'member', '1', 'admin在2016-04-22 14:57登录了账号', '1', '1461308223');
INSERT INTO `iot_action_log` VALUES ('487', '3', '1', '1022848977', 'member', '1', 'admin在2016-04-22 15:18登录了账号', '1', '1461309481');
INSERT INTO `iot_action_log` VALUES ('488', '3', '106', '3748136424', 'member', '106', 'sicon在2016-04-22 15:20登录了账号', '1', '1461309602');
INSERT INTO `iot_action_log` VALUES ('489', '3', '100', '1918346210', 'member', '100', 'test在2016-04-22 15:23登录了账号', '1', '1461309794');
INSERT INTO `iot_action_log` VALUES ('490', '1', '1', '3748136426', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/reg', '1', '1461314384');
INSERT INTO `iot_action_log` VALUES ('491', '3', '109', '3748136426', 'member', '109', 'chenyux在2016-04-22 16:39登录了账号【积分：10分】', '1', '1461314397');
INSERT INTO `iot_action_log` VALUES ('492', '3', '1', '1022848977', 'member', '1', 'admin在2016-04-22 16:40登录了账号', '1', '1461314400');
INSERT INTO `iot_action_log` VALUES ('493', '2', '1', '3748136426', 'ucenter_member', '1', '操作url：/iotpass/api.php?s=/users/login', '1', '1461314971');
INSERT INTO `iot_action_log` VALUES ('494', '3', '1', '3748136426', 'member', '1', 'admin在2016-04-22 16:49登录了账号', '1', '1461314979');
INSERT INTO `iot_action_log` VALUES ('495', '3', '106', '3748136424', 'member', '106', 'sicon在2016-04-22 17:12登录了账号', '1', '1461316345');
INSERT INTO `iot_action_log` VALUES ('496', '3', '1', '1022848977', 'member', '1', 'admin在2016-04-22 18:04登录了账号', '1', '1461319480');
INSERT INTO `iot_action_log` VALUES ('497', '3', '106', '1022848971', 'member', '106', 'sicon在2016-04-26 11:06登录了账号【积分：10分】', '1', '1461639976');
INSERT INTO `iot_action_log` VALUES ('498', '3', '106', '1022848971', 'member', '106', 'sicon在2016-04-26 11:35登录了账号', '1', '1461641714');
INSERT INTO `iot_action_log` VALUES ('499', '2', '106', '1022848972', 'ucenter_member', '106', '操作url：/iotpass/api.php?s=/users/login', '1', '1461642820');
INSERT INTO `iot_action_log` VALUES ('500', '3', '106', '1022848972', 'member', '106', 'sicon在2016-04-26 11:53登录了账号', '1', '1461642832');
INSERT INTO `iot_action_log` VALUES ('501', '3', '106', '1022848972', 'member', '106', 'sicon在2016-04-26 11:53登录了账号', '1', '1461642832');
INSERT INTO `iot_action_log` VALUES ('502', '3', '106', '1022848971', 'member', '106', 'sicon在2016-04-26 13:49登录了账号', '1', '1461649768');
INSERT INTO `iot_action_log` VALUES ('503', '2', '1', '1022848971', 'ucenter_member', '1', '操作url：/iotpass/index.php?s=/ucenter/member/login.html', '1', '1461810669');
INSERT INTO `iot_action_log` VALUES ('504', '3', '1', '1022848971', 'member', '1', 'admin在2016-04-28 10:31登录了账号【积分：10分】', '1', '1461810677');
INSERT INTO `iot_action_log` VALUES ('505', '3', '1', '1022848971', 'member', '1', 'admin在2016-04-28 10:31登录了账号', '1', '1461810694');
INSERT INTO `iot_action_log` VALUES ('506', '3', '1', '1022848971', 'member', '1', 'admin在2016-04-28 12:20登录了账号', '1', '1461817215');
INSERT INTO `iot_action_log` VALUES ('507', '3', '106', '3748136417', 'member', '106', 'sicon在2016-04-29 15:31登录了账号【积分：10分】', '1', '1461915110');
INSERT INTO `iot_action_log` VALUES ('508', '2', '1', '1022848970', 'ucenter_member', '1', '操作url：/iotpass/admin.php?s=/Public/login.html', '1', '1462261022');
INSERT INTO `iot_action_log` VALUES ('509', '2', '1', '1022848970', 'ucenter_member', '1', '操作url：/iotpass/admin.php?s=/Public/login.html', '1', '1462261027');
INSERT INTO `iot_action_log` VALUES ('510', '3', '1', '1022848970', 'member', '1', 'admin在2016-05-03 15:37登录了账号【积分：10分】', '1', '1462261033');
INSERT INTO `iot_action_log` VALUES ('511', '3', '1', '1780875274', 'member', '1', 'admin在2016-05-04 09:24登录了账号', '1', '1462325053');
INSERT INTO `iot_action_log` VALUES ('512', '2', '1', '1780875274', 'ucenter_member', '1', '操作url：/iotpass/admin.php?s=/Public/login.html', '1', '1462328328');
INSERT INTO `iot_action_log` VALUES ('513', '3', '1', '1780875274', 'member', '1', 'admin在2016-05-04 10:18登录了账号', '1', '1462328332');

-- -----------------------------
-- Table structure for `iot_addons`
-- -----------------------------
DROP TABLE IF EXISTS `iot_addons`;
CREATE TABLE `iot_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `iot_addons`
-- -----------------------------
INSERT INTO `iot_addons` VALUES ('7', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `iot_addons` VALUES ('8', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"6\",\"display\":\"1\"}', 'thinkphp', '0.1', '1420609113', '0');
INSERT INTO `iot_addons` VALUES ('9', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"ThinkOX\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"6\",\"display\":\"1\"}', 'thinkphp', '0.1', '1420609089', '0');
INSERT INTO `iot_addons` VALUES ('10', 'SyncLogin', '同步登陆', '同步登陆', '1', '{\"type\":null,\"meta\":\"\",\"bind\":\"0\",\"QqKEY\":\"\",\"QqSecret\":\"\",\"SinaKEY\":\"\",\"SinaSecret\":\"\"}', 'xjw129xjt', '0.1', '1406598876', '0');
INSERT INTO `iot_addons` VALUES ('11', 'LocalComment', '本地评论', '本地评论插件，不依赖社会化评论平台', '1', '{\"can_guest_comment\":\"1\"}', 'caipeichao', '0.1', '1399440324', '0');

-- -----------------------------
-- Table structure for `iot_app`
-- -----------------------------
DROP TABLE IF EXISTS `iot_app`;
CREATE TABLE `iot_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_type` varchar(64) NOT NULL,
  `business_type` varchar(64) NOT NULL,
  `app_name` varchar(64) NOT NULL,
  `app_version` varchar(32) NOT NULL,
  `app_update_comment` varchar(200) NOT NULL,
  `file_num` int(11) DEFAULT NULL,
  `file_name` varchar(64) DEFAULT NULL,
  `file_path` varchar(256) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_app`
-- -----------------------------
INSERT INTO `iot_app` VALUES ('1', 'Android', 'SmartAppliance', 'demo', '1.0', '1。0', '', '6', '', '1461810956', '1461810956', '1');
INSERT INTO `iot_app` VALUES ('2', 'Android', 'SmartAppliance', 'demo', '2.0', '2.0', '', '7', '', '1461817391', '1461817391', '1');

-- -----------------------------
-- Table structure for `iot_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `iot_attachment`;
CREATE TABLE `iot_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `iot_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `iot_auth_extend`;
CREATE TABLE `iot_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `iot_auth_extend`
-- -----------------------------
INSERT INTO `iot_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `iot_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `iot_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `iot_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `iot_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `iot_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `iot_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `iot_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `iot_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `iot_auth_group`;
CREATE TABLE `iot_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` text NOT NULL COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_auth_group`
-- -----------------------------
INSERT INTO `iot_auth_group` VALUES ('1', 'admin', '1', '普通用户', '', '1', ',433,435,436,437,438,439,1,404,406,407,408,412,413,423,424,426,427,434,440,441,443,444,445,446,447,448');
INSERT INTO `iot_auth_group` VALUES ('2', 'admin', '1', 'VIP', '', '1', '');

-- -----------------------------
-- Table structure for `iot_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `iot_auth_group_access`;
CREATE TABLE `iot_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_auth_group_access`
-- -----------------------------
INSERT INTO `iot_auth_group_access` VALUES ('1', '1');
INSERT INTO `iot_auth_group_access` VALUES ('100', '1');
INSERT INTO `iot_auth_group_access` VALUES ('101', '1');

-- -----------------------------
-- Table structure for `iot_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `iot_auth_rule`;
CREATE TABLE `iot_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=450 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_auth_rule`
-- -----------------------------
INSERT INTO `iot_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/mydocument', '资讯', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '插件', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('17', 'admin', '1', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('217', 'admin', '1', 'Admin/Forum/forum', '板块管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('218', 'admin', '1', 'Admin/Forum/post', '帖子管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('219', 'admin', '1', 'Admin/Forum/editForum', '编辑／发表帖子', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('220', 'admin', '1', 'Admin/Forum/editPost', 'edit pots', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('221', 'admin', '2', 'Admin//Admin/Forum/index', '讨论区', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('222', 'admin', '2', 'Admin//Admin/Weibo/index', '微博', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('223', 'admin', '1', 'Admin/Forum/sortForum', '排序', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('224', 'admin', '1', 'Admin/SEO/editRule', '新增、编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('225', 'admin', '1', 'Admin/SEO/sortRule', '排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('226', 'admin', '1', 'Admin/SEO/index', 'SEO规则管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('227', 'admin', '1', 'Admin/Forum/editReply', '新增 编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('228', 'admin', '1', 'Admin/Weibo/editComment', '编辑回复', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('229', 'admin', '1', 'Admin/Weibo/editWeibo', '编辑微博', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('230', 'admin', '1', 'Admin/SEO/ruleTrash', 'SEO规则回收站', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('231', 'admin', '1', 'Admin/Rank/userList', '查看用户', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('232', 'admin', '1', 'Admin/Rank/userRankList', '用户头衔列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('233', 'admin', '1', 'Admin/Rank/userAddRank', '关联新头衔', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('234', 'admin', '1', 'Admin/Rank/userChangeRank', '编辑头衔关联', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('235', 'admin', '1', 'Admin/Issue/add', '编辑专辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('236', 'admin', '1', 'Admin/Issue/issue', '专辑管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('237', 'admin', '1', 'Admin/Issue/operate', '专辑操作', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('238', 'admin', '1', 'Admin/Weibo/weibo', '微博管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('239', 'admin', '1', 'Admin/Rank/index', '头衔列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('240', 'admin', '1', 'Admin/Forum/forumTrash', '板块回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('241', 'admin', '1', 'Admin/Weibo/weiboTrash', '微博回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('242', 'admin', '1', 'Admin/Rank/editRank', '添加头衔', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('243', 'admin', '1', 'Admin/Weibo/comment', '回复管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('244', 'admin', '1', 'Admin/Forum/postTrash', '帖子回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('245', 'admin', '1', 'Admin/Weibo/commentTrash', '回复回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('246', 'admin', '1', 'Admin/Issue/issueTrash', '专辑回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('247', 'admin', '1', 'Admin//Admin/Forum/reply', '回复管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('248', 'admin', '1', 'Admin/Forum/replyTrash', '回复回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('249', 'admin', '2', 'Admin/Forum/index', '贴吧', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('250', 'admin', '2', 'Admin/Weibo/weibo', '微博', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('251', 'admin', '2', 'Admin/SEO/index', 'SEO', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('252', 'admin', '2', 'Admin/Rank/index', '头衔', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('253', 'admin', '2', 'Admin/Issue/issue', '专辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('254', 'admin', '1', 'Admin/Issue/contents', '内容管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('255', 'admin', '1', 'Admin/User/profile', '扩展资料', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('256', 'admin', '1', 'Admin/User/editProfile', '添加、编辑分组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('257', 'admin', '1', 'Admin/User/sortProfile', '分组排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('258', 'admin', '1', 'Admin/User/field', '字段列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('259', 'admin', '1', 'Admin/User/editFieldSetting', '添加、编辑字段', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('260', 'admin', '1', 'Admin/User/sortField', '字段排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('261', 'admin', '1', 'Admin/Update/quick', '全部补丁', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('262', 'admin', '1', 'Admin/Update/addpack', '新增补丁', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('263', 'admin', '1', 'Admin/User/expandinfo_select', '用户扩展资料列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('264', 'admin', '1', 'Admin/User/expandinfo_details', '扩展资料详情', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('265', 'admin', '1', 'Admin/Shop/shopLog', '商城信息记录', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('266', 'admin', '1', 'Admin/Shop/setStatus', '商品分类状态设置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('267', 'admin', '1', 'Admin/Shop/setGoodsStatus', '商品状态设置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('268', 'admin', '1', 'Admin/Shop/operate', '商品分类操作', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('269', 'admin', '1', 'Admin/Shop/add', '商品分类添加', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('270', 'admin', '1', 'Admin/Shop/goodsEdit', '添加、编辑商品', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('271', 'admin', '1', 'Admin/Shop/hotSellConfig', '热销商品阀值配置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('272', 'admin', '1', 'Admin/Shop/setNew', '设置新品', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('273', 'admin', '1', 'Admin/EventType/index', '活动分类管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('274', 'admin', '1', 'Admin/Event/event', '内容管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('275', 'admin', '1', 'Admin/EventType/eventTypeTrash', '活动分类回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('276', 'admin', '1', 'Admin/Event/verify', '内容审核', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('277', 'admin', '1', 'Admin/Event/contentTrash', '内容回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('278', 'admin', '1', 'Admin/Rank/rankVerify', '待审核用户头衔', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('279', 'admin', '1', 'Admin/Rank/rankVerifyFailure', '被驳回的头衔申请', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('280', 'admin', '1', 'Admin/Weibo/config', '微博设置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('281', 'admin', '1', 'Admin/Issue/verify', '内容审核', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('282', 'admin', '1', 'Admin/Shop/goodsList', '商品列表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('283', 'admin', '1', 'Admin/Shop/shopCategory', '商品分类配置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('284', 'admin', '1', 'Admin/Shop/categoryTrash', '商品分类回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('285', 'admin', '1', 'Admin/Shop/verify', '待发货交易', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('286', 'admin', '1', 'Admin/Issue/contentTrash', '内容回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('287', 'admin', '1', 'Admin/Shop/goodsBuySuccess', '交易成功记录', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('288', 'admin', '1', 'Admin/Shop/goodsTrash', '商品回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('289', 'admin', '1', 'Admin/Shop/toxMoneyConfig', '货币配置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('290', 'admin', '2', 'Admin/Shop/shopCategory', '商城', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('291', 'admin', '2', 'Admin/EventType/index', '活动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('337', 'Weibo', '1', 'manageTopic', '管理话题', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('297', 'Home', '1', 'deleteLocalComment', '删除本地评论', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('342', 'admin', '1', 'Admin/user/editScoreType', '新增/编辑类型', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('341', 'admin', '1', 'Admin/User/scoreList', '积分类型列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('336', 'Weibo', '1', 'beTopicAdmin', '抢先成为话题主持人', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('335', 'Weibo', '1', 'setWeiboTop', '微博置顶', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('334', 'Weibo', '1', 'deleteWeibo', '删除微博', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('333', 'Weibo', '1', 'sendWeibo', '发微博', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('313', 'admin', '1', 'Admin/module/install', '模块安装', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('315', 'admin', '1', 'Admin/module/lists', '模块管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('316', 'admin', '1', 'Admin/module/uninstall', '卸载模块', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('317', 'admin', '1', 'Admin/AuthManager/addNode', '新增权限节点', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('318', 'admin', '1', 'Admin/AuthManager/accessUser', '前台权限管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('319', 'admin', '1', 'Admin/User/changeGroup', '转移用户组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('320', 'admin', '1', 'Admin/AuthManager/deleteNode', '删除权限节点', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('321', 'admin', '1', 'Admin/Issue/config', '专辑设置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('322', 'admin', '2', 'Admin/module/lists', '云市场', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('340', 'admin', '1', 'Admin/UserConfig/index', '用户注册配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('343', 'admin', '1', 'Admin/user/recharge', '充值积分', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('344', 'admin', '1', 'Admin/Authorize/ssoSetting', '单点登录配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('345', 'admin', '1', 'Admin/Authorize/ssolist', '应用列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('346', 'admin', '1', 'Admin/authorize/editssoapp', '新增/编辑应用', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('347', 'admin', '1', 'Admin/ActionLimit/limitList', '行为限制列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('348', 'admin', '1', 'Admin/ActionLimit/editLimit', '新增/编辑行为限制', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('349', 'admin', '1', 'Admin/Role/index', '角色列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('350', 'admin', '1', 'Admin/Role/editRole', '编辑角色', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('351', 'admin', '1', 'Admin/Role/setStatus', '启用、禁用、删除角色', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('352', 'admin', '1', 'Admin/Role/sort', '角色排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('353', 'admin', '1', 'Admin/Role/configScore', '默认积分配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('354', 'admin', '1', 'Admin/Role/configAuth', '默认权限配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('355', 'admin', '1', 'Admin/Role/configAvatar', '默认头像配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('356', 'admin', '1', 'Admin/Role/configRank', '默认头衔配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('357', 'admin', '1', 'Admin/Role/configField', '默认字段管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('358', 'admin', '1', 'Admin/Role/group', '角色分组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('359', 'admin', '1', 'Admin/Role/editGroup', '编辑分组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('360', 'admin', '1', 'Admin/Role/deleteGroup', '删除分组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('361', 'admin', '1', 'Admin/Role/config', '角色基本信息配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('362', 'admin', '1', 'Admin/Role/userList', '用户列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('363', 'admin', '1', 'Admin/Role/setUserStatus', '设置用户状态', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('364', 'admin', '1', 'Admin/Role/setUserAudit', '审核用户', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('365', 'admin', '1', 'Admin/Role/changeRole', '迁移用户', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('366', 'admin', '1', 'Admin/Role/uploadPicture', '上传默认头像', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('367', 'admin', '1', 'Admin/Invite/index', '类型管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('368', 'admin', '1', 'Admin/Invite/invite', '邀请码管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('369', 'admin', '1', 'Admin/Invite/config', '基础配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('370', 'admin', '1', 'Admin/Invite/buyLog', '兑换记录', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('371', 'admin', '1', 'Admin/Invite/inviteLog', '邀请记录', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('372', 'admin', '1', 'Admin/Invite/userInfo', '用户信息', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('373', 'admin', '1', 'Admin/Invite/edit', '编辑邀请注册类型', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('374', 'admin', '1', 'Admin/Invite/setStatus', '删除邀请', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('375', 'admin', '1', 'Admin/Invite/delete', '删除邀请码', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('376', 'admin', '1', 'Admin/Invite/createCode', '生成邀请码', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('377', 'admin', '1', 'Admin/Invite/deleteTrue', '删除无用邀请码', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('378', 'admin', '1', 'Admin/Invite/cvs', '导出cvs', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('379', 'admin', '1', 'Admin/Invite/editUserInfo', '用户信息编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('380', 'admin', '1', 'Admin/Action/remove', '删除日志', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('381', 'admin', '1', 'Admin/Action/clear', '清空日志', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('382', 'admin', '1', 'Admin/User/setTypeStatus', '设置积分状态', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('383', 'admin', '1', 'Admin/User/delType', '删除积分类型', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('384', 'admin', '1', 'Admin/User/getNickname', '充值积分', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('385', 'admin', '1', 'Admin/Menu/del', '删除菜单', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('386', 'admin', '1', 'Admin/Menu/toogleDev', '设置开发者模式可见', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('387', 'admin', '1', 'Admin/Menu/toogleHide', '设置显示隐藏', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('388', 'admin', '1', 'Admin/ActionLimit/setLimitStatus', '行为限制启用、禁用、删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('389', 'admin', '1', 'Admin/SEO/setRuleStatus', '启用、禁用、删除、回收站还原', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('390', 'admin', '1', 'Admin/SEO/doClear', '回收站彻底删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('391', 'admin', '1', 'Admin/Role/initUnhaveUser', '初始化无角色用户', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('392', 'admin', '1', 'Admin/Addons/delHook', '删除钩子', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('393', 'admin', '1', 'Admin/Update/usePack', '使用补丁', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('394', 'admin', '1', 'Admin/Update/view', '查看补丁', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('395', 'admin', '1', 'Admin/Update/delPack', '删除补丁', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('396', 'admin', '1', 'Admin/UserTag/userTag', '标签列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('397', 'admin', '1', 'Admin/UserTag/add', '添加分类、标签', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('398', 'admin', '1', 'Admin/UserTag/setStatus', '设置分类、标签状态', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('399', 'admin', '1', 'Admin/UserTag/tagTrash', '分类、标签回收站', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('400', 'admin', '1', 'Admin/UserTag/userTagClear', '测底删除回收站内容', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('401', 'admin', '1', 'Admin/role/configusertag', '可拥有标签配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('402', 'admin', '1', 'Admin/Module/edit', '编辑模块', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('403', 'admin', '1', 'Admin/Config/website', '网站信息', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('404', 'admin', '1', 'Admin/Product/wizard', '产品导航', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('405', 'admin', '1', 'Admin/Device/index', '总体视图', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('406', 'admin', '1', 'Admin/Product/index', '产品管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('407', 'admin', '1', 'Admin/Product/addProduct', '产品添加修改', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('408', 'admin', '1', 'Admin/Product/listMetadata', '产品元数据列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('409', 'admin', '1', 'Admin/Device/list', '设备管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('410', 'admin', '2', 'Admin/authorize/ssoSetting', '授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('411', 'admin', '2', 'Admin/Role/index', '角色', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('412', 'admin', '1', 'Admin/Product/categories', '产品分类', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('413', 'admin', '1', 'Admin/Product/addCategories', '产品分类编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('414', 'admin', '2', 'Admin/ActionLimit/limitList', '安全', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('415', 'admin', '1', 'Admin/Metadata/index', '所有', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('416', 'admin', '1', 'Admin/DeviceOperation/index', '操作日志', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('417', 'admin', '1', 'Admin//Admin/Metadata/index/md_type/1', '功能类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('418', 'admin', '1', 'Admin//Admin/Metadata/edit', '添加传感类元素据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('419', 'admin', '1', 'Admin/DeviceData/index', '数据日志', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('420', 'admin', '1', 'Admin//Admin/Metadata/index/md_type/2', '传感类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('421', 'admin', '1', 'Admin//Admin/Metadata/index/md_type/3', '状态类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('422', 'admin', '1', 'Admin//Admin/Metadata/index/md_type/4', '异常类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('423', 'admin', '1', 'Admin/Product/listConnectModule', '联网模组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('424', 'admin', '1', 'Admin/Product/addConnectModule', '模组添加修改', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('425', 'admin', '1', 'Admin/DeviceMac/index', 'MAC维护', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('426', 'admin', '1', 'Admin/Product/listFirmware', '固件维护', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('427', 'admin', '1', 'Admin/Product/addFirmware', '固件添加修改', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('428', 'admin', '1', 'Admin/DeviceOwner/index', '授权维护', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('429', 'admin', '1', 'Admin/DeviceReport/activities', '活跃数统计', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('430', 'admin', '1', 'Admin/DeviceReport/index', 'XXX统计', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('431', 'admin', '2', 'Admin/Metadata/metadata', '硬件元数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('432', 'admin', '2', 'Admin/Device/index', '设备监控', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('433', 'admin', '2', 'Admin/Product/product', '智能硬件', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('434', 'admin', '1', 'Admin/Product/metadatas', '所有元数据', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('435', 'admin', '1', 'Admin//Admin/Product/metadatas/md_type/1', '功能类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('436', 'admin', '1', 'Admin//Admin/Product/metadatas/md_type/2', '传感类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('437', 'admin', '1', 'Admin//Admin/Product/metadatas/md_type/3', '状态类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('438', 'admin', '1', 'Admin//Admin/Product/metadatas/md_type/4', '异常类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('439', 'admin', '1', 'Admin//Admin/Product/editMetadata', '编辑传感类元素据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('440', 'admin', '1', 'Admin/Product/listLogConfig', '日志配置列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('441', 'admin', '1', 'Admin/Product/addLogConfig', '日志配置修改', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('442', 'admin', '1', 'Admin/User/addNewAdmin', '新增管理员', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('443', 'admin', '2', 'Admin/Product/index', '智能硬件', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('444', 'admin', '1', 'Admin//Product/metadatas/md_type/1', '功能类', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('445', 'admin', '1', 'Admin//Product/metadatas/md_type/2', '传感类', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('446', 'admin', '1', 'Admin//Product/metadatas/md_type/3', '状态类', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('447', 'admin', '1', 'Admin//Product/metadatas/md_type/4', '异常类', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('448', 'admin', '1', 'Admin/Product/editMetadata', '编辑传感类元素据', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('449', 'admin', '1', 'Admin/OpenAPI/apiList', '接口管理', '1', '');

-- -----------------------------
-- Table structure for `iot_avatar`
-- -----------------------------
DROP TABLE IF EXISTS `iot_avatar`;
CREATE TABLE `iot_avatar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `path` varchar(200) NOT NULL,
  `create_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `is_temp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_channel`
-- -----------------------------
DROP TABLE IF EXISTS `iot_channel`;
CREATE TABLE `iot_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  `color` varchar(30) NOT NULL,
  `band_color` varchar(30) NOT NULL,
  `band_text` varchar(30) NOT NULL,
  `icon` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_channel`
-- -----------------------------
INSERT INTO `iot_channel` VALUES ('1', '0', '首页', 'Home/Index/index', '1', '0', '0', '1', '0', '#000000', '#000000', '', 'home');

-- -----------------------------
-- Table structure for `iot_config`
-- -----------------------------
DROP TABLE IF EXISTS `iot_config`;
CREATE TABLE `iot_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_config`
-- -----------------------------
INSERT INTO `iot_config` VALUES ('1', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `iot_config` VALUES ('2', 'SITE_LOGO', '7', '网站LOGO', '1', '', '网站的logo设置，建议尺寸156*50', '1388332311', '1388501500', '1', '', '3');
INSERT INTO `iot_config` VALUES ('3', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举\r\n8:多选框', '8');
INSERT INTO `iot_config` VALUES ('4', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '沪CP备XX号', '12');
INSERT INTO `iot_config` VALUES ('5', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1450669835', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统\r\n5:邮件\r\n6:物联网', '15');
INSERT INTO `iot_config` VALUES ('6', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '17');
INSERT INTO `iot_config` VALUES ('7', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '20');
INSERT INTO `iot_config` VALUES ('9', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '24');
INSERT INTO `iot_config` VALUES ('11', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '13');
INSERT INTO `iot_config` VALUES ('12', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '16');
INSERT INTO `iot_config` VALUES ('13', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '18');
INSERT INTO `iot_config` VALUES ('14', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '22');
INSERT INTO `iot_config` VALUES ('15', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '25');
INSERT INTO `iot_config` VALUES ('16', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '26');
INSERT INTO `iot_config` VALUES ('17', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '2');
INSERT INTO `iot_config` VALUES ('18', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '3');
INSERT INTO `iot_config` VALUES ('19', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '27');
INSERT INTO `iot_config` VALUES ('20', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1450097812', '1', '1', '7');
INSERT INTO `iot_config` VALUES ('21', 'WEB_SITE', '1', '网站名称', '1', '', '用于邮件,短信,站内信显示', '1388332311', '1388501500', '1', '', '3');
INSERT INTO `iot_config` VALUES ('22', 'MAIL_TYPE', '4', '邮件类型', '5', '1:SMTP 模块发送\r\n2:mail() 函数发送', '如果您选择了采用服务器内置的 Mail 服务，您不需要填写下面的内容', '1388332882', '1388931416', '1', '1', '0');
INSERT INTO `iot_config` VALUES ('23', 'MAIL_SMTP_HOST', '1', 'SMTP 服务器', '5', '', 'SMTP服务器', '1388332932', '1388332932', '1', '', '0');
INSERT INTO `iot_config` VALUES ('24', 'MAIL_SMTP_PORT', '0', 'SMTP服务器端口', '5', '', '默认25', '1388332975', '1388332975', '1', '25', '0');
INSERT INTO `iot_config` VALUES ('25', 'MAIL_SMTP_USER', '1', 'SMTP服务器用户名', '5', '', '填写完整用户名', '1388333010', '1388333010', '1', '', '0');
INSERT INTO `iot_config` VALUES ('26', 'MAIL_SMTP_PASS', '6', 'SMTP服务器密码', '5', '', '填写您的密码', '1388333057', '1389187088', '1', '', '0');
INSERT INTO `iot_config` VALUES ('27', 'MAIL_USER_PASS', '5', '密码找回模板', '0', '', '支持HTML代码', '1388583989', '1388672614', '1', '密码找回111223333555111', '0');
INSERT INTO `iot_config` VALUES ('28', 'PIC_FILE_PATH', '1', '图片文件保存根目录', '4', '', '图片文件保存根目录./目录/', '1388673255', '1388673255', '1', './Uploads/', '0');
INSERT INTO `iot_config` VALUES ('29', 'COUNT_DAY', '0', '后台首页统计用户增长天数', '0', '', '默认统计最近半个月的用户数增长情况', '1420791945', '1420876261', '1', '15', '0');
INSERT INTO `iot_config` VALUES ('30', 'MAIL_USER_REG', '5', '注册邮件模板', '3', '', '支持HTML代码', '1388337307', '1389532335', '1', '<a href=\"http://3spp.cn\" target=\"_blank\">点击进入</a><span style=\"color:#E53333;\">当您收到这封邮件，表明您已注册成功，以上为您的用户名和密码。。。。祝您生活愉快····</span>', '55');
INSERT INTO `iot_config` VALUES ('31', 'USER_NAME_BAOLIU', '1', '保留用户名', '3', '', '禁止注册用户名,用\" , \"号隔开', '1388845937', '1388845937', '1', '管理员,测试,admin,垃圾', '0');
INSERT INTO `iot_config` VALUES ('33', 'VERIFY_OPEN', '8', '验证码配置', '4', 'reg:注册显示\r\nlogin:登陆显示\r\nreset:找回密码', '验证码配置', '1388500332', '1405561711', '1', '', '0');
INSERT INTO `iot_config` VALUES ('34', 'VERIFY_TYPE', '4', '验证码类型', '4', '1:中文\r\n2:英文\r\n3:数字\r\n4:英文+数字', '验证码类型', '1388500873', '1405561731', '1', '4', '0');
INSERT INTO `iot_config` VALUES ('35', 'NO_BODY_TLE', '2', '空白说明', '2', '', '空白说明', '1392216444', '1392981305', '1', '呵呵，暂时没有内容哦！！', '0');
INSERT INTO `iot_config` VALUES ('36', 'USER_RESPASS', '5', '密码找回模板', '3', '', '密码找回文本', '1396191234', '1396191234', '1', '<span style=\"color:#009900;\">请点击以下链接找回密码，如无反应，请将链接地址复制到浏览器中打开(下次登录前有效)</span>', '0');
INSERT INTO `iot_config` VALUES ('37', 'COUNT_CODE', '2', '统计代码', '1', '', '用于统计网站访问量的第三方代码，推荐CNZZ统计', '1403058890', '1403058890', '1', '', '4');
INSERT INTO `iot_config` VALUES ('38', 'AFTER_LOGIN_JUMP_URL', '2', '登陆后跳转的Url', '1', '', '支持形如weibo/index/index的ThinkPhp路由写法，支持普通的url写法', '1407145718', '1407154887', '1', 'Home/index/index', '7');
INSERT INTO `iot_config` VALUES ('40', 'URL_MODEL', '4', 'URL模式', '4', '1:PATHINFO模式\r\n2:REWRITE模式(开启伪静态)\r\n3:兼容模式', '选择Rewrite模式则开启伪静态，默认建议开启兼容模式', '1421027546', '1421027676', '1', '3', '0');
INSERT INTO `iot_config` VALUES ('41', 'DEFUALT_HOME_URL', '1', '默认首页Url', '1', '', '支持形如weibo/index/index的ThinkPhp路由写法，支持普通的url写法，不填则显示默认聚合首页', '1417509438', '1417509501', '1', '', '0');
INSERT INTO `iot_config` VALUES ('60', '_USERCONFIG_REG_SWITCH', '0', '', '0', '', '', '1450419564', '1450419564', '1', 'username', '0');
INSERT INTO `iot_config` VALUES ('74', 'MD_SCOPE', '3', '作用域', '6', '', '元素据作用域范围', '1379228036', '1384418383', '1', '1:公共型\r\n2:私有型 ', '53');
INSERT INTO `iot_config` VALUES ('72', 'MD_TYPE', '3', '元素据类型', '6', '', '元素据分类', '1379228036', '1384418383', '1', '1:功能\r\n2:传感\r\n3:状态\r\n4:错误', '51');
INSERT INTO `iot_config` VALUES ('73', 'MD_VALUE_TYPE', '3', '值类型', '6', '', '元素据值类型', '1379228036', '1384418383', '1', '0:N/A\r\n1:数值型\r\n2:字符型\r\n3:枚举型 ', '52');
INSERT INTO `iot_config` VALUES ('46', 'PARSER_TYPE', '3', '解析类别', '6', '', '针对该元数据的解析方式', '1379228036', '1384418383', '1', '1:16进制数值信号\r\n2:JSON文本\r\n3:流媒体', '61');
INSERT INTO `iot_config` VALUES ('47', 'PART_TYPE', '3', '片段类型', '6', '', '解析中定义的数据片段', '1379228036', '1450234484', '1', 'head:帧头\r\ncommand:命令域\r\nlength:内容长\r\ncontent:内容域\r\ntail:帧尾\r\nchksum:校验值', '62');
INSERT INTO `iot_config` VALUES ('48', 'MODULE_TYPE', '3', '模组分类', '6', '', '联网模组的分类', '1379228036', '1384418383', '1', '1:WIFI模组\r\n2:蓝牙模组\r\n3:SIM卡\r\n4:ZIGBEE', '63');
INSERT INTO `iot_config` VALUES ('61', '_USERCONFIG_EMAIL_VERIFY_TYPE', '0', '', '0', '', '', '1450419564', '1450419564', '1', '1', '0');
INSERT INTO `iot_config` VALUES ('62', '_USERCONFIG_MOBILE_VERIFY_TYPE', '0', '', '0', '', '', '1450419564', '1450419564', '1', '0', '0');
INSERT INTO `iot_config` VALUES ('63', '_USERCONFIG_REG_STEP', '0', '', '0', '', '', '1450419564', '1450419564', '1', '[{\"data-id\":\"disable\",\"title\":\"\\u7981\\u7528\",\"items\":[{\"data-id\":\"change_avatar\",\"title\":\"\\u4fee\\u6539\\u5934\\u50cf\"},{\"data-id\":\"expand_info\",\"title\":\"\\u586b\\u5199\\u6269\\u5c55\\u8d44\\u6599\"}]},{\"data-id\":\"enable\",\"title\":\"\\u542f\\u7528\",\"items\":[]}]', '0');
INSERT INTO `iot_config` VALUES ('64', '_USERCONFIG_REG_CAN_SKIP', '0', '', '0', '', '', '1450419564', '1450419564', '1', '', '0');
INSERT INTO `iot_config` VALUES ('65', '_USERCONFIG_OPEN_QUICK_LOGIN', '0', '', '0', '', '', '1450419564', '1450419564', '1', '0', '0');
INSERT INTO `iot_config` VALUES ('66', '_USERCONFIG_SMS_HTTP', '0', '', '0', '', '', '1450419564', '1450419564', '1', '', '0');
INSERT INTO `iot_config` VALUES ('67', '_USERCONFIG_SMS_UID', '0', '', '0', '', '', '1450419564', '1450419564', '1', '', '0');
INSERT INTO `iot_config` VALUES ('68', '_USERCONFIG_SMS_PWD', '0', '', '0', '', '', '1450419564', '1450419564', '1', '', '0');
INSERT INTO `iot_config` VALUES ('69', '_USERCONFIG_SMS_CONTENT', '0', '', '0', '', '', '1450419564', '1450419564', '1', '', '0');
INSERT INTO `iot_config` VALUES ('70', '_USERCONFIG_LEVEL', '0', '', '0', '', '', '1450419564', '1450419564', '1', '0:Lv1 实习\r\n50:Lv2 试用\r\n100:Lv3 转正\r\n200:Lv4 助理\r\n400:Lv 5 经理\r\n800:Lv6 董事\r\n1600:Lv7 董事长', '0');
INSERT INTO `iot_config` VALUES ('71', '_INVITE_REGISTER_TYPE', '0', '', '0', '', '', '1450422564', '1450422564', '1', 'normal,invite', '0');
INSERT INTO `iot_config` VALUES ('75', 'LOG_CONDITION_TYPE', '3', '日志记录类型', '6', '', '日志记录类型', '1379228036', '1384418383', '1', '1:直接记录\r\n2:变化超过阀值记录', '64');
INSERT INTO `iot_config` VALUES ('76', 'API_ERROR_MSG', '3', '值类型', '6', '', '接口返回错误', '1379228036', '1384418383', '1', 'PASSWORD_ERR_ENCRIPT:密码加密错误,\r\nSYSTEM_ERROR:系统错误', '52');
INSERT INTO `iot_config` VALUES ('82', 'BUSINESS_TYPE', '3', 'business_type', '0', '', '', '1452050491', '1452050727', '1', 'SmartAppliance:SmartAppliance\r\nChargingPiles:ChargingPiles\r\nBracelet:Bracelet', '0');
INSERT INTO `iot_config` VALUES ('81', 'APP_TYPE', '3', 'app_type', '0', '', '', '1452050455', '1452050455', '1', 'Android:Android\r\nIos:Ios', '0');
INSERT INTO `iot_config` VALUES ('83', 'DEVICE_STATUS', '3', '设备状态', '6', '', '设备的生命状态', '1379228036', '1384418383', '1', '1:初始化\r\n2:激活\r\n3:绑定', '61');
INSERT INTO `iot_config` VALUES ('84', 'ONLINE_STATUS', '3', '在线状态', '6', '', '设备的在线状态', '1379228036', '1384418383', '1', '0:不在线\r\n1:在线', '62');
INSERT INTO `iot_config` VALUES ('85', 'DEVICE_USRE_TYPE', '3', '用户设备关系', '6', '', '用户相对设备的权限类型', '1379228036', '1384418383', '1', '1:设备管理者\r\n2:设备所有者\r\n3:设备使用者\r\n4:没有关系', '63');
INSERT INTO `iot_config` VALUES ('86', 'OTA_STATUS', '3', 'OTA状态', '6', '', 'OTA的升级状态', '1379228036', '1384418383', '1', '1:开始下载\r\n2:设备端开始下载\r\n3:设备端下载完成\r\n4:设备端升级完成', '63');
INSERT INTO `iot_config` VALUES ('87', 'ENGINE_TYPE', '3', '智能引擎类型', '6', '', '智能引擎类型', '1379228036', '1384418383', '1', '1:情景模式\r\n2:设备互联\r\n3:音乐识别\r\n4:安全预警', '65');
INSERT INTO `iot_config` VALUES ('88', 'DEMO_HOST', '1', 'DEMO用接入服务', '6', '120.27.4.46', '', '1461062978', '1461202747', '1', '120.27.4.46', '0');
INSERT INTO `iot_config` VALUES ('89', 'DEFAULT_INBOUND_HOST', '1', '默认MQTT的接入Server', '6', '', '', '1461203003', '1461203003', '1', '115.29.41.218', '100');
INSERT INTO `iot_config` VALUES ('90', 'DEFAULT_INBOUND_PORT', '1', '默认MQTT接入用的端口', '6', '', '', '1461203036', '1461203036', '1', '1883', '101');

-- -----------------------------
-- Table structure for `iot_connect_module`
-- -----------------------------
DROP TABLE IF EXISTS `iot_connect_module`;
CREATE TABLE `iot_connect_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_type` tinyint(4) NOT NULL,
  `module_name` varchar(64) DEFAULT NULL,
  `vendor_name` varchar(64) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_connect_module`
-- -----------------------------
INSERT INTO `iot_connect_module` VALUES ('15', '1', 'ESP8266', '乐鑫', '1450150559', '1450150559', '1');
INSERT INTO `iot_connect_module` VALUES ('16', '1', 'EMW3238', '庆科', '1450675742', '1450675742', '1');

-- -----------------------------
-- Table structure for `iot_device`
-- -----------------------------
DROP TABLE IF EXISTS `iot_device`;
CREATE TABLE `iot_device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `device_sn` varchar(32) DEFAULT NULL,
  `device_mac` varchar(32) DEFAULT NULL,
  `device_name` varchar(32) DEFAULT NULL,
  `device_reg_uid` int(11) DEFAULT NULL,
  `device_reg_addr` text,
  `device_reg_flg` int(11) DEFAULT NULL,
  `device_addr` text,
  `device_ip_addr` text,
  `device_status` tinyint(4) NOT NULL,
  `online_status` tinyint(4) NOT NULL,
  `device_firmware_ver` varchar(32) DEFAULT NULL,
  `device_firmware_updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_device`
-- -----------------------------
INSERT INTO `iot_device` VALUES ('21', '11', '18FE3497EC7C', '18FE3497EC7C', '温湿度传感器', '', '', '', '', '', '3', '0', '', '2016-04-22 11:26:21', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('20', '9', '18FE34A107FA', '18FE34A107FA', '客厅灯07FA', '', '', '', '', '', '3', '0', '', '2016-04-22 11:52:30', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('17', '10', '18FE349D82A3', '18FE349D82A3', '手机充电插座', '', '', '', '', '', '2', '0', '', '2016-04-21 10:36:30', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('16', '9', '18FE34ED8823', '18FE34ED8823', '客厅灯', '', '', '', '', '', '2', '0', '', '2016-04-21 09:46:19', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('19', '9', '18FE349EC5AB', '18FE349EC5AB', '18FE349EC5AB', '', '', '', '', '', '1', '0', '', '2016-04-20 15:33:02', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('18', '9', '18FE34980402', '18FE34980402', '18FE34980402', '', '', '', '', '', '2', '0', '', '2016-04-19 21:05:01', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('22', '12', '18FE34FA026D', '18FE34FA026D', '智能按钮', '', '', '', '', '', '3', '0', '', '2016-04-22 11:54:24', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('23', '9', '18FE34A1090C', '18FE34A1090C', '主卧灯090C', '', '', '', '', '', '3', '0', '', '2016-04-22 11:19:15', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('24', '9', '18FE34A108A0', '18FE34A108A0', '餐厅灯08A0', '', '', '', '', '', '3', '0', '', '2016-04-22 10:48:56', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('25', '10', '18FE34F6715D', '18FE34F6715D', '18FE34F6715D', '', '', '', '', '', '3', '0', '', '2016-04-22 11:10:32', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('26', '9', '18FE34A1065B', '18FE34A1065B', '单独控制1065B', '', '', '', '', '', '3', '0', '', '2016-04-22 16:56:03', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('27', '9', '18FE34A02543', '18FE34A02543', '18FE34A02543', '', '', '', '', '', '2', '0', '', '2016-04-22 11:38:00', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('28', '9', '18FE34A107E3', '18FE34A107E3', '18FE34A107E3', '', '', '', '', '', '2', '0', '', '2016-04-22 11:42:44', '0000-00-00 00:00:00');
INSERT INTO `iot_device` VALUES ('29', '9', '18FE349EC967', '18FE349EC967', '18FE349EC967', '', '', '', '', '', '2', '0', '', '2016-04-22 11:46:31', '0000-00-00 00:00:00');

-- -----------------------------
-- Table structure for `iot_device_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_device_log`;
CREATE TABLE `iot_device_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `md_code` varchar(32) DEFAULT NULL,
  `md_type` int(11) DEFAULT NULL,
  `log_value` varchar(30) DEFAULT NULL,
  `log_display_txt` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6129 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_device_log`
-- -----------------------------
INSERT INTO `iot_device_log` VALUES ('1923', '21', 'TEMPERATURE', '2', '45.53', '45.53', '1', '2016-04-21 13:28:02');
INSERT INTO `iot_device_log` VALUES ('1924', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-21 13:28:02');
INSERT INTO `iot_device_log` VALUES ('1925', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 13:28:12');
INSERT INTO `iot_device_log` VALUES ('1926', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-21 13:28:12');
INSERT INTO `iot_device_log` VALUES ('1927', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-21 13:28:22');
INSERT INTO `iot_device_log` VALUES ('1928', '21', 'HUMIDITY', '2', '30.56', '30.56', '1', '2016-04-21 13:28:22');
INSERT INTO `iot_device_log` VALUES ('1929', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-21 13:28:32');
INSERT INTO `iot_device_log` VALUES ('1930', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-21 13:28:32');
INSERT INTO `iot_device_log` VALUES ('1931', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 13:28:42');
INSERT INTO `iot_device_log` VALUES ('1932', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-21 13:28:42');
INSERT INTO `iot_device_log` VALUES ('1933', '21', 'TEMPERATURE', '2', '45.52', '45.52', '1', '2016-04-21 13:28:52');
INSERT INTO `iot_device_log` VALUES ('1934', '21', 'HUMIDITY', '2', '30.63', '30.63', '1', '2016-04-21 13:28:52');
INSERT INTO `iot_device_log` VALUES ('1935', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-21 13:29:02');
INSERT INTO `iot_device_log` VALUES ('1936', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-21 13:29:02');
INSERT INTO `iot_device_log` VALUES ('1937', '21', 'TEMPERATURE', '2', '46.2', '46.2', '1', '2016-04-21 13:29:12');
INSERT INTO `iot_device_log` VALUES ('1938', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-21 13:29:12');
INSERT INTO `iot_device_log` VALUES ('1939', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 13:29:22');
INSERT INTO `iot_device_log` VALUES ('1940', '21', 'HUMIDITY', '2', '30.71', '30.71', '1', '2016-04-21 13:29:22');
INSERT INTO `iot_device_log` VALUES ('1941', '21', 'TEMPERATURE', '2', '45.47', '45.47', '1', '2016-04-21 13:29:32');
INSERT INTO `iot_device_log` VALUES ('1942', '21', 'HUMIDITY', '2', '30.75', '30.75', '1', '2016-04-21 13:29:32');
INSERT INTO `iot_device_log` VALUES ('1943', '21', 'TEMPERATURE', '2', '45.3', '45.3', '1', '2016-04-21 13:29:42');
INSERT INTO `iot_device_log` VALUES ('1944', '21', 'HUMIDITY', '2', '30.8', '30.8', '1', '2016-04-21 13:29:42');
INSERT INTO `iot_device_log` VALUES ('1945', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-21 13:29:52');
INSERT INTO `iot_device_log` VALUES ('1946', '21', 'HUMIDITY', '2', '30.71', '30.71', '1', '2016-04-21 13:29:52');
INSERT INTO `iot_device_log` VALUES ('1947', '21', 'TEMPERATURE', '2', '45.28', '45.28', '1', '2016-04-21 13:30:07');
INSERT INTO `iot_device_log` VALUES ('1948', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-21 13:30:07');
INSERT INTO `iot_device_log` VALUES ('1949', '21', 'TEMPERATURE', '2', '45.18', '45.18', '1', '2016-04-21 13:30:12');
INSERT INTO `iot_device_log` VALUES ('1950', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-21 13:30:12');
INSERT INTO `iot_device_log` VALUES ('1951', '21', 'TEMPERATURE', '2', '45.13', '45.13', '1', '2016-04-21 13:30:22');
INSERT INTO `iot_device_log` VALUES ('1952', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-21 13:30:22');
INSERT INTO `iot_device_log` VALUES ('1953', '21', 'TEMPERATURE', '2', '45.11', '45.11', '1', '2016-04-21 13:30:32');
INSERT INTO `iot_device_log` VALUES ('1954', '21', 'HUMIDITY', '2', '30.82', '30.82', '1', '2016-04-21 13:30:32');
INSERT INTO `iot_device_log` VALUES ('1955', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-21 13:30:42');
INSERT INTO `iot_device_log` VALUES ('1956', '21', 'HUMIDITY', '2', '30.77', '30.77', '1', '2016-04-21 13:30:42');
INSERT INTO `iot_device_log` VALUES ('1957', '21', 'TEMPERATURE', '2', '45.1', '45.1', '1', '2016-04-21 13:30:52');
INSERT INTO `iot_device_log` VALUES ('1958', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-21 13:30:52');
INSERT INTO `iot_device_log` VALUES ('1959', '21', 'TEMPERATURE', '2', '44.93', '44.93', '1', '2016-04-21 13:31:02');
INSERT INTO `iot_device_log` VALUES ('1960', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-21 13:31:02');
INSERT INTO `iot_device_log` VALUES ('1961', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-21 13:31:12');
INSERT INTO `iot_device_log` VALUES ('1962', '21', 'HUMIDITY', '2', '30.91', '30.91', '1', '2016-04-21 13:31:12');
INSERT INTO `iot_device_log` VALUES ('1963', '21', 'TEMPERATURE', '2', '45.05', '45.05', '1', '2016-04-21 13:31:22');
INSERT INTO `iot_device_log` VALUES ('1964', '21', 'HUMIDITY', '2', '30.82', '30.82', '1', '2016-04-21 13:31:22');
INSERT INTO `iot_device_log` VALUES ('1965', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-21 13:31:33');
INSERT INTO `iot_device_log` VALUES ('1966', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-21 13:31:33');
INSERT INTO `iot_device_log` VALUES ('1967', '21', 'TEMPERATURE', '2', '45.31', '45.31', '1', '2016-04-21 13:31:42');
INSERT INTO `iot_device_log` VALUES ('1968', '21', 'HUMIDITY', '2', '30.71', '30.71', '1', '2016-04-21 13:31:42');
INSERT INTO `iot_device_log` VALUES ('1969', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 13:31:57');
INSERT INTO `iot_device_log` VALUES ('1970', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-21 13:31:57');
INSERT INTO `iot_device_log` VALUES ('1971', '21', 'TEMPERATURE', '2', '45.89', '45.89', '1', '2016-04-21 13:32:02');
INSERT INTO `iot_device_log` VALUES ('1972', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-21 13:32:02');
INSERT INTO `iot_device_log` VALUES ('1973', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-21 13:32:12');
INSERT INTO `iot_device_log` VALUES ('1974', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-21 13:32:12');
INSERT INTO `iot_device_log` VALUES ('1975', '21', 'TEMPERATURE', '2', '45.96', '45.96', '1', '2016-04-21 13:32:22');
INSERT INTO `iot_device_log` VALUES ('1976', '21', 'HUMIDITY', '2', '30.66', '30.66', '1', '2016-04-21 13:32:22');
INSERT INTO `iot_device_log` VALUES ('1977', '21', 'TEMPERATURE', '2', '45.96', '45.96', '1', '2016-04-21 13:32:32');
INSERT INTO `iot_device_log` VALUES ('1978', '21', 'HUMIDITY', '2', '30.66', '30.66', '1', '2016-04-21 13:32:32');
INSERT INTO `iot_device_log` VALUES ('1979', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-21 13:32:42');
INSERT INTO `iot_device_log` VALUES ('1980', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-21 13:32:42');
INSERT INTO `iot_device_log` VALUES ('1981', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-21 13:32:52');
INSERT INTO `iot_device_log` VALUES ('1982', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-21 13:32:52');
INSERT INTO `iot_device_log` VALUES ('1983', '21', 'TEMPERATURE', '2', '44.94', '44.94', '1', '2016-04-21 13:33:02');
INSERT INTO `iot_device_log` VALUES ('1984', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-21 13:33:02');
INSERT INTO `iot_device_log` VALUES ('1985', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-21 13:33:12');
INSERT INTO `iot_device_log` VALUES ('1986', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-21 13:33:12');
INSERT INTO `iot_device_log` VALUES ('1987', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-21 13:33:22');
INSERT INTO `iot_device_log` VALUES ('1988', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-21 13:33:22');
INSERT INTO `iot_device_log` VALUES ('1989', '21', 'TEMPERATURE', '2', '44.82', '44.82', '1', '2016-04-21 13:33:32');
INSERT INTO `iot_device_log` VALUES ('1990', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-21 13:33:32');
INSERT INTO `iot_device_log` VALUES ('1991', '21', 'TEMPERATURE', '2', '44.98', '44.98', '1', '2016-04-21 13:33:42');
INSERT INTO `iot_device_log` VALUES ('1992', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-21 13:33:42');
INSERT INTO `iot_device_log` VALUES ('1993', '21', 'TEMPERATURE', '2', '45.11', '45.11', '1', '2016-04-21 13:33:52');
INSERT INTO `iot_device_log` VALUES ('1994', '21', 'HUMIDITY', '2', '30.75', '30.75', '1', '2016-04-21 13:33:52');
INSERT INTO `iot_device_log` VALUES ('1995', '21', 'TEMPERATURE', '2', '45.01', '45.01', '1', '2016-04-21 13:34:02');
INSERT INTO `iot_device_log` VALUES ('1996', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-21 13:34:02');
INSERT INTO `iot_device_log` VALUES ('1997', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-21 13:34:13');
INSERT INTO `iot_device_log` VALUES ('1998', '21', 'HUMIDITY', '2', '30.8', '30.8', '1', '2016-04-21 13:34:13');
INSERT INTO `iot_device_log` VALUES ('1999', '21', 'TEMPERATURE', '2', '44.64', '44.64', '1', '2016-04-21 13:34:22');
INSERT INTO `iot_device_log` VALUES ('2000', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-21 13:34:22');
INSERT INTO `iot_device_log` VALUES ('2001', '21', 'TEMPERATURE', '2', '44.6', '44.6', '1', '2016-04-21 13:34:32');
INSERT INTO `iot_device_log` VALUES ('2002', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-21 13:34:32');
INSERT INTO `iot_device_log` VALUES ('2003', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-21 13:34:42');
INSERT INTO `iot_device_log` VALUES ('2004', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-21 13:34:42');
INSERT INTO `iot_device_log` VALUES ('2005', '21', 'TEMPERATURE', '2', '44.46', '44.46', '1', '2016-04-21 13:34:52');
INSERT INTO `iot_device_log` VALUES ('2006', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-21 13:34:52');
INSERT INTO `iot_device_log` VALUES ('2007', '21', 'TEMPERATURE', '2', '44.11', '44.11', '1', '2016-04-21 13:35:02');
INSERT INTO `iot_device_log` VALUES ('2008', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-21 13:35:02');
INSERT INTO `iot_device_log` VALUES ('2009', '21', 'TEMPERATURE', '2', '43.91', '43.91', '1', '2016-04-21 13:35:12');
INSERT INTO `iot_device_log` VALUES ('2010', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-21 13:35:12');
INSERT INTO `iot_device_log` VALUES ('2011', '21', 'TEMPERATURE', '2', '43.88', '43.88', '1', '2016-04-21 13:35:22');
INSERT INTO `iot_device_log` VALUES ('2012', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-21 13:35:22');
INSERT INTO `iot_device_log` VALUES ('2013', '21', 'TEMPERATURE', '2', '43.94', '43.94', '1', '2016-04-21 13:35:32');
INSERT INTO `iot_device_log` VALUES ('2014', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-21 13:35:32');
INSERT INTO `iot_device_log` VALUES ('2015', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-21 13:35:42');
INSERT INTO `iot_device_log` VALUES ('2016', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-21 13:35:42');
INSERT INTO `iot_device_log` VALUES ('2017', '21', 'TEMPERATURE', '2', '44.36', '44.36', '1', '2016-04-21 13:35:52');
INSERT INTO `iot_device_log` VALUES ('2018', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-21 13:35:52');
INSERT INTO `iot_device_log` VALUES ('2019', '21', 'TEMPERATURE', '2', '44.45', '44.45', '1', '2016-04-21 13:36:02');
INSERT INTO `iot_device_log` VALUES ('2020', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-21 13:36:02');
INSERT INTO `iot_device_log` VALUES ('2021', '21', 'TEMPERATURE', '2', '44.37', '44.37', '1', '2016-04-21 13:36:12');
INSERT INTO `iot_device_log` VALUES ('2022', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-21 13:36:12');
INSERT INTO `iot_device_log` VALUES ('2023', '21', 'TEMPERATURE', '2', '44.39', '44.39', '1', '2016-04-21 13:36:22');
INSERT INTO `iot_device_log` VALUES ('2024', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-21 13:36:22');
INSERT INTO `iot_device_log` VALUES ('2025', '21', 'TEMPERATURE', '2', '44.48', '44.48', '1', '2016-04-21 13:36:32');
INSERT INTO `iot_device_log` VALUES ('2026', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-21 13:36:32');
INSERT INTO `iot_device_log` VALUES ('2027', '21', 'TEMPERATURE', '2', '44.16', '44.16', '1', '2016-04-21 13:36:43');
INSERT INTO `iot_device_log` VALUES ('2028', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-21 13:36:43');
INSERT INTO `iot_device_log` VALUES ('2029', '21', 'TEMPERATURE', '2', '44.33', '44.33', '1', '2016-04-21 13:36:53');
INSERT INTO `iot_device_log` VALUES ('2030', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-21 13:36:53');
INSERT INTO `iot_device_log` VALUES ('2031', '21', 'TEMPERATURE', '2', '44.39', '44.39', '1', '2016-04-21 13:37:02');
INSERT INTO `iot_device_log` VALUES ('2032', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-21 13:37:02');
INSERT INTO `iot_device_log` VALUES ('2033', '21', 'TEMPERATURE', '2', '44.24', '44.24', '1', '2016-04-21 13:37:12');
INSERT INTO `iot_device_log` VALUES ('2034', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-21 13:37:12');
INSERT INTO `iot_device_log` VALUES ('2035', '21', 'TEMPERATURE', '2', '44.3', '44.3', '1', '2016-04-21 13:37:22');
INSERT INTO `iot_device_log` VALUES ('2036', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-21 13:37:22');
INSERT INTO `iot_device_log` VALUES ('2037', '21', 'TEMPERATURE', '2', '44.28', '44.28', '1', '2016-04-21 13:37:32');
INSERT INTO `iot_device_log` VALUES ('2038', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-21 13:37:32');
INSERT INTO `iot_device_log` VALUES ('2039', '21', 'TEMPERATURE', '2', '44.3', '44.3', '1', '2016-04-21 13:37:42');
INSERT INTO `iot_device_log` VALUES ('2040', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-21 13:37:42');
INSERT INTO `iot_device_log` VALUES ('2041', '21', 'TEMPERATURE', '2', '44.16', '44.16', '1', '2016-04-21 13:37:52');
INSERT INTO `iot_device_log` VALUES ('2042', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-21 13:37:52');
INSERT INTO `iot_device_log` VALUES ('2043', '21', 'TEMPERATURE', '2', '44.07', '44.07', '1', '2016-04-21 13:38:02');
INSERT INTO `iot_device_log` VALUES ('2044', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-21 13:38:02');
INSERT INTO `iot_device_log` VALUES ('2045', '21', 'TEMPERATURE', '2', '44.01', '44.01', '1', '2016-04-21 13:38:13');
INSERT INTO `iot_device_log` VALUES ('2046', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-21 13:38:13');
INSERT INTO `iot_device_log` VALUES ('2047', '21', 'TEMPERATURE', '2', '43.94', '43.94', '1', '2016-04-21 13:38:22');
INSERT INTO `iot_device_log` VALUES ('2048', '21', 'HUMIDITY', '2', '31.12', '31.12', '1', '2016-04-21 13:38:22');
INSERT INTO `iot_device_log` VALUES ('2049', '21', 'TEMPERATURE', '2', '43.8', '43.8', '1', '2016-04-21 13:38:32');
INSERT INTO `iot_device_log` VALUES ('2050', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-21 13:38:32');
INSERT INTO `iot_device_log` VALUES ('2051', '21', 'TEMPERATURE', '2', '43.84', '43.84', '1', '2016-04-21 13:38:42');
INSERT INTO `iot_device_log` VALUES ('2052', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-21 13:38:42');
INSERT INTO `iot_device_log` VALUES ('2053', '21', 'TEMPERATURE', '2', '43.77', '43.77', '1', '2016-04-21 13:38:52');
INSERT INTO `iot_device_log` VALUES ('2054', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-21 13:38:52');
INSERT INTO `iot_device_log` VALUES ('2055', '21', 'TEMPERATURE', '2', '43.99', '43.99', '1', '2016-04-21 13:39:02');
INSERT INTO `iot_device_log` VALUES ('2056', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-21 13:39:02');
INSERT INTO `iot_device_log` VALUES ('2057', '21', 'TEMPERATURE', '2', '43.86', '43.86', '1', '2016-04-21 13:39:12');
INSERT INTO `iot_device_log` VALUES ('2058', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-21 13:39:12');
INSERT INTO `iot_device_log` VALUES ('2059', '21', 'TEMPERATURE', '2', '43.84', '43.84', '1', '2016-04-21 13:39:22');
INSERT INTO `iot_device_log` VALUES ('2060', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-21 13:39:22');
INSERT INTO `iot_device_log` VALUES ('2061', '21', 'TEMPERATURE', '2', '43.72', '43.72', '1', '2016-04-21 13:39:32');
INSERT INTO `iot_device_log` VALUES ('2062', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-21 13:39:32');
INSERT INTO `iot_device_log` VALUES ('2063', '21', 'TEMPERATURE', '2', '43.81', '43.81', '1', '2016-04-21 13:39:42');
INSERT INTO `iot_device_log` VALUES ('2064', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-21 13:39:42');
INSERT INTO `iot_device_log` VALUES ('2065', '21', 'TEMPERATURE', '2', '43.8', '43.8', '1', '2016-04-21 13:39:52');
INSERT INTO `iot_device_log` VALUES ('2066', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-21 13:39:52');
INSERT INTO `iot_device_log` VALUES ('2067', '21', 'TEMPERATURE', '2', '43.8', '43.8', '1', '2016-04-21 13:40:02');
INSERT INTO `iot_device_log` VALUES ('2068', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-21 13:40:02');
INSERT INTO `iot_device_log` VALUES ('2069', '21', 'TEMPERATURE', '2', '43.83', '43.83', '1', '2016-04-21 13:40:12');
INSERT INTO `iot_device_log` VALUES ('2070', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-21 13:40:12');
INSERT INTO `iot_device_log` VALUES ('2071', '21', 'TEMPERATURE', '2', '43.75', '43.75', '1', '2016-04-21 13:40:22');
INSERT INTO `iot_device_log` VALUES ('2072', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-21 13:40:22');
INSERT INTO `iot_device_log` VALUES ('2073', '21', 'TEMPERATURE', '2', '43.69', '43.69', '1', '2016-04-21 13:40:32');
INSERT INTO `iot_device_log` VALUES ('2074', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-21 13:40:32');
INSERT INTO `iot_device_log` VALUES ('2075', '21', 'TEMPERATURE', '2', '43.61', '43.61', '1', '2016-04-21 13:40:44');
INSERT INTO `iot_device_log` VALUES ('2076', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-21 13:40:44');
INSERT INTO `iot_device_log` VALUES ('2077', '21', 'TEMPERATURE', '2', '43.38', '43.38', '1', '2016-04-21 13:40:52');
INSERT INTO `iot_device_log` VALUES ('2078', '21', 'HUMIDITY', '2', '31.47', '31.47', '1', '2016-04-21 13:40:52');
INSERT INTO `iot_device_log` VALUES ('2079', '21', 'TEMPERATURE', '2', '43.28', '43.28', '1', '2016-04-21 13:41:02');
INSERT INTO `iot_device_log` VALUES ('2080', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-21 13:41:02');
INSERT INTO `iot_device_log` VALUES ('2081', '21', 'TEMPERATURE', '2', '43.16', '43.16', '1', '2016-04-21 13:41:12');
INSERT INTO `iot_device_log` VALUES ('2082', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-21 13:41:12');
INSERT INTO `iot_device_log` VALUES ('2083', '21', 'TEMPERATURE', '2', '43.12', '43.12', '1', '2016-04-21 13:41:23');
INSERT INTO `iot_device_log` VALUES ('2084', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-21 13:41:23');
INSERT INTO `iot_device_log` VALUES ('2085', '21', 'TEMPERATURE', '2', '42.97', '42.97', '1', '2016-04-21 13:41:32');
INSERT INTO `iot_device_log` VALUES ('2086', '21', 'HUMIDITY', '2', '31.66', '31.66', '1', '2016-04-21 13:41:32');
INSERT INTO `iot_device_log` VALUES ('2087', '21', 'TEMPERATURE', '2', '42.7', '42.7', '1', '2016-04-21 13:41:42');
INSERT INTO `iot_device_log` VALUES ('2088', '21', 'HUMIDITY', '2', '31.81', '31.81', '1', '2016-04-21 13:41:42');
INSERT INTO `iot_device_log` VALUES ('2089', '21', 'TEMPERATURE', '2', '42.58', '42.58', '1', '2016-04-21 13:41:54');
INSERT INTO `iot_device_log` VALUES ('2090', '21', 'HUMIDITY', '2', '31.91', '31.91', '1', '2016-04-21 13:41:54');
INSERT INTO `iot_device_log` VALUES ('2091', '21', 'TEMPERATURE', '2', '42.45', '42.45', '1', '2016-04-21 13:42:03');
INSERT INTO `iot_device_log` VALUES ('2092', '21', 'HUMIDITY', '2', '31.96', '31.96', '1', '2016-04-21 13:42:03');
INSERT INTO `iot_device_log` VALUES ('2093', '21', 'TEMPERATURE', '2', '42.36', '42.36', '1', '2016-04-21 13:42:12');
INSERT INTO `iot_device_log` VALUES ('2094', '21', 'HUMIDITY', '2', '32.03', '32.03', '1', '2016-04-21 13:42:12');
INSERT INTO `iot_device_log` VALUES ('2095', '21', 'TEMPERATURE', '2', '42.2', '42.2', '1', '2016-04-21 13:42:22');
INSERT INTO `iot_device_log` VALUES ('2096', '21', 'HUMIDITY', '2', '32.1', '32.1', '1', '2016-04-21 13:42:22');
INSERT INTO `iot_device_log` VALUES ('2097', '21', 'TEMPERATURE', '2', '42.08', '42.08', '1', '2016-04-21 13:42:32');
INSERT INTO `iot_device_log` VALUES ('2098', '21', 'HUMIDITY', '2', '32.1', '32.1', '1', '2016-04-21 13:42:32');
INSERT INTO `iot_device_log` VALUES ('2099', '21', 'TEMPERATURE', '2', '42.18', '42.18', '1', '2016-04-21 13:42:42');
INSERT INTO `iot_device_log` VALUES ('2100', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 13:42:42');
INSERT INTO `iot_device_log` VALUES ('2101', '21', 'TEMPERATURE', '2', '42.17', '42.17', '1', '2016-04-21 13:42:52');
INSERT INTO `iot_device_log` VALUES ('2102', '21', 'HUMIDITY', '2', '31.97', '31.97', '1', '2016-04-21 13:42:52');
INSERT INTO `iot_device_log` VALUES ('2103', '21', 'TEMPERATURE', '2', '42.26', '42.26', '1', '2016-04-21 13:43:02');
INSERT INTO `iot_device_log` VALUES ('2104', '21', 'HUMIDITY', '2', '31.97', '31.97', '1', '2016-04-21 13:43:02');
INSERT INTO `iot_device_log` VALUES ('2105', '21', 'TEMPERATURE', '2', '42.28', '42.28', '1', '2016-04-21 13:43:12');
INSERT INTO `iot_device_log` VALUES ('2106', '21', 'HUMIDITY', '2', '31.94', '31.94', '1', '2016-04-21 13:43:12');
INSERT INTO `iot_device_log` VALUES ('2107', '21', 'TEMPERATURE', '2', '42.14', '42.14', '1', '2016-04-21 13:43:22');
INSERT INTO `iot_device_log` VALUES ('2108', '21', 'HUMIDITY', '2', '32', '32', '1', '2016-04-21 13:43:22');
INSERT INTO `iot_device_log` VALUES ('2109', '21', 'TEMPERATURE', '2', '42.15', '42.15', '1', '2016-04-21 13:43:32');
INSERT INTO `iot_device_log` VALUES ('2110', '21', 'HUMIDITY', '2', '32.15', '32.15', '1', '2016-04-21 13:43:32');
INSERT INTO `iot_device_log` VALUES ('2111', '21', 'TEMPERATURE', '2', '42.24', '42.24', '1', '2016-04-21 13:43:42');
INSERT INTO `iot_device_log` VALUES ('2112', '21', 'HUMIDITY', '2', '32.03', '32.03', '1', '2016-04-21 13:43:42');
INSERT INTO `iot_device_log` VALUES ('2113', '21', 'TEMPERATURE', '2', '42.09', '42.09', '1', '2016-04-21 13:43:54');
INSERT INTO `iot_device_log` VALUES ('2114', '21', 'HUMIDITY', '2', '32.16', '32.16', '1', '2016-04-21 13:43:54');
INSERT INTO `iot_device_log` VALUES ('2115', '21', 'TEMPERATURE', '2', '42.01', '42.01', '1', '2016-04-21 13:44:02');
INSERT INTO `iot_device_log` VALUES ('2116', '21', 'HUMIDITY', '2', '32.21', '32.21', '1', '2016-04-21 13:44:02');
INSERT INTO `iot_device_log` VALUES ('2117', '21', 'TEMPERATURE', '2', '42.04', '42.04', '1', '2016-04-21 13:44:12');
INSERT INTO `iot_device_log` VALUES ('2118', '21', 'HUMIDITY', '2', '32.25', '32.25', '1', '2016-04-21 13:44:12');
INSERT INTO `iot_device_log` VALUES ('2119', '21', 'TEMPERATURE', '2', '42.15', '42.15', '1', '2016-04-21 13:44:22');
INSERT INTO `iot_device_log` VALUES ('2120', '21', 'HUMIDITY', '2', '32.18', '32.18', '1', '2016-04-21 13:44:22');
INSERT INTO `iot_device_log` VALUES ('2121', '21', 'TEMPERATURE', '2', '42.17', '42.17', '1', '2016-04-21 13:44:32');
INSERT INTO `iot_device_log` VALUES ('2122', '21', 'HUMIDITY', '2', '32.21', '32.21', '1', '2016-04-21 13:44:32');
INSERT INTO `iot_device_log` VALUES ('2123', '21', 'TEMPERATURE', '2', '42.34', '42.34', '1', '2016-04-21 13:44:42');
INSERT INTO `iot_device_log` VALUES ('2124', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 13:44:42');
INSERT INTO `iot_device_log` VALUES ('2125', '21', 'TEMPERATURE', '2', '42.4', '42.4', '1', '2016-04-21 13:44:52');
INSERT INTO `iot_device_log` VALUES ('2126', '21', 'HUMIDITY', '2', '32.1', '32.1', '1', '2016-04-21 13:44:52');
INSERT INTO `iot_device_log` VALUES ('2127', '21', 'TEMPERATURE', '2', '42.3', '42.3', '1', '2016-04-21 13:45:03');
INSERT INTO `iot_device_log` VALUES ('2128', '21', 'HUMIDITY', '2', '32', '32', '1', '2016-04-21 13:45:03');
INSERT INTO `iot_device_log` VALUES ('2129', '21', 'TEMPERATURE', '2', '42.47', '42.47', '1', '2016-04-21 13:45:12');
INSERT INTO `iot_device_log` VALUES ('2130', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-21 13:45:12');
INSERT INTO `iot_device_log` VALUES ('2131', '21', 'TEMPERATURE', '2', '42.47', '42.47', '1', '2016-04-21 13:45:22');
INSERT INTO `iot_device_log` VALUES ('2132', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-21 13:45:22');
INSERT INTO `iot_device_log` VALUES ('2133', '21', 'TEMPERATURE', '2', '42.43', '42.43', '1', '2016-04-21 13:45:32');
INSERT INTO `iot_device_log` VALUES ('2134', '21', 'HUMIDITY', '2', '31.93', '31.93', '1', '2016-04-21 13:45:32');
INSERT INTO `iot_device_log` VALUES ('2135', '21', 'TEMPERATURE', '2', '42.09', '42.09', '1', '2016-04-21 13:45:42');
INSERT INTO `iot_device_log` VALUES ('2136', '21', 'HUMIDITY', '2', '31.91', '31.91', '1', '2016-04-21 13:45:42');
INSERT INTO `iot_device_log` VALUES ('2137', '21', 'TEMPERATURE', '2', '42.22', '42.22', '1', '2016-04-21 13:45:53');
INSERT INTO `iot_device_log` VALUES ('2138', '21', 'HUMIDITY', '2', '31.72', '31.72', '1', '2016-04-21 13:45:53');
INSERT INTO `iot_device_log` VALUES ('2139', '21', 'TEMPERATURE', '2', '42.35', '42.35', '1', '2016-04-21 13:46:02');
INSERT INTO `iot_device_log` VALUES ('2140', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-21 13:46:02');
INSERT INTO `iot_device_log` VALUES ('2141', '21', 'TEMPERATURE', '2', '42.42', '42.42', '1', '2016-04-21 13:46:13');
INSERT INTO `iot_device_log` VALUES ('2142', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-21 13:46:13');
INSERT INTO `iot_device_log` VALUES ('2143', '21', 'TEMPERATURE', '2', '42.49', '42.49', '1', '2016-04-21 13:46:22');
INSERT INTO `iot_device_log` VALUES ('2144', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-21 13:46:22');
INSERT INTO `iot_device_log` VALUES ('2145', '21', 'TEMPERATURE', '2', '42.55', '42.55', '1', '2016-04-21 13:46:32');
INSERT INTO `iot_device_log` VALUES ('2146', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-21 13:46:32');
INSERT INTO `iot_device_log` VALUES ('2147', '21', 'TEMPERATURE', '2', '42.6', '42.6', '1', '2016-04-21 13:46:42');
INSERT INTO `iot_device_log` VALUES ('2148', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-21 13:46:42');
INSERT INTO `iot_device_log` VALUES ('2149', '21', 'TEMPERATURE', '2', '42.64', '42.64', '1', '2016-04-21 13:46:52');
INSERT INTO `iot_device_log` VALUES ('2150', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-21 13:46:52');
INSERT INTO `iot_device_log` VALUES ('2151', '21', 'TEMPERATURE', '2', '42.6', '42.6', '1', '2016-04-21 13:47:02');
INSERT INTO `iot_device_log` VALUES ('2152', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-21 13:47:02');
INSERT INTO `iot_device_log` VALUES ('2153', '21', 'TEMPERATURE', '2', '42.66', '42.66', '1', '2016-04-21 13:47:12');
INSERT INTO `iot_device_log` VALUES ('2154', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-21 13:47:12');
INSERT INTO `iot_device_log` VALUES ('2155', '21', 'TEMPERATURE', '2', '42.72', '42.72', '1', '2016-04-21 13:47:29');
INSERT INTO `iot_device_log` VALUES ('2156', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-21 13:47:29');
INSERT INTO `iot_device_log` VALUES ('2157', '21', 'TEMPERATURE', '2', '43.17', '43.17', '1', '2016-04-21 13:47:32');
INSERT INTO `iot_device_log` VALUES ('2158', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-21 13:47:32');
INSERT INTO `iot_device_log` VALUES ('2159', '21', 'TEMPERATURE', '2', '43.23', '43.23', '1', '2016-04-21 13:47:42');
INSERT INTO `iot_device_log` VALUES ('2160', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-21 13:47:42');
INSERT INTO `iot_device_log` VALUES ('2161', '21', 'TEMPERATURE', '2', '43.21', '43.21', '1', '2016-04-21 13:47:52');
INSERT INTO `iot_device_log` VALUES ('2162', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-21 13:47:52');
INSERT INTO `iot_device_log` VALUES ('2163', '21', 'TEMPERATURE', '2', '43.34', '43.34', '1', '2016-04-21 13:48:02');
INSERT INTO `iot_device_log` VALUES ('2164', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-21 13:48:02');
INSERT INTO `iot_device_log` VALUES ('2165', '21', 'TEMPERATURE', '2', '43.06', '43.06', '1', '2016-04-21 13:48:12');
INSERT INTO `iot_device_log` VALUES ('2166', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-21 13:48:12');
INSERT INTO `iot_device_log` VALUES ('2167', '21', 'TEMPERATURE', '2', '43.33', '43.33', '1', '2016-04-21 13:48:22');
INSERT INTO `iot_device_log` VALUES ('2168', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-21 13:48:22');
INSERT INTO `iot_device_log` VALUES ('2169', '21', 'TEMPERATURE', '2', '43.62', '43.62', '1', '2016-04-21 13:48:32');
INSERT INTO `iot_device_log` VALUES ('2170', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-21 13:48:32');
INSERT INTO `iot_device_log` VALUES ('2171', '21', 'TEMPERATURE', '2', '43.46', '43.46', '1', '2016-04-21 13:48:42');
INSERT INTO `iot_device_log` VALUES ('2172', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-21 13:48:42');
INSERT INTO `iot_device_log` VALUES ('2173', '21', 'TEMPERATURE', '2', '43.41', '43.41', '1', '2016-04-21 13:48:52');
INSERT INTO `iot_device_log` VALUES ('2174', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-21 13:48:52');
INSERT INTO `iot_device_log` VALUES ('2175', '21', 'TEMPERATURE', '2', '43.49', '43.49', '1', '2016-04-21 13:49:02');
INSERT INTO `iot_device_log` VALUES ('2176', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-21 13:49:02');
INSERT INTO `iot_device_log` VALUES ('2177', '21', 'TEMPERATURE', '2', '43.86', '43.86', '1', '2016-04-21 13:49:12');
INSERT INTO `iot_device_log` VALUES ('2178', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-21 13:49:12');
INSERT INTO `iot_device_log` VALUES ('2179', '21', 'TEMPERATURE', '2', '43.82', '43.82', '1', '2016-04-21 13:49:22');
INSERT INTO `iot_device_log` VALUES ('2180', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-21 13:49:22');
INSERT INTO `iot_device_log` VALUES ('2181', '21', 'TEMPERATURE', '2', '43.92', '43.92', '1', '2016-04-21 13:49:32');
INSERT INTO `iot_device_log` VALUES ('2182', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-21 13:49:32');
INSERT INTO `iot_device_log` VALUES ('2183', '21', 'TEMPERATURE', '2', '43.84', '43.84', '1', '2016-04-21 13:49:42');
INSERT INTO `iot_device_log` VALUES ('2184', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-21 13:49:42');
INSERT INTO `iot_device_log` VALUES ('2185', '21', 'TEMPERATURE', '2', '43.82', '43.82', '1', '2016-04-21 13:49:52');
INSERT INTO `iot_device_log` VALUES ('2186', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-21 13:49:52');
INSERT INTO `iot_device_log` VALUES ('2187', '21', 'TEMPERATURE', '2', '43.7', '43.7', '1', '2016-04-21 13:50:02');
INSERT INTO `iot_device_log` VALUES ('2188', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-21 13:50:02');
INSERT INTO `iot_device_log` VALUES ('2189', '21', 'TEMPERATURE', '2', '43.67', '43.67', '1', '2016-04-21 13:50:12');
INSERT INTO `iot_device_log` VALUES ('2190', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-21 13:50:12');
INSERT INTO `iot_device_log` VALUES ('2191', '21', 'TEMPERATURE', '2', '43.64', '43.64', '1', '2016-04-21 13:50:22');
INSERT INTO `iot_device_log` VALUES ('2192', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-21 13:50:22');
INSERT INTO `iot_device_log` VALUES ('2193', '21', 'TEMPERATURE', '2', '43.58', '43.58', '1', '2016-04-21 13:50:32');
INSERT INTO `iot_device_log` VALUES ('2194', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-21 13:50:32');
INSERT INTO `iot_device_log` VALUES ('2195', '21', 'TEMPERATURE', '2', '43.67', '43.67', '1', '2016-04-21 13:50:42');
INSERT INTO `iot_device_log` VALUES ('2196', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-21 13:50:42');
INSERT INTO `iot_device_log` VALUES ('2197', '21', 'TEMPERATURE', '2', '43.65', '43.65', '1', '2016-04-21 13:50:52');
INSERT INTO `iot_device_log` VALUES ('2198', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-21 13:50:52');
INSERT INTO `iot_device_log` VALUES ('2199', '21', 'TEMPERATURE', '2', '43.88', '43.88', '1', '2016-04-21 13:51:02');
INSERT INTO `iot_device_log` VALUES ('2200', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-21 13:51:02');
INSERT INTO `iot_device_log` VALUES ('2201', '21', 'TEMPERATURE', '2', '43.7', '43.7', '1', '2016-04-21 13:51:12');
INSERT INTO `iot_device_log` VALUES ('2202', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-21 13:51:12');
INSERT INTO `iot_device_log` VALUES ('2203', '21', 'TEMPERATURE', '2', '43.72', '43.72', '1', '2016-04-21 13:51:23');
INSERT INTO `iot_device_log` VALUES ('2204', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-21 13:51:23');
INSERT INTO `iot_device_log` VALUES ('2205', '21', 'TEMPERATURE', '2', '43.89', '43.89', '1', '2016-04-21 13:51:32');
INSERT INTO `iot_device_log` VALUES ('2206', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-21 13:51:32');
INSERT INTO `iot_device_log` VALUES ('2207', '21', 'TEMPERATURE', '2', '44.09', '44.09', '1', '2016-04-21 13:51:42');
INSERT INTO `iot_device_log` VALUES ('2208', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-21 13:51:42');
INSERT INTO `iot_device_log` VALUES ('2209', '21', 'TEMPERATURE', '2', '43.98', '43.98', '1', '2016-04-21 13:51:52');
INSERT INTO `iot_device_log` VALUES ('2210', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-21 13:51:52');
INSERT INTO `iot_device_log` VALUES ('2211', '21', 'TEMPERATURE', '2', '43.8', '43.8', '1', '2016-04-21 13:52:02');
INSERT INTO `iot_device_log` VALUES ('2212', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-21 13:52:02');
INSERT INTO `iot_device_log` VALUES ('2213', '21', 'TEMPERATURE', '2', '43.66', '43.66', '1', '2016-04-21 13:52:12');
INSERT INTO `iot_device_log` VALUES ('2214', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-21 13:52:12');
INSERT INTO `iot_device_log` VALUES ('2215', '21', 'TEMPERATURE', '2', '43.64', '43.64', '1', '2016-04-21 13:52:22');
INSERT INTO `iot_device_log` VALUES ('2216', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-21 13:52:22');
INSERT INTO `iot_device_log` VALUES ('2217', '21', 'TEMPERATURE', '2', '43.89', '43.89', '1', '2016-04-21 13:52:32');
INSERT INTO `iot_device_log` VALUES ('2218', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-21 13:52:32');
INSERT INTO `iot_device_log` VALUES ('2219', '21', 'TEMPERATURE', '2', '43.67', '43.67', '1', '2016-04-21 13:52:42');
INSERT INTO `iot_device_log` VALUES ('2220', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-21 13:52:42');
INSERT INTO `iot_device_log` VALUES ('2221', '21', 'TEMPERATURE', '2', '43.38', '43.38', '1', '2016-04-21 13:52:52');
INSERT INTO `iot_device_log` VALUES ('2222', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-21 13:52:52');
INSERT INTO `iot_device_log` VALUES ('2223', '21', 'TEMPERATURE', '2', '43.34', '43.34', '1', '2016-04-21 13:53:02');
INSERT INTO `iot_device_log` VALUES ('2224', '21', 'HUMIDITY', '2', '31.41', '31.41', '1', '2016-04-21 13:53:02');
INSERT INTO `iot_device_log` VALUES ('2225', '21', 'TEMPERATURE', '2', '43.32', '43.32', '1', '2016-04-21 13:53:12');
INSERT INTO `iot_device_log` VALUES ('2226', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-21 13:53:12');
INSERT INTO `iot_device_log` VALUES ('2227', '21', 'TEMPERATURE', '2', '43.28', '43.28', '1', '2016-04-21 13:53:22');
INSERT INTO `iot_device_log` VALUES ('2228', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-21 13:53:22');
INSERT INTO `iot_device_log` VALUES ('2229', '21', 'TEMPERATURE', '2', '42.72', '42.72', '1', '2016-04-21 13:53:33');
INSERT INTO `iot_device_log` VALUES ('2230', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-21 13:53:33');
INSERT INTO `iot_device_log` VALUES ('2231', '21', 'TEMPERATURE', '2', '42.86', '42.86', '1', '2016-04-21 13:53:42');
INSERT INTO `iot_device_log` VALUES ('2232', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-21 13:53:42');
INSERT INTO `iot_device_log` VALUES ('2233', '21', 'TEMPERATURE', '2', '42.86', '42.86', '1', '2016-04-21 13:53:52');
INSERT INTO `iot_device_log` VALUES ('2234', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-21 13:53:52');
INSERT INTO `iot_device_log` VALUES ('2235', '21', 'TEMPERATURE', '2', '43.03', '43.03', '1', '2016-04-21 13:54:02');
INSERT INTO `iot_device_log` VALUES ('2236', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-21 13:54:02');
INSERT INTO `iot_device_log` VALUES ('2237', '21', 'TEMPERATURE', '2', '42.83', '42.83', '1', '2016-04-21 13:54:12');
INSERT INTO `iot_device_log` VALUES ('2238', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-21 13:54:12');
INSERT INTO `iot_device_log` VALUES ('2239', '21', 'TEMPERATURE', '2', '42.93', '42.93', '1', '2016-04-21 13:54:22');
INSERT INTO `iot_device_log` VALUES ('2240', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-21 13:54:22');
INSERT INTO `iot_device_log` VALUES ('2241', '21', 'TEMPERATURE', '2', '43', '43', '1', '2016-04-21 13:54:32');
INSERT INTO `iot_device_log` VALUES ('2242', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-21 13:54:32');
INSERT INTO `iot_device_log` VALUES ('2243', '21', 'TEMPERATURE', '2', '42.84', '42.84', '1', '2016-04-21 13:54:42');
INSERT INTO `iot_device_log` VALUES ('2244', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-21 13:54:42');
INSERT INTO `iot_device_log` VALUES ('2245', '21', 'TEMPERATURE', '2', '42.92', '42.92', '1', '2016-04-21 13:54:52');
INSERT INTO `iot_device_log` VALUES ('2246', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-21 13:54:52');
INSERT INTO `iot_device_log` VALUES ('2247', '21', 'TEMPERATURE', '2', '42.87', '42.87', '1', '2016-04-21 13:55:02');
INSERT INTO `iot_device_log` VALUES ('2248', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-21 13:55:02');
INSERT INTO `iot_device_log` VALUES ('2249', '21', 'TEMPERATURE', '2', '42.9', '42.9', '1', '2016-04-21 13:55:12');
INSERT INTO `iot_device_log` VALUES ('2250', '21', 'HUMIDITY', '2', '31.41', '31.41', '1', '2016-04-21 13:55:12');
INSERT INTO `iot_device_log` VALUES ('2251', '21', 'TEMPERATURE', '2', '42.72', '42.72', '1', '2016-04-21 13:55:22');
INSERT INTO `iot_device_log` VALUES ('2252', '21', 'HUMIDITY', '2', '31.41', '31.41', '1', '2016-04-21 13:55:22');
INSERT INTO `iot_device_log` VALUES ('2253', '21', 'TEMPERATURE', '2', '42.79', '42.79', '1', '2016-04-21 13:55:32');
INSERT INTO `iot_device_log` VALUES ('2254', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-21 13:55:32');
INSERT INTO `iot_device_log` VALUES ('2255', '21', 'TEMPERATURE', '2', '42.69', '42.69', '1', '2016-04-21 13:55:42');
INSERT INTO `iot_device_log` VALUES ('2256', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-21 13:55:42');
INSERT INTO `iot_device_log` VALUES ('2257', '21', 'TEMPERATURE', '2', '42.75', '42.75', '1', '2016-04-21 13:55:52');
INSERT INTO `iot_device_log` VALUES ('2258', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-21 13:55:52');
INSERT INTO `iot_device_log` VALUES ('2259', '21', 'TEMPERATURE', '2', '42.84', '42.84', '1', '2016-04-21 13:56:02');
INSERT INTO `iot_device_log` VALUES ('2260', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-21 13:56:02');
INSERT INTO `iot_device_log` VALUES ('2261', '21', 'TEMPERATURE', '2', '42.72', '42.72', '1', '2016-04-21 13:56:13');
INSERT INTO `iot_device_log` VALUES ('2262', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-21 13:56:13');
INSERT INTO `iot_device_log` VALUES ('2263', '21', 'TEMPERATURE', '2', '42.88', '42.88', '1', '2016-04-21 13:56:22');
INSERT INTO `iot_device_log` VALUES ('2264', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-21 13:56:22');
INSERT INTO `iot_device_log` VALUES ('2265', '21', 'TEMPERATURE', '2', '42.84', '42.84', '1', '2016-04-21 13:56:32');
INSERT INTO `iot_device_log` VALUES ('2266', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-21 13:56:32');
INSERT INTO `iot_device_log` VALUES ('2267', '21', 'TEMPERATURE', '2', '42.75', '42.75', '1', '2016-04-21 13:56:42');
INSERT INTO `iot_device_log` VALUES ('2268', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-21 13:56:42');
INSERT INTO `iot_device_log` VALUES ('2269', '21', 'TEMPERATURE', '2', '42.83', '42.83', '1', '2016-04-21 13:56:52');
INSERT INTO `iot_device_log` VALUES ('2270', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-21 13:56:52');
INSERT INTO `iot_device_log` VALUES ('2271', '21', 'TEMPERATURE', '2', '42.95', '42.95', '1', '2016-04-21 13:57:02');
INSERT INTO `iot_device_log` VALUES ('2272', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-21 13:57:02');
INSERT INTO `iot_device_log` VALUES ('2273', '21', 'TEMPERATURE', '2', '43.05', '43.05', '1', '2016-04-21 13:57:12');
INSERT INTO `iot_device_log` VALUES ('2274', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-21 13:57:12');
INSERT INTO `iot_device_log` VALUES ('2275', '21', 'TEMPERATURE', '2', '43.11', '43.11', '1', '2016-04-21 13:57:22');
INSERT INTO `iot_device_log` VALUES ('2276', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-21 13:57:22');
INSERT INTO `iot_device_log` VALUES ('2277', '21', 'TEMPERATURE', '2', '43.37', '43.37', '1', '2016-04-21 13:57:32');
INSERT INTO `iot_device_log` VALUES ('2278', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-21 13:57:32');
INSERT INTO `iot_device_log` VALUES ('2279', '21', 'TEMPERATURE', '2', '43.37', '43.37', '1', '2016-04-21 13:57:44');
INSERT INTO `iot_device_log` VALUES ('2280', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-21 13:57:44');
INSERT INTO `iot_device_log` VALUES ('2281', '21', 'TEMPERATURE', '2', '43.46', '43.46', '1', '2016-04-21 13:57:52');
INSERT INTO `iot_device_log` VALUES ('2282', '21', 'HUMIDITY', '2', '30.73', '30.73', '1', '2016-04-21 13:57:52');
INSERT INTO `iot_device_log` VALUES ('2283', '21', 'TEMPERATURE', '2', '43.47', '43.47', '1', '2016-04-21 13:58:03');
INSERT INTO `iot_device_log` VALUES ('2284', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-21 13:58:03');
INSERT INTO `iot_device_log` VALUES ('2285', '21', 'TEMPERATURE', '2', '43.39', '43.39', '1', '2016-04-21 13:58:12');
INSERT INTO `iot_device_log` VALUES ('2286', '21', 'HUMIDITY', '2', '30.69', '30.69', '1', '2016-04-21 13:58:12');
INSERT INTO `iot_device_log` VALUES ('2287', '21', 'TEMPERATURE', '2', '43.59', '43.59', '1', '2016-04-21 13:58:22');
INSERT INTO `iot_device_log` VALUES ('2288', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-21 13:58:22');
INSERT INTO `iot_device_log` VALUES ('2289', '21', 'TEMPERATURE', '2', '43.42', '43.42', '1', '2016-04-21 13:58:32');
INSERT INTO `iot_device_log` VALUES ('2290', '21', 'HUMIDITY', '2', '30.53', '30.53', '1', '2016-04-21 13:58:32');
INSERT INTO `iot_device_log` VALUES ('2291', '21', 'TEMPERATURE', '2', '43.65', '43.65', '1', '2016-04-21 13:58:42');
INSERT INTO `iot_device_log` VALUES ('2292', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-21 13:58:42');
INSERT INTO `iot_device_log` VALUES ('2293', '21', 'TEMPERATURE', '2', '43.52', '43.52', '1', '2016-04-21 13:58:52');
INSERT INTO `iot_device_log` VALUES ('2294', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-21 13:58:52');
INSERT INTO `iot_device_log` VALUES ('2295', '21', 'TEMPERATURE', '2', '43.41', '43.41', '1', '2016-04-21 13:59:02');
INSERT INTO `iot_device_log` VALUES ('2296', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-21 13:59:02');
INSERT INTO `iot_device_log` VALUES ('2297', '21', 'TEMPERATURE', '2', '43.63', '43.63', '1', '2016-04-21 13:59:12');
INSERT INTO `iot_device_log` VALUES ('2298', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-21 13:59:12');
INSERT INTO `iot_device_log` VALUES ('2299', '21', 'TEMPERATURE', '2', '43.31', '43.31', '1', '2016-04-21 13:59:22');
INSERT INTO `iot_device_log` VALUES ('2300', '21', 'HUMIDITY', '2', '30.75', '30.75', '1', '2016-04-21 13:59:22');
INSERT INTO `iot_device_log` VALUES ('2301', '21', 'TEMPERATURE', '2', '43.17', '43.17', '1', '2016-04-21 13:59:32');
INSERT INTO `iot_device_log` VALUES ('2302', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-21 13:59:32');
INSERT INTO `iot_device_log` VALUES ('2303', '21', 'TEMPERATURE', '2', '42.79', '42.79', '1', '2016-04-21 13:59:42');
INSERT INTO `iot_device_log` VALUES ('2304', '21', 'HUMIDITY', '2', '30.77', '30.77', '1', '2016-04-21 13:59:42');
INSERT INTO `iot_device_log` VALUES ('2305', '21', 'TEMPERATURE', '2', '43.28', '43.28', '1', '2016-04-21 13:59:52');
INSERT INTO `iot_device_log` VALUES ('2306', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-21 13:59:52');
INSERT INTO `iot_device_log` VALUES ('2307', '21', 'TEMPERATURE', '2', '43.28', '43.28', '1', '2016-04-21 14:00:02');
INSERT INTO `iot_device_log` VALUES ('2308', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-21 14:00:02');
INSERT INTO `iot_device_log` VALUES ('2309', '21', 'TEMPERATURE', '2', '43.17', '43.17', '1', '2016-04-21 14:00:12');
INSERT INTO `iot_device_log` VALUES ('2310', '21', 'HUMIDITY', '2', '30.82', '30.82', '1', '2016-04-21 14:00:12');
INSERT INTO `iot_device_log` VALUES ('2311', '21', 'TEMPERATURE', '2', '43.1', '43.1', '1', '2016-04-21 14:00:22');
INSERT INTO `iot_device_log` VALUES ('2312', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-21 14:00:22');
INSERT INTO `iot_device_log` VALUES ('2313', '21', 'TEMPERATURE', '2', '42.98', '42.98', '1', '2016-04-21 14:00:32');
INSERT INTO `iot_device_log` VALUES ('2314', '21', 'HUMIDITY', '2', '30.95', '30.95', '1', '2016-04-21 14:00:32');
INSERT INTO `iot_device_log` VALUES ('2315', '21', 'TEMPERATURE', '2', '43.38', '43.38', '1', '2016-04-21 14:00:42');
INSERT INTO `iot_device_log` VALUES ('2316', '21', 'HUMIDITY', '2', '30.91', '30.91', '1', '2016-04-21 14:00:42');
INSERT INTO `iot_device_log` VALUES ('2317', '21', 'TEMPERATURE', '2', '42.77', '42.77', '1', '2016-04-21 14:00:52');
INSERT INTO `iot_device_log` VALUES ('2318', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-21 14:00:52');
INSERT INTO `iot_device_log` VALUES ('2319', '21', 'TEMPERATURE', '2', '42.79', '42.79', '1', '2016-04-21 14:01:02');
INSERT INTO `iot_device_log` VALUES ('2320', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-21 14:01:02');
INSERT INTO `iot_device_log` VALUES ('2321', '21', 'TEMPERATURE', '2', '42.75', '42.75', '1', '2016-04-21 14:01:12');
INSERT INTO `iot_device_log` VALUES ('2322', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-21 14:01:12');
INSERT INTO `iot_device_log` VALUES ('2323', '21', 'TEMPERATURE', '2', '42.95', '42.95', '1', '2016-04-21 14:01:22');
INSERT INTO `iot_device_log` VALUES ('2324', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-21 14:01:22');
INSERT INTO `iot_device_log` VALUES ('2325', '21', 'TEMPERATURE', '2', '42.35', '42.35', '1', '2016-04-21 14:01:32');
INSERT INTO `iot_device_log` VALUES ('2326', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-21 14:01:32');
INSERT INTO `iot_device_log` VALUES ('2327', '21', 'TEMPERATURE', '2', '42.31', '42.31', '1', '2016-04-21 14:01:42');
INSERT INTO `iot_device_log` VALUES ('2328', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-21 14:01:42');
INSERT INTO `iot_device_log` VALUES ('2329', '21', 'TEMPERATURE', '2', '42.12', '42.12', '1', '2016-04-21 14:01:52');
INSERT INTO `iot_device_log` VALUES ('2330', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-21 14:01:52');
INSERT INTO `iot_device_log` VALUES ('2331', '21', 'TEMPERATURE', '2', '42.24', '42.24', '1', '2016-04-21 14:02:03');
INSERT INTO `iot_device_log` VALUES ('2332', '21', 'HUMIDITY', '2', '31.69', '31.69', '1', '2016-04-21 14:02:03');
INSERT INTO `iot_device_log` VALUES ('2333', '21', 'TEMPERATURE', '2', '41.56', '41.56', '1', '2016-04-21 14:02:12');
INSERT INTO `iot_device_log` VALUES ('2334', '21', 'HUMIDITY', '2', '32.05', '32.05', '1', '2016-04-21 14:02:12');
INSERT INTO `iot_device_log` VALUES ('2335', '21', 'TEMPERATURE', '2', '41.17', '41.17', '1', '2016-04-21 14:02:22');
INSERT INTO `iot_device_log` VALUES ('2336', '21', 'HUMIDITY', '2', '32.26', '32.26', '1', '2016-04-21 14:02:22');
INSERT INTO `iot_device_log` VALUES ('2337', '21', 'TEMPERATURE', '2', '40.83', '40.83', '1', '2016-04-21 14:02:32');
INSERT INTO `iot_device_log` VALUES ('2338', '21', 'HUMIDITY', '2', '32.56', '32.56', '1', '2016-04-21 14:02:32');
INSERT INTO `iot_device_log` VALUES ('2339', '21', 'TEMPERATURE', '2', '40.44', '40.44', '1', '2016-04-21 14:02:42');
INSERT INTO `iot_device_log` VALUES ('2340', '21', 'HUMIDITY', '2', '32.78', '32.78', '1', '2016-04-21 14:02:42');
INSERT INTO `iot_device_log` VALUES ('2341', '21', 'TEMPERATURE', '2', '40.02', '40.02', '1', '2016-04-21 14:02:52');
INSERT INTO `iot_device_log` VALUES ('2342', '21', 'HUMIDITY', '2', '32.97', '32.97', '1', '2016-04-21 14:02:52');
INSERT INTO `iot_device_log` VALUES ('2343', '21', 'TEMPERATURE', '2', '39.65', '39.65', '1', '2016-04-21 14:03:02');
INSERT INTO `iot_device_log` VALUES ('2344', '21', 'HUMIDITY', '2', '33.12', '33.12', '1', '2016-04-21 14:03:02');
INSERT INTO `iot_device_log` VALUES ('2345', '21', 'TEMPERATURE', '2', '39.63', '39.63', '1', '2016-04-21 14:03:12');
INSERT INTO `iot_device_log` VALUES ('2346', '21', 'HUMIDITY', '2', '33.25', '33.25', '1', '2016-04-21 14:03:12');
INSERT INTO `iot_device_log` VALUES ('2347', '21', 'TEMPERATURE', '2', '39.23', '39.23', '1', '2016-04-21 14:03:22');
INSERT INTO `iot_device_log` VALUES ('2348', '21', 'HUMIDITY', '2', '33.46', '33.46', '1', '2016-04-21 14:03:22');
INSERT INTO `iot_device_log` VALUES ('2349', '21', 'TEMPERATURE', '2', '39.5', '39.5', '1', '2016-04-21 14:03:32');
INSERT INTO `iot_device_log` VALUES ('2350', '21', 'HUMIDITY', '2', '33.42', '33.42', '1', '2016-04-21 14:03:32');
INSERT INTO `iot_device_log` VALUES ('2351', '21', 'TEMPERATURE', '2', '39.15', '39.15', '1', '2016-04-21 14:03:42');
INSERT INTO `iot_device_log` VALUES ('2352', '21', 'HUMIDITY', '2', '33.42', '33.42', '1', '2016-04-21 14:03:42');
INSERT INTO `iot_device_log` VALUES ('2353', '21', 'TEMPERATURE', '2', '38.88', '38.88', '1', '2016-04-21 14:03:52');
INSERT INTO `iot_device_log` VALUES ('2354', '21', 'HUMIDITY', '2', '33.6', '33.6', '1', '2016-04-21 14:03:52');
INSERT INTO `iot_device_log` VALUES ('2355', '21', 'TEMPERATURE', '2', '38.68', '38.68', '1', '2016-04-21 14:04:02');
INSERT INTO `iot_device_log` VALUES ('2356', '21', 'HUMIDITY', '2', '33.71', '33.71', '1', '2016-04-21 14:04:02');
INSERT INTO `iot_device_log` VALUES ('2357', '21', 'TEMPERATURE', '2', '38.61', '38.61', '1', '2016-04-21 14:04:12');
INSERT INTO `iot_device_log` VALUES ('2358', '21', 'HUMIDITY', '2', '33.69', '33.69', '1', '2016-04-21 14:04:12');
INSERT INTO `iot_device_log` VALUES ('2359', '21', 'TEMPERATURE', '2', '38.78', '38.78', '1', '2016-04-21 14:04:22');
INSERT INTO `iot_device_log` VALUES ('2360', '21', 'HUMIDITY', '2', '33.8', '33.8', '1', '2016-04-21 14:04:22');
INSERT INTO `iot_device_log` VALUES ('2361', '21', 'TEMPERATURE', '2', '38.63', '38.63', '1', '2016-04-21 14:04:32');
INSERT INTO `iot_device_log` VALUES ('2362', '21', 'HUMIDITY', '2', '33.82', '33.82', '1', '2016-04-21 14:04:32');
INSERT INTO `iot_device_log` VALUES ('2363', '21', 'TEMPERATURE', '2', '38.55', '38.55', '1', '2016-04-21 14:04:42');
INSERT INTO `iot_device_log` VALUES ('2364', '21', 'HUMIDITY', '2', '33.83', '33.83', '1', '2016-04-21 14:04:42');
INSERT INTO `iot_device_log` VALUES ('2365', '21', 'TEMPERATURE', '2', '38.39', '38.39', '1', '2016-04-21 14:04:52');
INSERT INTO `iot_device_log` VALUES ('2366', '21', 'HUMIDITY', '2', '33.83', '33.83', '1', '2016-04-21 14:04:52');
INSERT INTO `iot_device_log` VALUES ('2367', '21', 'TEMPERATURE', '2', '38.42', '38.42', '1', '2016-04-21 14:05:02');
INSERT INTO `iot_device_log` VALUES ('2368', '21', 'HUMIDITY', '2', '33.71', '33.71', '1', '2016-04-21 14:05:02');
INSERT INTO `iot_device_log` VALUES ('2369', '21', 'TEMPERATURE', '2', '38.61', '38.61', '1', '2016-04-21 14:05:12');
INSERT INTO `iot_device_log` VALUES ('2370', '21', 'HUMIDITY', '2', '33.68', '33.68', '1', '2016-04-21 14:05:12');
INSERT INTO `iot_device_log` VALUES ('2371', '21', 'TEMPERATURE', '2', '38.61', '38.61', '1', '2016-04-21 14:05:22');
INSERT INTO `iot_device_log` VALUES ('2372', '21', 'HUMIDITY', '2', '33.46', '33.46', '1', '2016-04-21 14:05:22');
INSERT INTO `iot_device_log` VALUES ('2373', '21', 'TEMPERATURE', '2', '38.71', '38.71', '1', '2016-04-21 14:05:32');
INSERT INTO `iot_device_log` VALUES ('2374', '21', 'HUMIDITY', '2', '33.45', '33.45', '1', '2016-04-21 14:05:32');
INSERT INTO `iot_device_log` VALUES ('2375', '21', 'TEMPERATURE', '2', '38.72', '38.72', '1', '2016-04-21 14:05:42');
INSERT INTO `iot_device_log` VALUES ('2376', '21', 'HUMIDITY', '2', '33.54', '33.54', '1', '2016-04-21 14:05:42');
INSERT INTO `iot_device_log` VALUES ('2377', '21', 'TEMPERATURE', '2', '38.55', '38.55', '1', '2016-04-21 14:05:52');
INSERT INTO `iot_device_log` VALUES ('2378', '21', 'HUMIDITY', '2', '33.6', '33.6', '1', '2016-04-21 14:05:52');
INSERT INTO `iot_device_log` VALUES ('2379', '21', 'TEMPERATURE', '2', '38.59', '38.59', '1', '2016-04-21 14:06:02');
INSERT INTO `iot_device_log` VALUES ('2380', '21', 'HUMIDITY', '2', '33.52', '33.52', '1', '2016-04-21 14:06:02');
INSERT INTO `iot_device_log` VALUES ('2381', '21', 'TEMPERATURE', '2', '38.64', '38.64', '1', '2016-04-21 14:06:12');
INSERT INTO `iot_device_log` VALUES ('2382', '21', 'HUMIDITY', '2', '33.41', '33.41', '1', '2016-04-21 14:06:12');
INSERT INTO `iot_device_log` VALUES ('2383', '21', 'TEMPERATURE', '2', '38.56', '38.56', '1', '2016-04-21 14:06:22');
INSERT INTO `iot_device_log` VALUES ('2384', '21', 'HUMIDITY', '2', '33.47', '33.47', '1', '2016-04-21 14:06:22');
INSERT INTO `iot_device_log` VALUES ('2385', '21', 'TEMPERATURE', '2', '38.43', '38.43', '1', '2016-04-21 14:06:34');
INSERT INTO `iot_device_log` VALUES ('2386', '21', 'HUMIDITY', '2', '33.58', '33.58', '1', '2016-04-21 14:06:34');
INSERT INTO `iot_device_log` VALUES ('2387', '21', 'TEMPERATURE', '2', '38.2', '38.2', '1', '2016-04-21 14:06:42');
INSERT INTO `iot_device_log` VALUES ('2388', '21', 'HUMIDITY', '2', '33.78', '33.78', '1', '2016-04-21 14:06:42');
INSERT INTO `iot_device_log` VALUES ('2389', '21', 'TEMPERATURE', '2', '37.76', '37.76', '1', '2016-04-21 14:06:52');
INSERT INTO `iot_device_log` VALUES ('2390', '21', 'HUMIDITY', '2', '33.98', '33.98', '1', '2016-04-21 14:06:52');
INSERT INTO `iot_device_log` VALUES ('2391', '21', 'TEMPERATURE', '2', '37.52', '37.52', '1', '2016-04-21 14:07:03');
INSERT INTO `iot_device_log` VALUES ('2392', '21', 'HUMIDITY', '2', '34.19', '34.19', '1', '2016-04-21 14:07:03');
INSERT INTO `iot_device_log` VALUES ('2393', '21', 'TEMPERATURE', '2', '37.41', '37.41', '1', '2016-04-21 14:07:13');
INSERT INTO `iot_device_log` VALUES ('2394', '21', 'HUMIDITY', '2', '34.35', '34.35', '1', '2016-04-21 14:07:13');
INSERT INTO `iot_device_log` VALUES ('2395', '21', 'TEMPERATURE', '2', '37.05', '37.05', '1', '2016-04-21 14:07:23');
INSERT INTO `iot_device_log` VALUES ('2396', '21', 'HUMIDITY', '2', '34.53', '34.53', '1', '2016-04-21 14:07:23');
INSERT INTO `iot_device_log` VALUES ('2397', '21', 'TEMPERATURE', '2', '36.7', '36.7', '1', '2016-04-21 14:07:32');
INSERT INTO `iot_device_log` VALUES ('2398', '21', 'HUMIDITY', '2', '34.46', '34.46', '1', '2016-04-21 14:07:32');
INSERT INTO `iot_device_log` VALUES ('2399', '21', 'TEMPERATURE', '2', '36.91', '36.91', '1', '2016-04-21 14:07:42');
INSERT INTO `iot_device_log` VALUES ('2400', '21', 'HUMIDITY', '2', '34.6', '34.6', '1', '2016-04-21 14:07:42');
INSERT INTO `iot_device_log` VALUES ('2401', '21', 'TEMPERATURE', '2', '36.78', '36.78', '1', '2016-04-21 14:07:52');
INSERT INTO `iot_device_log` VALUES ('2402', '21', 'HUMIDITY', '2', '34.75', '34.75', '1', '2016-04-21 14:07:52');
INSERT INTO `iot_device_log` VALUES ('2403', '21', 'TEMPERATURE', '2', '36.45', '36.45', '1', '2016-04-21 14:08:02');
INSERT INTO `iot_device_log` VALUES ('2404', '21', 'HUMIDITY', '2', '34.93', '34.93', '1', '2016-04-21 14:08:02');
INSERT INTO `iot_device_log` VALUES ('2405', '21', 'TEMPERATURE', '2', '36.37', '36.37', '1', '2016-04-21 14:08:12');
INSERT INTO `iot_device_log` VALUES ('2406', '21', 'HUMIDITY', '2', '34.94', '34.94', '1', '2016-04-21 14:08:12');
INSERT INTO `iot_device_log` VALUES ('2407', '21', 'TEMPERATURE', '2', '36.5', '36.5', '1', '2016-04-21 14:08:22');
INSERT INTO `iot_device_log` VALUES ('2408', '21', 'HUMIDITY', '2', '34.79', '34.79', '1', '2016-04-21 14:08:22');
INSERT INTO `iot_device_log` VALUES ('2409', '21', 'TEMPERATURE', '2', '36.65', '36.65', '1', '2016-04-21 14:08:32');
INSERT INTO `iot_device_log` VALUES ('2410', '21', 'HUMIDITY', '2', '34.45', '34.45', '1', '2016-04-21 14:08:32');
INSERT INTO `iot_device_log` VALUES ('2411', '21', 'TEMPERATURE', '2', '36.92', '36.92', '1', '2016-04-21 14:08:42');
INSERT INTO `iot_device_log` VALUES ('2412', '21', 'HUMIDITY', '2', '34.42', '34.42', '1', '2016-04-21 14:08:42');
INSERT INTO `iot_device_log` VALUES ('2413', '21', 'TEMPERATURE', '2', '36.94', '36.94', '1', '2016-04-21 14:08:52');
INSERT INTO `iot_device_log` VALUES ('2414', '21', 'HUMIDITY', '2', '34.35', '34.35', '1', '2016-04-21 14:08:52');
INSERT INTO `iot_device_log` VALUES ('2415', '21', 'TEMPERATURE', '2', '36.8', '36.8', '1', '2016-04-21 14:09:02');
INSERT INTO `iot_device_log` VALUES ('2416', '21', 'HUMIDITY', '2', '34.41', '34.41', '1', '2016-04-21 14:09:02');
INSERT INTO `iot_device_log` VALUES ('2417', '21', 'TEMPERATURE', '2', '36.83', '36.83', '1', '2016-04-21 14:09:12');
INSERT INTO `iot_device_log` VALUES ('2418', '21', 'HUMIDITY', '2', '34.59', '34.59', '1', '2016-04-21 14:09:12');
INSERT INTO `iot_device_log` VALUES ('2419', '21', 'TEMPERATURE', '2', '37.03', '37.03', '1', '2016-04-21 14:09:22');
INSERT INTO `iot_device_log` VALUES ('2420', '21', 'HUMIDITY', '2', '34.5', '34.5', '1', '2016-04-21 14:09:22');
INSERT INTO `iot_device_log` VALUES ('2421', '21', 'TEMPERATURE', '2', '37.08', '37.08', '1', '2016-04-21 14:09:33');
INSERT INTO `iot_device_log` VALUES ('2422', '21', 'HUMIDITY', '2', '34.57', '34.57', '1', '2016-04-21 14:09:33');
INSERT INTO `iot_device_log` VALUES ('2423', '21', 'TEMPERATURE', '2', '36.72', '36.72', '1', '2016-04-21 14:09:42');
INSERT INTO `iot_device_log` VALUES ('2424', '21', 'HUMIDITY', '2', '34.68', '34.68', '1', '2016-04-21 14:09:42');
INSERT INTO `iot_device_log` VALUES ('2425', '21', 'TEMPERATURE', '2', '36.4', '36.4', '1', '2016-04-21 14:09:53');
INSERT INTO `iot_device_log` VALUES ('2426', '21', 'HUMIDITY', '2', '34.89', '34.89', '1', '2016-04-21 14:09:53');
INSERT INTO `iot_device_log` VALUES ('2427', '21', 'TEMPERATURE', '2', '36.72', '36.72', '1', '2016-04-21 14:10:02');
INSERT INTO `iot_device_log` VALUES ('2428', '21', 'HUMIDITY', '2', '34.75', '34.75', '1', '2016-04-21 14:10:02');
INSERT INTO `iot_device_log` VALUES ('2429', '21', 'TEMPERATURE', '2', '36.73', '36.73', '1', '2016-04-21 14:10:14');
INSERT INTO `iot_device_log` VALUES ('2430', '21', 'HUMIDITY', '2', '34.63', '34.63', '1', '2016-04-21 14:10:14');
INSERT INTO `iot_device_log` VALUES ('2431', '21', 'TEMPERATURE', '2', '36.89', '36.89', '1', '2016-04-21 14:10:22');
INSERT INTO `iot_device_log` VALUES ('2432', '21', 'HUMIDITY', '2', '34.63', '34.63', '1', '2016-04-21 14:10:22');
INSERT INTO `iot_device_log` VALUES ('2433', '21', 'TEMPERATURE', '2', '36.91', '36.91', '1', '2016-04-21 14:10:32');
INSERT INTO `iot_device_log` VALUES ('2434', '21', 'HUMIDITY', '2', '34.56', '34.56', '1', '2016-04-21 14:10:32');
INSERT INTO `iot_device_log` VALUES ('2435', '21', 'TEMPERATURE', '2', '36.8', '36.8', '1', '2016-04-21 14:10:42');
INSERT INTO `iot_device_log` VALUES ('2436', '21', 'HUMIDITY', '2', '34.56', '34.56', '1', '2016-04-21 14:10:42');
INSERT INTO `iot_device_log` VALUES ('2437', '21', 'TEMPERATURE', '2', '36.78', '36.78', '1', '2016-04-21 14:10:52');
INSERT INTO `iot_device_log` VALUES ('2438', '21', 'HUMIDITY', '2', '34.59', '34.59', '1', '2016-04-21 14:10:52');
INSERT INTO `iot_device_log` VALUES ('2439', '21', 'TEMPERATURE', '2', '36.37', '36.37', '1', '2016-04-21 14:11:02');
INSERT INTO `iot_device_log` VALUES ('2440', '21', 'HUMIDITY', '2', '34.72', '34.72', '1', '2016-04-21 14:11:02');
INSERT INTO `iot_device_log` VALUES ('2441', '21', 'TEMPERATURE', '2', '36.55', '36.55', '1', '2016-04-21 14:11:13');
INSERT INTO `iot_device_log` VALUES ('2442', '21', 'HUMIDITY', '2', '34.45', '34.45', '1', '2016-04-21 14:11:13');
INSERT INTO `iot_device_log` VALUES ('2443', '21', 'TEMPERATURE', '2', '36.74', '36.74', '1', '2016-04-21 14:11:22');
INSERT INTO `iot_device_log` VALUES ('2444', '21', 'HUMIDITY', '2', '34.23', '34.23', '1', '2016-04-21 14:11:22');
INSERT INTO `iot_device_log` VALUES ('2445', '21', 'TEMPERATURE', '2', '36.69', '36.69', '1', '2016-04-21 14:11:32');
INSERT INTO `iot_device_log` VALUES ('2446', '21', 'HUMIDITY', '2', '34.2', '34.2', '1', '2016-04-21 14:11:32');
INSERT INTO `iot_device_log` VALUES ('2447', '21', 'TEMPERATURE', '2', '36.74', '36.74', '1', '2016-04-21 14:11:42');
INSERT INTO `iot_device_log` VALUES ('2448', '21', 'HUMIDITY', '2', '34.2', '34.2', '1', '2016-04-21 14:11:42');
INSERT INTO `iot_device_log` VALUES ('2449', '21', 'TEMPERATURE', '2', '36.98', '36.98', '1', '2016-04-21 14:11:52');
INSERT INTO `iot_device_log` VALUES ('2450', '21', 'HUMIDITY', '2', '34.09', '34.09', '1', '2016-04-21 14:11:52');
INSERT INTO `iot_device_log` VALUES ('2451', '21', 'TEMPERATURE', '2', '36.92', '36.92', '1', '2016-04-21 14:12:03');
INSERT INTO `iot_device_log` VALUES ('2452', '21', 'HUMIDITY', '2', '34.17', '34.17', '1', '2016-04-21 14:12:03');
INSERT INTO `iot_device_log` VALUES ('2453', '21', 'TEMPERATURE', '2', '36.62', '36.62', '1', '2016-04-21 14:12:12');
INSERT INTO `iot_device_log` VALUES ('2454', '21', 'HUMIDITY', '2', '34.55', '34.55', '1', '2016-04-21 14:12:12');
INSERT INTO `iot_device_log` VALUES ('2455', '21', 'TEMPERATURE', '2', '36.39', '36.39', '1', '2016-04-21 14:12:22');
INSERT INTO `iot_device_log` VALUES ('2456', '21', 'HUMIDITY', '2', '34.57', '34.57', '1', '2016-04-21 14:12:22');
INSERT INTO `iot_device_log` VALUES ('2457', '21', 'TEMPERATURE', '2', '36.21', '36.21', '1', '2016-04-21 14:12:32');
INSERT INTO `iot_device_log` VALUES ('2458', '21', 'HUMIDITY', '2', '34.75', '34.75', '1', '2016-04-21 14:12:32');
INSERT INTO `iot_device_log` VALUES ('2459', '21', 'TEMPERATURE', '2', '36.17', '36.17', '1', '2016-04-21 14:12:42');
INSERT INTO `iot_device_log` VALUES ('2460', '21', 'HUMIDITY', '2', '34.79', '34.79', '1', '2016-04-21 14:12:42');
INSERT INTO `iot_device_log` VALUES ('2461', '21', 'TEMPERATURE', '2', '35.84', '35.84', '1', '2016-04-21 14:12:52');
INSERT INTO `iot_device_log` VALUES ('2462', '21', 'HUMIDITY', '2', '34.98', '34.98', '1', '2016-04-21 14:12:52');
INSERT INTO `iot_device_log` VALUES ('2463', '21', 'TEMPERATURE', '2', '35.59', '35.59', '1', '2016-04-21 14:13:02');
INSERT INTO `iot_device_log` VALUES ('2464', '21', 'HUMIDITY', '2', '34.67', '34.67', '1', '2016-04-21 14:13:02');
INSERT INTO `iot_device_log` VALUES ('2465', '21', 'TEMPERATURE', '2', '35.79', '35.79', '1', '2016-04-21 14:13:12');
INSERT INTO `iot_device_log` VALUES ('2466', '21', 'HUMIDITY', '2', '34.66', '34.66', '1', '2016-04-21 14:13:12');
INSERT INTO `iot_device_log` VALUES ('2467', '21', 'TEMPERATURE', '2', '35.73', '35.73', '1', '2016-04-21 14:13:22');
INSERT INTO `iot_device_log` VALUES ('2468', '21', 'HUMIDITY', '2', '34.83', '34.83', '1', '2016-04-21 14:13:22');
INSERT INTO `iot_device_log` VALUES ('2469', '21', 'TEMPERATURE', '2', '35.56', '35.56', '1', '2016-04-21 14:13:32');
INSERT INTO `iot_device_log` VALUES ('2470', '21', 'HUMIDITY', '2', '34.91', '34.91', '1', '2016-04-21 14:13:32');
INSERT INTO `iot_device_log` VALUES ('2471', '21', 'TEMPERATURE', '2', '35.87', '35.87', '1', '2016-04-21 14:13:42');
INSERT INTO `iot_device_log` VALUES ('2472', '21', 'HUMIDITY', '2', '34.56', '34.56', '1', '2016-04-21 14:13:42');
INSERT INTO `iot_device_log` VALUES ('2473', '21', 'TEMPERATURE', '2', '35.23', '35.23', '1', '2016-04-21 14:13:53');
INSERT INTO `iot_device_log` VALUES ('2474', '21', 'HUMIDITY', '2', '34.61', '34.61', '1', '2016-04-21 14:13:53');
INSERT INTO `iot_device_log` VALUES ('2475', '21', 'TEMPERATURE', '2', '35.68', '35.68', '1', '2016-04-21 14:14:02');
INSERT INTO `iot_device_log` VALUES ('2476', '21', 'HUMIDITY', '2', '34.5', '34.5', '1', '2016-04-21 14:14:02');
INSERT INTO `iot_device_log` VALUES ('2477', '21', 'TEMPERATURE', '2', '35.65', '35.65', '1', '2016-04-21 14:14:12');
INSERT INTO `iot_device_log` VALUES ('2478', '21', 'HUMIDITY', '2', '34.39', '34.39', '1', '2016-04-21 14:14:12');
INSERT INTO `iot_device_log` VALUES ('2479', '21', 'TEMPERATURE', '2', '35.72', '35.72', '1', '2016-04-21 14:14:22');
INSERT INTO `iot_device_log` VALUES ('2480', '21', 'HUMIDITY', '2', '34.52', '34.52', '1', '2016-04-21 14:14:22');
INSERT INTO `iot_device_log` VALUES ('2481', '21', 'TEMPERATURE', '2', '35.36', '35.36', '1', '2016-04-21 14:14:32');
INSERT INTO `iot_device_log` VALUES ('2482', '21', 'HUMIDITY', '2', '34.76', '34.76', '1', '2016-04-21 14:14:32');
INSERT INTO `iot_device_log` VALUES ('2483', '21', 'TEMPERATURE', '2', '35.47', '35.47', '1', '2016-04-21 14:14:42');
INSERT INTO `iot_device_log` VALUES ('2484', '21', 'HUMIDITY', '2', '34.78', '34.78', '1', '2016-04-21 14:14:42');
INSERT INTO `iot_device_log` VALUES ('2485', '21', 'TEMPERATURE', '2', '35.35', '35.35', '1', '2016-04-21 14:14:52');
INSERT INTO `iot_device_log` VALUES ('2486', '21', 'HUMIDITY', '2', '34.63', '34.63', '1', '2016-04-21 14:14:52');
INSERT INTO `iot_device_log` VALUES ('2487', '21', 'TEMPERATURE', '2', '35.51', '35.51', '1', '2016-04-21 14:15:02');
INSERT INTO `iot_device_log` VALUES ('2488', '21', 'HUMIDITY', '2', '34.46', '34.46', '1', '2016-04-21 14:15:02');
INSERT INTO `iot_device_log` VALUES ('2489', '21', 'TEMPERATURE', '2', '35.64', '35.64', '1', '2016-04-21 14:15:12');
INSERT INTO `iot_device_log` VALUES ('2490', '21', 'HUMIDITY', '2', '34.53', '34.53', '1', '2016-04-21 14:15:12');
INSERT INTO `iot_device_log` VALUES ('2491', '21', 'TEMPERATURE', '2', '35.51', '35.51', '1', '2016-04-21 14:15:22');
INSERT INTO `iot_device_log` VALUES ('2492', '21', 'HUMIDITY', '2', '34.72', '34.72', '1', '2016-04-21 14:15:22');
INSERT INTO `iot_device_log` VALUES ('2493', '21', 'TEMPERATURE', '2', '35.22', '35.22', '1', '2016-04-21 14:15:32');
INSERT INTO `iot_device_log` VALUES ('2494', '21', 'HUMIDITY', '2', '34.89', '34.89', '1', '2016-04-21 14:15:32');
INSERT INTO `iot_device_log` VALUES ('2495', '21', 'TEMPERATURE', '2', '35.17', '35.17', '1', '2016-04-21 14:15:42');
INSERT INTO `iot_device_log` VALUES ('2496', '21', 'HUMIDITY', '2', '34.97', '34.97', '1', '2016-04-21 14:15:42');
INSERT INTO `iot_device_log` VALUES ('2497', '21', 'TEMPERATURE', '2', '34.97', '34.97', '1', '2016-04-21 14:15:52');
INSERT INTO `iot_device_log` VALUES ('2498', '21', 'HUMIDITY', '2', '35.19', '35.19', '1', '2016-04-21 14:15:52');
INSERT INTO `iot_device_log` VALUES ('2499', '21', 'TEMPERATURE', '2', '34.99', '34.99', '1', '2016-04-21 14:16:02');
INSERT INTO `iot_device_log` VALUES ('2500', '21', 'HUMIDITY', '2', '35.21', '35.21', '1', '2016-04-21 14:16:02');
INSERT INTO `iot_device_log` VALUES ('2501', '21', 'TEMPERATURE', '2', '35.01', '35.01', '1', '2016-04-21 14:16:12');
INSERT INTO `iot_device_log` VALUES ('2502', '21', 'HUMIDITY', '2', '35.26', '35.26', '1', '2016-04-21 14:16:12');
INSERT INTO `iot_device_log` VALUES ('2503', '21', 'TEMPERATURE', '2', '35.17', '35.17', '1', '2016-04-21 14:16:22');
INSERT INTO `iot_device_log` VALUES ('2504', '21', 'HUMIDITY', '2', '35.1', '35.1', '1', '2016-04-21 14:16:22');
INSERT INTO `iot_device_log` VALUES ('2505', '21', 'TEMPERATURE', '2', '35.23', '35.23', '1', '2016-04-21 14:16:32');
INSERT INTO `iot_device_log` VALUES ('2506', '21', 'HUMIDITY', '2', '34.93', '34.93', '1', '2016-04-21 14:16:32');
INSERT INTO `iot_device_log` VALUES ('2507', '21', 'TEMPERATURE', '2', '35.17', '35.17', '1', '2016-04-21 14:16:42');
INSERT INTO `iot_device_log` VALUES ('2508', '21', 'HUMIDITY', '2', '34.9', '34.9', '1', '2016-04-21 14:16:42');
INSERT INTO `iot_device_log` VALUES ('2509', '22', 'BUTTON_1', '3', '4', '4', '1', '2016-04-21 14:21:40');
INSERT INTO `iot_device_log` VALUES ('2510', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:21:40');
INSERT INTO `iot_device_log` VALUES ('2511', '22', 'BUTTON_1', '3', '4', '4', '1', '2016-04-21 14:21:40');
INSERT INTO `iot_device_log` VALUES ('2512', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:21:40');
INSERT INTO `iot_device_log` VALUES ('2513', '22', 'BUTTON_1', '3', '3', '3', '1', '2016-04-21 14:21:40');
INSERT INTO `iot_device_log` VALUES ('2514', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:21:40');
INSERT INTO `iot_device_log` VALUES ('2515', '22', 'BUTTON_1', '3', '4', '4', '1', '2016-04-21 14:21:40');
INSERT INTO `iot_device_log` VALUES ('2516', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:21:40');
INSERT INTO `iot_device_log` VALUES ('2517', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:25:05');
INSERT INTO `iot_device_log` VALUES ('2518', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:25:58');
INSERT INTO `iot_device_log` VALUES ('2519', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:26:19');
INSERT INTO `iot_device_log` VALUES ('2520', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:26:19');
INSERT INTO `iot_device_log` VALUES ('2521', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:26:41');
INSERT INTO `iot_device_log` VALUES ('2522', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:26:41');
INSERT INTO `iot_device_log` VALUES ('2523', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:26:41');
INSERT INTO `iot_device_log` VALUES ('2524', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 14:26:45');
INSERT INTO `iot_device_log` VALUES ('2525', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:26:53');
INSERT INTO `iot_device_log` VALUES ('2526', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:27:00');
INSERT INTO `iot_device_log` VALUES ('2527', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:27:10');
INSERT INTO `iot_device_log` VALUES ('2528', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:27:24');
INSERT INTO `iot_device_log` VALUES ('2529', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:27:37');
INSERT INTO `iot_device_log` VALUES ('2530', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:27:37');
INSERT INTO `iot_device_log` VALUES ('2531', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:28:28');
INSERT INTO `iot_device_log` VALUES ('2532', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:28:29');
INSERT INTO `iot_device_log` VALUES ('2533', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:28:29');
INSERT INTO `iot_device_log` VALUES ('2534', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:28:29');
INSERT INTO `iot_device_log` VALUES ('2535', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:28:58');
INSERT INTO `iot_device_log` VALUES ('2536', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:28:58');
INSERT INTO `iot_device_log` VALUES ('2537', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:29:23');
INSERT INTO `iot_device_log` VALUES ('2538', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:29:23');
INSERT INTO `iot_device_log` VALUES ('2539', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:32:48');
INSERT INTO `iot_device_log` VALUES ('2540', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:32:51');
INSERT INTO `iot_device_log` VALUES ('2541', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:33:21');
INSERT INTO `iot_device_log` VALUES ('2542', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:33:24');
INSERT INTO `iot_device_log` VALUES ('2543', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:33:32');
INSERT INTO `iot_device_log` VALUES ('2544', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:33:42');
INSERT INTO `iot_device_log` VALUES ('2545', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:33:49');
INSERT INTO `iot_device_log` VALUES ('2546', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:33:51');
INSERT INTO `iot_device_log` VALUES ('2547', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:33:52');
INSERT INTO `iot_device_log` VALUES ('2548', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:33:54');
INSERT INTO `iot_device_log` VALUES ('2549', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:34:01');
INSERT INTO `iot_device_log` VALUES ('2550', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:34:11');
INSERT INTO `iot_device_log` VALUES ('2551', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:34:21');
INSERT INTO `iot_device_log` VALUES ('2552', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:41');
INSERT INTO `iot_device_log` VALUES ('2553', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:41');
INSERT INTO `iot_device_log` VALUES ('2554', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:42');
INSERT INTO `iot_device_log` VALUES ('2555', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:42');
INSERT INTO `iot_device_log` VALUES ('2556', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 14:35:43');
INSERT INTO `iot_device_log` VALUES ('2557', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 14:35:44');
INSERT INTO `iot_device_log` VALUES ('2558', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:44');
INSERT INTO `iot_device_log` VALUES ('2559', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:44');
INSERT INTO `iot_device_log` VALUES ('2560', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 14:35:45');
INSERT INTO `iot_device_log` VALUES ('2561', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 14:35:46');
INSERT INTO `iot_device_log` VALUES ('2562', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:49');
INSERT INTO `iot_device_log` VALUES ('2563', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:49');
INSERT INTO `iot_device_log` VALUES ('2564', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:50');
INSERT INTO `iot_device_log` VALUES ('2565', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:50');
INSERT INTO `iot_device_log` VALUES ('2566', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:50');
INSERT INTO `iot_device_log` VALUES ('2567', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:51');
INSERT INTO `iot_device_log` VALUES ('2568', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:51');
INSERT INTO `iot_device_log` VALUES ('2569', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:35:51');
INSERT INTO `iot_device_log` VALUES ('2570', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:35:51');
INSERT INTO `iot_device_log` VALUES ('2571', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:35:52');
INSERT INTO `iot_device_log` VALUES ('2572', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:35:54');
INSERT INTO `iot_device_log` VALUES ('2573', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:36:02');
INSERT INTO `iot_device_log` VALUES ('2574', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:36:10');
INSERT INTO `iot_device_log` VALUES ('2575', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:36:10');
INSERT INTO `iot_device_log` VALUES ('2576', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:36:23');
INSERT INTO `iot_device_log` VALUES ('2577', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:36:23');
INSERT INTO `iot_device_log` VALUES ('2578', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:50:14');
INSERT INTO `iot_device_log` VALUES ('2579', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:50:17');
INSERT INTO `iot_device_log` VALUES ('2580', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:50:38');
INSERT INTO `iot_device_log` VALUES ('2581', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:50:48');
INSERT INTO `iot_device_log` VALUES ('2582', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:43');
INSERT INTO `iot_device_log` VALUES ('2583', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:43');
INSERT INTO `iot_device_log` VALUES ('2584', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:47');
INSERT INTO `iot_device_log` VALUES ('2585', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:47');
INSERT INTO `iot_device_log` VALUES ('2586', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:51');
INSERT INTO `iot_device_log` VALUES ('2587', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:51');
INSERT INTO `iot_device_log` VALUES ('2588', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:51');
INSERT INTO `iot_device_log` VALUES ('2589', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:51');
INSERT INTO `iot_device_log` VALUES ('2590', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:52');
INSERT INTO `iot_device_log` VALUES ('2591', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:53');
INSERT INTO `iot_device_log` VALUES ('2592', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:53');
INSERT INTO `iot_device_log` VALUES ('2593', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:53');
INSERT INTO `iot_device_log` VALUES ('2594', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:53');
INSERT INTO `iot_device_log` VALUES ('2595', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:53');
INSERT INTO `iot_device_log` VALUES ('2596', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:53');
INSERT INTO `iot_device_log` VALUES ('2597', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:53');
INSERT INTO `iot_device_log` VALUES ('2598', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:53');
INSERT INTO `iot_device_log` VALUES ('2599', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:53');
INSERT INTO `iot_device_log` VALUES ('2600', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 14:51:53');
INSERT INTO `iot_device_log` VALUES ('2601', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:54:02');
INSERT INTO `iot_device_log` VALUES ('2602', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:54:49');
INSERT INTO `iot_device_log` VALUES ('2603', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 14:54:49');
INSERT INTO `iot_device_log` VALUES ('2604', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:59:42');
INSERT INTO `iot_device_log` VALUES ('2605', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 14:59:52');
INSERT INTO `iot_device_log` VALUES ('2606', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:09:12');
INSERT INTO `iot_device_log` VALUES ('2607', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:09:14');
INSERT INTO `iot_device_log` VALUES ('2608', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:09:14');
INSERT INTO `iot_device_log` VALUES ('2609', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:09:25');
INSERT INTO `iot_device_log` VALUES ('2610', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:09:26');
INSERT INTO `iot_device_log` VALUES ('2611', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:09:31');
INSERT INTO `iot_device_log` VALUES ('2612', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:12:25');
INSERT INTO `iot_device_log` VALUES ('2613', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:12:25');
INSERT INTO `iot_device_log` VALUES ('2614', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:12:25');
INSERT INTO `iot_device_log` VALUES ('2615', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:12:25');
INSERT INTO `iot_device_log` VALUES ('2616', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:12:25');
INSERT INTO `iot_device_log` VALUES ('2617', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:12:25');
INSERT INTO `iot_device_log` VALUES ('2618', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:12:25');
INSERT INTO `iot_device_log` VALUES ('2619', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:12:25');
INSERT INTO `iot_device_log` VALUES ('2620', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:13:14');
INSERT INTO `iot_device_log` VALUES ('2621', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:13:24');
INSERT INTO `iot_device_log` VALUES ('2622', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:14:46');
INSERT INTO `iot_device_log` VALUES ('2623', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:14:53');
INSERT INTO `iot_device_log` VALUES ('2624', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:15:00');
INSERT INTO `iot_device_log` VALUES ('2625', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:22:03');
INSERT INTO `iot_device_log` VALUES ('2626', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:22:07');
INSERT INTO `iot_device_log` VALUES ('2627', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:22:07');
INSERT INTO `iot_device_log` VALUES ('2628', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:22:08');
INSERT INTO `iot_device_log` VALUES ('2629', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:22:08');
INSERT INTO `iot_device_log` VALUES ('2630', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:22:15');
INSERT INTO `iot_device_log` VALUES ('2631', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:22:47');
INSERT INTO `iot_device_log` VALUES ('2632', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:22:47');
INSERT INTO `iot_device_log` VALUES ('2633', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:22:54');
INSERT INTO `iot_device_log` VALUES ('2634', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:23:32');
INSERT INTO `iot_device_log` VALUES ('2635', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:24:09');
INSERT INTO `iot_device_log` VALUES ('2636', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:24:09');
INSERT INTO `iot_device_log` VALUES ('2637', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:24:09');
INSERT INTO `iot_device_log` VALUES ('2638', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:24:09');
INSERT INTO `iot_device_log` VALUES ('2639', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:24:09');
INSERT INTO `iot_device_log` VALUES ('2640', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:24:11');
INSERT INTO `iot_device_log` VALUES ('2641', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:24:11');
INSERT INTO `iot_device_log` VALUES ('2642', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:24:12');
INSERT INTO `iot_device_log` VALUES ('2643', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 15:24:19');
INSERT INTO `iot_device_log` VALUES ('2644', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 15:30:32');
INSERT INTO `iot_device_log` VALUES ('2645', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 15:30:47');
INSERT INTO `iot_device_log` VALUES ('2646', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 15:30:47');
INSERT INTO `iot_device_log` VALUES ('2647', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 15:30:56');
INSERT INTO `iot_device_log` VALUES ('2648', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 15:31:15');
INSERT INTO `iot_device_log` VALUES ('2649', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 15:31:20');
INSERT INTO `iot_device_log` VALUES ('2650', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 15:32:29');
INSERT INTO `iot_device_log` VALUES ('2651', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 15:38:28');
INSERT INTO `iot_device_log` VALUES ('2652', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 15:40:21');
INSERT INTO `iot_device_log` VALUES ('2653', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 15:40:28');
INSERT INTO `iot_device_log` VALUES ('2654', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:10:14');
INSERT INTO `iot_device_log` VALUES ('2655', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:10:14');
INSERT INTO `iot_device_log` VALUES ('2656', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:10:14');
INSERT INTO `iot_device_log` VALUES ('2657', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:10:14');
INSERT INTO `iot_device_log` VALUES ('2658', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:10:14');
INSERT INTO `iot_device_log` VALUES ('2659', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:10:14');
INSERT INTO `iot_device_log` VALUES ('2660', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:10:14');
INSERT INTO `iot_device_log` VALUES ('2661', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:16:42');
INSERT INTO `iot_device_log` VALUES ('2662', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:16:46');
INSERT INTO `iot_device_log` VALUES ('2663', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2664', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2665', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2666', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2667', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2668', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2669', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2670', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2671', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2672', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2673', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2674', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:31:43');
INSERT INTO `iot_device_log` VALUES ('2675', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 16:33:13');
INSERT INTO `iot_device_log` VALUES ('2676', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 16:33:13');
INSERT INTO `iot_device_log` VALUES ('2677', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 16:33:13');
INSERT INTO `iot_device_log` VALUES ('2678', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 16:33:15');
INSERT INTO `iot_device_log` VALUES ('2679', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 16:33:15');
INSERT INTO `iot_device_log` VALUES ('2680', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 16:33:22');
INSERT INTO `iot_device_log` VALUES ('2681', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:35:44');
INSERT INTO `iot_device_log` VALUES ('2682', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:35:50');
INSERT INTO `iot_device_log` VALUES ('2683', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 16:36:06');
INSERT INTO `iot_device_log` VALUES ('2684', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 16:36:06');
INSERT INTO `iot_device_log` VALUES ('2685', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:36:11');
INSERT INTO `iot_device_log` VALUES ('2686', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:36:13');
INSERT INTO `iot_device_log` VALUES ('2687', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 16:36:17');
INSERT INTO `iot_device_log` VALUES ('2688', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:36:22');
INSERT INTO `iot_device_log` VALUES ('2689', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:36:37');
INSERT INTO `iot_device_log` VALUES ('2690', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:36:44');
INSERT INTO `iot_device_log` VALUES ('2691', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:36:51');
INSERT INTO `iot_device_log` VALUES ('2692', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:36:56');
INSERT INTO `iot_device_log` VALUES ('2693', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:37:05');
INSERT INTO `iot_device_log` VALUES ('2694', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:37:09');
INSERT INTO `iot_device_log` VALUES ('2695', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:37:12');
INSERT INTO `iot_device_log` VALUES ('2696', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:53:20');
INSERT INTO `iot_device_log` VALUES ('2697', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 16:54:08');
INSERT INTO `iot_device_log` VALUES ('2698', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 16:54:17');
INSERT INTO `iot_device_log` VALUES ('2699', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 16:54:20');
INSERT INTO `iot_device_log` VALUES ('2700', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 16:54:22');
INSERT INTO `iot_device_log` VALUES ('2701', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 16:59:21');
INSERT INTO `iot_device_log` VALUES ('2702', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 17:00:14');
INSERT INTO `iot_device_log` VALUES ('2703', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 17:09:33');
INSERT INTO `iot_device_log` VALUES ('2704', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 17:09:35');
INSERT INTO `iot_device_log` VALUES ('2705', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:09:37');
INSERT INTO `iot_device_log` VALUES ('2706', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 17:09:39');
INSERT INTO `iot_device_log` VALUES ('2707', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 17:09:41');
INSERT INTO `iot_device_log` VALUES ('2708', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 17:09:42');
INSERT INTO `iot_device_log` VALUES ('2709', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 17:09:44');
INSERT INTO `iot_device_log` VALUES ('2710', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 17:21:19');
INSERT INTO `iot_device_log` VALUES ('2711', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 17:22:09');
INSERT INTO `iot_device_log` VALUES ('2712', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 17:23:11');
INSERT INTO `iot_device_log` VALUES ('2713', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 17:23:23');
INSERT INTO `iot_device_log` VALUES ('2714', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 17:23:30');
INSERT INTO `iot_device_log` VALUES ('2715', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:23:34');
INSERT INTO `iot_device_log` VALUES ('2716', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 17:24:21');
INSERT INTO `iot_device_log` VALUES ('2717', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:24:40');
INSERT INTO `iot_device_log` VALUES ('2718', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:24:47');
INSERT INTO `iot_device_log` VALUES ('2719', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:25:03');
INSERT INTO `iot_device_log` VALUES ('2720', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:25:11');
INSERT INTO `iot_device_log` VALUES ('2721', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 17:25:26');
INSERT INTO `iot_device_log` VALUES ('2722', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 17:25:33');
INSERT INTO `iot_device_log` VALUES ('2723', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 17:25:40');
INSERT INTO `iot_device_log` VALUES ('2724', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:45:04');
INSERT INTO `iot_device_log` VALUES ('2725', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 17:45:16');
INSERT INTO `iot_device_log` VALUES ('2726', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 17:45:20');
INSERT INTO `iot_device_log` VALUES ('2727', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 17:45:24');
INSERT INTO `iot_device_log` VALUES ('2728', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 17:45:31');
INSERT INTO `iot_device_log` VALUES ('2729', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:45:38');
INSERT INTO `iot_device_log` VALUES ('2730', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:45:40');
INSERT INTO `iot_device_log` VALUES ('2731', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:45:41');
INSERT INTO `iot_device_log` VALUES ('2732', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:45:43');
INSERT INTO `iot_device_log` VALUES ('2733', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:45:47');
INSERT INTO `iot_device_log` VALUES ('2734', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:45:48');
INSERT INTO `iot_device_log` VALUES ('2735', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 17:45:49');
INSERT INTO `iot_device_log` VALUES ('2736', '21', 'TEMPERATURE', '2', '64.26', '64.26', '1', '2016-04-21 18:10:22');
INSERT INTO `iot_device_log` VALUES ('2737', '21', 'HUMIDITY', '2', '26.11', '26.11', '1', '2016-04-21 18:10:22');
INSERT INTO `iot_device_log` VALUES ('2738', '21', 'TEMPERATURE', '2', '61.26', '61.26', '1', '2016-04-21 18:10:31');
INSERT INTO `iot_device_log` VALUES ('2739', '21', 'HUMIDITY', '2', '26.82', '26.82', '1', '2016-04-21 18:10:31');
INSERT INTO `iot_device_log` VALUES ('2740', '21', 'TEMPERATURE', '2', '58.57', '58.57', '1', '2016-04-21 18:10:42');
INSERT INTO `iot_device_log` VALUES ('2741', '21', 'HUMIDITY', '2', '27.45', '27.45', '1', '2016-04-21 18:10:42');
INSERT INTO `iot_device_log` VALUES ('2742', '21', 'TEMPERATURE', '2', '56.75', '56.75', '1', '2016-04-21 18:10:51');
INSERT INTO `iot_device_log` VALUES ('2743', '21', 'HUMIDITY', '2', '27.9', '27.9', '1', '2016-04-21 18:10:51');
INSERT INTO `iot_device_log` VALUES ('2744', '21', 'TEMPERATURE', '2', '55.21', '55.21', '1', '2016-04-21 18:11:01');
INSERT INTO `iot_device_log` VALUES ('2745', '21', 'HUMIDITY', '2', '28.36', '28.36', '1', '2016-04-21 18:11:01');
INSERT INTO `iot_device_log` VALUES ('2746', '21', 'TEMPERATURE', '2', '53.95', '53.95', '1', '2016-04-21 18:11:13');
INSERT INTO `iot_device_log` VALUES ('2747', '21', 'HUMIDITY', '2', '28.73', '28.73', '1', '2016-04-21 18:11:13');
INSERT INTO `iot_device_log` VALUES ('2748', '21', 'TEMPERATURE', '2', '52.89', '52.89', '1', '2016-04-21 18:11:22');
INSERT INTO `iot_device_log` VALUES ('2749', '21', 'HUMIDITY', '2', '29.04', '29.04', '1', '2016-04-21 18:11:22');
INSERT INTO `iot_device_log` VALUES ('2750', '21', 'TEMPERATURE', '2', '51.93', '51.93', '1', '2016-04-21 18:11:32');
INSERT INTO `iot_device_log` VALUES ('2751', '21', 'HUMIDITY', '2', '29.4', '29.4', '1', '2016-04-21 18:11:32');
INSERT INTO `iot_device_log` VALUES ('2752', '21', 'TEMPERATURE', '2', '51.07', '51.07', '1', '2016-04-21 18:11:41');
INSERT INTO `iot_device_log` VALUES ('2753', '21', 'HUMIDITY', '2', '29.72', '29.72', '1', '2016-04-21 18:11:41');
INSERT INTO `iot_device_log` VALUES ('2754', '21', 'TEMPERATURE', '2', '50.14', '50.14', '1', '2016-04-21 18:11:51');
INSERT INTO `iot_device_log` VALUES ('2755', '21', 'HUMIDITY', '2', '30.05', '30.05', '1', '2016-04-21 18:11:51');
INSERT INTO `iot_device_log` VALUES ('2756', '21', 'TEMPERATURE', '2', '49.5', '49.5', '1', '2016-04-21 18:12:01');
INSERT INTO `iot_device_log` VALUES ('2757', '21', 'HUMIDITY', '2', '30.2', '30.2', '1', '2016-04-21 18:12:01');
INSERT INTO `iot_device_log` VALUES ('2758', '21', 'TEMPERATURE', '2', '69.29', '69.29', '1', '2016-04-21 18:12:34');
INSERT INTO `iot_device_log` VALUES ('2759', '21', 'HUMIDITY', '2', '31.72', '31.72', '1', '2016-04-21 18:12:34');
INSERT INTO `iot_device_log` VALUES ('2760', '21', 'TEMPERATURE', '2', '71.35', '71.35', '1', '2016-04-21 18:12:34');
INSERT INTO `iot_device_log` VALUES ('2761', '21', 'HUMIDITY', '2', '34.5', '34.5', '1', '2016-04-21 18:12:34');
INSERT INTO `iot_device_log` VALUES ('2762', '21', 'TEMPERATURE', '2', '49.13', '49.13', '1', '2016-04-21 18:12:41');
INSERT INTO `iot_device_log` VALUES ('2763', '21', 'HUMIDITY', '2', '33.98', '33.98', '1', '2016-04-21 18:12:41');
INSERT INTO `iot_device_log` VALUES ('2764', '21', 'TEMPERATURE', '2', '47.55', '47.55', '1', '2016-04-21 18:12:51');
INSERT INTO `iot_device_log` VALUES ('2765', '21', 'HUMIDITY', '2', '33.41', '33.41', '1', '2016-04-21 18:12:51');
INSERT INTO `iot_device_log` VALUES ('2766', '21', 'TEMPERATURE', '2', '46.7', '46.7', '1', '2016-04-21 18:13:01');
INSERT INTO `iot_device_log` VALUES ('2767', '21', 'HUMIDITY', '2', '33.16', '33.16', '1', '2016-04-21 18:13:01');
INSERT INTO `iot_device_log` VALUES ('2768', '21', 'TEMPERATURE', '2', '46.13', '46.13', '1', '2016-04-21 18:13:11');
INSERT INTO `iot_device_log` VALUES ('2769', '21', 'HUMIDITY', '2', '33.03', '33.03', '1', '2016-04-21 18:13:11');
INSERT INTO `iot_device_log` VALUES ('2770', '21', 'TEMPERATURE', '2', '45.94', '45.94', '1', '2016-04-21 18:13:21');
INSERT INTO `iot_device_log` VALUES ('2771', '21', 'HUMIDITY', '2', '32.88', '32.88', '1', '2016-04-21 18:13:21');
INSERT INTO `iot_device_log` VALUES ('2772', '21', 'TEMPERATURE', '2', '45.6', '45.6', '1', '2016-04-21 18:13:32');
INSERT INTO `iot_device_log` VALUES ('2773', '21', 'HUMIDITY', '2', '32.82', '32.82', '1', '2016-04-21 18:13:32');
INSERT INTO `iot_device_log` VALUES ('2774', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-21 18:13:41');
INSERT INTO `iot_device_log` VALUES ('2775', '21', 'HUMIDITY', '2', '32.85', '32.85', '1', '2016-04-21 18:13:41');
INSERT INTO `iot_device_log` VALUES ('2776', '21', 'TEMPERATURE', '2', '44.83', '44.83', '1', '2016-04-21 18:13:56');
INSERT INTO `iot_device_log` VALUES ('2777', '21', 'HUMIDITY', '2', '32.99', '32.99', '1', '2016-04-21 18:13:56');
INSERT INTO `iot_device_log` VALUES ('2778', '21', 'TEMPERATURE', '2', '44.21', '44.21', '1', '2016-04-21 18:14:01');
INSERT INTO `iot_device_log` VALUES ('2779', '21', 'HUMIDITY', '2', '33.34', '33.34', '1', '2016-04-21 18:14:01');
INSERT INTO `iot_device_log` VALUES ('2780', '21', 'TEMPERATURE', '2', '43.96', '43.96', '1', '2016-04-21 18:14:11');
INSERT INTO `iot_device_log` VALUES ('2781', '21', 'HUMIDITY', '2', '33.35', '33.35', '1', '2016-04-21 18:14:11');
INSERT INTO `iot_device_log` VALUES ('2782', '21', 'TEMPERATURE', '2', '43.91', '43.91', '1', '2016-04-21 18:14:22');
INSERT INTO `iot_device_log` VALUES ('2783', '21', 'HUMIDITY', '2', '33.39', '33.39', '1', '2016-04-21 18:14:22');
INSERT INTO `iot_device_log` VALUES ('2784', '21', 'TEMPERATURE', '2', '43.67', '43.67', '1', '2016-04-21 18:14:31');
INSERT INTO `iot_device_log` VALUES ('2785', '21', 'HUMIDITY', '2', '33.37', '33.37', '1', '2016-04-21 18:14:31');
INSERT INTO `iot_device_log` VALUES ('2786', '21', 'TEMPERATURE', '2', '43.74', '43.74', '1', '2016-04-21 18:14:41');
INSERT INTO `iot_device_log` VALUES ('2787', '21', 'HUMIDITY', '2', '33.37', '33.37', '1', '2016-04-21 18:14:41');
INSERT INTO `iot_device_log` VALUES ('2788', '21', 'TEMPERATURE', '2', '43.92', '43.92', '1', '2016-04-21 18:14:51');
INSERT INTO `iot_device_log` VALUES ('2789', '21', 'HUMIDITY', '2', '33.19', '33.19', '1', '2016-04-21 18:14:51');
INSERT INTO `iot_device_log` VALUES ('2790', '21', 'TEMPERATURE', '2', '43.86', '43.86', '1', '2016-04-21 18:15:01');
INSERT INTO `iot_device_log` VALUES ('2791', '21', 'HUMIDITY', '2', '33.19', '33.19', '1', '2016-04-21 18:15:01');
INSERT INTO `iot_device_log` VALUES ('2792', '21', 'TEMPERATURE', '2', '43.96', '43.96', '1', '2016-04-21 18:15:11');
INSERT INTO `iot_device_log` VALUES ('2793', '21', 'HUMIDITY', '2', '33.02', '33.02', '1', '2016-04-21 18:15:11');
INSERT INTO `iot_device_log` VALUES ('2794', '21', 'TEMPERATURE', '2', '44.23', '44.23', '1', '2016-04-21 18:15:21');
INSERT INTO `iot_device_log` VALUES ('2795', '21', 'HUMIDITY', '2', '32.82', '32.82', '1', '2016-04-21 18:15:21');
INSERT INTO `iot_device_log` VALUES ('2796', '21', 'TEMPERATURE', '2', '44.53', '44.53', '1', '2016-04-21 18:15:31');
INSERT INTO `iot_device_log` VALUES ('2797', '21', 'HUMIDITY', '2', '32.69', '32.69', '1', '2016-04-21 18:15:31');
INSERT INTO `iot_device_log` VALUES ('2798', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-21 18:15:41');
INSERT INTO `iot_device_log` VALUES ('2799', '21', 'HUMIDITY', '2', '32.59', '32.59', '1', '2016-04-21 18:15:41');
INSERT INTO `iot_device_log` VALUES ('2800', '21', 'TEMPERATURE', '2', '44.96', '44.96', '1', '2016-04-21 18:15:51');
INSERT INTO `iot_device_log` VALUES ('2801', '21', 'HUMIDITY', '2', '32.41', '32.41', '1', '2016-04-21 18:15:51');
INSERT INTO `iot_device_log` VALUES ('2802', '21', 'TEMPERATURE', '2', '45.23', '45.23', '1', '2016-04-21 18:16:01');
INSERT INTO `iot_device_log` VALUES ('2803', '21', 'HUMIDITY', '2', '32.26', '32.26', '1', '2016-04-21 18:16:01');
INSERT INTO `iot_device_log` VALUES ('2804', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-21 18:16:11');
INSERT INTO `iot_device_log` VALUES ('2805', '21', 'HUMIDITY', '2', '32.29', '32.29', '1', '2016-04-21 18:16:11');
INSERT INTO `iot_device_log` VALUES ('2806', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-21 18:16:21');
INSERT INTO `iot_device_log` VALUES ('2807', '21', 'HUMIDITY', '2', '32.18', '32.18', '1', '2016-04-21 18:16:21');
INSERT INTO `iot_device_log` VALUES ('2808', '21', 'TEMPERATURE', '2', '45.73', '45.73', '1', '2016-04-21 18:16:31');
INSERT INTO `iot_device_log` VALUES ('2809', '21', 'HUMIDITY', '2', '32.11', '32.11', '1', '2016-04-21 18:16:31');
INSERT INTO `iot_device_log` VALUES ('2810', '21', 'TEMPERATURE', '2', '45.82', '45.82', '1', '2016-04-21 18:16:41');
INSERT INTO `iot_device_log` VALUES ('2811', '21', 'HUMIDITY', '2', '32.03', '32.03', '1', '2016-04-21 18:16:41');
INSERT INTO `iot_device_log` VALUES ('2812', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-21 18:16:51');
INSERT INTO `iot_device_log` VALUES ('2813', '21', 'HUMIDITY', '2', '32.11', '32.11', '1', '2016-04-21 18:16:51');
INSERT INTO `iot_device_log` VALUES ('2814', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 18:17:01');
INSERT INTO `iot_device_log` VALUES ('2815', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 18:17:01');
INSERT INTO `iot_device_log` VALUES ('2816', '21', 'TEMPERATURE', '2', '45.82', '45.82', '1', '2016-04-21 18:17:11');
INSERT INTO `iot_device_log` VALUES ('2817', '21', 'HUMIDITY', '2', '31.99', '31.99', '1', '2016-04-21 18:17:11');
INSERT INTO `iot_device_log` VALUES ('2818', '21', 'TEMPERATURE', '2', '45.67', '45.67', '1', '2016-04-21 18:17:21');
INSERT INTO `iot_device_log` VALUES ('2819', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 18:17:21');
INSERT INTO `iot_device_log` VALUES ('2820', '21', 'TEMPERATURE', '2', '45.43', '45.43', '1', '2016-04-21 18:17:31');
INSERT INTO `iot_device_log` VALUES ('2821', '21', 'HUMIDITY', '2', '32.16', '32.16', '1', '2016-04-21 18:17:31');
INSERT INTO `iot_device_log` VALUES ('2822', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-21 18:17:41');
INSERT INTO `iot_device_log` VALUES ('2823', '21', 'HUMIDITY', '2', '32.19', '32.19', '1', '2016-04-21 18:17:41');
INSERT INTO `iot_device_log` VALUES ('2824', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:17:51');
INSERT INTO `iot_device_log` VALUES ('2825', '21', 'HUMIDITY', '2', '32.12', '32.12', '1', '2016-04-21 18:17:51');
INSERT INTO `iot_device_log` VALUES ('2826', '21', 'TEMPERATURE', '2', '45.6', '45.6', '1', '2016-04-21 18:18:01');
INSERT INTO `iot_device_log` VALUES ('2827', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 18:18:01');
INSERT INTO `iot_device_log` VALUES ('2828', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-21 18:18:11');
INSERT INTO `iot_device_log` VALUES ('2829', '21', 'HUMIDITY', '2', '32.1', '32.1', '1', '2016-04-21 18:18:11');
INSERT INTO `iot_device_log` VALUES ('2830', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:18:21');
INSERT INTO `iot_device_log` VALUES ('2831', '21', 'HUMIDITY', '2', '32.11', '32.11', '1', '2016-04-21 18:18:21');
INSERT INTO `iot_device_log` VALUES ('2832', '21', 'TEMPERATURE', '2', '45.32', '45.32', '1', '2016-04-21 18:18:31');
INSERT INTO `iot_device_log` VALUES ('2833', '21', 'HUMIDITY', '2', '32.16', '32.16', '1', '2016-04-21 18:18:31');
INSERT INTO `iot_device_log` VALUES ('2834', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-21 18:18:42');
INSERT INTO `iot_device_log` VALUES ('2835', '21', 'HUMIDITY', '2', '32.05', '32.05', '1', '2016-04-21 18:18:42');
INSERT INTO `iot_device_log` VALUES ('2836', '21', 'TEMPERATURE', '2', '45.19', '45.19', '1', '2016-04-21 18:18:51');
INSERT INTO `iot_device_log` VALUES ('2837', '21', 'HUMIDITY', '2', '32.14', '32.14', '1', '2016-04-21 18:18:51');
INSERT INTO `iot_device_log` VALUES ('2838', '21', 'TEMPERATURE', '2', '44.98', '44.98', '1', '2016-04-21 18:19:01');
INSERT INTO `iot_device_log` VALUES ('2839', '21', 'HUMIDITY', '2', '32.21', '32.21', '1', '2016-04-21 18:19:01');
INSERT INTO `iot_device_log` VALUES ('2840', '21', 'TEMPERATURE', '2', '45.12', '45.12', '1', '2016-04-21 18:19:11');
INSERT INTO `iot_device_log` VALUES ('2841', '21', 'HUMIDITY', '2', '32.1', '32.1', '1', '2016-04-21 18:19:11');
INSERT INTO `iot_device_log` VALUES ('2842', '21', 'TEMPERATURE', '2', '45.11', '45.11', '1', '2016-04-21 18:19:21');
INSERT INTO `iot_device_log` VALUES ('2843', '21', 'HUMIDITY', '2', '32.14', '32.14', '1', '2016-04-21 18:19:21');
INSERT INTO `iot_device_log` VALUES ('2844', '21', 'TEMPERATURE', '2', '44.96', '44.96', '1', '2016-04-21 18:19:31');
INSERT INTO `iot_device_log` VALUES ('2845', '21', 'HUMIDITY', '2', '32.26', '32.26', '1', '2016-04-21 18:19:31');
INSERT INTO `iot_device_log` VALUES ('2846', '21', 'TEMPERATURE', '2', '45.13', '45.13', '1', '2016-04-21 18:19:41');
INSERT INTO `iot_device_log` VALUES ('2847', '21', 'HUMIDITY', '2', '32.12', '32.12', '1', '2016-04-21 18:19:41');
INSERT INTO `iot_device_log` VALUES ('2848', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-21 18:19:51');
INSERT INTO `iot_device_log` VALUES ('2849', '21', 'HUMIDITY', '2', '32.11', '32.11', '1', '2016-04-21 18:19:51');
INSERT INTO `iot_device_log` VALUES ('2850', '21', 'TEMPERATURE', '2', '45.26', '45.26', '1', '2016-04-21 18:20:01');
INSERT INTO `iot_device_log` VALUES ('2851', '21', 'HUMIDITY', '2', '32.14', '32.14', '1', '2016-04-21 18:20:01');
INSERT INTO `iot_device_log` VALUES ('2852', '21', 'TEMPERATURE', '2', '45.06', '45.06', '1', '2016-04-21 18:20:11');
INSERT INTO `iot_device_log` VALUES ('2853', '21', 'HUMIDITY', '2', '32.27', '32.27', '1', '2016-04-21 18:20:11');
INSERT INTO `iot_device_log` VALUES ('2854', '21', 'TEMPERATURE', '2', '45.26', '45.26', '1', '2016-04-21 18:20:21');
INSERT INTO `iot_device_log` VALUES ('2855', '21', 'HUMIDITY', '2', '32.16', '32.16', '1', '2016-04-21 18:20:21');
INSERT INTO `iot_device_log` VALUES ('2856', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-21 18:20:32');
INSERT INTO `iot_device_log` VALUES ('2857', '21', 'HUMIDITY', '2', '31.96', '31.96', '1', '2016-04-21 18:20:32');
INSERT INTO `iot_device_log` VALUES ('2858', '21', 'TEMPERATURE', '2', '45.49', '45.49', '1', '2016-04-21 18:20:41');
INSERT INTO `iot_device_log` VALUES ('2859', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-21 18:20:41');
INSERT INTO `iot_device_log` VALUES ('2860', '21', 'TEMPERATURE', '2', '45.74', '45.74', '1', '2016-04-21 18:20:51');
INSERT INTO `iot_device_log` VALUES ('2861', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-21 18:20:51');
INSERT INTO `iot_device_log` VALUES ('2862', '21', 'TEMPERATURE', '2', '45.96', '45.96', '1', '2016-04-21 18:21:01');
INSERT INTO `iot_device_log` VALUES ('2863', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-21 18:21:01');
INSERT INTO `iot_device_log` VALUES ('2864', '21', 'TEMPERATURE', '2', '45.49', '45.49', '1', '2016-04-21 18:21:13');
INSERT INTO `iot_device_log` VALUES ('2865', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-21 18:21:13');
INSERT INTO `iot_device_log` VALUES ('2866', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-21 18:21:21');
INSERT INTO `iot_device_log` VALUES ('2867', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-21 18:21:21');
INSERT INTO `iot_device_log` VALUES ('2868', '21', 'TEMPERATURE', '2', '45.56', '45.56', '1', '2016-04-21 18:21:31');
INSERT INTO `iot_device_log` VALUES ('2869', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-21 18:21:31');
INSERT INTO `iot_device_log` VALUES ('2870', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 18:21:43');
INSERT INTO `iot_device_log` VALUES ('2871', '21', 'HUMIDITY', '2', '31.93', '31.93', '1', '2016-04-21 18:21:43');
INSERT INTO `iot_device_log` VALUES ('2872', '21', 'TEMPERATURE', '2', '45.79', '45.79', '1', '2016-04-21 18:21:51');
INSERT INTO `iot_device_log` VALUES ('2873', '21', 'HUMIDITY', '2', '32.12', '32.12', '1', '2016-04-21 18:21:51');
INSERT INTO `iot_device_log` VALUES ('2874', '21', 'TEMPERATURE', '2', '45.06', '45.06', '1', '2016-04-21 18:22:01');
INSERT INTO `iot_device_log` VALUES ('2875', '21', 'HUMIDITY', '2', '32.25', '32.25', '1', '2016-04-21 18:22:01');
INSERT INTO `iot_device_log` VALUES ('2876', '21', 'TEMPERATURE', '2', '44.84', '44.84', '1', '2016-04-21 18:22:11');
INSERT INTO `iot_device_log` VALUES ('2877', '21', 'HUMIDITY', '2', '32.18', '32.18', '1', '2016-04-21 18:22:11');
INSERT INTO `iot_device_log` VALUES ('2878', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-21 18:22:21');
INSERT INTO `iot_device_log` VALUES ('2879', '21', 'HUMIDITY', '2', '32.33', '32.33', '1', '2016-04-21 18:22:21');
INSERT INTO `iot_device_log` VALUES ('2880', '21', 'TEMPERATURE', '2', '44.52', '44.52', '1', '2016-04-21 18:22:31');
INSERT INTO `iot_device_log` VALUES ('2881', '21', 'HUMIDITY', '2', '32.3', '32.3', '1', '2016-04-21 18:22:31');
INSERT INTO `iot_device_log` VALUES ('2882', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-21 18:22:41');
INSERT INTO `iot_device_log` VALUES ('2883', '21', 'HUMIDITY', '2', '32.25', '32.25', '1', '2016-04-21 18:22:41');
INSERT INTO `iot_device_log` VALUES ('2884', '21', 'TEMPERATURE', '2', '44.52', '44.52', '1', '2016-04-21 18:22:52');
INSERT INTO `iot_device_log` VALUES ('2885', '21', 'HUMIDITY', '2', '32.33', '32.33', '1', '2016-04-21 18:22:52');
INSERT INTO `iot_device_log` VALUES ('2886', '21', 'TEMPERATURE', '2', '44.65', '44.65', '1', '2016-04-21 18:23:02');
INSERT INTO `iot_device_log` VALUES ('2887', '21', 'HUMIDITY', '2', '32.26', '32.26', '1', '2016-04-21 18:23:02');
INSERT INTO `iot_device_log` VALUES ('2888', '21', 'TEMPERATURE', '2', '44.85', '44.85', '1', '2016-04-21 18:23:11');
INSERT INTO `iot_device_log` VALUES ('2889', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 18:23:11');
INSERT INTO `iot_device_log` VALUES ('2890', '21', 'TEMPERATURE', '2', '45.1', '45.1', '1', '2016-04-21 18:23:21');
INSERT INTO `iot_device_log` VALUES ('2891', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-21 18:23:21');
INSERT INTO `iot_device_log` VALUES ('2892', '21', 'TEMPERATURE', '2', '45.09', '45.09', '1', '2016-04-21 18:23:31');
INSERT INTO `iot_device_log` VALUES ('2893', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-21 18:23:31');
INSERT INTO `iot_device_log` VALUES ('2894', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-21 18:23:41');
INSERT INTO `iot_device_log` VALUES ('2895', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-21 18:23:41');
INSERT INTO `iot_device_log` VALUES ('2896', '21', 'TEMPERATURE', '2', '45.82', '45.82', '1', '2016-04-21 18:23:52');
INSERT INTO `iot_device_log` VALUES ('2897', '21', 'HUMIDITY', '2', '31.69', '31.69', '1', '2016-04-21 18:23:52');
INSERT INTO `iot_device_log` VALUES ('2898', '21', 'TEMPERATURE', '2', '45.52', '45.52', '1', '2016-04-21 18:24:01');
INSERT INTO `iot_device_log` VALUES ('2899', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-21 18:24:01');
INSERT INTO `iot_device_log` VALUES ('2900', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-21 18:24:11');
INSERT INTO `iot_device_log` VALUES ('2901', '21', 'HUMIDITY', '2', '31.76', '31.76', '1', '2016-04-21 18:24:11');
INSERT INTO `iot_device_log` VALUES ('2902', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-21 18:24:21');
INSERT INTO `iot_device_log` VALUES ('2903', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-21 18:24:21');
INSERT INTO `iot_device_log` VALUES ('2904', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-21 18:24:31');
INSERT INTO `iot_device_log` VALUES ('2905', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-21 18:24:31');
INSERT INTO `iot_device_log` VALUES ('2906', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-21 18:24:43');
INSERT INTO `iot_device_log` VALUES ('2907', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-21 18:24:43');
INSERT INTO `iot_device_log` VALUES ('2908', '21', 'TEMPERATURE', '2', '45.43', '45.43', '1', '2016-04-21 18:24:51');
INSERT INTO `iot_device_log` VALUES ('2909', '21', 'HUMIDITY', '2', '31.73', '31.73', '1', '2016-04-21 18:24:51');
INSERT INTO `iot_device_log` VALUES ('2910', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-21 18:25:01');
INSERT INTO `iot_device_log` VALUES ('2911', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-21 18:25:01');
INSERT INTO `iot_device_log` VALUES ('2912', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 18:25:11');
INSERT INTO `iot_device_log` VALUES ('2913', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-21 18:25:11');
INSERT INTO `iot_device_log` VALUES ('2914', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-21 18:25:21');
INSERT INTO `iot_device_log` VALUES ('2915', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-21 18:25:21');
INSERT INTO `iot_device_log` VALUES ('2916', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 18:25:31');
INSERT INTO `iot_device_log` VALUES ('2917', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-21 18:25:31');
INSERT INTO `iot_device_log` VALUES ('2918', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-21 18:25:41');
INSERT INTO `iot_device_log` VALUES ('2919', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-21 18:25:41');
INSERT INTO `iot_device_log` VALUES ('2920', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-21 18:25:51');
INSERT INTO `iot_device_log` VALUES ('2921', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-21 18:25:51');
INSERT INTO `iot_device_log` VALUES ('2922', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-21 18:26:01');
INSERT INTO `iot_device_log` VALUES ('2923', '21', 'HUMIDITY', '2', '31.78', '31.78', '1', '2016-04-21 18:26:01');
INSERT INTO `iot_device_log` VALUES ('2924', '21', 'TEMPERATURE', '2', '46.31', '46.31', '1', '2016-04-21 18:26:11');
INSERT INTO `iot_device_log` VALUES ('2925', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-21 18:26:11');
INSERT INTO `iot_device_log` VALUES ('2926', '21', 'TEMPERATURE', '2', '46.29', '46.29', '1', '2016-04-21 18:26:21');
INSERT INTO `iot_device_log` VALUES ('2927', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-21 18:26:21');
INSERT INTO `iot_device_log` VALUES ('2928', '21', 'TEMPERATURE', '2', '46.38', '46.38', '1', '2016-04-21 18:26:31');
INSERT INTO `iot_device_log` VALUES ('2929', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-21 18:26:31');
INSERT INTO `iot_device_log` VALUES ('2930', '21', 'TEMPERATURE', '2', '46.45', '46.45', '1', '2016-04-21 18:26:41');
INSERT INTO `iot_device_log` VALUES ('2931', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-21 18:26:41');
INSERT INTO `iot_device_log` VALUES ('2932', '21', 'TEMPERATURE', '2', '46.5', '46.5', '1', '2016-04-21 18:26:51');
INSERT INTO `iot_device_log` VALUES ('2933', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-21 18:26:51');
INSERT INTO `iot_device_log` VALUES ('2934', '21', 'TEMPERATURE', '2', '46.56', '46.56', '1', '2016-04-21 18:27:01');
INSERT INTO `iot_device_log` VALUES ('2935', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-21 18:27:01');
INSERT INTO `iot_device_log` VALUES ('2936', '21', 'TEMPERATURE', '2', '46.17', '46.17', '1', '2016-04-21 18:27:11');
INSERT INTO `iot_device_log` VALUES ('2937', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-21 18:27:11');
INSERT INTO `iot_device_log` VALUES ('2938', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:27:21');
INSERT INTO `iot_device_log` VALUES ('2939', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-21 18:27:21');
INSERT INTO `iot_device_log` VALUES ('2940', '21', 'TEMPERATURE', '2', '45.12', '45.12', '1', '2016-04-21 18:27:31');
INSERT INTO `iot_device_log` VALUES ('2941', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 18:27:31');
INSERT INTO `iot_device_log` VALUES ('2942', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:27:41');
INSERT INTO `iot_device_log` VALUES ('2943', '21', 'HUMIDITY', '2', '32.23', '32.23', '1', '2016-04-21 18:27:41');
INSERT INTO `iot_device_log` VALUES ('2944', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-21 18:27:51');
INSERT INTO `iot_device_log` VALUES ('2945', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 18:27:51');
INSERT INTO `iot_device_log` VALUES ('2946', '21', 'TEMPERATURE', '2', '45.49', '45.49', '1', '2016-04-21 18:28:01');
INSERT INTO `iot_device_log` VALUES ('2947', '21', 'HUMIDITY', '2', '31.96', '31.96', '1', '2016-04-21 18:28:01');
INSERT INTO `iot_device_log` VALUES ('2948', '21', 'TEMPERATURE', '2', '45.3', '45.3', '1', '2016-04-21 18:28:12');
INSERT INTO `iot_device_log` VALUES ('2949', '21', 'HUMIDITY', '2', '31.97', '31.97', '1', '2016-04-21 18:28:12');
INSERT INTO `iot_device_log` VALUES ('2950', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-21 18:28:21');
INSERT INTO `iot_device_log` VALUES ('2951', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-21 18:28:21');
INSERT INTO `iot_device_log` VALUES ('2952', '21', 'TEMPERATURE', '2', '45.45', '45.45', '1', '2016-04-21 18:28:31');
INSERT INTO `iot_device_log` VALUES ('2953', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-21 18:28:31');
INSERT INTO `iot_device_log` VALUES ('2954', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:28:41');
INSERT INTO `iot_device_log` VALUES ('2955', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-21 18:28:41');
INSERT INTO `iot_device_log` VALUES ('2956', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-21 18:28:51');
INSERT INTO `iot_device_log` VALUES ('2957', '21', 'HUMIDITY', '2', '31.76', '31.76', '1', '2016-04-21 18:28:51');
INSERT INTO `iot_device_log` VALUES ('2958', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:29:01');
INSERT INTO `iot_device_log` VALUES ('2959', '21', 'HUMIDITY', '2', '31.76', '31.76', '1', '2016-04-21 18:29:01');
INSERT INTO `iot_device_log` VALUES ('2960', '21', 'TEMPERATURE', '2', '45.79', '45.79', '1', '2016-04-21 18:29:11');
INSERT INTO `iot_device_log` VALUES ('2961', '21', 'HUMIDITY', '2', '31.81', '31.81', '1', '2016-04-21 18:29:11');
INSERT INTO `iot_device_log` VALUES ('2962', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 18:29:21');
INSERT INTO `iot_device_log` VALUES ('2963', '21', 'HUMIDITY', '2', '31.81', '31.81', '1', '2016-04-21 18:29:21');
INSERT INTO `iot_device_log` VALUES ('2964', '21', 'TEMPERATURE', '2', '45.38', '45.38', '1', '2016-04-21 18:29:36');
INSERT INTO `iot_device_log` VALUES ('2965', '21', 'HUMIDITY', '2', '32.03', '32.03', '1', '2016-04-21 18:29:36');
INSERT INTO `iot_device_log` VALUES ('2966', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-21 18:29:41');
INSERT INTO `iot_device_log` VALUES ('2967', '21', 'HUMIDITY', '2', '32.1', '32.1', '1', '2016-04-21 18:29:41');
INSERT INTO `iot_device_log` VALUES ('2968', '21', 'TEMPERATURE', '2', '44.75', '44.75', '1', '2016-04-21 18:29:51');
INSERT INTO `iot_device_log` VALUES ('2969', '21', 'HUMIDITY', '2', '32.1', '32.1', '1', '2016-04-21 18:29:51');
INSERT INTO `iot_device_log` VALUES ('2970', '21', 'TEMPERATURE', '2', '44.5', '44.5', '1', '2016-04-21 18:30:01');
INSERT INTO `iot_device_log` VALUES ('2971', '21', 'HUMIDITY', '2', '32.27', '32.27', '1', '2016-04-21 18:30:01');
INSERT INTO `iot_device_log` VALUES ('2972', '21', 'TEMPERATURE', '2', '44.21', '44.21', '1', '2016-04-21 18:30:11');
INSERT INTO `iot_device_log` VALUES ('2973', '21', 'HUMIDITY', '2', '32.44', '32.44', '1', '2016-04-21 18:30:11');
INSERT INTO `iot_device_log` VALUES ('2974', '21', 'TEMPERATURE', '2', '44.13', '44.13', '1', '2016-04-21 18:30:28');
INSERT INTO `iot_device_log` VALUES ('2975', '21', 'HUMIDITY', '2', '32.47', '32.47', '1', '2016-04-21 18:30:28');
INSERT INTO `iot_device_log` VALUES ('2976', '21', 'TEMPERATURE', '2', '44.68', '44.68', '1', '2016-04-21 18:30:31');
INSERT INTO `iot_device_log` VALUES ('2977', '21', 'HUMIDITY', '2', '32.36', '32.36', '1', '2016-04-21 18:30:31');
INSERT INTO `iot_device_log` VALUES ('2978', '21', 'TEMPERATURE', '2', '44.74', '44.74', '1', '2016-04-21 18:30:41');
INSERT INTO `iot_device_log` VALUES ('2979', '21', 'HUMIDITY', '2', '32.32', '32.32', '1', '2016-04-21 18:30:41');
INSERT INTO `iot_device_log` VALUES ('2980', '21', 'TEMPERATURE', '2', '44.17', '44.17', '1', '2016-04-21 18:30:51');
INSERT INTO `iot_device_log` VALUES ('2981', '21', 'HUMIDITY', '2', '32.4', '32.4', '1', '2016-04-21 18:30:51');
INSERT INTO `iot_device_log` VALUES ('2982', '21', 'TEMPERATURE', '2', '44.14', '44.14', '1', '2016-04-21 18:31:01');
INSERT INTO `iot_device_log` VALUES ('2983', '21', 'HUMIDITY', '2', '32.34', '32.34', '1', '2016-04-21 18:31:01');
INSERT INTO `iot_device_log` VALUES ('2984', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-21 18:31:12');
INSERT INTO `iot_device_log` VALUES ('2985', '21', 'HUMIDITY', '2', '32.21', '32.21', '1', '2016-04-21 18:31:12');
INSERT INTO `iot_device_log` VALUES ('2986', '21', 'TEMPERATURE', '2', '44.23', '44.23', '1', '2016-04-21 18:31:21');
INSERT INTO `iot_device_log` VALUES ('2987', '21', 'HUMIDITY', '2', '32.32', '32.32', '1', '2016-04-21 18:31:21');
INSERT INTO `iot_device_log` VALUES ('2988', '21', 'TEMPERATURE', '2', '44.42', '44.42', '1', '2016-04-21 18:31:31');
INSERT INTO `iot_device_log` VALUES ('2989', '21', 'HUMIDITY', '2', '32.29', '32.29', '1', '2016-04-21 18:31:31');
INSERT INTO `iot_device_log` VALUES ('2990', '21', 'TEMPERATURE', '2', '44.64', '44.64', '1', '2016-04-21 18:31:41');
INSERT INTO `iot_device_log` VALUES ('2991', '21', 'HUMIDITY', '2', '32.19', '32.19', '1', '2016-04-21 18:31:41');
INSERT INTO `iot_device_log` VALUES ('2992', '21', 'TEMPERATURE', '2', '44.55', '44.55', '1', '2016-04-21 18:31:51');
INSERT INTO `iot_device_log` VALUES ('2993', '21', 'HUMIDITY', '2', '32.22', '32.22', '1', '2016-04-21 18:31:51');
INSERT INTO `iot_device_log` VALUES ('2994', '21', 'TEMPERATURE', '2', '44.7', '44.7', '1', '2016-04-21 18:32:01');
INSERT INTO `iot_device_log` VALUES ('2995', '21', 'HUMIDITY', '2', '32.04', '32.04', '1', '2016-04-21 18:32:01');
INSERT INTO `iot_device_log` VALUES ('2996', '21', 'TEMPERATURE', '2', '44.9', '44.9', '1', '2016-04-21 18:32:11');
INSERT INTO `iot_device_log` VALUES ('2997', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-21 18:32:11');
INSERT INTO `iot_device_log` VALUES ('2998', '21', 'TEMPERATURE', '2', '44.99', '44.99', '1', '2016-04-21 18:32:21');
INSERT INTO `iot_device_log` VALUES ('2999', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-21 18:32:21');
INSERT INTO `iot_device_log` VALUES ('3000', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:32:33');
INSERT INTO `iot_device_log` VALUES ('3001', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-21 18:32:33');
INSERT INTO `iot_device_log` VALUES ('3002', '21', 'TEMPERATURE', '2', '45.38', '45.38', '1', '2016-04-21 18:32:41');
INSERT INTO `iot_device_log` VALUES ('3003', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-21 18:32:41');
INSERT INTO `iot_device_log` VALUES ('3004', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-21 18:32:51');
INSERT INTO `iot_device_log` VALUES ('3005', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-21 18:32:51');
INSERT INTO `iot_device_log` VALUES ('3006', '21', 'TEMPERATURE', '2', '45.44', '45.44', '1', '2016-04-21 18:33:01');
INSERT INTO `iot_device_log` VALUES ('3007', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-21 18:33:01');
INSERT INTO `iot_device_log` VALUES ('3008', '21', 'TEMPERATURE', '2', '45.54', '45.54', '1', '2016-04-21 18:33:11');
INSERT INTO `iot_device_log` VALUES ('3009', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-21 18:33:11');
INSERT INTO `iot_device_log` VALUES ('3010', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-21 18:33:22');
INSERT INTO `iot_device_log` VALUES ('3011', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-21 18:33:22');
INSERT INTO `iot_device_log` VALUES ('3012', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-21 18:33:31');
INSERT INTO `iot_device_log` VALUES ('3013', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-21 18:33:31');
INSERT INTO `iot_device_log` VALUES ('3014', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 18:33:41');
INSERT INTO `iot_device_log` VALUES ('3015', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-21 18:33:41');
INSERT INTO `iot_device_log` VALUES ('3016', '21', 'TEMPERATURE', '2', '45.62', '45.62', '1', '2016-04-21 18:33:51');
INSERT INTO `iot_device_log` VALUES ('3017', '21', 'HUMIDITY', '2', '31.78', '31.78', '1', '2016-04-21 18:33:51');
INSERT INTO `iot_device_log` VALUES ('3018', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-21 18:34:01');
INSERT INTO `iot_device_log` VALUES ('3019', '21', 'HUMIDITY', '2', '31.72', '31.72', '1', '2016-04-21 18:34:01');
INSERT INTO `iot_device_log` VALUES ('3020', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-21 18:34:12');
INSERT INTO `iot_device_log` VALUES ('3021', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-21 18:34:12');
INSERT INTO `iot_device_log` VALUES ('3022', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-21 18:34:22');
INSERT INTO `iot_device_log` VALUES ('3023', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-21 18:34:22');
INSERT INTO `iot_device_log` VALUES ('3024', '21', 'TEMPERATURE', '2', '45.25', '45.25', '1', '2016-04-21 18:34:31');
INSERT INTO `iot_device_log` VALUES ('3025', '21', 'HUMIDITY', '2', '31.84', '31.84', '1', '2016-04-21 18:34:31');
INSERT INTO `iot_device_log` VALUES ('3026', '21', 'TEMPERATURE', '2', '45.42', '45.42', '1', '2016-04-21 18:34:41');
INSERT INTO `iot_device_log` VALUES ('3027', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-21 18:34:41');
INSERT INTO `iot_device_log` VALUES ('3028', '21', 'TEMPERATURE', '2', '45.25', '45.25', '1', '2016-04-21 18:34:51');
INSERT INTO `iot_device_log` VALUES ('3029', '21', 'HUMIDITY', '2', '31.85', '31.85', '1', '2016-04-21 18:34:51');
INSERT INTO `iot_device_log` VALUES ('3030', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:35:01');
INSERT INTO `iot_device_log` VALUES ('3031', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-21 18:35:01');
INSERT INTO `iot_device_log` VALUES ('3032', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-21 18:35:11');
INSERT INTO `iot_device_log` VALUES ('3033', '21', 'HUMIDITY', '2', '31.69', '31.69', '1', '2016-04-21 18:35:11');
INSERT INTO `iot_device_log` VALUES ('3034', '21', 'TEMPERATURE', '2', '45.32', '45.32', '1', '2016-04-21 18:35:21');
INSERT INTO `iot_device_log` VALUES ('3035', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-21 18:35:21');
INSERT INTO `iot_device_log` VALUES ('3036', '21', 'TEMPERATURE', '2', '45.25', '45.25', '1', '2016-04-21 18:35:36');
INSERT INTO `iot_device_log` VALUES ('3037', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-21 18:35:36');
INSERT INTO `iot_device_log` VALUES ('3038', '21', 'TEMPERATURE', '2', '45.11', '45.11', '1', '2016-04-21 18:35:42');
INSERT INTO `iot_device_log` VALUES ('3039', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-21 18:35:42');
INSERT INTO `iot_device_log` VALUES ('3040', '21', 'TEMPERATURE', '2', '44.64', '44.64', '1', '2016-04-21 18:35:51');
INSERT INTO `iot_device_log` VALUES ('3041', '21', 'HUMIDITY', '2', '32.15', '32.15', '1', '2016-04-21 18:35:51');
INSERT INTO `iot_device_log` VALUES ('3042', '21', 'TEMPERATURE', '2', '44.24', '44.24', '1', '2016-04-21 18:36:01');
INSERT INTO `iot_device_log` VALUES ('3043', '21', 'HUMIDITY', '2', '32.36', '32.36', '1', '2016-04-21 18:36:01');
INSERT INTO `iot_device_log` VALUES ('3044', '21', 'TEMPERATURE', '2', '44.21', '44.21', '1', '2016-04-21 18:36:13');
INSERT INTO `iot_device_log` VALUES ('3045', '21', 'HUMIDITY', '2', '32.29', '32.29', '1', '2016-04-21 18:36:13');
INSERT INTO `iot_device_log` VALUES ('3046', '21', 'TEMPERATURE', '2', '44.19', '44.19', '1', '2016-04-21 18:36:21');
INSERT INTO `iot_device_log` VALUES ('3047', '21', 'HUMIDITY', '2', '32.3', '32.3', '1', '2016-04-21 18:36:21');
INSERT INTO `iot_device_log` VALUES ('3048', '21', 'TEMPERATURE', '2', '44.22', '44.22', '1', '2016-04-21 18:36:31');
INSERT INTO `iot_device_log` VALUES ('3049', '21', 'HUMIDITY', '2', '32.22', '32.22', '1', '2016-04-21 18:36:31');
INSERT INTO `iot_device_log` VALUES ('3050', '21', 'TEMPERATURE', '2', '44.65', '44.65', '1', '2016-04-21 18:36:41');
INSERT INTO `iot_device_log` VALUES ('3051', '21', 'HUMIDITY', '2', '32.01', '32.01', '1', '2016-04-21 18:36:41');
INSERT INTO `iot_device_log` VALUES ('3052', '21', 'TEMPERATURE', '2', '44.63', '44.63', '1', '2016-04-21 18:36:51');
INSERT INTO `iot_device_log` VALUES ('3053', '21', 'HUMIDITY', '2', '32.11', '32.11', '1', '2016-04-21 18:36:51');
INSERT INTO `iot_device_log` VALUES ('3054', '21', 'TEMPERATURE', '2', '44.99', '44.99', '1', '2016-04-21 18:37:01');
INSERT INTO `iot_device_log` VALUES ('3055', '21', 'HUMIDITY', '2', '32.05', '32.05', '1', '2016-04-21 18:37:01');
INSERT INTO `iot_device_log` VALUES ('3056', '21', 'TEMPERATURE', '2', '45.07', '45.07', '1', '2016-04-21 18:37:11');
INSERT INTO `iot_device_log` VALUES ('3057', '21', 'HUMIDITY', '2', '31.97', '31.97', '1', '2016-04-21 18:37:11');
INSERT INTO `iot_device_log` VALUES ('3058', '21', 'TEMPERATURE', '2', '45.42', '45.42', '1', '2016-04-21 18:37:21');
INSERT INTO `iot_device_log` VALUES ('3059', '21', 'HUMIDITY', '2', '32.03', '32.03', '1', '2016-04-21 18:37:21');
INSERT INTO `iot_device_log` VALUES ('3060', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-21 18:37:31');
INSERT INTO `iot_device_log` VALUES ('3061', '21', 'HUMIDITY', '2', '32', '32', '1', '2016-04-21 18:37:31');
INSERT INTO `iot_device_log` VALUES ('3062', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-21 18:37:41');
INSERT INTO `iot_device_log` VALUES ('3063', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-21 18:37:41');
INSERT INTO `iot_device_log` VALUES ('3064', '21', 'TEMPERATURE', '2', '45.18', '45.18', '1', '2016-04-21 18:37:51');
INSERT INTO `iot_device_log` VALUES ('3065', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-21 18:37:51');
INSERT INTO `iot_device_log` VALUES ('3066', '21', 'TEMPERATURE', '2', '45.19', '45.19', '1', '2016-04-21 18:38:01');
INSERT INTO `iot_device_log` VALUES ('3067', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-21 18:38:01');
INSERT INTO `iot_device_log` VALUES ('3068', '21', 'TEMPERATURE', '2', '45.28', '45.28', '1', '2016-04-21 18:38:11');
INSERT INTO `iot_device_log` VALUES ('3069', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-21 18:38:11');
INSERT INTO `iot_device_log` VALUES ('3070', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-21 18:38:21');
INSERT INTO `iot_device_log` VALUES ('3071', '21', 'HUMIDITY', '2', '31.69', '31.69', '1', '2016-04-21 18:38:21');
INSERT INTO `iot_device_log` VALUES ('3072', '21', 'TEMPERATURE', '2', '45.44', '45.44', '1', '2016-04-21 18:38:31');
INSERT INTO `iot_device_log` VALUES ('3073', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-21 18:38:31');
INSERT INTO `iot_device_log` VALUES ('3074', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:38:41');
INSERT INTO `iot_device_log` VALUES ('3075', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-21 18:38:41');
INSERT INTO `iot_device_log` VALUES ('3076', '21', 'TEMPERATURE', '2', '45.61', '45.61', '1', '2016-04-21 18:38:51');
INSERT INTO `iot_device_log` VALUES ('3077', '21', 'HUMIDITY', '2', '31.56', '31.56', '1', '2016-04-21 18:38:51');
INSERT INTO `iot_device_log` VALUES ('3078', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 18:39:01');
INSERT INTO `iot_device_log` VALUES ('3079', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-21 18:39:01');
INSERT INTO `iot_device_log` VALUES ('3080', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-21 18:39:11');
INSERT INTO `iot_device_log` VALUES ('3081', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-21 18:39:11');
INSERT INTO `iot_device_log` VALUES ('3082', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 18:39:21');
INSERT INTO `iot_device_log` VALUES ('3083', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-21 18:39:21');
INSERT INTO `iot_device_log` VALUES ('3084', '21', 'TEMPERATURE', '2', '45.52', '45.52', '1', '2016-04-21 18:39:31');
INSERT INTO `iot_device_log` VALUES ('3085', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-21 18:39:31');
INSERT INTO `iot_device_log` VALUES ('3086', '21', 'TEMPERATURE', '2', '45.31', '45.31', '1', '2016-04-21 18:39:41');
INSERT INTO `iot_device_log` VALUES ('3087', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-21 18:39:41');
INSERT INTO `iot_device_log` VALUES ('3088', '21', 'TEMPERATURE', '2', '45.6', '45.6', '1', '2016-04-21 18:39:51');
INSERT INTO `iot_device_log` VALUES ('3089', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-21 18:39:51');
INSERT INTO `iot_device_log` VALUES ('3090', '21', 'TEMPERATURE', '2', '45.61', '45.61', '1', '2016-04-21 18:40:01');
INSERT INTO `iot_device_log` VALUES ('3091', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-21 18:40:01');
INSERT INTO `iot_device_log` VALUES ('3092', '21', 'TEMPERATURE', '2', '45.7', '45.7', '1', '2016-04-21 18:40:11');
INSERT INTO `iot_device_log` VALUES ('3093', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-21 18:40:11');
INSERT INTO `iot_device_log` VALUES ('3094', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-21 18:40:22');
INSERT INTO `iot_device_log` VALUES ('3095', '21', 'HUMIDITY', '2', '31.65', '31.65', '1', '2016-04-21 18:40:22');
INSERT INTO `iot_device_log` VALUES ('3096', '21', 'TEMPERATURE', '2', '45.72', '45.72', '1', '2016-04-21 18:40:31');
INSERT INTO `iot_device_log` VALUES ('3097', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-21 18:40:31');
INSERT INTO `iot_device_log` VALUES ('3098', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-21 18:40:41');
INSERT INTO `iot_device_log` VALUES ('3099', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-21 18:40:41');
INSERT INTO `iot_device_log` VALUES ('3100', '21', 'TEMPERATURE', '2', '45.74', '45.74', '1', '2016-04-21 18:40:51');
INSERT INTO `iot_device_log` VALUES ('3101', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-21 18:40:51');
INSERT INTO `iot_device_log` VALUES ('3102', '21', 'TEMPERATURE', '2', '45.72', '45.72', '1', '2016-04-21 18:41:01');
INSERT INTO `iot_device_log` VALUES ('3103', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-21 18:41:01');
INSERT INTO `iot_device_log` VALUES ('3104', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-21 18:41:11');
INSERT INTO `iot_device_log` VALUES ('3105', '21', 'HUMIDITY', '2', '31.81', '31.81', '1', '2016-04-21 18:41:11');
INSERT INTO `iot_device_log` VALUES ('3106', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-21 18:41:21');
INSERT INTO `iot_device_log` VALUES ('3107', '21', 'HUMIDITY', '2', '31.72', '31.72', '1', '2016-04-21 18:41:21');
INSERT INTO `iot_device_log` VALUES ('3108', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-21 18:41:31');
INSERT INTO `iot_device_log` VALUES ('3109', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-21 18:41:31');
INSERT INTO `iot_device_log` VALUES ('3110', '21', 'TEMPERATURE', '2', '45.85', '45.85', '1', '2016-04-21 18:41:41');
INSERT INTO `iot_device_log` VALUES ('3111', '21', 'HUMIDITY', '2', '31.56', '31.56', '1', '2016-04-21 18:41:41');
INSERT INTO `iot_device_log` VALUES ('3112', '21', 'TEMPERATURE', '2', '45.99', '45.99', '1', '2016-04-21 18:41:51');
INSERT INTO `iot_device_log` VALUES ('3113', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-21 18:41:51');
INSERT INTO `iot_device_log` VALUES ('3114', '21', 'TEMPERATURE', '2', '45.91', '45.91', '1', '2016-04-21 18:42:01');
INSERT INTO `iot_device_log` VALUES ('3115', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-21 18:42:01');
INSERT INTO `iot_device_log` VALUES ('3116', '21', 'TEMPERATURE', '2', '46.24', '46.24', '1', '2016-04-21 18:42:11');
INSERT INTO `iot_device_log` VALUES ('3117', '21', 'HUMIDITY', '2', '31.56', '31.56', '1', '2016-04-21 18:42:11');
INSERT INTO `iot_device_log` VALUES ('3118', '21', 'TEMPERATURE', '2', '45.98', '45.98', '1', '2016-04-21 18:42:21');
INSERT INTO `iot_device_log` VALUES ('3119', '21', 'HUMIDITY', '2', '31.44', '31.44', '1', '2016-04-21 18:42:21');
INSERT INTO `iot_device_log` VALUES ('3120', '21', 'TEMPERATURE', '2', '46.32', '46.32', '1', '2016-04-21 18:42:31');
INSERT INTO `iot_device_log` VALUES ('3121', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-21 18:42:31');
INSERT INTO `iot_device_log` VALUES ('3122', '21', 'TEMPERATURE', '2', '46.62', '46.62', '1', '2016-04-21 18:42:41');
INSERT INTO `iot_device_log` VALUES ('3123', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-21 18:42:41');
INSERT INTO `iot_device_log` VALUES ('3124', '21', 'TEMPERATURE', '2', '46.73', '46.73', '1', '2016-04-21 18:42:52');
INSERT INTO `iot_device_log` VALUES ('3125', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-21 18:42:52');
INSERT INTO `iot_device_log` VALUES ('3126', '21', 'TEMPERATURE', '2', '46.57', '46.57', '1', '2016-04-21 18:43:01');
INSERT INTO `iot_device_log` VALUES ('3127', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-21 18:43:01');
INSERT INTO `iot_device_log` VALUES ('3128', '21', 'TEMPERATURE', '2', '46.23', '46.23', '1', '2016-04-21 18:43:12');
INSERT INTO `iot_device_log` VALUES ('3129', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-21 18:43:12');
INSERT INTO `iot_device_log` VALUES ('3130', '21', 'TEMPERATURE', '2', '45.92', '45.92', '1', '2016-04-21 18:43:21');
INSERT INTO `iot_device_log` VALUES ('3131', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-21 18:43:21');
INSERT INTO `iot_device_log` VALUES ('3132', '21', 'TEMPERATURE', '2', '45.82', '45.82', '1', '2016-04-21 18:43:31');
INSERT INTO `iot_device_log` VALUES ('3133', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-21 18:43:31');
INSERT INTO `iot_device_log` VALUES ('3134', '21', 'TEMPERATURE', '2', '45.66', '45.66', '1', '2016-04-21 18:43:41');
INSERT INTO `iot_device_log` VALUES ('3135', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-21 18:43:41');
INSERT INTO `iot_device_log` VALUES ('3136', '21', 'TEMPERATURE', '2', '45.7', '45.7', '1', '2016-04-21 18:43:52');
INSERT INTO `iot_device_log` VALUES ('3137', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-21 18:43:52');
INSERT INTO `iot_device_log` VALUES ('3138', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 18:44:01');
INSERT INTO `iot_device_log` VALUES ('3139', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-21 18:44:01');
INSERT INTO `iot_device_log` VALUES ('3140', '21', 'TEMPERATURE', '2', '45.61', '45.61', '1', '2016-04-21 18:44:13');
INSERT INTO `iot_device_log` VALUES ('3141', '21', 'HUMIDITY', '2', '31.56', '31.56', '1', '2016-04-21 18:44:13');
INSERT INTO `iot_device_log` VALUES ('3142', '21', 'TEMPERATURE', '2', '45.61', '45.61', '1', '2016-04-21 18:44:21');
INSERT INTO `iot_device_log` VALUES ('3143', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-21 18:44:21');
INSERT INTO `iot_device_log` VALUES ('3144', '21', 'TEMPERATURE', '2', '45.85', '45.85', '1', '2016-04-21 18:44:32');
INSERT INTO `iot_device_log` VALUES ('3145', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-21 18:44:32');
INSERT INTO `iot_device_log` VALUES ('3146', '21', 'TEMPERATURE', '2', '45.69', '45.69', '1', '2016-04-21 18:44:41');
INSERT INTO `iot_device_log` VALUES ('3147', '21', 'HUMIDITY', '2', '31.73', '31.73', '1', '2016-04-21 18:44:41');
INSERT INTO `iot_device_log` VALUES ('3148', '21', 'TEMPERATURE', '2', '45.48', '45.48', '1', '2016-04-21 18:44:51');
INSERT INTO `iot_device_log` VALUES ('3149', '21', 'HUMIDITY', '2', '31.81', '31.81', '1', '2016-04-21 18:44:51');
INSERT INTO `iot_device_log` VALUES ('3150', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-21 18:45:02');
INSERT INTO `iot_device_log` VALUES ('3151', '21', 'HUMIDITY', '2', '31.81', '31.81', '1', '2016-04-21 18:45:02');
INSERT INTO `iot_device_log` VALUES ('3152', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:45:19');
INSERT INTO `iot_device_log` VALUES ('3153', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-21 18:45:19');
INSERT INTO `iot_device_log` VALUES ('3154', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-21 18:45:23');
INSERT INTO `iot_device_log` VALUES ('3155', '21', 'HUMIDITY', '2', '31.81', '31.81', '1', '2016-04-21 18:45:23');
INSERT INTO `iot_device_log` VALUES ('3156', '21', 'TEMPERATURE', '2', '45.14', '45.14', '1', '2016-04-21 18:45:31');
INSERT INTO `iot_device_log` VALUES ('3157', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-21 18:45:31');
INSERT INTO `iot_device_log` VALUES ('3158', '21', 'TEMPERATURE', '2', '44.95', '44.95', '1', '2016-04-21 18:45:43');
INSERT INTO `iot_device_log` VALUES ('3159', '21', 'HUMIDITY', '2', '31.91', '31.91', '1', '2016-04-21 18:45:43');
INSERT INTO `iot_device_log` VALUES ('3160', '21', 'TEMPERATURE', '2', '44.93', '44.93', '1', '2016-04-21 18:45:56');
INSERT INTO `iot_device_log` VALUES ('3161', '21', 'HUMIDITY', '2', '32.03', '32.03', '1', '2016-04-21 18:45:56');
INSERT INTO `iot_device_log` VALUES ('3162', '21', 'TEMPERATURE', '2', '44.85', '44.85', '1', '2016-04-21 18:46:01');
INSERT INTO `iot_device_log` VALUES ('3163', '21', 'HUMIDITY', '2', '32.01', '32.01', '1', '2016-04-21 18:46:01');
INSERT INTO `iot_device_log` VALUES ('3164', '21', 'TEMPERATURE', '2', '44.72', '44.72', '1', '2016-04-21 18:46:11');
INSERT INTO `iot_device_log` VALUES ('3165', '21', 'HUMIDITY', '2', '32.11', '32.11', '1', '2016-04-21 18:46:11');
INSERT INTO `iot_device_log` VALUES ('3166', '21', 'TEMPERATURE', '2', '44.6', '44.6', '1', '2016-04-21 18:46:21');
INSERT INTO `iot_device_log` VALUES ('3167', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 18:46:21');
INSERT INTO `iot_device_log` VALUES ('3168', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-21 18:46:32');
INSERT INTO `iot_device_log` VALUES ('3169', '21', 'HUMIDITY', '2', '31.96', '31.96', '1', '2016-04-21 18:46:32');
INSERT INTO `iot_device_log` VALUES ('3170', '21', 'TEMPERATURE', '2', '45.02', '45.02', '1', '2016-04-21 18:46:41');
INSERT INTO `iot_device_log` VALUES ('3171', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-21 18:46:41');
INSERT INTO `iot_device_log` VALUES ('3172', '21', 'TEMPERATURE', '2', '45.29', '45.29', '1', '2016-04-21 18:46:52');
INSERT INTO `iot_device_log` VALUES ('3173', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-21 18:46:52');
INSERT INTO `iot_device_log` VALUES ('3174', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-21 18:47:01');
INSERT INTO `iot_device_log` VALUES ('3175', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-21 18:47:01');
INSERT INTO `iot_device_log` VALUES ('3176', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-21 18:47:11');
INSERT INTO `iot_device_log` VALUES ('3177', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-21 18:47:11');
INSERT INTO `iot_device_log` VALUES ('3178', '21', 'TEMPERATURE', '2', '45.29', '45.29', '1', '2016-04-21 18:47:21');
INSERT INTO `iot_device_log` VALUES ('3179', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-21 18:47:21');
INSERT INTO `iot_device_log` VALUES ('3180', '21', 'TEMPERATURE', '2', '45.49', '45.49', '1', '2016-04-21 18:47:31');
INSERT INTO `iot_device_log` VALUES ('3181', '21', 'HUMIDITY', '2', '31.51', '31.51', '1', '2016-04-21 18:47:31');
INSERT INTO `iot_device_log` VALUES ('3182', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-21 18:47:41');
INSERT INTO `iot_device_log` VALUES ('3183', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-21 18:47:41');
INSERT INTO `iot_device_log` VALUES ('3184', '21', 'TEMPERATURE', '2', '45.79', '45.79', '1', '2016-04-21 18:47:51');
INSERT INTO `iot_device_log` VALUES ('3185', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-21 18:47:51');
INSERT INTO `iot_device_log` VALUES ('3186', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-21 18:48:01');
INSERT INTO `iot_device_log` VALUES ('3187', '21', 'HUMIDITY', '2', '31.51', '31.51', '1', '2016-04-21 18:48:01');
INSERT INTO `iot_device_log` VALUES ('3188', '21', 'TEMPERATURE', '2', '45.9', '45.9', '1', '2016-04-21 18:48:12');
INSERT INTO `iot_device_log` VALUES ('3189', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-21 18:48:12');
INSERT INTO `iot_device_log` VALUES ('3190', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-21 18:48:21');
INSERT INTO `iot_device_log` VALUES ('3191', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-21 18:48:21');
INSERT INTO `iot_device_log` VALUES ('3192', '21', 'TEMPERATURE', '2', '46.02', '46.02', '1', '2016-04-21 18:48:33');
INSERT INTO `iot_device_log` VALUES ('3193', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-21 18:48:33');
INSERT INTO `iot_device_log` VALUES ('3194', '21', 'TEMPERATURE', '2', '46.06', '46.06', '1', '2016-04-21 18:48:41');
INSERT INTO `iot_device_log` VALUES ('3195', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-21 18:48:41');
INSERT INTO `iot_device_log` VALUES ('3196', '21', 'TEMPERATURE', '2', '46.04', '46.04', '1', '2016-04-21 18:48:51');
INSERT INTO `iot_device_log` VALUES ('3197', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-21 18:48:51');
INSERT INTO `iot_device_log` VALUES ('3198', '21', 'TEMPERATURE', '2', '46.07', '46.07', '1', '2016-04-21 18:49:01');
INSERT INTO `iot_device_log` VALUES ('3199', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-21 18:49:01');
INSERT INTO `iot_device_log` VALUES ('3200', '21', 'TEMPERATURE', '2', '45.96', '45.96', '1', '2016-04-21 18:49:16');
INSERT INTO `iot_device_log` VALUES ('3201', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-21 18:49:16');
INSERT INTO `iot_device_log` VALUES ('3202', '21', 'TEMPERATURE', '2', '46.03', '46.03', '1', '2016-04-21 18:49:23');
INSERT INTO `iot_device_log` VALUES ('3203', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-21 18:49:23');
INSERT INTO `iot_device_log` VALUES ('3204', '21', 'TEMPERATURE', '2', '45.86', '45.86', '1', '2016-04-21 18:49:32');
INSERT INTO `iot_device_log` VALUES ('3205', '21', 'HUMIDITY', '2', '31.41', '31.41', '1', '2016-04-21 18:49:32');
INSERT INTO `iot_device_log` VALUES ('3206', '21', 'TEMPERATURE', '2', '45.71', '45.71', '1', '2016-04-21 18:49:41');
INSERT INTO `iot_device_log` VALUES ('3207', '21', 'HUMIDITY', '2', '31.5', '31.5', '1', '2016-04-21 18:49:41');
INSERT INTO `iot_device_log` VALUES ('3208', '21', 'TEMPERATURE', '2', '45.54', '45.54', '1', '2016-04-21 18:49:51');
INSERT INTO `iot_device_log` VALUES ('3209', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-21 18:49:51');
INSERT INTO `iot_device_log` VALUES ('3210', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-21 18:50:03');
INSERT INTO `iot_device_log` VALUES ('3211', '21', 'HUMIDITY', '2', '31.56', '31.56', '1', '2016-04-21 18:50:03');
INSERT INTO `iot_device_log` VALUES ('3212', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-21 18:50:11');
INSERT INTO `iot_device_log` VALUES ('3213', '21', 'HUMIDITY', '2', '31.65', '31.65', '1', '2016-04-21 18:50:11');
INSERT INTO `iot_device_log` VALUES ('3214', '21', 'TEMPERATURE', '2', '45.43', '45.43', '1', '2016-04-21 18:50:22');
INSERT INTO `iot_device_log` VALUES ('3215', '21', 'HUMIDITY', '2', '31.66', '31.66', '1', '2016-04-21 18:50:22');
INSERT INTO `iot_device_log` VALUES ('3216', '21', 'TEMPERATURE', '2', '45.54', '45.54', '1', '2016-04-21 18:50:31');
INSERT INTO `iot_device_log` VALUES ('3217', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-21 18:50:31');
INSERT INTO `iot_device_log` VALUES ('3218', '21', 'TEMPERATURE', '2', '45.86', '45.86', '1', '2016-04-21 18:50:41');
INSERT INTO `iot_device_log` VALUES ('3219', '21', 'HUMIDITY', '2', '31.5', '31.5', '1', '2016-04-21 18:50:41');
INSERT INTO `iot_device_log` VALUES ('3220', '21', 'TEMPERATURE', '2', '45.57', '45.57', '1', '2016-04-21 18:50:51');
INSERT INTO `iot_device_log` VALUES ('3221', '21', 'HUMIDITY', '2', '31.56', '31.56', '1', '2016-04-21 18:50:51');
INSERT INTO `iot_device_log` VALUES ('3222', '21', 'TEMPERATURE', '2', '45.68', '45.68', '1', '2016-04-21 18:51:01');
INSERT INTO `iot_device_log` VALUES ('3223', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-21 18:51:01');
INSERT INTO `iot_device_log` VALUES ('3224', '21', 'TEMPERATURE', '2', '45.62', '45.62', '1', '2016-04-21 18:51:11');
INSERT INTO `iot_device_log` VALUES ('3225', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-21 18:51:11');
INSERT INTO `iot_device_log` VALUES ('3226', '21', 'TEMPERATURE', '2', '45.67', '45.67', '1', '2016-04-21 18:51:21');
INSERT INTO `iot_device_log` VALUES ('3227', '21', 'HUMIDITY', '2', '31.5', '31.5', '1', '2016-04-21 18:51:21');
INSERT INTO `iot_device_log` VALUES ('3228', '21', 'TEMPERATURE', '2', '45.54', '45.54', '1', '2016-04-21 18:51:32');
INSERT INTO `iot_device_log` VALUES ('3229', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-21 18:51:32');
INSERT INTO `iot_device_log` VALUES ('3230', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-21 18:51:41');
INSERT INTO `iot_device_log` VALUES ('3231', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-21 18:51:41');
INSERT INTO `iot_device_log` VALUES ('3232', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-21 18:51:51');
INSERT INTO `iot_device_log` VALUES ('3233', '21', 'HUMIDITY', '2', '31.47', '31.47', '1', '2016-04-21 18:51:51');
INSERT INTO `iot_device_log` VALUES ('3234', '21', 'TEMPERATURE', '2', '45.82', '45.82', '1', '2016-04-21 18:52:01');
INSERT INTO `iot_device_log` VALUES ('3235', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-21 18:52:01');
INSERT INTO `iot_device_log` VALUES ('3236', '21', 'TEMPERATURE', '2', '45.93', '45.93', '1', '2016-04-21 18:52:11');
INSERT INTO `iot_device_log` VALUES ('3237', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-21 18:52:11');
INSERT INTO `iot_device_log` VALUES ('3238', '21', 'TEMPERATURE', '2', '46.06', '46.06', '1', '2016-04-21 18:52:21');
INSERT INTO `iot_device_log` VALUES ('3239', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-21 18:52:21');
INSERT INTO `iot_device_log` VALUES ('3240', '21', 'TEMPERATURE', '2', '46.1', '46.1', '1', '2016-04-21 18:52:31');
INSERT INTO `iot_device_log` VALUES ('3241', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-21 18:52:31');
INSERT INTO `iot_device_log` VALUES ('3242', '21', 'TEMPERATURE', '2', '46.2', '46.2', '1', '2016-04-21 18:52:41');
INSERT INTO `iot_device_log` VALUES ('3243', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-21 18:52:41');
INSERT INTO `iot_device_log` VALUES ('3244', '21', 'TEMPERATURE', '2', '46.12', '46.12', '1', '2016-04-21 18:52:51');
INSERT INTO `iot_device_log` VALUES ('3245', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-21 18:52:51');
INSERT INTO `iot_device_log` VALUES ('3246', '21', 'TEMPERATURE', '2', '46.09', '46.09', '1', '2016-04-21 18:53:01');
INSERT INTO `iot_device_log` VALUES ('3247', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-21 18:53:01');
INSERT INTO `iot_device_log` VALUES ('3248', '21', 'TEMPERATURE', '2', '46.01', '46.01', '1', '2016-04-21 18:53:11');
INSERT INTO `iot_device_log` VALUES ('3249', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-21 18:53:11');
INSERT INTO `iot_device_log` VALUES ('3250', '21', 'TEMPERATURE', '2', '46.12', '46.12', '1', '2016-04-21 18:53:21');
INSERT INTO `iot_device_log` VALUES ('3251', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-21 18:53:21');
INSERT INTO `iot_device_log` VALUES ('3252', '21', 'TEMPERATURE', '2', '45.98', '45.98', '1', '2016-04-21 18:53:31');
INSERT INTO `iot_device_log` VALUES ('3253', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-21 18:53:31');
INSERT INTO `iot_device_log` VALUES ('3254', '21', 'TEMPERATURE', '2', '45.88', '45.88', '1', '2016-04-21 18:53:41');
INSERT INTO `iot_device_log` VALUES ('3255', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-21 18:53:41');
INSERT INTO `iot_device_log` VALUES ('3256', '21', 'TEMPERATURE', '2', '45.92', '45.92', '1', '2016-04-21 18:53:51');
INSERT INTO `iot_device_log` VALUES ('3257', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-21 18:53:51');
INSERT INTO `iot_device_log` VALUES ('3258', '21', 'TEMPERATURE', '2', '46', '46', '1', '2016-04-21 18:54:01');
INSERT INTO `iot_device_log` VALUES ('3259', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-21 18:54:01');
INSERT INTO `iot_device_log` VALUES ('3260', '21', 'TEMPERATURE', '2', '46.09', '46.09', '1', '2016-04-21 18:54:11');
INSERT INTO `iot_device_log` VALUES ('3261', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-21 18:54:11');
INSERT INTO `iot_device_log` VALUES ('3262', '21', 'TEMPERATURE', '2', '46.01', '46.01', '1', '2016-04-21 18:54:21');
INSERT INTO `iot_device_log` VALUES ('3263', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-21 18:54:21');
INSERT INTO `iot_device_log` VALUES ('3264', '21', 'TEMPERATURE', '2', '46.01', '46.01', '1', '2016-04-21 18:54:32');
INSERT INTO `iot_device_log` VALUES ('3265', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-21 18:54:32');
INSERT INTO `iot_device_log` VALUES ('3266', '21', 'TEMPERATURE', '2', '45.88', '45.88', '1', '2016-04-21 18:54:41');
INSERT INTO `iot_device_log` VALUES ('3267', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-21 18:54:41');
INSERT INTO `iot_device_log` VALUES ('3268', '21', 'TEMPERATURE', '2', '46.05', '46.05', '1', '2016-04-21 18:54:51');
INSERT INTO `iot_device_log` VALUES ('3269', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-21 18:54:51');
INSERT INTO `iot_device_log` VALUES ('3270', '21', 'TEMPERATURE', '2', '46.23', '46.23', '1', '2016-04-21 18:55:03');
INSERT INTO `iot_device_log` VALUES ('3271', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-21 18:55:03');
INSERT INTO `iot_device_log` VALUES ('3272', '21', 'TEMPERATURE', '2', '45.93', '45.93', '1', '2016-04-21 18:55:11');
INSERT INTO `iot_device_log` VALUES ('3273', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-21 18:55:11');
INSERT INTO `iot_device_log` VALUES ('3274', '21', 'TEMPERATURE', '2', '45.54', '45.54', '1', '2016-04-21 18:55:21');
INSERT INTO `iot_device_log` VALUES ('3275', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-21 18:55:21');
INSERT INTO `iot_device_log` VALUES ('3276', '21', 'TEMPERATURE', '2', '45.49', '45.49', '1', '2016-04-21 18:55:32');
INSERT INTO `iot_device_log` VALUES ('3277', '21', 'HUMIDITY', '2', '31.65', '31.65', '1', '2016-04-21 18:55:32');
INSERT INTO `iot_device_log` VALUES ('3278', '21', 'TEMPERATURE', '2', '45.47', '45.47', '1', '2016-04-21 18:55:41');
INSERT INTO `iot_device_log` VALUES ('3279', '21', 'HUMIDITY', '2', '31.65', '31.65', '1', '2016-04-21 18:55:41');
INSERT INTO `iot_device_log` VALUES ('3280', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-21 18:55:51');
INSERT INTO `iot_device_log` VALUES ('3281', '21', 'HUMIDITY', '2', '31.66', '31.66', '1', '2016-04-21 18:55:51');
INSERT INTO `iot_device_log` VALUES ('3282', '21', 'TEMPERATURE', '2', '45.3', '45.3', '1', '2016-04-21 18:56:05');
INSERT INTO `iot_device_log` VALUES ('3283', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-21 18:56:05');
INSERT INTO `iot_device_log` VALUES ('3284', '21', 'TEMPERATURE', '2', '45.44', '45.44', '1', '2016-04-21 18:56:14');
INSERT INTO `iot_device_log` VALUES ('3285', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-21 18:56:14');
INSERT INTO `iot_device_log` VALUES ('3286', '21', 'TEMPERATURE', '2', '45.48', '45.48', '1', '2016-04-21 18:56:26');
INSERT INTO `iot_device_log` VALUES ('3287', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-21 18:56:26');
INSERT INTO `iot_device_log` VALUES ('3288', '21', 'TEMPERATURE', '2', '45.41', '45.41', '1', '2016-04-21 18:56:32');
INSERT INTO `iot_device_log` VALUES ('3289', '21', 'HUMIDITY', '2', '31.65', '31.65', '1', '2016-04-21 18:56:32');
INSERT INTO `iot_device_log` VALUES ('3290', '21', 'TEMPERATURE', '2', '45.3', '45.3', '1', '2016-04-21 18:56:41');
INSERT INTO `iot_device_log` VALUES ('3291', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-21 18:56:41');
INSERT INTO `iot_device_log` VALUES ('3292', '21', 'TEMPERATURE', '2', '45.19', '45.19', '1', '2016-04-21 18:57:00');
INSERT INTO `iot_device_log` VALUES ('3293', '21', 'HUMIDITY', '2', '31.76', '31.76', '1', '2016-04-21 18:57:00');
INSERT INTO `iot_device_log` VALUES ('3294', '21', 'TEMPERATURE', '2', '45.04', '45.04', '1', '2016-04-21 18:57:01');
INSERT INTO `iot_device_log` VALUES ('3295', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-21 18:57:01');
INSERT INTO `iot_device_log` VALUES ('3296', '21', 'TEMPERATURE', '2', '44.82', '44.82', '1', '2016-04-21 18:57:11');
INSERT INTO `iot_device_log` VALUES ('3297', '21', 'HUMIDITY', '2', '31.97', '31.97', '1', '2016-04-21 18:57:11');
INSERT INTO `iot_device_log` VALUES ('3298', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-21 18:57:32');
INSERT INTO `iot_device_log` VALUES ('3299', '21', 'HUMIDITY', '2', '31.85', '31.85', '1', '2016-04-21 18:57:32');
INSERT INTO `iot_device_log` VALUES ('3300', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-21 18:57:41');
INSERT INTO `iot_device_log` VALUES ('3301', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-21 18:57:41');
INSERT INTO `iot_device_log` VALUES ('3302', '21', 'TEMPERATURE', '2', '44.9', '44.9', '1', '2016-04-21 18:57:53');
INSERT INTO `iot_device_log` VALUES ('3303', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-21 18:57:53');
INSERT INTO `iot_device_log` VALUES ('3304', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-21 18:58:01');
INSERT INTO `iot_device_log` VALUES ('3305', '21', 'HUMIDITY', '2', '32', '32', '1', '2016-04-21 18:58:01');
INSERT INTO `iot_device_log` VALUES ('3306', '21', 'TEMPERATURE', '2', '44.84', '44.84', '1', '2016-04-21 18:58:11');
INSERT INTO `iot_device_log` VALUES ('3307', '21', 'HUMIDITY', '2', '31.93', '31.93', '1', '2016-04-21 18:58:11');
INSERT INTO `iot_device_log` VALUES ('3308', '21', 'TEMPERATURE', '2', '44.74', '44.74', '1', '2016-04-21 18:58:21');
INSERT INTO `iot_device_log` VALUES ('3309', '21', 'HUMIDITY', '2', '31.96', '31.96', '1', '2016-04-21 18:58:21');
INSERT INTO `iot_device_log` VALUES ('3310', '21', 'TEMPERATURE', '2', '44.99', '44.99', '1', '2016-04-21 18:58:32');
INSERT INTO `iot_device_log` VALUES ('3311', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-21 18:58:32');
INSERT INTO `iot_device_log` VALUES ('3312', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-21 18:58:43');
INSERT INTO `iot_device_log` VALUES ('3313', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-21 18:58:43');
INSERT INTO `iot_device_log` VALUES ('3314', '21', 'TEMPERATURE', '2', '45.11', '45.11', '1', '2016-04-21 18:58:52');
INSERT INTO `iot_device_log` VALUES ('3315', '21', 'HUMIDITY', '2', '31.76', '31.76', '1', '2016-04-21 18:58:52');
INSERT INTO `iot_device_log` VALUES ('3316', '21', 'TEMPERATURE', '2', '44.99', '44.99', '1', '2016-04-21 18:59:01');
INSERT INTO `iot_device_log` VALUES ('3317', '21', 'HUMIDITY', '2', '31.81', '31.81', '1', '2016-04-21 18:59:01');
INSERT INTO `iot_device_log` VALUES ('3318', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 18:59:11');
INSERT INTO `iot_device_log` VALUES ('3319', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 18:59:11');
INSERT INTO `iot_device_log` VALUES ('3320', '21', 'TEMPERATURE', '2', '44.74', '44.74', '1', '2016-04-21 18:59:11');
INSERT INTO `iot_device_log` VALUES ('3321', '21', 'HUMIDITY', '2', '31.96', '31.96', '1', '2016-04-21 18:59:11');
INSERT INTO `iot_device_log` VALUES ('3322', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 18:59:15');
INSERT INTO `iot_device_log` VALUES ('3323', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 18:59:19');
INSERT INTO `iot_device_log` VALUES ('3324', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 18:59:23');
INSERT INTO `iot_device_log` VALUES ('3325', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 18:59:25');
INSERT INTO `iot_device_log` VALUES ('3326', '21', 'TEMPERATURE', '2', '44.72', '44.72', '1', '2016-04-21 18:59:32');
INSERT INTO `iot_device_log` VALUES ('3327', '21', 'HUMIDITY', '2', '31.94', '31.94', '1', '2016-04-21 18:59:32');
INSERT INTO `iot_device_log` VALUES ('3328', '21', 'TEMPERATURE', '2', '44.93', '44.93', '1', '2016-04-21 18:59:42');
INSERT INTO `iot_device_log` VALUES ('3329', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-21 18:59:42');
INSERT INTO `iot_device_log` VALUES ('3330', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-21 18:59:53');
INSERT INTO `iot_device_log` VALUES ('3331', '21', 'HUMIDITY', '2', '31.91', '31.91', '1', '2016-04-21 18:59:53');
INSERT INTO `iot_device_log` VALUES ('3332', '21', 'TEMPERATURE', '2', '44.5', '44.5', '1', '2016-04-21 19:00:01');
INSERT INTO `iot_device_log` VALUES ('3333', '21', 'HUMIDITY', '2', '32.08', '32.08', '1', '2016-04-21 19:00:01');
INSERT INTO `iot_device_log` VALUES ('3334', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-21 19:00:11');
INSERT INTO `iot_device_log` VALUES ('3335', '21', 'HUMIDITY', '2', '32.15', '32.15', '1', '2016-04-21 19:00:11');
INSERT INTO `iot_device_log` VALUES ('3336', '21', 'TEMPERATURE', '2', '44.37', '44.37', '1', '2016-04-21 19:00:21');
INSERT INTO `iot_device_log` VALUES ('3337', '21', 'HUMIDITY', '2', '32.15', '32.15', '1', '2016-04-21 19:00:21');
INSERT INTO `iot_device_log` VALUES ('3338', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:00:28');
INSERT INTO `iot_device_log` VALUES ('3339', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 19:00:32');
INSERT INTO `iot_device_log` VALUES ('3340', '21', 'TEMPERATURE', '2', '44.26', '44.26', '1', '2016-04-21 19:00:33');
INSERT INTO `iot_device_log` VALUES ('3341', '21', 'HUMIDITY', '2', '32.18', '32.18', '1', '2016-04-21 19:00:33');
INSERT INTO `iot_device_log` VALUES ('3342', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 19:00:39');
INSERT INTO `iot_device_log` VALUES ('3343', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 19:00:41');
INSERT INTO `iot_device_log` VALUES ('3344', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:00:41');
INSERT INTO `iot_device_log` VALUES ('3345', '21', 'TEMPERATURE', '2', '44.36', '44.36', '1', '2016-04-21 19:00:42');
INSERT INTO `iot_device_log` VALUES ('3346', '21', 'HUMIDITY', '2', '32.1', '32.1', '1', '2016-04-21 19:00:42');
INSERT INTO `iot_device_log` VALUES ('3347', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 19:00:42');
INSERT INTO `iot_device_log` VALUES ('3348', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:00:46');
INSERT INTO `iot_device_log` VALUES ('3349', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 19:00:49');
INSERT INTO `iot_device_log` VALUES ('3350', '21', 'TEMPERATURE', '2', '44.49', '44.49', '1', '2016-04-21 19:00:51');
INSERT INTO `iot_device_log` VALUES ('3351', '21', 'HUMIDITY', '2', '31.99', '31.99', '1', '2016-04-21 19:00:51');
INSERT INTO `iot_device_log` VALUES ('3352', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:00:54');
INSERT INTO `iot_device_log` VALUES ('3353', '21', 'TEMPERATURE', '2', '44.57', '44.57', '1', '2016-04-21 19:01:01');
INSERT INTO `iot_device_log` VALUES ('3354', '21', 'HUMIDITY', '2', '31.94', '31.94', '1', '2016-04-21 19:01:01');
INSERT INTO `iot_device_log` VALUES ('3355', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:01:02');
INSERT INTO `iot_device_log` VALUES ('3356', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:01:05');
INSERT INTO `iot_device_log` VALUES ('3357', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:01:06');
INSERT INTO `iot_device_log` VALUES ('3358', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:01:08');
INSERT INTO `iot_device_log` VALUES ('3359', '21', 'TEMPERATURE', '2', '44.56', '44.56', '1', '2016-04-21 19:01:13');
INSERT INTO `iot_device_log` VALUES ('3360', '21', 'HUMIDITY', '2', '32.03', '32.03', '1', '2016-04-21 19:01:13');
INSERT INTO `iot_device_log` VALUES ('3361', '21', 'TEMPERATURE', '2', '44.5', '44.5', '1', '2016-04-21 19:01:22');
INSERT INTO `iot_device_log` VALUES ('3362', '21', 'HUMIDITY', '2', '32', '32', '1', '2016-04-21 19:01:22');
INSERT INTO `iot_device_log` VALUES ('3363', '21', 'TEMPERATURE', '2', '44.44', '44.44', '1', '2016-04-21 19:01:31');
INSERT INTO `iot_device_log` VALUES ('3364', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 19:01:31');
INSERT INTO `iot_device_log` VALUES ('3365', '21', 'TEMPERATURE', '2', '44.52', '44.52', '1', '2016-04-21 19:02:00');
INSERT INTO `iot_device_log` VALUES ('3366', '21', 'HUMIDITY', '2', '32.01', '32.01', '1', '2016-04-21 19:02:00');
INSERT INTO `iot_device_log` VALUES ('3367', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:02:01');
INSERT INTO `iot_device_log` VALUES ('3368', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-21 19:02:01');
INSERT INTO `iot_device_log` VALUES ('3369', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-21 19:02:01');
INSERT INTO `iot_device_log` VALUES ('3370', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 19:02:07');
INSERT INTO `iot_device_log` VALUES ('3371', '21', 'TEMPERATURE', '2', '44.71', '44.71', '1', '2016-04-21 19:02:11');
INSERT INTO `iot_device_log` VALUES ('3372', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-21 19:02:11');
INSERT INTO `iot_device_log` VALUES ('3373', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-21 19:02:22');
INSERT INTO `iot_device_log` VALUES ('3374', '21', 'HUMIDITY', '2', '31.99', '31.99', '1', '2016-04-21 19:02:22');
INSERT INTO `iot_device_log` VALUES ('3375', '21', 'TEMPERATURE', '2', '44.71', '44.71', '1', '2016-04-21 19:02:31');
INSERT INTO `iot_device_log` VALUES ('3376', '21', 'HUMIDITY', '2', '31.93', '31.93', '1', '2016-04-21 19:02:31');
INSERT INTO `iot_device_log` VALUES ('3377', '21', 'TEMPERATURE', '2', '44.65', '44.65', '1', '2016-04-21 19:02:41');
INSERT INTO `iot_device_log` VALUES ('3378', '21', 'HUMIDITY', '2', '31.96', '31.96', '1', '2016-04-21 19:02:41');
INSERT INTO `iot_device_log` VALUES ('3379', '21', 'TEMPERATURE', '2', '44.71', '44.71', '1', '2016-04-21 19:03:00');
INSERT INTO `iot_device_log` VALUES ('3380', '21', 'HUMIDITY', '2', '31.99', '31.99', '1', '2016-04-21 19:03:00');
INSERT INTO `iot_device_log` VALUES ('3381', '21', 'TEMPERATURE', '2', '44.55', '44.55', '1', '2016-04-21 19:03:01');
INSERT INTO `iot_device_log` VALUES ('3382', '21', 'HUMIDITY', '2', '31.97', '31.97', '1', '2016-04-21 19:03:01');
INSERT INTO `iot_device_log` VALUES ('3383', '21', 'TEMPERATURE', '2', '44.52', '44.52', '1', '2016-04-21 19:03:11');
INSERT INTO `iot_device_log` VALUES ('3384', '21', 'HUMIDITY', '2', '32.03', '32.03', '1', '2016-04-21 19:03:11');
INSERT INTO `iot_device_log` VALUES ('3385', '21', 'TEMPERATURE', '2', '44.51', '44.51', '1', '2016-04-21 19:03:21');
INSERT INTO `iot_device_log` VALUES ('3386', '21', 'HUMIDITY', '2', '31.99', '31.99', '1', '2016-04-21 19:03:21');
INSERT INTO `iot_device_log` VALUES ('3387', '21', 'TEMPERATURE', '2', '44.55', '44.55', '1', '2016-04-21 19:03:42');
INSERT INTO `iot_device_log` VALUES ('3388', '21', 'HUMIDITY', '2', '31.97', '31.97', '1', '2016-04-21 19:03:42');
INSERT INTO `iot_device_log` VALUES ('3389', '21', 'TEMPERATURE', '2', '44.65', '44.65', '1', '2016-04-21 19:03:51');
INSERT INTO `iot_device_log` VALUES ('3390', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-21 19:03:51');
INSERT INTO `iot_device_log` VALUES ('3391', '21', 'TEMPERATURE', '2', '44.38', '44.38', '1', '2016-04-21 19:04:01');
INSERT INTO `iot_device_log` VALUES ('3392', '21', 'HUMIDITY', '2', '32.08', '32.08', '1', '2016-04-21 19:04:01');
INSERT INTO `iot_device_log` VALUES ('3393', '21', 'TEMPERATURE', '2', '44.24', '44.24', '1', '2016-04-21 19:04:11');
INSERT INTO `iot_device_log` VALUES ('3394', '21', 'HUMIDITY', '2', '32.14', '32.14', '1', '2016-04-21 19:04:11');
INSERT INTO `iot_device_log` VALUES ('3395', '21', 'TEMPERATURE', '2', '44.16', '44.16', '1', '2016-04-21 19:04:22');
INSERT INTO `iot_device_log` VALUES ('3396', '21', 'HUMIDITY', '2', '32.16', '32.16', '1', '2016-04-21 19:04:22');
INSERT INTO `iot_device_log` VALUES ('3397', '21', 'TEMPERATURE', '2', '44.22', '44.22', '1', '2016-04-21 19:04:32');
INSERT INTO `iot_device_log` VALUES ('3398', '21', 'HUMIDITY', '2', '32.12', '32.12', '1', '2016-04-21 19:04:32');
INSERT INTO `iot_device_log` VALUES ('3399', '21', 'TEMPERATURE', '2', '44.25', '44.25', '1', '2016-04-21 19:04:41');
INSERT INTO `iot_device_log` VALUES ('3400', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-21 19:04:41');
INSERT INTO `iot_device_log` VALUES ('3401', '21', 'TEMPERATURE', '2', '44.2', '44.2', '1', '2016-04-21 19:04:51');
INSERT INTO `iot_device_log` VALUES ('3402', '21', 'HUMIDITY', '2', '32.19', '32.19', '1', '2016-04-21 19:04:51');
INSERT INTO `iot_device_log` VALUES ('3403', '21', 'TEMPERATURE', '2', '44.11', '44.11', '1', '2016-04-21 19:05:01');
INSERT INTO `iot_device_log` VALUES ('3404', '21', 'HUMIDITY', '2', '32.25', '32.25', '1', '2016-04-21 19:05:01');
INSERT INTO `iot_device_log` VALUES ('3405', '21', 'TEMPERATURE', '2', '43.96', '43.96', '1', '2016-04-21 19:05:30');
INSERT INTO `iot_device_log` VALUES ('3406', '21', 'HUMIDITY', '2', '32.43', '32.43', '1', '2016-04-21 19:05:30');
INSERT INTO `iot_device_log` VALUES ('3407', '21', 'TEMPERATURE', '2', '43.53', '43.53', '1', '2016-04-21 19:05:32');
INSERT INTO `iot_device_log` VALUES ('3408', '21', 'HUMIDITY', '2', '32.58', '32.58', '1', '2016-04-21 19:05:32');
INSERT INTO `iot_device_log` VALUES ('3409', '21', 'TEMPERATURE', '2', '43.5', '43.5', '1', '2016-04-21 19:05:41');
INSERT INTO `iot_device_log` VALUES ('3410', '21', 'HUMIDITY', '2', '32.51', '32.51', '1', '2016-04-21 19:05:41');
INSERT INTO `iot_device_log` VALUES ('3411', '21', 'TEMPERATURE', '2', '43.56', '43.56', '1', '2016-04-21 19:05:53');
INSERT INTO `iot_device_log` VALUES ('3412', '21', 'HUMIDITY', '2', '32.44', '32.44', '1', '2016-04-21 19:05:53');
INSERT INTO `iot_device_log` VALUES ('3413', '21', 'TEMPERATURE', '2', '43.74', '43.74', '1', '2016-04-21 19:06:24');
INSERT INTO `iot_device_log` VALUES ('3414', '21', 'HUMIDITY', '2', '32.37', '32.37', '1', '2016-04-21 19:06:24');
INSERT INTO `iot_device_log` VALUES ('3415', '21', 'TEMPERATURE', '2', '43.56', '43.56', '1', '2016-04-21 19:06:36');
INSERT INTO `iot_device_log` VALUES ('3416', '21', 'HUMIDITY', '2', '32.47', '32.47', '1', '2016-04-21 19:06:36');
INSERT INTO `iot_device_log` VALUES ('3417', '21', 'TEMPERATURE', '2', '43.46', '43.46', '1', '2016-04-21 19:06:42');
INSERT INTO `iot_device_log` VALUES ('3418', '21', 'HUMIDITY', '2', '32.47', '32.47', '1', '2016-04-21 19:06:42');
INSERT INTO `iot_device_log` VALUES ('3419', '21', 'TEMPERATURE', '2', '43.46', '43.46', '1', '2016-04-21 19:06:52');
INSERT INTO `iot_device_log` VALUES ('3420', '21', 'HUMIDITY', '2', '32.49', '32.49', '1', '2016-04-21 19:06:52');
INSERT INTO `iot_device_log` VALUES ('3421', '21', 'TEMPERATURE', '2', '43.14', '43.14', '1', '2016-04-21 19:07:11');
INSERT INTO `iot_device_log` VALUES ('3422', '21', 'HUMIDITY', '2', '32.75', '32.75', '1', '2016-04-21 19:07:11');
INSERT INTO `iot_device_log` VALUES ('3423', '21', 'TEMPERATURE', '2', '43.04', '43.04', '1', '2016-04-21 19:07:21');
INSERT INTO `iot_device_log` VALUES ('3424', '21', 'HUMIDITY', '2', '32.71', '32.71', '1', '2016-04-21 19:07:21');
INSERT INTO `iot_device_log` VALUES ('3425', '21', 'TEMPERATURE', '2', '42.98', '42.98', '1', '2016-04-21 19:07:36');
INSERT INTO `iot_device_log` VALUES ('3426', '21', 'HUMIDITY', '2', '32.74', '32.74', '1', '2016-04-21 19:07:36');
INSERT INTO `iot_device_log` VALUES ('3427', '21', 'TEMPERATURE', '2', '42.98', '42.98', '1', '2016-04-21 19:07:46');
INSERT INTO `iot_device_log` VALUES ('3428', '21', 'HUMIDITY', '2', '32.73', '32.73', '1', '2016-04-21 19:07:46');
INSERT INTO `iot_device_log` VALUES ('3429', '21', 'TEMPERATURE', '2', '42.9', '42.9', '1', '2016-04-21 19:07:51');
INSERT INTO `iot_device_log` VALUES ('3430', '21', 'HUMIDITY', '2', '32.78', '32.78', '1', '2016-04-21 19:07:51');
INSERT INTO `iot_device_log` VALUES ('3431', '21', 'TEMPERATURE', '2', '42.79', '42.79', '1', '2016-04-21 19:08:01');
INSERT INTO `iot_device_log` VALUES ('3432', '21', 'HUMIDITY', '2', '32.85', '32.85', '1', '2016-04-21 19:08:01');
INSERT INTO `iot_device_log` VALUES ('3433', '21', 'TEMPERATURE', '2', '42.73', '42.73', '1', '2016-04-21 19:08:11');
INSERT INTO `iot_device_log` VALUES ('3434', '21', 'HUMIDITY', '2', '32.84', '32.84', '1', '2016-04-21 19:08:11');
INSERT INTO `iot_device_log` VALUES ('3435', '21', 'TEMPERATURE', '2', '42.84', '42.84', '1', '2016-04-21 19:08:32');
INSERT INTO `iot_device_log` VALUES ('3436', '21', 'HUMIDITY', '2', '32.74', '32.74', '1', '2016-04-21 19:08:32');
INSERT INTO `iot_device_log` VALUES ('3437', '21', 'TEMPERATURE', '2', '42.98', '42.98', '1', '2016-04-21 19:08:41');
INSERT INTO `iot_device_log` VALUES ('3438', '21', 'HUMIDITY', '2', '32.64', '32.64', '1', '2016-04-21 19:08:41');
INSERT INTO `iot_device_log` VALUES ('3439', '21', 'TEMPERATURE', '2', '43.21', '43.21', '1', '2016-04-21 19:08:51');
INSERT INTO `iot_device_log` VALUES ('3440', '21', 'HUMIDITY', '2', '32.55', '32.55', '1', '2016-04-21 19:08:51');
INSERT INTO `iot_device_log` VALUES ('3441', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:09:32');
INSERT INTO `iot_device_log` VALUES ('3442', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 19:09:32');
INSERT INTO `iot_device_log` VALUES ('3443', '21', 'TEMPERATURE', '2', '48.57', '48.57', '1', '2016-04-21 19:10:13');
INSERT INTO `iot_device_log` VALUES ('3444', '21', 'HUMIDITY', '2', '30.8', '30.8', '1', '2016-04-21 19:10:13');
INSERT INTO `iot_device_log` VALUES ('3445', '21', 'TEMPERATURE', '2', '47.83', '47.83', '1', '2016-04-21 19:10:26');
INSERT INTO `iot_device_log` VALUES ('3446', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-21 19:10:26');
INSERT INTO `iot_device_log` VALUES ('3447', '21', 'TEMPERATURE', '2', '47.92', '47.92', '1', '2016-04-21 19:10:37');
INSERT INTO `iot_device_log` VALUES ('3448', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-21 19:10:37');
INSERT INTO `iot_device_log` VALUES ('3449', '21', 'TEMPERATURE', '2', '47.63', '47.63', '1', '2016-04-21 19:10:40');
INSERT INTO `iot_device_log` VALUES ('3450', '21', 'HUMIDITY', '2', '31.44', '31.44', '1', '2016-04-21 19:10:40');
INSERT INTO `iot_device_log` VALUES ('3451', '21', 'TEMPERATURE', '2', '47.51', '47.51', '1', '2016-04-21 19:10:50');
INSERT INTO `iot_device_log` VALUES ('3452', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-21 19:10:50');
INSERT INTO `iot_device_log` VALUES ('3453', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 19:11:19');
INSERT INTO `iot_device_log` VALUES ('3454', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 19:11:27');
INSERT INTO `iot_device_log` VALUES ('3455', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:11:35');
INSERT INTO `iot_device_log` VALUES ('3456', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:11:40');
INSERT INTO `iot_device_log` VALUES ('3457', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:11:43');
INSERT INTO `iot_device_log` VALUES ('3458', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:11:45');
INSERT INTO `iot_device_log` VALUES ('3459', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:11:46');
INSERT INTO `iot_device_log` VALUES ('3460', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:12:11');
INSERT INTO `iot_device_log` VALUES ('3461', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:12:11');
INSERT INTO `iot_device_log` VALUES ('3462', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:12:11');
INSERT INTO `iot_device_log` VALUES ('3463', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:12:11');
INSERT INTO `iot_device_log` VALUES ('3464', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:12:11');
INSERT INTO `iot_device_log` VALUES ('3465', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 19:12:11');
INSERT INTO `iot_device_log` VALUES ('3466', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 19:12:11');
INSERT INTO `iot_device_log` VALUES ('3467', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:12:11');
INSERT INTO `iot_device_log` VALUES ('3468', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:12:11');
INSERT INTO `iot_device_log` VALUES ('3469', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:12:11');
INSERT INTO `iot_device_log` VALUES ('3470', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:12:52');
INSERT INTO `iot_device_log` VALUES ('3471', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:12:59');
INSERT INTO `iot_device_log` VALUES ('3472', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:13:02');
INSERT INTO `iot_device_log` VALUES ('3473', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3474', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3475', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3476', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3477', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3478', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3479', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3480', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3481', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3482', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3483', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3484', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 19:16:35');
INSERT INTO `iot_device_log` VALUES ('3485', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:16:41');
INSERT INTO `iot_device_log` VALUES ('3486', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 19:17:42');
INSERT INTO `iot_device_log` VALUES ('3487', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 19:17:47');
INSERT INTO `iot_device_log` VALUES ('3488', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:20:57');
INSERT INTO `iot_device_log` VALUES ('3489', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 19:20:57');
INSERT INTO `iot_device_log` VALUES ('3490', '21', 'TEMPERATURE', '2', '46.61', '46.61', '1', '2016-04-21 19:24:03');
INSERT INTO `iot_device_log` VALUES ('3491', '21', 'HUMIDITY', '2', '36.73', '36.73', '1', '2016-04-21 19:24:03');
INSERT INTO `iot_device_log` VALUES ('3492', '21', 'TEMPERATURE', '2', '40.63', '40.63', '1', '2016-04-21 19:24:30');
INSERT INTO `iot_device_log` VALUES ('3493', '21', 'HUMIDITY', '2', '37.02', '37.02', '1', '2016-04-21 19:24:30');
INSERT INTO `iot_device_log` VALUES ('3494', '21', 'TEMPERATURE', '2', '49.4', '49.4', '1', '2016-04-21 19:25:09');
INSERT INTO `iot_device_log` VALUES ('3495', '21', 'HUMIDITY', '2', '34.26', '34.26', '1', '2016-04-21 19:25:09');
INSERT INTO `iot_device_log` VALUES ('3496', '21', 'TEMPERATURE', '2', '42.51', '42.51', '1', '2016-04-21 19:25:46');
INSERT INTO `iot_device_log` VALUES ('3497', '21', 'HUMIDITY', '2', '33.87', '33.87', '1', '2016-04-21 19:25:46');
INSERT INTO `iot_device_log` VALUES ('3498', '21', 'TEMPERATURE', '2', '41.93', '41.93', '1', '2016-04-21 19:25:56');
INSERT INTO `iot_device_log` VALUES ('3499', '21', 'HUMIDITY', '2', '33.86', '33.86', '1', '2016-04-21 19:25:56');
INSERT INTO `iot_device_log` VALUES ('3500', '21', 'TEMPERATURE', '2', '42.18', '42.18', '1', '2016-04-21 19:26:06');
INSERT INTO `iot_device_log` VALUES ('3501', '21', 'HUMIDITY', '2', '33.61', '33.61', '1', '2016-04-21 19:26:06');
INSERT INTO `iot_device_log` VALUES ('3502', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-21 19:26:16');
INSERT INTO `iot_device_log` VALUES ('3503', '21', 'HUMIDITY', '2', '33.27', '33.27', '1', '2016-04-21 19:26:16');
INSERT INTO `iot_device_log` VALUES ('3504', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:36:16');
INSERT INTO `iot_device_log` VALUES ('3505', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 19:36:22');
INSERT INTO `iot_device_log` VALUES ('3506', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 20:31:04');
INSERT INTO `iot_device_log` VALUES ('3507', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 20:31:12');
INSERT INTO `iot_device_log` VALUES ('3508', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 20:31:14');
INSERT INTO `iot_device_log` VALUES ('3509', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:26');
INSERT INTO `iot_device_log` VALUES ('3510', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:32');
INSERT INTO `iot_device_log` VALUES ('3511', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:34');
INSERT INTO `iot_device_log` VALUES ('3512', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:37');
INSERT INTO `iot_device_log` VALUES ('3513', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:38');
INSERT INTO `iot_device_log` VALUES ('3514', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:39');
INSERT INTO `iot_device_log` VALUES ('3515', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:40');
INSERT INTO `iot_device_log` VALUES ('3516', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:41');
INSERT INTO `iot_device_log` VALUES ('3517', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:42');
INSERT INTO `iot_device_log` VALUES ('3518', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 20:31:46');
INSERT INTO `iot_device_log` VALUES ('3519', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 20:31:50');
INSERT INTO `iot_device_log` VALUES ('3520', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 20:31:53');
INSERT INTO `iot_device_log` VALUES ('3521', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:55');
INSERT INTO `iot_device_log` VALUES ('3522', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:56');
INSERT INTO `iot_device_log` VALUES ('3523', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:56');
INSERT INTO `iot_device_log` VALUES ('3524', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:58');
INSERT INTO `iot_device_log` VALUES ('3525', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:31:58');
INSERT INTO `iot_device_log` VALUES ('3526', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-21 20:33:04');
INSERT INTO `iot_device_log` VALUES ('3527', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:34:07');
INSERT INTO `iot_device_log` VALUES ('3528', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:34:13');
INSERT INTO `iot_device_log` VALUES ('3529', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:34:15');
INSERT INTO `iot_device_log` VALUES ('3530', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:34:16');
INSERT INTO `iot_device_log` VALUES ('3531', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:34:18');
INSERT INTO `iot_device_log` VALUES ('3532', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:34:19');
INSERT INTO `iot_device_log` VALUES ('3533', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:34:27');
INSERT INTO `iot_device_log` VALUES ('3534', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:21');
INSERT INTO `iot_device_log` VALUES ('3535', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:24');
INSERT INTO `iot_device_log` VALUES ('3536', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:26');
INSERT INTO `iot_device_log` VALUES ('3537', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:28');
INSERT INTO `iot_device_log` VALUES ('3538', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:29');
INSERT INTO `iot_device_log` VALUES ('3539', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:31');
INSERT INTO `iot_device_log` VALUES ('3540', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:32');
INSERT INTO `iot_device_log` VALUES ('3541', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:33');
INSERT INTO `iot_device_log` VALUES ('3542', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:34');
INSERT INTO `iot_device_log` VALUES ('3543', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:35');
INSERT INTO `iot_device_log` VALUES ('3544', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:37');
INSERT INTO `iot_device_log` VALUES ('3545', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:38');
INSERT INTO `iot_device_log` VALUES ('3546', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:39');
INSERT INTO `iot_device_log` VALUES ('3547', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:41');
INSERT INTO `iot_device_log` VALUES ('3548', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:42');
INSERT INTO `iot_device_log` VALUES ('3549', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:44');
INSERT INTO `iot_device_log` VALUES ('3550', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:45');
INSERT INTO `iot_device_log` VALUES ('3551', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:46');
INSERT INTO `iot_device_log` VALUES ('3552', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:47');
INSERT INTO `iot_device_log` VALUES ('3553', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:47');
INSERT INTO `iot_device_log` VALUES ('3554', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:48');
INSERT INTO `iot_device_log` VALUES ('3555', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:49');
INSERT INTO `iot_device_log` VALUES ('3556', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:50');
INSERT INTO `iot_device_log` VALUES ('3557', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:51');
INSERT INTO `iot_device_log` VALUES ('3558', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:52');
INSERT INTO `iot_device_log` VALUES ('3559', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:53');
INSERT INTO `iot_device_log` VALUES ('3560', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:54');
INSERT INTO `iot_device_log` VALUES ('3561', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:55');
INSERT INTO `iot_device_log` VALUES ('3562', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:55');
INSERT INTO `iot_device_log` VALUES ('3563', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:56');
INSERT INTO `iot_device_log` VALUES ('3564', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:57');
INSERT INTO `iot_device_log` VALUES ('3565', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:58');
INSERT INTO `iot_device_log` VALUES ('3566', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:58');
INSERT INTO `iot_device_log` VALUES ('3567', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:40:59');
INSERT INTO `iot_device_log` VALUES ('3568', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:00');
INSERT INTO `iot_device_log` VALUES ('3569', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:01');
INSERT INTO `iot_device_log` VALUES ('3570', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:01');
INSERT INTO `iot_device_log` VALUES ('3571', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:02');
INSERT INTO `iot_device_log` VALUES ('3572', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:03');
INSERT INTO `iot_device_log` VALUES ('3573', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:03');
INSERT INTO `iot_device_log` VALUES ('3574', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:04');
INSERT INTO `iot_device_log` VALUES ('3575', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:04');
INSERT INTO `iot_device_log` VALUES ('3576', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:05');
INSERT INTO `iot_device_log` VALUES ('3577', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:05');
INSERT INTO `iot_device_log` VALUES ('3578', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:06');
INSERT INTO `iot_device_log` VALUES ('3579', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:07');
INSERT INTO `iot_device_log` VALUES ('3580', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:07');
INSERT INTO `iot_device_log` VALUES ('3581', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:08');
INSERT INTO `iot_device_log` VALUES ('3582', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:09');
INSERT INTO `iot_device_log` VALUES ('3583', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:09');
INSERT INTO `iot_device_log` VALUES ('3584', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:10');
INSERT INTO `iot_device_log` VALUES ('3585', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:11');
INSERT INTO `iot_device_log` VALUES ('3586', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:11');
INSERT INTO `iot_device_log` VALUES ('3587', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:12');
INSERT INTO `iot_device_log` VALUES ('3588', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:12');
INSERT INTO `iot_device_log` VALUES ('3589', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:13');
INSERT INTO `iot_device_log` VALUES ('3590', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:13');
INSERT INTO `iot_device_log` VALUES ('3591', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:14');
INSERT INTO `iot_device_log` VALUES ('3592', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:14');
INSERT INTO `iot_device_log` VALUES ('3593', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:15');
INSERT INTO `iot_device_log` VALUES ('3594', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:16');
INSERT INTO `iot_device_log` VALUES ('3595', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:16');
INSERT INTO `iot_device_log` VALUES ('3596', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:17');
INSERT INTO `iot_device_log` VALUES ('3597', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:17');
INSERT INTO `iot_device_log` VALUES ('3598', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:18');
INSERT INTO `iot_device_log` VALUES ('3599', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:19');
INSERT INTO `iot_device_log` VALUES ('3600', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:19');
INSERT INTO `iot_device_log` VALUES ('3601', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:20');
INSERT INTO `iot_device_log` VALUES ('3602', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:20');
INSERT INTO `iot_device_log` VALUES ('3603', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:21');
INSERT INTO `iot_device_log` VALUES ('3604', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:21');
INSERT INTO `iot_device_log` VALUES ('3605', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:22');
INSERT INTO `iot_device_log` VALUES ('3606', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:23');
INSERT INTO `iot_device_log` VALUES ('3607', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:23');
INSERT INTO `iot_device_log` VALUES ('3608', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:24');
INSERT INTO `iot_device_log` VALUES ('3609', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:24');
INSERT INTO `iot_device_log` VALUES ('3610', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:25');
INSERT INTO `iot_device_log` VALUES ('3611', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:26');
INSERT INTO `iot_device_log` VALUES ('3612', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:26');
INSERT INTO `iot_device_log` VALUES ('3613', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:27');
INSERT INTO `iot_device_log` VALUES ('3614', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:27');
INSERT INTO `iot_device_log` VALUES ('3615', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:28');
INSERT INTO `iot_device_log` VALUES ('3616', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:29');
INSERT INTO `iot_device_log` VALUES ('3617', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:29');
INSERT INTO `iot_device_log` VALUES ('3618', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:30');
INSERT INTO `iot_device_log` VALUES ('3619', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:30');
INSERT INTO `iot_device_log` VALUES ('3620', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:31');
INSERT INTO `iot_device_log` VALUES ('3621', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:31');
INSERT INTO `iot_device_log` VALUES ('3622', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:44');
INSERT INTO `iot_device_log` VALUES ('3623', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:45');
INSERT INTO `iot_device_log` VALUES ('3624', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:46');
INSERT INTO `iot_device_log` VALUES ('3625', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:47');
INSERT INTO `iot_device_log` VALUES ('3626', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:47');
INSERT INTO `iot_device_log` VALUES ('3627', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:48');
INSERT INTO `iot_device_log` VALUES ('3628', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:48');
INSERT INTO `iot_device_log` VALUES ('3629', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:51');
INSERT INTO `iot_device_log` VALUES ('3630', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:51');
INSERT INTO `iot_device_log` VALUES ('3631', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:52');
INSERT INTO `iot_device_log` VALUES ('3632', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:53');
INSERT INTO `iot_device_log` VALUES ('3633', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:54');
INSERT INTO `iot_device_log` VALUES ('3634', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:54');
INSERT INTO `iot_device_log` VALUES ('3635', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:55');
INSERT INTO `iot_device_log` VALUES ('3636', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:56');
INSERT INTO `iot_device_log` VALUES ('3637', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-21 20:41:56');
INSERT INTO `iot_device_log` VALUES ('3638', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 21:57:52');
INSERT INTO `iot_device_log` VALUES ('3639', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-21 21:57:53');
INSERT INTO `iot_device_log` VALUES ('3640', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 22:06:56');
INSERT INTO `iot_device_log` VALUES ('3641', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 22:06:56');
INSERT INTO `iot_device_log` VALUES ('3642', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-21 22:06:57');
INSERT INTO `iot_device_log` VALUES ('3643', '21', 'TEMPERATURE', '2', '75.26', '75.26', '1', '2016-04-22 09:11:03');
INSERT INTO `iot_device_log` VALUES ('3644', '21', 'HUMIDITY', '2', '27.11', '27.11', '1', '2016-04-22 09:11:03');
INSERT INTO `iot_device_log` VALUES ('3645', '21', 'TEMPERATURE', '2', '80.77', '80.77', '1', '2016-04-22 09:11:13');
INSERT INTO `iot_device_log` VALUES ('3646', '21', 'HUMIDITY', '2', '28.02', '28.02', '1', '2016-04-22 09:11:13');
INSERT INTO `iot_device_log` VALUES ('3647', '21', 'TEMPERATURE', '2', '62.16', '62.16', '1', '2016-04-22 09:11:52');
INSERT INTO `iot_device_log` VALUES ('3648', '21', 'HUMIDITY', '2', '30.91', '30.91', '1', '2016-04-22 09:11:52');
INSERT INTO `iot_device_log` VALUES ('3649', '21', 'TEMPERATURE', '2', '61.67', '61.67', '1', '2016-04-22 09:12:02');
INSERT INTO `iot_device_log` VALUES ('3650', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-22 09:12:02');
INSERT INTO `iot_device_log` VALUES ('3651', '21', 'TEMPERATURE', '2', '58.31', '58.31', '1', '2016-04-22 09:12:12');
INSERT INTO `iot_device_log` VALUES ('3652', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-22 09:12:12');
INSERT INTO `iot_device_log` VALUES ('3653', '21', 'TEMPERATURE', '2', '59.08', '59.08', '1', '2016-04-22 09:12:22');
INSERT INTO `iot_device_log` VALUES ('3654', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 09:12:22');
INSERT INTO `iot_device_log` VALUES ('3655', '21', 'TEMPERATURE', '2', '58.61', '58.61', '1', '2016-04-22 09:12:32');
INSERT INTO `iot_device_log` VALUES ('3656', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 09:12:32');
INSERT INTO `iot_device_log` VALUES ('3657', '21', 'TEMPERATURE', '2', '69.01', '69.01', '1', '2016-04-22 09:12:42');
INSERT INTO `iot_device_log` VALUES ('3658', '21', 'HUMIDITY', '2', '32.23', '32.23', '1', '2016-04-22 09:12:42');
INSERT INTO `iot_device_log` VALUES ('3659', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:46:14');
INSERT INTO `iot_device_log` VALUES ('3660', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:46:17');
INSERT INTO `iot_device_log` VALUES ('3661', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 09:46:21');
INSERT INTO `iot_device_log` VALUES ('3662', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:30');
INSERT INTO `iot_device_log` VALUES ('3663', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:31');
INSERT INTO `iot_device_log` VALUES ('3664', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:32');
INSERT INTO `iot_device_log` VALUES ('3665', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:33');
INSERT INTO `iot_device_log` VALUES ('3666', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:34');
INSERT INTO `iot_device_log` VALUES ('3667', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:35');
INSERT INTO `iot_device_log` VALUES ('3668', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:36');
INSERT INTO `iot_device_log` VALUES ('3669', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:36');
INSERT INTO `iot_device_log` VALUES ('3670', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:36');
INSERT INTO `iot_device_log` VALUES ('3671', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:46:49');
INSERT INTO `iot_device_log` VALUES ('3672', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:53');
INSERT INTO `iot_device_log` VALUES ('3673', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:46:55');
INSERT INTO `iot_device_log` VALUES ('3674', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:46:56');
INSERT INTO `iot_device_log` VALUES ('3675', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 09:46:58');
INSERT INTO `iot_device_log` VALUES ('3676', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:46:59');
INSERT INTO `iot_device_log` VALUES ('3677', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:01');
INSERT INTO `iot_device_log` VALUES ('3678', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:03');
INSERT INTO `iot_device_log` VALUES ('3679', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:04');
INSERT INTO `iot_device_log` VALUES ('3680', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:05');
INSERT INTO `iot_device_log` VALUES ('3681', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:06');
INSERT INTO `iot_device_log` VALUES ('3682', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:07');
INSERT INTO `iot_device_log` VALUES ('3683', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:09');
INSERT INTO `iot_device_log` VALUES ('3684', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:09');
INSERT INTO `iot_device_log` VALUES ('3685', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:10');
INSERT INTO `iot_device_log` VALUES ('3686', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:11');
INSERT INTO `iot_device_log` VALUES ('3687', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:12');
INSERT INTO `iot_device_log` VALUES ('3688', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:12');
INSERT INTO `iot_device_log` VALUES ('3689', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:13');
INSERT INTO `iot_device_log` VALUES ('3690', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:14');
INSERT INTO `iot_device_log` VALUES ('3691', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:47:17');
INSERT INTO `iot_device_log` VALUES ('3692', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:47:17');
INSERT INTO `iot_device_log` VALUES ('3693', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 09:47:20');
INSERT INTO `iot_device_log` VALUES ('3694', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:22');
INSERT INTO `iot_device_log` VALUES ('3695', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:29');
INSERT INTO `iot_device_log` VALUES ('3696', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:47:48');
INSERT INTO `iot_device_log` VALUES ('3697', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 09:47:54');
INSERT INTO `iot_device_log` VALUES ('3698', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:47:58');
INSERT INTO `iot_device_log` VALUES ('3699', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:48:10');
INSERT INTO `iot_device_log` VALUES ('3700', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:48:14');
INSERT INTO `iot_device_log` VALUES ('3701', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 09:48:22');
INSERT INTO `iot_device_log` VALUES ('3702', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:28');
INSERT INTO `iot_device_log` VALUES ('3703', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:30');
INSERT INTO `iot_device_log` VALUES ('3704', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:31');
INSERT INTO `iot_device_log` VALUES ('3705', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:33');
INSERT INTO `iot_device_log` VALUES ('3706', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:34');
INSERT INTO `iot_device_log` VALUES ('3707', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:36');
INSERT INTO `iot_device_log` VALUES ('3708', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:37');
INSERT INTO `iot_device_log` VALUES ('3709', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:38');
INSERT INTO `iot_device_log` VALUES ('3710', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:39');
INSERT INTO `iot_device_log` VALUES ('3711', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:41');
INSERT INTO `iot_device_log` VALUES ('3712', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:42');
INSERT INTO `iot_device_log` VALUES ('3713', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:43');
INSERT INTO `iot_device_log` VALUES ('3714', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:45');
INSERT INTO `iot_device_log` VALUES ('3715', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:47');
INSERT INTO `iot_device_log` VALUES ('3716', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:48:48');
INSERT INTO `iot_device_log` VALUES ('3717', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:48:54');
INSERT INTO `iot_device_log` VALUES ('3718', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 09:48:56');
INSERT INTO `iot_device_log` VALUES ('3719', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:49:02');
INSERT INTO `iot_device_log` VALUES ('3720', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:49:06');
INSERT INTO `iot_device_log` VALUES ('3721', '21', 'TEMPERATURE', '2', '55.6', '55.6', '1', '2016-04-22 09:52:16');
INSERT INTO `iot_device_log` VALUES ('3722', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 09:52:16');
INSERT INTO `iot_device_log` VALUES ('3723', '21', 'TEMPERATURE', '2', '54.45', '54.45', '1', '2016-04-22 09:52:26');
INSERT INTO `iot_device_log` VALUES ('3724', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 09:52:26');
INSERT INTO `iot_device_log` VALUES ('3725', '21', 'TEMPERATURE', '2', '53.66', '53.66', '1', '2016-04-22 09:52:35');
INSERT INTO `iot_device_log` VALUES ('3726', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 09:52:36');
INSERT INTO `iot_device_log` VALUES ('3727', '21', 'TEMPERATURE', '2', '52.84', '52.84', '1', '2016-04-22 09:52:46');
INSERT INTO `iot_device_log` VALUES ('3728', '21', 'HUMIDITY', '2', '30.95', '30.95', '1', '2016-04-22 09:52:46');
INSERT INTO `iot_device_log` VALUES ('3729', '21', 'TEMPERATURE', '2', '52.61', '52.61', '1', '2016-04-22 09:52:56');
INSERT INTO `iot_device_log` VALUES ('3730', '21', 'HUMIDITY', '2', '30.63', '30.63', '1', '2016-04-22 09:52:56');
INSERT INTO `iot_device_log` VALUES ('3731', '21', 'TEMPERATURE', '2', '52.76', '52.76', '1', '2016-04-22 09:53:06');
INSERT INTO `iot_device_log` VALUES ('3732', '21', 'HUMIDITY', '2', '30.4', '30.4', '1', '2016-04-22 09:53:06');
INSERT INTO `iot_device_log` VALUES ('3733', '21', 'TEMPERATURE', '2', '52.73', '52.73', '1', '2016-04-22 09:53:16');
INSERT INTO `iot_device_log` VALUES ('3734', '21', 'HUMIDITY', '2', '30.25', '30.25', '1', '2016-04-22 09:53:16');
INSERT INTO `iot_device_log` VALUES ('3735', '21', 'TEMPERATURE', '2', '52.49', '52.49', '1', '2016-04-22 09:53:26');
INSERT INTO `iot_device_log` VALUES ('3736', '21', 'HUMIDITY', '2', '30.16', '30.16', '1', '2016-04-22 09:53:26');
INSERT INTO `iot_device_log` VALUES ('3737', '21', 'TEMPERATURE', '2', '52.62', '52.62', '1', '2016-04-22 09:53:36');
INSERT INTO `iot_device_log` VALUES ('3738', '21', 'HUMIDITY', '2', '29.97', '29.97', '1', '2016-04-22 09:53:36');
INSERT INTO `iot_device_log` VALUES ('3739', '21', 'TEMPERATURE', '2', '53.06', '53.06', '1', '2016-04-22 09:53:46');
INSERT INTO `iot_device_log` VALUES ('3740', '21', 'HUMIDITY', '2', '29.68', '29.68', '1', '2016-04-22 09:53:46');
INSERT INTO `iot_device_log` VALUES ('3741', '21', 'TEMPERATURE', '2', '52.82', '52.82', '1', '2016-04-22 09:53:56');
INSERT INTO `iot_device_log` VALUES ('3742', '21', 'HUMIDITY', '2', '29.8', '29.8', '1', '2016-04-22 09:53:56');
INSERT INTO `iot_device_log` VALUES ('3743', '21', 'TEMPERATURE', '2', '52.52', '52.52', '1', '2016-04-22 09:54:06');
INSERT INTO `iot_device_log` VALUES ('3744', '21', 'HUMIDITY', '2', '29.73', '29.73', '1', '2016-04-22 09:54:06');
INSERT INTO `iot_device_log` VALUES ('3745', '21', 'TEMPERATURE', '2', '52.54', '52.54', '1', '2016-04-22 09:54:16');
INSERT INTO `iot_device_log` VALUES ('3746', '21', 'HUMIDITY', '2', '29.81', '29.81', '1', '2016-04-22 09:54:16');
INSERT INTO `iot_device_log` VALUES ('3747', '21', 'TEMPERATURE', '2', '52.68', '52.68', '1', '2016-04-22 09:54:26');
INSERT INTO `iot_device_log` VALUES ('3748', '21', 'HUMIDITY', '2', '29.88', '29.88', '1', '2016-04-22 09:54:26');
INSERT INTO `iot_device_log` VALUES ('3749', '21', 'TEMPERATURE', '2', '53.35', '53.35', '1', '2016-04-22 09:54:36');
INSERT INTO `iot_device_log` VALUES ('3750', '21', 'HUMIDITY', '2', '29.98', '29.98', '1', '2016-04-22 09:54:36');
INSERT INTO `iot_device_log` VALUES ('3751', '21', 'TEMPERATURE', '2', '51.75', '51.75', '1', '2016-04-22 09:54:46');
INSERT INTO `iot_device_log` VALUES ('3752', '21', 'HUMIDITY', '2', '30.14', '30.14', '1', '2016-04-22 09:54:46');
INSERT INTO `iot_device_log` VALUES ('3753', '21', 'TEMPERATURE', '2', '51.79', '51.79', '1', '2016-04-22 09:54:56');
INSERT INTO `iot_device_log` VALUES ('3754', '21', 'HUMIDITY', '2', '30.29', '30.29', '1', '2016-04-22 09:54:56');
INSERT INTO `iot_device_log` VALUES ('3755', '21', 'TEMPERATURE', '2', '51.16', '51.16', '1', '2016-04-22 09:55:06');
INSERT INTO `iot_device_log` VALUES ('3756', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 09:55:06');
INSERT INTO `iot_device_log` VALUES ('3757', '21', 'TEMPERATURE', '2', '50.9', '50.9', '1', '2016-04-22 09:55:16');
INSERT INTO `iot_device_log` VALUES ('3758', '21', 'HUMIDITY', '2', '30.82', '30.82', '1', '2016-04-22 09:55:16');
INSERT INTO `iot_device_log` VALUES ('3759', '21', 'TEMPERATURE', '2', '49.77', '49.77', '1', '2016-04-22 09:55:26');
INSERT INTO `iot_device_log` VALUES ('3760', '21', 'HUMIDITY', '2', '30.73', '30.73', '1', '2016-04-22 09:55:26');
INSERT INTO `iot_device_log` VALUES ('3761', '21', 'TEMPERATURE', '2', '50.18', '50.18', '1', '2016-04-22 09:55:36');
INSERT INTO `iot_device_log` VALUES ('3762', '21', 'HUMIDITY', '2', '30.34', '30.34', '1', '2016-04-22 09:55:36');
INSERT INTO `iot_device_log` VALUES ('3763', '21', 'TEMPERATURE', '2', '50.38', '50.38', '1', '2016-04-22 09:55:46');
INSERT INTO `iot_device_log` VALUES ('3764', '21', 'HUMIDITY', '2', '30.14', '30.14', '1', '2016-04-22 09:55:46');
INSERT INTO `iot_device_log` VALUES ('3765', '21', 'TEMPERATURE', '2', '51.32', '51.32', '1', '2016-04-22 09:55:56');
INSERT INTO `iot_device_log` VALUES ('3766', '21', 'HUMIDITY', '2', '29.95', '29.95', '1', '2016-04-22 09:55:56');
INSERT INTO `iot_device_log` VALUES ('3767', '21', 'TEMPERATURE', '2', '50.61', '50.61', '1', '2016-04-22 09:56:06');
INSERT INTO `iot_device_log` VALUES ('3768', '21', 'HUMIDITY', '2', '30.08', '30.08', '1', '2016-04-22 09:56:06');
INSERT INTO `iot_device_log` VALUES ('3769', '21', 'TEMPERATURE', '2', '51.43', '51.43', '1', '2016-04-22 09:56:16');
INSERT INTO `iot_device_log` VALUES ('3770', '21', 'HUMIDITY', '2', '29.92', '29.92', '1', '2016-04-22 09:56:16');
INSERT INTO `iot_device_log` VALUES ('3771', '21', 'TEMPERATURE', '2', '50.83', '50.83', '1', '2016-04-22 09:56:28');
INSERT INTO `iot_device_log` VALUES ('3772', '21', 'HUMIDITY', '2', '29.73', '29.73', '1', '2016-04-22 09:56:28');
INSERT INTO `iot_device_log` VALUES ('3773', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:56:34');
INSERT INTO `iot_device_log` VALUES ('3774', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:56:34');
INSERT INTO `iot_device_log` VALUES ('3775', '21', 'TEMPERATURE', '2', '51.04', '51.04', '1', '2016-04-22 09:56:36');
INSERT INTO `iot_device_log` VALUES ('3776', '21', 'HUMIDITY', '2', '29.84', '29.84', '1', '2016-04-22 09:56:36');
INSERT INTO `iot_device_log` VALUES ('3777', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:37');
INSERT INTO `iot_device_log` VALUES ('3778', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:39');
INSERT INTO `iot_device_log` VALUES ('3779', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:42');
INSERT INTO `iot_device_log` VALUES ('3780', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:44');
INSERT INTO `iot_device_log` VALUES ('3781', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:45');
INSERT INTO `iot_device_log` VALUES ('3782', '21', 'TEMPERATURE', '2', '50.65', '50.65', '1', '2016-04-22 09:56:46');
INSERT INTO `iot_device_log` VALUES ('3783', '21', 'HUMIDITY', '2', '30.02', '30.02', '1', '2016-04-22 09:56:46');
INSERT INTO `iot_device_log` VALUES ('3784', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:46');
INSERT INTO `iot_device_log` VALUES ('3785', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:47');
INSERT INTO `iot_device_log` VALUES ('3786', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:48');
INSERT INTO `iot_device_log` VALUES ('3787', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:50');
INSERT INTO `iot_device_log` VALUES ('3788', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:51');
INSERT INTO `iot_device_log` VALUES ('3789', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:52');
INSERT INTO `iot_device_log` VALUES ('3790', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:56:53');
INSERT INTO `iot_device_log` VALUES ('3791', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 09:56:56');
INSERT INTO `iot_device_log` VALUES ('3792', '21', 'TEMPERATURE', '2', '50.69', '50.69', '1', '2016-04-22 09:56:56');
INSERT INTO `iot_device_log` VALUES ('3793', '21', 'HUMIDITY', '2', '29.87', '29.87', '1', '2016-04-22 09:56:56');
INSERT INTO `iot_device_log` VALUES ('3794', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:57:01');
INSERT INTO `iot_device_log` VALUES ('3795', '21', 'TEMPERATURE', '2', '50.92', '50.92', '1', '2016-04-22 09:57:06');
INSERT INTO `iot_device_log` VALUES ('3796', '21', 'HUMIDITY', '2', '29.79', '29.79', '1', '2016-04-22 09:57:06');
INSERT INTO `iot_device_log` VALUES ('3797', '21', 'TEMPERATURE', '2', '51.02', '51.02', '1', '2016-04-22 09:57:16');
INSERT INTO `iot_device_log` VALUES ('3798', '21', 'HUMIDITY', '2', '29.57', '29.57', '1', '2016-04-22 09:57:16');
INSERT INTO `iot_device_log` VALUES ('3799', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 09:57:16');
INSERT INTO `iot_device_log` VALUES ('3800', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:57:19');
INSERT INTO `iot_device_log` VALUES ('3801', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:57:24');
INSERT INTO `iot_device_log` VALUES ('3802', '21', 'TEMPERATURE', '2', '51.13', '51.13', '1', '2016-04-22 09:57:26');
INSERT INTO `iot_device_log` VALUES ('3803', '21', 'HUMIDITY', '2', '29.54', '29.54', '1', '2016-04-22 09:57:26');
INSERT INTO `iot_device_log` VALUES ('3804', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:57:30');
INSERT INTO `iot_device_log` VALUES ('3805', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:57:31');
INSERT INTO `iot_device_log` VALUES ('3806', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:57:35');
INSERT INTO `iot_device_log` VALUES ('3807', '21', 'TEMPERATURE', '2', '51.18', '51.18', '1', '2016-04-22 09:57:36');
INSERT INTO `iot_device_log` VALUES ('3808', '21', 'HUMIDITY', '2', '29.54', '29.54', '1', '2016-04-22 09:57:36');
INSERT INTO `iot_device_log` VALUES ('3809', '21', 'TEMPERATURE', '2', '53.59', '53.59', '1', '2016-04-22 09:57:46');
INSERT INTO `iot_device_log` VALUES ('3810', '21', 'HUMIDITY', '2', '29.75', '29.75', '1', '2016-04-22 09:57:46');
INSERT INTO `iot_device_log` VALUES ('3811', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:58:56');
INSERT INTO `iot_device_log` VALUES ('3812', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 09:59:01');
INSERT INTO `iot_device_log` VALUES ('3813', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:59:16');
INSERT INTO `iot_device_log` VALUES ('3814', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 09:59:30');
INSERT INTO `iot_device_log` VALUES ('3815', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 09:59:39');
INSERT INTO `iot_device_log` VALUES ('3816', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 10:00:42');
INSERT INTO `iot_device_log` VALUES ('3817', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 10:01:06');
INSERT INTO `iot_device_log` VALUES ('3818', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 10:01:30');
INSERT INTO `iot_device_log` VALUES ('3819', '21', 'TEMPERATURE', '2', '65.2', '65.2', '1', '2016-04-22 10:11:33');
INSERT INTO `iot_device_log` VALUES ('3820', '21', 'HUMIDITY', '2', '25.81', '25.81', '1', '2016-04-22 10:11:33');
INSERT INTO `iot_device_log` VALUES ('3821', '21', 'TEMPERATURE', '2', '61.81', '61.81', '1', '2016-04-22 10:11:42');
INSERT INTO `iot_device_log` VALUES ('3822', '21', 'HUMIDITY', '2', '26.41', '26.41', '1', '2016-04-22 10:11:42');
INSERT INTO `iot_device_log` VALUES ('3823', '21', 'TEMPERATURE', '2', '60.2', '60.2', '1', '2016-04-22 10:11:52');
INSERT INTO `iot_device_log` VALUES ('3824', '21', 'HUMIDITY', '2', '27.01', '27.01', '1', '2016-04-22 10:11:52');
INSERT INTO `iot_device_log` VALUES ('3825', '21', 'TEMPERATURE', '2', '58.51', '58.51', '1', '2016-04-22 10:12:02');
INSERT INTO `iot_device_log` VALUES ('3826', '21', 'HUMIDITY', '2', '27.38', '27.38', '1', '2016-04-22 10:12:02');
INSERT INTO `iot_device_log` VALUES ('3827', '21', 'TEMPERATURE', '2', '57.28', '57.28', '1', '2016-04-22 10:12:12');
INSERT INTO `iot_device_log` VALUES ('3828', '21', 'HUMIDITY', '2', '27.75', '27.75', '1', '2016-04-22 10:12:12');
INSERT INTO `iot_device_log` VALUES ('3829', '21', 'TEMPERATURE', '2', '56.8', '56.8', '1', '2016-04-22 10:12:22');
INSERT INTO `iot_device_log` VALUES ('3830', '21', 'HUMIDITY', '2', '28.06', '28.06', '1', '2016-04-22 10:12:22');
INSERT INTO `iot_device_log` VALUES ('3831', '21', 'TEMPERATURE', '2', '56.41', '56.41', '1', '2016-04-22 10:12:32');
INSERT INTO `iot_device_log` VALUES ('3832', '21', 'HUMIDITY', '2', '28.34', '28.34', '1', '2016-04-22 10:12:32');
INSERT INTO `iot_device_log` VALUES ('3833', '21', 'TEMPERATURE', '2', '54.79', '54.79', '1', '2016-04-22 10:12:42');
INSERT INTO `iot_device_log` VALUES ('3834', '21', 'HUMIDITY', '2', '28.47', '28.47', '1', '2016-04-22 10:12:42');
INSERT INTO `iot_device_log` VALUES ('3835', '21', 'TEMPERATURE', '2', '54.38', '54.38', '1', '2016-04-22 10:12:52');
INSERT INTO `iot_device_log` VALUES ('3836', '21', 'HUMIDITY', '2', '28.49', '28.49', '1', '2016-04-22 10:12:52');
INSERT INTO `iot_device_log` VALUES ('3837', '21', 'TEMPERATURE', '2', '54.29', '54.29', '1', '2016-04-22 10:13:02');
INSERT INTO `iot_device_log` VALUES ('3838', '21', 'HUMIDITY', '2', '28.69', '28.69', '1', '2016-04-22 10:13:02');
INSERT INTO `iot_device_log` VALUES ('3839', '21', 'TEMPERATURE', '2', '53.07', '53.07', '1', '2016-04-22 10:13:12');
INSERT INTO `iot_device_log` VALUES ('3840', '21', 'HUMIDITY', '2', '28.79', '28.79', '1', '2016-04-22 10:13:12');
INSERT INTO `iot_device_log` VALUES ('3841', '21', 'TEMPERATURE', '2', '52.89', '52.89', '1', '2016-04-22 10:13:22');
INSERT INTO `iot_device_log` VALUES ('3842', '21', 'HUMIDITY', '2', '28.79', '28.79', '1', '2016-04-22 10:13:22');
INSERT INTO `iot_device_log` VALUES ('3843', '21', 'TEMPERATURE', '2', '52.68', '52.68', '1', '2016-04-22 10:13:32');
INSERT INTO `iot_device_log` VALUES ('3844', '21', 'HUMIDITY', '2', '28.95', '28.95', '1', '2016-04-22 10:13:32');
INSERT INTO `iot_device_log` VALUES ('3845', '21', 'TEMPERATURE', '2', '51.8', '51.8', '1', '2016-04-22 10:13:42');
INSERT INTO `iot_device_log` VALUES ('3846', '21', 'HUMIDITY', '2', '29.06', '29.06', '1', '2016-04-22 10:13:42');
INSERT INTO `iot_device_log` VALUES ('3847', '21', 'TEMPERATURE', '2', '51.89', '51.89', '1', '2016-04-22 10:13:52');
INSERT INTO `iot_device_log` VALUES ('3848', '21', 'HUMIDITY', '2', '29.17', '29.17', '1', '2016-04-22 10:13:52');
INSERT INTO `iot_device_log` VALUES ('3849', '21', 'TEMPERATURE', '2', '51.16', '51.16', '1', '2016-04-22 10:14:02');
INSERT INTO `iot_device_log` VALUES ('3850', '21', 'HUMIDITY', '2', '29.28', '29.28', '1', '2016-04-22 10:14:02');
INSERT INTO `iot_device_log` VALUES ('3851', '21', 'TEMPERATURE', '2', '50.99', '50.99', '1', '2016-04-22 10:14:13');
INSERT INTO `iot_device_log` VALUES ('3852', '21', 'HUMIDITY', '2', '29.39', '29.39', '1', '2016-04-22 10:14:13');
INSERT INTO `iot_device_log` VALUES ('3853', '21', 'TEMPERATURE', '2', '50.56', '50.56', '1', '2016-04-22 10:14:23');
INSERT INTO `iot_device_log` VALUES ('3854', '21', 'HUMIDITY', '2', '29.57', '29.57', '1', '2016-04-22 10:14:23');
INSERT INTO `iot_device_log` VALUES ('3855', '21', 'TEMPERATURE', '2', '50.58', '50.58', '1', '2016-04-22 10:14:46');
INSERT INTO `iot_device_log` VALUES ('3856', '21', 'HUMIDITY', '2', '29.62', '29.62', '1', '2016-04-22 10:14:46');
INSERT INTO `iot_device_log` VALUES ('3857', '21', 'TEMPERATURE', '2', '50.63', '50.63', '1', '2016-04-22 10:14:47');
INSERT INTO `iot_device_log` VALUES ('3858', '21', 'HUMIDITY', '2', '29.48', '29.48', '1', '2016-04-22 10:14:47');
INSERT INTO `iot_device_log` VALUES ('3859', '21', 'TEMPERATURE', '2', '50.54', '50.54', '1', '2016-04-22 10:14:52');
INSERT INTO `iot_device_log` VALUES ('3860', '21', 'HUMIDITY', '2', '29.46', '29.46', '1', '2016-04-22 10:14:52');
INSERT INTO `iot_device_log` VALUES ('3861', '21', 'TEMPERATURE', '2', '50.23', '50.23', '1', '2016-04-22 10:15:03');
INSERT INTO `iot_device_log` VALUES ('3862', '21', 'HUMIDITY', '2', '29.5', '29.5', '1', '2016-04-22 10:15:03');
INSERT INTO `iot_device_log` VALUES ('3863', '21', 'TEMPERATURE', '2', '49.96', '49.96', '1', '2016-04-22 10:15:12');
INSERT INTO `iot_device_log` VALUES ('3864', '21', 'HUMIDITY', '2', '29.65', '29.65', '1', '2016-04-22 10:15:12');
INSERT INTO `iot_device_log` VALUES ('3865', '21', 'TEMPERATURE', '2', '49.73', '49.73', '1', '2016-04-22 10:15:23');
INSERT INTO `iot_device_log` VALUES ('3866', '21', 'HUMIDITY', '2', '29.72', '29.72', '1', '2016-04-22 10:15:23');
INSERT INTO `iot_device_log` VALUES ('3867', '21', 'TEMPERATURE', '2', '49.6', '49.6', '1', '2016-04-22 10:15:32');
INSERT INTO `iot_device_log` VALUES ('3868', '21', 'HUMIDITY', '2', '29.72', '29.72', '1', '2016-04-22 10:15:32');
INSERT INTO `iot_device_log` VALUES ('3869', '21', 'TEMPERATURE', '2', '49.4', '49.4', '1', '2016-04-22 10:15:45');
INSERT INTO `iot_device_log` VALUES ('3870', '21', 'HUMIDITY', '2', '29.66', '29.66', '1', '2016-04-22 10:15:45');
INSERT INTO `iot_device_log` VALUES ('3871', '21', 'TEMPERATURE', '2', '49.75', '49.75', '1', '2016-04-22 10:15:52');
INSERT INTO `iot_device_log` VALUES ('3872', '21', 'HUMIDITY', '2', '29.62', '29.62', '1', '2016-04-22 10:15:52');
INSERT INTO `iot_device_log` VALUES ('3873', '21', 'TEMPERATURE', '2', '49.42', '49.42', '1', '2016-04-22 10:16:02');
INSERT INTO `iot_device_log` VALUES ('3874', '21', 'HUMIDITY', '2', '29.8', '29.8', '1', '2016-04-22 10:16:02');
INSERT INTO `iot_device_log` VALUES ('3875', '21', 'TEMPERATURE', '2', '49.69', '49.69', '1', '2016-04-22 10:16:12');
INSERT INTO `iot_device_log` VALUES ('3876', '21', 'HUMIDITY', '2', '29.94', '29.94', '1', '2016-04-22 10:16:12');
INSERT INTO `iot_device_log` VALUES ('3877', '21', 'TEMPERATURE', '2', '49.39', '49.39', '1', '2016-04-22 10:16:22');
INSERT INTO `iot_device_log` VALUES ('3878', '21', 'HUMIDITY', '2', '29.79', '29.79', '1', '2016-04-22 10:16:22');
INSERT INTO `iot_device_log` VALUES ('3879', '21', 'TEMPERATURE', '2', '48.94', '48.94', '1', '2016-04-22 10:16:32');
INSERT INTO `iot_device_log` VALUES ('3880', '21', 'HUMIDITY', '2', '29.95', '29.95', '1', '2016-04-22 10:16:32');
INSERT INTO `iot_device_log` VALUES ('3881', '21', 'TEMPERATURE', '2', '48.59', '48.59', '1', '2016-04-22 10:16:42');
INSERT INTO `iot_device_log` VALUES ('3882', '21', 'HUMIDITY', '2', '30.13', '30.13', '1', '2016-04-22 10:16:42');
INSERT INTO `iot_device_log` VALUES ('3883', '21', 'TEMPERATURE', '2', '48.14', '48.14', '1', '2016-04-22 10:16:52');
INSERT INTO `iot_device_log` VALUES ('3884', '21', 'HUMIDITY', '2', '30.39', '30.39', '1', '2016-04-22 10:16:52');
INSERT INTO `iot_device_log` VALUES ('3885', '21', 'TEMPERATURE', '2', '47.61', '47.61', '1', '2016-04-22 10:17:02');
INSERT INTO `iot_device_log` VALUES ('3886', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 10:17:02');
INSERT INTO `iot_device_log` VALUES ('3887', '21', 'TEMPERATURE', '2', '47.36', '47.36', '1', '2016-04-22 10:17:24');
INSERT INTO `iot_device_log` VALUES ('3888', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-22 10:17:24');
INSERT INTO `iot_device_log` VALUES ('3889', '21', 'TEMPERATURE', '2', '46.6', '46.6', '1', '2016-04-22 10:17:32');
INSERT INTO `iot_device_log` VALUES ('3890', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 10:17:32');
INSERT INTO `iot_device_log` VALUES ('3891', '21', 'TEMPERATURE', '2', '46.92', '46.92', '1', '2016-04-22 10:17:42');
INSERT INTO `iot_device_log` VALUES ('3892', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-22 10:17:42');
INSERT INTO `iot_device_log` VALUES ('3893', '21', 'TEMPERATURE', '2', '46.79', '46.79', '1', '2016-04-22 10:18:04');
INSERT INTO `iot_device_log` VALUES ('3894', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 10:18:04');
INSERT INTO `iot_device_log` VALUES ('3895', '21', 'TEMPERATURE', '2', '46.32', '46.32', '1', '2016-04-22 10:18:12');
INSERT INTO `iot_device_log` VALUES ('3896', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 10:18:12');
INSERT INTO `iot_device_log` VALUES ('3897', '21', 'TEMPERATURE', '2', '46.32', '46.32', '1', '2016-04-22 10:18:22');
INSERT INTO `iot_device_log` VALUES ('3898', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-22 10:18:22');
INSERT INTO `iot_device_log` VALUES ('3899', '21', 'TEMPERATURE', '2', '45.62', '45.62', '1', '2016-04-22 10:18:32');
INSERT INTO `iot_device_log` VALUES ('3900', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 10:18:32');
INSERT INTO `iot_device_log` VALUES ('3901', '21', 'TEMPERATURE', '2', '45.61', '45.61', '1', '2016-04-22 10:18:42');
INSERT INTO `iot_device_log` VALUES ('3902', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 10:18:42');
INSERT INTO `iot_device_log` VALUES ('3903', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-22 10:18:52');
INSERT INTO `iot_device_log` VALUES ('3904', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 10:18:52');
INSERT INTO `iot_device_log` VALUES ('3905', '21', 'TEMPERATURE', '2', '45.93', '45.93', '1', '2016-04-22 10:19:02');
INSERT INTO `iot_device_log` VALUES ('3906', '21', 'HUMIDITY', '2', '31.44', '31.44', '1', '2016-04-22 10:19:02');
INSERT INTO `iot_device_log` VALUES ('3907', '21', 'TEMPERATURE', '2', '46.07', '46.07', '1', '2016-04-22 10:19:12');
INSERT INTO `iot_device_log` VALUES ('3908', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-22 10:19:12');
INSERT INTO `iot_device_log` VALUES ('3909', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-22 10:19:22');
INSERT INTO `iot_device_log` VALUES ('3910', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-22 10:19:22');
INSERT INTO `iot_device_log` VALUES ('3911', '21', 'TEMPERATURE', '2', '46.12', '46.12', '1', '2016-04-22 10:19:32');
INSERT INTO `iot_device_log` VALUES ('3912', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 10:19:32');
INSERT INTO `iot_device_log` VALUES ('3913', '21', 'TEMPERATURE', '2', '46.11', '46.11', '1', '2016-04-22 10:19:42');
INSERT INTO `iot_device_log` VALUES ('3914', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 10:19:42');
INSERT INTO `iot_device_log` VALUES ('3915', '21', 'TEMPERATURE', '2', '46.15', '46.15', '1', '2016-04-22 10:19:52');
INSERT INTO `iot_device_log` VALUES ('3916', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-22 10:19:52');
INSERT INTO `iot_device_log` VALUES ('3917', '21', 'TEMPERATURE', '2', '46.32', '46.32', '1', '2016-04-22 10:20:02');
INSERT INTO `iot_device_log` VALUES ('3918', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 10:20:02');
INSERT INTO `iot_device_log` VALUES ('3919', '21', 'TEMPERATURE', '2', '46.59', '46.59', '1', '2016-04-22 10:20:12');
INSERT INTO `iot_device_log` VALUES ('3920', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 10:20:12');
INSERT INTO `iot_device_log` VALUES ('3921', '21', 'TEMPERATURE', '2', '46.71', '46.71', '1', '2016-04-22 10:20:23');
INSERT INTO `iot_device_log` VALUES ('3922', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-22 10:20:23');
INSERT INTO `iot_device_log` VALUES ('3923', '21', 'TEMPERATURE', '2', '46.82', '46.82', '1', '2016-04-22 10:20:32');
INSERT INTO `iot_device_log` VALUES ('3924', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 10:20:32');
INSERT INTO `iot_device_log` VALUES ('3925', '21', 'TEMPERATURE', '2', '46.87', '46.87', '1', '2016-04-22 10:20:42');
INSERT INTO `iot_device_log` VALUES ('3926', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 10:20:42');
INSERT INTO `iot_device_log` VALUES ('3927', '21', 'TEMPERATURE', '2', '46.96', '46.96', '1', '2016-04-22 10:20:52');
INSERT INTO `iot_device_log` VALUES ('3928', '21', 'HUMIDITY', '2', '30.66', '30.66', '1', '2016-04-22 10:20:52');
INSERT INTO `iot_device_log` VALUES ('3929', '21', 'TEMPERATURE', '2', '46.76', '46.76', '1', '2016-04-22 10:21:02');
INSERT INTO `iot_device_log` VALUES ('3930', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-22 10:21:02');
INSERT INTO `iot_device_log` VALUES ('3931', '21', 'TEMPERATURE', '2', '47.01', '47.01', '1', '2016-04-22 10:21:12');
INSERT INTO `iot_device_log` VALUES ('3932', '21', 'HUMIDITY', '2', '30.47', '30.47', '1', '2016-04-22 10:21:12');
INSERT INTO `iot_device_log` VALUES ('3933', '21', 'TEMPERATURE', '2', '47.46', '47.46', '1', '2016-04-22 10:21:23');
INSERT INTO `iot_device_log` VALUES ('3934', '21', 'HUMIDITY', '2', '30.46', '30.46', '1', '2016-04-22 10:21:23');
INSERT INTO `iot_device_log` VALUES ('3935', '21', 'TEMPERATURE', '2', '47.27', '47.27', '1', '2016-04-22 10:21:32');
INSERT INTO `iot_device_log` VALUES ('3936', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-22 10:21:32');
INSERT INTO `iot_device_log` VALUES ('3937', '21', 'TEMPERATURE', '2', '47.01', '47.01', '1', '2016-04-22 10:21:42');
INSERT INTO `iot_device_log` VALUES ('3938', '21', 'HUMIDITY', '2', '30.66', '30.66', '1', '2016-04-22 10:21:42');
INSERT INTO `iot_device_log` VALUES ('3939', '21', 'TEMPERATURE', '2', '47.05', '47.05', '1', '2016-04-22 10:21:52');
INSERT INTO `iot_device_log` VALUES ('3940', '21', 'HUMIDITY', '2', '30.66', '30.66', '1', '2016-04-22 10:21:52');
INSERT INTO `iot_device_log` VALUES ('3941', '21', 'TEMPERATURE', '2', '46.94', '46.94', '1', '2016-04-22 10:22:02');
INSERT INTO `iot_device_log` VALUES ('3942', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 10:22:02');
INSERT INTO `iot_device_log` VALUES ('3943', '21', 'TEMPERATURE', '2', '46.84', '46.84', '1', '2016-04-22 10:22:12');
INSERT INTO `iot_device_log` VALUES ('3944', '21', 'HUMIDITY', '2', '30.69', '30.69', '1', '2016-04-22 10:22:12');
INSERT INTO `iot_device_log` VALUES ('3945', '21', 'TEMPERATURE', '2', '46.9', '46.9', '1', '2016-04-22 10:22:22');
INSERT INTO `iot_device_log` VALUES ('3946', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 10:22:22');
INSERT INTO `iot_device_log` VALUES ('3947', '21', 'TEMPERATURE', '2', '47.09', '47.09', '1', '2016-04-22 10:22:32');
INSERT INTO `iot_device_log` VALUES ('3948', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 10:22:32');
INSERT INTO `iot_device_log` VALUES ('3949', '21', 'TEMPERATURE', '2', '47.05', '47.05', '1', '2016-04-22 10:22:42');
INSERT INTO `iot_device_log` VALUES ('3950', '21', 'HUMIDITY', '2', '30.69', '30.69', '1', '2016-04-22 10:22:42');
INSERT INTO `iot_device_log` VALUES ('3951', '21', 'TEMPERATURE', '2', '46.89', '46.89', '1', '2016-04-22 10:22:52');
INSERT INTO `iot_device_log` VALUES ('3952', '21', 'HUMIDITY', '2', '30.56', '30.56', '1', '2016-04-22 10:22:52');
INSERT INTO `iot_device_log` VALUES ('3953', '21', 'TEMPERATURE', '2', '47.09', '47.09', '1', '2016-04-22 10:23:02');
INSERT INTO `iot_device_log` VALUES ('3954', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 10:23:02');
INSERT INTO `iot_device_log` VALUES ('3955', '21', 'TEMPERATURE', '2', '47.15', '47.15', '1', '2016-04-22 10:23:12');
INSERT INTO `iot_device_log` VALUES ('3956', '21', 'HUMIDITY', '2', '30.56', '30.56', '1', '2016-04-22 10:23:12');
INSERT INTO `iot_device_log` VALUES ('3957', '21', 'TEMPERATURE', '2', '47.08', '47.08', '1', '2016-04-22 10:23:22');
INSERT INTO `iot_device_log` VALUES ('3958', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-22 10:23:22');
INSERT INTO `iot_device_log` VALUES ('3959', '21', 'TEMPERATURE', '2', '47.2', '47.2', '1', '2016-04-22 10:23:32');
INSERT INTO `iot_device_log` VALUES ('3960', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-22 10:23:32');
INSERT INTO `iot_device_log` VALUES ('3961', '21', 'TEMPERATURE', '2', '47.22', '47.22', '1', '2016-04-22 10:23:42');
INSERT INTO `iot_device_log` VALUES ('3962', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 10:23:42');
INSERT INTO `iot_device_log` VALUES ('3963', '21', 'TEMPERATURE', '2', '47.21', '47.21', '1', '2016-04-22 10:23:52');
INSERT INTO `iot_device_log` VALUES ('3964', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 10:23:52');
INSERT INTO `iot_device_log` VALUES ('3965', '21', 'TEMPERATURE', '2', '47.65', '47.65', '1', '2016-04-22 10:24:02');
INSERT INTO `iot_device_log` VALUES ('3966', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 10:24:02');
INSERT INTO `iot_device_log` VALUES ('3967', '21', 'TEMPERATURE', '2', '47.84', '47.84', '1', '2016-04-22 10:24:12');
INSERT INTO `iot_device_log` VALUES ('3968', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 10:24:12');
INSERT INTO `iot_device_log` VALUES ('3969', '21', 'TEMPERATURE', '2', '47.22', '47.22', '1', '2016-04-22 10:24:22');
INSERT INTO `iot_device_log` VALUES ('3970', '21', 'HUMIDITY', '2', '30.71', '30.71', '1', '2016-04-22 10:24:22');
INSERT INTO `iot_device_log` VALUES ('3971', '21', 'TEMPERATURE', '2', '47.24', '47.24', '1', '2016-04-22 10:24:32');
INSERT INTO `iot_device_log` VALUES ('3972', '21', 'HUMIDITY', '2', '30.73', '30.73', '1', '2016-04-22 10:24:32');
INSERT INTO `iot_device_log` VALUES ('3973', '21', 'TEMPERATURE', '2', '47.18', '47.18', '1', '2016-04-22 10:24:42');
INSERT INTO `iot_device_log` VALUES ('3974', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 10:24:42');
INSERT INTO `iot_device_log` VALUES ('3975', '21', 'TEMPERATURE', '2', '46.57', '46.57', '1', '2016-04-22 10:24:52');
INSERT INTO `iot_device_log` VALUES ('3976', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 10:24:52');
INSERT INTO `iot_device_log` VALUES ('3977', '21', 'TEMPERATURE', '2', '46.4', '46.4', '1', '2016-04-22 10:25:02');
INSERT INTO `iot_device_log` VALUES ('3978', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-22 10:25:02');
INSERT INTO `iot_device_log` VALUES ('3979', '21', 'TEMPERATURE', '2', '47.1', '47.1', '1', '2016-04-22 10:25:12');
INSERT INTO `iot_device_log` VALUES ('3980', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 10:25:12');
INSERT INTO `iot_device_log` VALUES ('3981', '21', 'TEMPERATURE', '2', '46.49', '46.49', '1', '2016-04-22 10:25:22');
INSERT INTO `iot_device_log` VALUES ('3982', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 10:25:22');
INSERT INTO `iot_device_log` VALUES ('3983', '21', 'TEMPERATURE', '2', '46.42', '46.42', '1', '2016-04-22 10:25:32');
INSERT INTO `iot_device_log` VALUES ('3984', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 10:25:32');
INSERT INTO `iot_device_log` VALUES ('3985', '21', 'TEMPERATURE', '2', '46.24', '46.24', '1', '2016-04-22 10:25:42');
INSERT INTO `iot_device_log` VALUES ('3986', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-22 10:25:42');
INSERT INTO `iot_device_log` VALUES ('3987', '21', 'TEMPERATURE', '2', '46.4', '46.4', '1', '2016-04-22 10:25:52');
INSERT INTO `iot_device_log` VALUES ('3988', '21', 'HUMIDITY', '2', '30.95', '30.95', '1', '2016-04-22 10:25:52');
INSERT INTO `iot_device_log` VALUES ('3989', '21', 'TEMPERATURE', '2', '46.69', '46.69', '1', '2016-04-22 10:26:02');
INSERT INTO `iot_device_log` VALUES ('3990', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 10:26:02');
INSERT INTO `iot_device_log` VALUES ('3991', '21', 'TEMPERATURE', '2', '46.4', '46.4', '1', '2016-04-22 10:26:12');
INSERT INTO `iot_device_log` VALUES ('3992', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 10:26:12');
INSERT INTO `iot_device_log` VALUES ('3993', '21', 'TEMPERATURE', '2', '46.37', '46.37', '1', '2016-04-22 10:26:22');
INSERT INTO `iot_device_log` VALUES ('3994', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 10:26:22');
INSERT INTO `iot_device_log` VALUES ('3995', '21', 'TEMPERATURE', '2', '46.34', '46.34', '1', '2016-04-22 10:26:32');
INSERT INTO `iot_device_log` VALUES ('3996', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 10:26:32');
INSERT INTO `iot_device_log` VALUES ('3997', '21', 'TEMPERATURE', '2', '46.29', '46.29', '1', '2016-04-22 10:26:42');
INSERT INTO `iot_device_log` VALUES ('3998', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 10:26:42');
INSERT INTO `iot_device_log` VALUES ('3999', '21', 'TEMPERATURE', '2', '46.87', '46.87', '1', '2016-04-22 10:26:52');
INSERT INTO `iot_device_log` VALUES ('4000', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 10:26:52');
INSERT INTO `iot_device_log` VALUES ('4001', '21', 'TEMPERATURE', '2', '46.5', '46.5', '1', '2016-04-22 10:27:02');
INSERT INTO `iot_device_log` VALUES ('4002', '21', 'HUMIDITY', '2', '31.03', '31.03', '1', '2016-04-22 10:27:02');
INSERT INTO `iot_device_log` VALUES ('4003', '21', 'TEMPERATURE', '2', '46.59', '46.59', '1', '2016-04-22 10:27:12');
INSERT INTO `iot_device_log` VALUES ('4004', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-22 10:27:12');
INSERT INTO `iot_device_log` VALUES ('4005', '21', 'TEMPERATURE', '2', '46.42', '46.42', '1', '2016-04-22 10:27:22');
INSERT INTO `iot_device_log` VALUES ('4006', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 10:27:22');
INSERT INTO `iot_device_log` VALUES ('4007', '21', 'TEMPERATURE', '2', '50.63', '50.63', '1', '2016-04-22 10:27:32');
INSERT INTO `iot_device_log` VALUES ('4008', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 10:27:32');
INSERT INTO `iot_device_log` VALUES ('4009', '21', 'TEMPERATURE', '2', '49.42', '49.42', '1', '2016-04-22 10:27:42');
INSERT INTO `iot_device_log` VALUES ('4010', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 10:27:42');
INSERT INTO `iot_device_log` VALUES ('4011', '21', 'TEMPERATURE', '2', '49.31', '49.31', '1', '2016-04-22 10:27:52');
INSERT INTO `iot_device_log` VALUES ('4012', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 10:27:52');
INSERT INTO `iot_device_log` VALUES ('4013', '21', 'TEMPERATURE', '2', '47.69', '47.69', '1', '2016-04-22 10:28:02');
INSERT INTO `iot_device_log` VALUES ('4014', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 10:28:02');
INSERT INTO `iot_device_log` VALUES ('4015', '21', 'TEMPERATURE', '2', '47.45', '47.45', '1', '2016-04-22 10:28:12');
INSERT INTO `iot_device_log` VALUES ('4016', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-22 10:28:12');
INSERT INTO `iot_device_log` VALUES ('4017', '21', 'TEMPERATURE', '2', '46.93', '46.93', '1', '2016-04-22 10:28:22');
INSERT INTO `iot_device_log` VALUES ('4018', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-22 10:28:22');
INSERT INTO `iot_device_log` VALUES ('4019', '21', 'TEMPERATURE', '2', '46.31', '46.31', '1', '2016-04-22 10:28:32');
INSERT INTO `iot_device_log` VALUES ('4020', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 10:28:32');
INSERT INTO `iot_device_log` VALUES ('4021', '21', 'TEMPERATURE', '2', '46.15', '46.15', '1', '2016-04-22 10:28:42');
INSERT INTO `iot_device_log` VALUES ('4022', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-22 10:28:42');
INSERT INTO `iot_device_log` VALUES ('4023', '21', 'TEMPERATURE', '2', '46.33', '46.33', '1', '2016-04-22 10:28:52');
INSERT INTO `iot_device_log` VALUES ('4024', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-22 10:28:52');
INSERT INTO `iot_device_log` VALUES ('4025', '21', 'TEMPERATURE', '2', '46.13', '46.13', '1', '2016-04-22 10:29:02');
INSERT INTO `iot_device_log` VALUES ('4026', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-22 10:29:02');
INSERT INTO `iot_device_log` VALUES ('4027', '21', 'TEMPERATURE', '2', '46.1', '46.1', '1', '2016-04-22 10:29:12');
INSERT INTO `iot_device_log` VALUES ('4028', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-22 10:29:12');
INSERT INTO `iot_device_log` VALUES ('4029', '21', 'TEMPERATURE', '2', '45.88', '45.88', '1', '2016-04-22 10:29:22');
INSERT INTO `iot_device_log` VALUES ('4030', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-22 10:29:22');
INSERT INTO `iot_device_log` VALUES ('4031', '21', 'TEMPERATURE', '2', '47.28', '47.28', '1', '2016-04-22 10:29:32');
INSERT INTO `iot_device_log` VALUES ('4032', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 10:29:32');
INSERT INTO `iot_device_log` VALUES ('4033', '21', 'TEMPERATURE', '2', '46.95', '46.95', '1', '2016-04-22 10:29:42');
INSERT INTO `iot_device_log` VALUES ('4034', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-22 10:29:42');
INSERT INTO `iot_device_log` VALUES ('4035', '21', 'TEMPERATURE', '2', '46.52', '46.52', '1', '2016-04-22 10:29:52');
INSERT INTO `iot_device_log` VALUES ('4036', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-22 10:29:52');
INSERT INTO `iot_device_log` VALUES ('4037', '21', 'TEMPERATURE', '2', '48', '48', '1', '2016-04-22 10:30:02');
INSERT INTO `iot_device_log` VALUES ('4038', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-22 10:30:02');
INSERT INTO `iot_device_log` VALUES ('4039', '21', 'TEMPERATURE', '2', '46.02', '46.02', '1', '2016-04-22 10:30:12');
INSERT INTO `iot_device_log` VALUES ('4040', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 10:30:12');
INSERT INTO `iot_device_log` VALUES ('4041', '21', 'TEMPERATURE', '2', '46.67', '46.67', '1', '2016-04-22 10:30:22');
INSERT INTO `iot_device_log` VALUES ('4042', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-22 10:30:22');
INSERT INTO `iot_device_log` VALUES ('4043', '21', 'TEMPERATURE', '2', '46.84', '46.84', '1', '2016-04-22 10:30:32');
INSERT INTO `iot_device_log` VALUES ('4044', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 10:30:32');
INSERT INTO `iot_device_log` VALUES ('4045', '21', 'TEMPERATURE', '2', '47.92', '47.92', '1', '2016-04-22 10:30:42');
INSERT INTO `iot_device_log` VALUES ('4046', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 10:30:42');
INSERT INTO `iot_device_log` VALUES ('4047', '21', 'TEMPERATURE', '2', '46.26', '46.26', '1', '2016-04-22 10:30:52');
INSERT INTO `iot_device_log` VALUES ('4048', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-22 10:30:52');
INSERT INTO `iot_device_log` VALUES ('4049', '21', 'TEMPERATURE', '2', '46.05', '46.05', '1', '2016-04-22 10:31:02');
INSERT INTO `iot_device_log` VALUES ('4050', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-22 10:31:02');
INSERT INTO `iot_device_log` VALUES ('4051', '21', 'TEMPERATURE', '2', '45.79', '45.79', '1', '2016-04-22 10:31:12');
INSERT INTO `iot_device_log` VALUES ('4052', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 10:31:12');
INSERT INTO `iot_device_log` VALUES ('4053', '21', 'TEMPERATURE', '2', '44.99', '44.99', '1', '2016-04-22 10:31:22');
INSERT INTO `iot_device_log` VALUES ('4054', '21', 'HUMIDITY', '2', '31.56', '31.56', '1', '2016-04-22 10:31:22');
INSERT INTO `iot_device_log` VALUES ('4055', '21', 'TEMPERATURE', '2', '45', '45', '1', '2016-04-22 10:31:32');
INSERT INTO `iot_device_log` VALUES ('4056', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 10:31:32');
INSERT INTO `iot_device_log` VALUES ('4057', '21', 'TEMPERATURE', '2', '45.13', '45.13', '1', '2016-04-22 10:31:44');
INSERT INTO `iot_device_log` VALUES ('4058', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 10:31:44');
INSERT INTO `iot_device_log` VALUES ('4059', '21', 'TEMPERATURE', '2', '44.86', '44.86', '1', '2016-04-22 10:31:52');
INSERT INTO `iot_device_log` VALUES ('4060', '21', 'HUMIDITY', '2', '31.66', '31.66', '1', '2016-04-22 10:31:52');
INSERT INTO `iot_device_log` VALUES ('4061', '21', 'TEMPERATURE', '2', '44.6', '44.6', '1', '2016-04-22 10:32:02');
INSERT INTO `iot_device_log` VALUES ('4062', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-22 10:32:02');
INSERT INTO `iot_device_log` VALUES ('4063', '21', 'TEMPERATURE', '2', '45.75', '45.75', '1', '2016-04-22 10:32:12');
INSERT INTO `iot_device_log` VALUES ('4064', '21', 'HUMIDITY', '2', '31.65', '31.65', '1', '2016-04-22 10:32:12');
INSERT INTO `iot_device_log` VALUES ('4065', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 10:32:22');
INSERT INTO `iot_device_log` VALUES ('4066', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-22 10:32:22');
INSERT INTO `iot_device_log` VALUES ('4067', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 10:32:32');
INSERT INTO `iot_device_log` VALUES ('4068', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 10:32:32');
INSERT INTO `iot_device_log` VALUES ('4069', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 10:32:42');
INSERT INTO `iot_device_log` VALUES ('4070', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-22 10:32:42');
INSERT INTO `iot_device_log` VALUES ('4071', '21', 'TEMPERATURE', '2', '45.23', '45.23', '1', '2016-04-22 10:32:52');
INSERT INTO `iot_device_log` VALUES ('4072', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-22 10:32:52');
INSERT INTO `iot_device_log` VALUES ('4073', '21', 'TEMPERATURE', '2', '45.02', '45.02', '1', '2016-04-22 10:33:02');
INSERT INTO `iot_device_log` VALUES ('4074', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-22 10:33:02');
INSERT INTO `iot_device_log` VALUES ('4075', '21', 'TEMPERATURE', '2', '45.27', '45.27', '1', '2016-04-22 10:33:12');
INSERT INTO `iot_device_log` VALUES ('4076', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 10:33:12');
INSERT INTO `iot_device_log` VALUES ('4077', '21', 'TEMPERATURE', '2', '45.02', '45.02', '1', '2016-04-22 10:33:22');
INSERT INTO `iot_device_log` VALUES ('4078', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 10:33:22');
INSERT INTO `iot_device_log` VALUES ('4079', '21', 'TEMPERATURE', '2', '45.52', '45.52', '1', '2016-04-22 10:33:32');
INSERT INTO `iot_device_log` VALUES ('4080', '21', 'HUMIDITY', '2', '31.12', '31.12', '1', '2016-04-22 10:33:32');
INSERT INTO `iot_device_log` VALUES ('4081', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 10:33:43');
INSERT INTO `iot_device_log` VALUES ('4082', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 10:33:43');
INSERT INTO `iot_device_log` VALUES ('4083', '21', 'TEMPERATURE', '2', '46.23', '46.23', '1', '2016-04-22 10:33:52');
INSERT INTO `iot_device_log` VALUES ('4084', '21', 'HUMIDITY', '2', '30.63', '30.63', '1', '2016-04-22 10:33:52');
INSERT INTO `iot_device_log` VALUES ('4085', '21', 'TEMPERATURE', '2', '46.64', '46.64', '1', '2016-04-22 10:34:02');
INSERT INTO `iot_device_log` VALUES ('4086', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-22 10:34:02');
INSERT INTO `iot_device_log` VALUES ('4087', '21', 'TEMPERATURE', '2', '46.28', '46.28', '1', '2016-04-22 10:34:13');
INSERT INTO `iot_device_log` VALUES ('4088', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-22 10:34:13');
INSERT INTO `iot_device_log` VALUES ('4089', '21', 'TEMPERATURE', '2', '45.96', '45.96', '1', '2016-04-22 10:34:22');
INSERT INTO `iot_device_log` VALUES ('4090', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 10:34:22');
INSERT INTO `iot_device_log` VALUES ('4091', '21', 'TEMPERATURE', '2', '45.93', '45.93', '1', '2016-04-22 10:34:32');
INSERT INTO `iot_device_log` VALUES ('4092', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 10:34:32');
INSERT INTO `iot_device_log` VALUES ('4093', '21', 'TEMPERATURE', '2', '45.82', '45.82', '1', '2016-04-22 10:34:42');
INSERT INTO `iot_device_log` VALUES ('4094', '21', 'HUMIDITY', '2', '30.8', '30.8', '1', '2016-04-22 10:34:42');
INSERT INTO `iot_device_log` VALUES ('4095', '21', 'TEMPERATURE', '2', '46', '46', '1', '2016-04-22 10:34:52');
INSERT INTO `iot_device_log` VALUES ('4096', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-22 10:34:52');
INSERT INTO `iot_device_log` VALUES ('4097', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-22 10:35:02');
INSERT INTO `iot_device_log` VALUES ('4098', '21', 'HUMIDITY', '2', '30.75', '30.75', '1', '2016-04-22 10:35:02');
INSERT INTO `iot_device_log` VALUES ('4099', '21', 'TEMPERATURE', '2', '47.3', '47.3', '1', '2016-04-22 10:35:12');
INSERT INTO `iot_device_log` VALUES ('4100', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 10:35:12');
INSERT INTO `iot_device_log` VALUES ('4101', '21', 'TEMPERATURE', '2', '46.84', '46.84', '1', '2016-04-22 10:35:22');
INSERT INTO `iot_device_log` VALUES ('4102', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-22 10:35:22');
INSERT INTO `iot_device_log` VALUES ('4103', '21', 'TEMPERATURE', '2', '45.99', '45.99', '1', '2016-04-22 10:35:32');
INSERT INTO `iot_device_log` VALUES ('4104', '21', 'HUMIDITY', '2', '30.91', '30.91', '1', '2016-04-22 10:35:32');
INSERT INTO `iot_device_log` VALUES ('4105', '21', 'TEMPERATURE', '2', '45.73', '45.73', '1', '2016-04-22 10:35:42');
INSERT INTO `iot_device_log` VALUES ('4106', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 10:35:42');
INSERT INTO `iot_device_log` VALUES ('4107', '21', 'TEMPERATURE', '2', '45.87', '45.87', '1', '2016-04-22 10:35:52');
INSERT INTO `iot_device_log` VALUES ('4108', '21', 'HUMIDITY', '2', '30.75', '30.75', '1', '2016-04-22 10:35:52');
INSERT INTO `iot_device_log` VALUES ('4109', '21', 'TEMPERATURE', '2', '45.85', '45.85', '1', '2016-04-22 10:36:02');
INSERT INTO `iot_device_log` VALUES ('4110', '21', 'HUMIDITY', '2', '30.77', '30.77', '1', '2016-04-22 10:36:02');
INSERT INTO `iot_device_log` VALUES ('4111', '21', 'TEMPERATURE', '2', '45.79', '45.79', '1', '2016-04-22 10:36:12');
INSERT INTO `iot_device_log` VALUES ('4112', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 10:36:12');
INSERT INTO `iot_device_log` VALUES ('4113', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-22 10:36:23');
INSERT INTO `iot_device_log` VALUES ('4114', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 10:36:23');
INSERT INTO `iot_device_log` VALUES ('4115', '21', 'TEMPERATURE', '2', '45.02', '45.02', '1', '2016-04-22 10:36:56');
INSERT INTO `iot_device_log` VALUES ('4116', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 10:36:56');
INSERT INTO `iot_device_log` VALUES ('4117', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-22 10:36:56');
INSERT INTO `iot_device_log` VALUES ('4118', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-22 10:36:56');
INSERT INTO `iot_device_log` VALUES ('4119', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-22 10:37:02');
INSERT INTO `iot_device_log` VALUES ('4120', '21', 'HUMIDITY', '2', '31.69', '31.69', '1', '2016-04-22 10:37:02');
INSERT INTO `iot_device_log` VALUES ('4121', '21', 'TEMPERATURE', '2', '45.42', '45.42', '1', '2016-04-22 10:37:12');
INSERT INTO `iot_device_log` VALUES ('4122', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-22 10:37:12');
INSERT INTO `iot_device_log` VALUES ('4123', '21', 'TEMPERATURE', '2', '45.28', '45.28', '1', '2016-04-22 10:37:22');
INSERT INTO `iot_device_log` VALUES ('4124', '21', 'HUMIDITY', '2', '31.41', '31.41', '1', '2016-04-22 10:37:22');
INSERT INTO `iot_device_log` VALUES ('4125', '21', 'TEMPERATURE', '2', '45.19', '45.19', '1', '2016-04-22 10:37:32');
INSERT INTO `iot_device_log` VALUES ('4126', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-22 10:37:32');
INSERT INTO `iot_device_log` VALUES ('4127', '21', 'TEMPERATURE', '2', '45.12', '45.12', '1', '2016-04-22 10:37:42');
INSERT INTO `iot_device_log` VALUES ('4128', '21', 'HUMIDITY', '2', '31.44', '31.44', '1', '2016-04-22 10:37:42');
INSERT INTO `iot_device_log` VALUES ('4129', '21', 'TEMPERATURE', '2', '44.96', '44.96', '1', '2016-04-22 10:37:53');
INSERT INTO `iot_device_log` VALUES ('4130', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 10:37:53');
INSERT INTO `iot_device_log` VALUES ('4131', '21', 'TEMPERATURE', '2', '46.05', '46.05', '1', '2016-04-22 10:38:02');
INSERT INTO `iot_device_log` VALUES ('4132', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-22 10:38:02');
INSERT INTO `iot_device_log` VALUES ('4133', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-22 10:38:12');
INSERT INTO `iot_device_log` VALUES ('4134', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-22 10:38:12');
INSERT INTO `iot_device_log` VALUES ('4135', '21', 'TEMPERATURE', '2', '44.33', '44.33', '1', '2016-04-22 10:38:22');
INSERT INTO `iot_device_log` VALUES ('4136', '21', 'HUMIDITY', '2', '31.66', '31.66', '1', '2016-04-22 10:38:22');
INSERT INTO `iot_device_log` VALUES ('4137', '21', 'TEMPERATURE', '2', '45.14', '45.14', '1', '2016-04-22 10:38:32');
INSERT INTO `iot_device_log` VALUES ('4138', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 10:38:32');
INSERT INTO `iot_device_log` VALUES ('4139', '21', 'TEMPERATURE', '2', '44.71', '44.71', '1', '2016-04-22 10:38:42');
INSERT INTO `iot_device_log` VALUES ('4140', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-22 10:38:42');
INSERT INTO `iot_device_log` VALUES ('4141', '21', 'TEMPERATURE', '2', '44.74', '44.74', '1', '2016-04-22 10:38:52');
INSERT INTO `iot_device_log` VALUES ('4142', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-22 10:38:52');
INSERT INTO `iot_device_log` VALUES ('4143', '21', 'TEMPERATURE', '2', '44.96', '44.96', '1', '2016-04-22 10:39:02');
INSERT INTO `iot_device_log` VALUES ('4144', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 10:39:02');
INSERT INTO `iot_device_log` VALUES ('4145', '21', 'TEMPERATURE', '2', '44.96', '44.96', '1', '2016-04-22 10:39:12');
INSERT INTO `iot_device_log` VALUES ('4146', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 10:39:12');
INSERT INTO `iot_device_log` VALUES ('4147', '21', 'TEMPERATURE', '2', '46', '46', '1', '2016-04-22 10:39:22');
INSERT INTO `iot_device_log` VALUES ('4148', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 10:39:22');
INSERT INTO `iot_device_log` VALUES ('4149', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-22 10:39:32');
INSERT INTO `iot_device_log` VALUES ('4150', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 10:39:32');
INSERT INTO `iot_device_log` VALUES ('4151', '21', 'TEMPERATURE', '2', '45.72', '45.72', '1', '2016-04-22 10:39:44');
INSERT INTO `iot_device_log` VALUES ('4152', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-22 10:39:44');
INSERT INTO `iot_device_log` VALUES ('4153', '21', 'TEMPERATURE', '2', '45.47', '45.47', '1', '2016-04-22 10:39:52');
INSERT INTO `iot_device_log` VALUES ('4154', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-22 10:39:52');
INSERT INTO `iot_device_log` VALUES ('4155', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 10:40:02');
INSERT INTO `iot_device_log` VALUES ('4156', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-22 10:40:02');
INSERT INTO `iot_device_log` VALUES ('4157', '21', 'TEMPERATURE', '2', '46.52', '46.52', '1', '2016-04-22 10:40:12');
INSERT INTO `iot_device_log` VALUES ('4158', '21', 'HUMIDITY', '2', '31.44', '31.44', '1', '2016-04-22 10:40:12');
INSERT INTO `iot_device_log` VALUES ('4159', '21', 'TEMPERATURE', '2', '45.45', '45.45', '1', '2016-04-22 10:40:22');
INSERT INTO `iot_device_log` VALUES ('4160', '21', 'HUMIDITY', '2', '31.47', '31.47', '1', '2016-04-22 10:40:22');
INSERT INTO `iot_device_log` VALUES ('4161', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-22 10:40:32');
INSERT INTO `iot_device_log` VALUES ('4162', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-22 10:40:32');
INSERT INTO `iot_device_log` VALUES ('4163', '21', 'TEMPERATURE', '2', '45.15', '45.15', '1', '2016-04-22 10:40:43');
INSERT INTO `iot_device_log` VALUES ('4164', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-22 10:40:43');
INSERT INTO `iot_device_log` VALUES ('4165', '21', 'TEMPERATURE', '2', '44.99', '44.99', '1', '2016-04-22 10:40:53');
INSERT INTO `iot_device_log` VALUES ('4166', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-22 10:40:53');
INSERT INTO `iot_device_log` VALUES ('4167', '21', 'TEMPERATURE', '2', '45.08', '45.08', '1', '2016-04-22 10:41:02');
INSERT INTO `iot_device_log` VALUES ('4168', '21', 'HUMIDITY', '2', '31.44', '31.44', '1', '2016-04-22 10:41:02');
INSERT INTO `iot_device_log` VALUES ('4169', '21', 'TEMPERATURE', '2', '44.93', '44.93', '1', '2016-04-22 10:41:12');
INSERT INTO `iot_device_log` VALUES ('4170', '21', 'HUMIDITY', '2', '31.47', '31.47', '1', '2016-04-22 10:41:12');
INSERT INTO `iot_device_log` VALUES ('4171', '21', 'TEMPERATURE', '2', '44.84', '44.84', '1', '2016-04-22 10:41:22');
INSERT INTO `iot_device_log` VALUES ('4172', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 10:41:22');
INSERT INTO `iot_device_log` VALUES ('4173', '21', 'TEMPERATURE', '2', '44.6', '44.6', '1', '2016-04-22 10:41:32');
INSERT INTO `iot_device_log` VALUES ('4174', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 10:41:32');
INSERT INTO `iot_device_log` VALUES ('4175', '21', 'TEMPERATURE', '2', '45.07', '45.07', '1', '2016-04-22 10:41:42');
INSERT INTO `iot_device_log` VALUES ('4176', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 10:41:42');
INSERT INTO `iot_device_log` VALUES ('4177', '21', 'TEMPERATURE', '2', '45', '45', '1', '2016-04-22 10:41:55');
INSERT INTO `iot_device_log` VALUES ('4178', '21', 'HUMIDITY', '2', '31.5', '31.5', '1', '2016-04-22 10:41:55');
INSERT INTO `iot_device_log` VALUES ('4179', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-22 10:42:02');
INSERT INTO `iot_device_log` VALUES ('4180', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-22 10:42:02');
INSERT INTO `iot_device_log` VALUES ('4181', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-22 10:42:14');
INSERT INTO `iot_device_log` VALUES ('4182', '21', 'HUMIDITY', '2', '31.5', '31.5', '1', '2016-04-22 10:42:14');
INSERT INTO `iot_device_log` VALUES ('4183', '21', 'TEMPERATURE', '2', '44.69', '44.69', '1', '2016-04-22 10:42:22');
INSERT INTO `iot_device_log` VALUES ('4184', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 10:42:22');
INSERT INTO `iot_device_log` VALUES ('4185', '21', 'TEMPERATURE', '2', '44.66', '44.66', '1', '2016-04-22 10:42:32');
INSERT INTO `iot_device_log` VALUES ('4186', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-22 10:42:32');
INSERT INTO `iot_device_log` VALUES ('4187', '21', 'TEMPERATURE', '2', '44.63', '44.63', '1', '2016-04-22 10:42:42');
INSERT INTO `iot_device_log` VALUES ('4188', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 10:42:42');
INSERT INTO `iot_device_log` VALUES ('4189', '21', 'TEMPERATURE', '2', '44.89', '44.89', '1', '2016-04-22 10:42:52');
INSERT INTO `iot_device_log` VALUES ('4190', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 10:42:52');
INSERT INTO `iot_device_log` VALUES ('4191', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 10:43:02');
INSERT INTO `iot_device_log` VALUES ('4192', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 10:43:02');
INSERT INTO `iot_device_log` VALUES ('4193', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-22 10:43:12');
INSERT INTO `iot_device_log` VALUES ('4194', '21', 'HUMIDITY', '2', '31.41', '31.41', '1', '2016-04-22 10:43:12');
INSERT INTO `iot_device_log` VALUES ('4195', '21', 'TEMPERATURE', '2', '44.83', '44.83', '1', '2016-04-22 10:43:22');
INSERT INTO `iot_device_log` VALUES ('4196', '21', 'HUMIDITY', '2', '31.44', '31.44', '1', '2016-04-22 10:43:22');
INSERT INTO `iot_device_log` VALUES ('4197', '21', 'TEMPERATURE', '2', '45.13', '45.13', '1', '2016-04-22 10:43:32');
INSERT INTO `iot_device_log` VALUES ('4198', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-22 10:43:32');
INSERT INTO `iot_device_log` VALUES ('4199', '21', 'TEMPERATURE', '2', '44.96', '44.96', '1', '2016-04-22 10:43:42');
INSERT INTO `iot_device_log` VALUES ('4200', '21', 'HUMIDITY', '2', '31.44', '31.44', '1', '2016-04-22 10:43:42');
INSERT INTO `iot_device_log` VALUES ('4201', '21', 'TEMPERATURE', '2', '45.18', '45.18', '1', '2016-04-22 10:43:52');
INSERT INTO `iot_device_log` VALUES ('4202', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-22 10:43:52');
INSERT INTO `iot_device_log` VALUES ('4203', '21', 'TEMPERATURE', '2', '45.54', '45.54', '1', '2016-04-22 10:44:50');
INSERT INTO `iot_device_log` VALUES ('4204', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-22 10:44:50');
INSERT INTO `iot_device_log` VALUES ('4205', '21', 'TEMPERATURE', '2', '44.32', '44.32', '1', '2016-04-22 10:44:52');
INSERT INTO `iot_device_log` VALUES ('4206', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-22 10:44:52');
INSERT INTO `iot_device_log` VALUES ('4207', '21', 'TEMPERATURE', '2', '44.27', '44.27', '1', '2016-04-22 10:45:02');
INSERT INTO `iot_device_log` VALUES ('4208', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-22 10:45:02');
INSERT INTO `iot_device_log` VALUES ('4209', '21', 'TEMPERATURE', '2', '44.32', '44.32', '1', '2016-04-22 10:45:12');
INSERT INTO `iot_device_log` VALUES ('4210', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 10:45:12');
INSERT INTO `iot_device_log` VALUES ('4211', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-22 10:45:22');
INSERT INTO `iot_device_log` VALUES ('4212', '21', 'HUMIDITY', '2', '31.41', '31.41', '1', '2016-04-22 10:45:22');
INSERT INTO `iot_device_log` VALUES ('4213', '21', 'TEMPERATURE', '2', '44.9', '44.9', '1', '2016-04-22 10:45:32');
INSERT INTO `iot_device_log` VALUES ('4214', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-22 10:45:32');
INSERT INTO `iot_device_log` VALUES ('4215', '21', 'TEMPERATURE', '2', '44.93', '44.93', '1', '2016-04-22 10:45:42');
INSERT INTO `iot_device_log` VALUES ('4216', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-22 10:45:42');
INSERT INTO `iot_device_log` VALUES ('4217', '21', 'TEMPERATURE', '2', '45.13', '45.13', '1', '2016-04-22 10:45:52');
INSERT INTO `iot_device_log` VALUES ('4218', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-22 10:45:52');
INSERT INTO `iot_device_log` VALUES ('4219', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 10:46:02');
INSERT INTO `iot_device_log` VALUES ('4220', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 10:46:02');
INSERT INTO `iot_device_log` VALUES ('4221', '21', 'TEMPERATURE', '2', '45.61', '45.61', '1', '2016-04-22 10:46:12');
INSERT INTO `iot_device_log` VALUES ('4222', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 10:46:12');
INSERT INTO `iot_device_log` VALUES ('4223', '21', 'TEMPERATURE', '2', '45.52', '45.52', '1', '2016-04-22 10:46:22');
INSERT INTO `iot_device_log` VALUES ('4224', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 10:46:22');
INSERT INTO `iot_device_log` VALUES ('4225', '21', 'TEMPERATURE', '2', '45.6', '45.6', '1', '2016-04-22 10:46:32');
INSERT INTO `iot_device_log` VALUES ('4226', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 10:46:32');
INSERT INTO `iot_device_log` VALUES ('4227', '21', 'TEMPERATURE', '2', '45.43', '45.43', '1', '2016-04-22 10:46:42');
INSERT INTO `iot_device_log` VALUES ('4228', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-22 10:46:42');
INSERT INTO `iot_device_log` VALUES ('4229', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-22 10:46:53');
INSERT INTO `iot_device_log` VALUES ('4230', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 10:46:53');
INSERT INTO `iot_device_log` VALUES ('4231', '21', 'TEMPERATURE', '2', '45.93', '45.93', '1', '2016-04-22 10:47:02');
INSERT INTO `iot_device_log` VALUES ('4232', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 10:47:02');
INSERT INTO `iot_device_log` VALUES ('4233', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 10:47:12');
INSERT INTO `iot_device_log` VALUES ('4234', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-22 10:47:12');
INSERT INTO `iot_device_log` VALUES ('4235', '21', 'TEMPERATURE', '2', '45.29', '45.29', '1', '2016-04-22 10:47:23');
INSERT INTO `iot_device_log` VALUES ('4236', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-22 10:47:23');
INSERT INTO `iot_device_log` VALUES ('4237', '21', 'TEMPERATURE', '2', '46.17', '46.17', '1', '2016-04-22 10:47:32');
INSERT INTO `iot_device_log` VALUES ('4238', '21', 'HUMIDITY', '2', '31.65', '31.65', '1', '2016-04-22 10:47:32');
INSERT INTO `iot_device_log` VALUES ('4239', '21', 'TEMPERATURE', '2', '44.86', '44.86', '1', '2016-04-22 10:47:43');
INSERT INTO `iot_device_log` VALUES ('4240', '21', 'HUMIDITY', '2', '31.72', '31.72', '1', '2016-04-22 10:47:43');
INSERT INTO `iot_device_log` VALUES ('4241', '21', 'TEMPERATURE', '2', '44.51', '44.51', '1', '2016-04-22 10:47:52');
INSERT INTO `iot_device_log` VALUES ('4242', '21', 'HUMIDITY', '2', '31.96', '31.96', '1', '2016-04-22 10:47:52');
INSERT INTO `iot_device_log` VALUES ('4243', '21', 'TEMPERATURE', '2', '44.48', '44.48', '1', '2016-04-22 10:48:02');
INSERT INTO `iot_device_log` VALUES ('4244', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-22 10:48:02');
INSERT INTO `iot_device_log` VALUES ('4245', '21', 'TEMPERATURE', '2', '44.75', '44.75', '1', '2016-04-22 10:48:12');
INSERT INTO `iot_device_log` VALUES ('4246', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-22 10:48:12');
INSERT INTO `iot_device_log` VALUES ('4247', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-22 10:48:22');
INSERT INTO `iot_device_log` VALUES ('4248', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 10:48:22');
INSERT INTO `iot_device_log` VALUES ('4249', '21', 'TEMPERATURE', '2', '44.72', '44.72', '1', '2016-04-22 10:48:32');
INSERT INTO `iot_device_log` VALUES ('4250', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-22 10:48:32');
INSERT INTO `iot_device_log` VALUES ('4251', '21', 'TEMPERATURE', '2', '44.55', '44.55', '1', '2016-04-22 10:48:42');
INSERT INTO `iot_device_log` VALUES ('4252', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-22 10:48:42');
INSERT INTO `iot_device_log` VALUES ('4253', '21', 'TEMPERATURE', '2', '44.44', '44.44', '1', '2016-04-22 10:48:52');
INSERT INTO `iot_device_log` VALUES ('4254', '21', 'HUMIDITY', '2', '31.78', '31.78', '1', '2016-04-22 10:48:52');
INSERT INTO `iot_device_log` VALUES ('4255', '21', 'TEMPERATURE', '2', '44.57', '44.57', '1', '2016-04-22 10:49:02');
INSERT INTO `iot_device_log` VALUES ('4256', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 10:49:02');
INSERT INTO `iot_device_log` VALUES ('4257', '21', 'TEMPERATURE', '2', '44.89', '44.89', '1', '2016-04-22 10:49:12');
INSERT INTO `iot_device_log` VALUES ('4258', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 10:49:12');
INSERT INTO `iot_device_log` VALUES ('4259', '21', 'TEMPERATURE', '2', '45.44', '45.44', '1', '2016-04-22 10:49:22');
INSERT INTO `iot_device_log` VALUES ('4260', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 10:49:22');
INSERT INTO `iot_device_log` VALUES ('4261', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 10:49:32');
INSERT INTO `iot_device_log` VALUES ('4262', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-22 10:49:32');
INSERT INTO `iot_device_log` VALUES ('4263', '21', 'TEMPERATURE', '2', '45.75', '45.75', '1', '2016-04-22 10:49:42');
INSERT INTO `iot_device_log` VALUES ('4264', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 10:49:42');
INSERT INTO `iot_device_log` VALUES ('4265', '21', 'TEMPERATURE', '2', '46.49', '46.49', '1', '2016-04-22 10:49:52');
INSERT INTO `iot_device_log` VALUES ('4266', '21', 'HUMIDITY', '2', '31.12', '31.12', '1', '2016-04-22 10:49:52');
INSERT INTO `iot_device_log` VALUES ('4267', '21', 'TEMPERATURE', '2', '46.14', '46.14', '1', '2016-04-22 10:50:02');
INSERT INTO `iot_device_log` VALUES ('4268', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 10:50:02');
INSERT INTO `iot_device_log` VALUES ('4269', '21', 'TEMPERATURE', '2', '46.43', '46.43', '1', '2016-04-22 10:50:12');
INSERT INTO `iot_device_log` VALUES ('4270', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-22 10:50:12');
INSERT INTO `iot_device_log` VALUES ('4271', '21', 'TEMPERATURE', '2', '46.23', '46.23', '1', '2016-04-22 10:50:23');
INSERT INTO `iot_device_log` VALUES ('4272', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-22 10:50:23');
INSERT INTO `iot_device_log` VALUES ('4273', '21', 'TEMPERATURE', '2', '46.21', '46.21', '1', '2016-04-22 10:50:32');
INSERT INTO `iot_device_log` VALUES ('4274', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 10:50:32');
INSERT INTO `iot_device_log` VALUES ('4275', '21', 'TEMPERATURE', '2', '45.45', '45.45', '1', '2016-04-22 10:50:42');
INSERT INTO `iot_device_log` VALUES ('4276', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 10:50:42');
INSERT INTO `iot_device_log` VALUES ('4277', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 10:50:52');
INSERT INTO `iot_device_log` VALUES ('4278', '21', 'HUMIDITY', '2', '31.03', '31.03', '1', '2016-04-22 10:50:52');
INSERT INTO `iot_device_log` VALUES ('4279', '21', 'TEMPERATURE', '2', '47.88', '47.88', '1', '2016-04-22 10:51:02');
INSERT INTO `iot_device_log` VALUES ('4280', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 10:51:02');
INSERT INTO `iot_device_log` VALUES ('4281', '21', 'TEMPERATURE', '2', '46.59', '46.59', '1', '2016-04-22 10:51:12');
INSERT INTO `iot_device_log` VALUES ('4282', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 10:51:12');
INSERT INTO `iot_device_log` VALUES ('4283', '21', 'TEMPERATURE', '2', '47.27', '47.27', '1', '2016-04-22 10:51:22');
INSERT INTO `iot_device_log` VALUES ('4284', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-22 10:51:22');
INSERT INTO `iot_device_log` VALUES ('4285', '21', 'TEMPERATURE', '2', '46.17', '46.17', '1', '2016-04-22 10:51:32');
INSERT INTO `iot_device_log` VALUES ('4286', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-22 10:51:32');
INSERT INTO `iot_device_log` VALUES ('4287', '21', 'TEMPERATURE', '2', '45.54', '45.54', '1', '2016-04-22 10:51:42');
INSERT INTO `iot_device_log` VALUES ('4288', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-22 10:51:42');
INSERT INTO `iot_device_log` VALUES ('4289', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 10:51:52');
INSERT INTO `iot_device_log` VALUES ('4290', '21', 'HUMIDITY', '2', '31.51', '31.51', '1', '2016-04-22 10:51:52');
INSERT INTO `iot_device_log` VALUES ('4291', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 10:52:02');
INSERT INTO `iot_device_log` VALUES ('4292', '21', 'HUMIDITY', '2', '31.44', '31.44', '1', '2016-04-22 10:52:02');
INSERT INTO `iot_device_log` VALUES ('4293', '21', 'TEMPERATURE', '2', '44.96', '44.96', '1', '2016-04-22 10:52:13');
INSERT INTO `iot_device_log` VALUES ('4294', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 10:52:13');
INSERT INTO `iot_device_log` VALUES ('4295', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 10:52:22');
INSERT INTO `iot_device_log` VALUES ('4296', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-22 10:52:22');
INSERT INTO `iot_device_log` VALUES ('4297', '21', 'TEMPERATURE', '2', '45.76', '45.76', '1', '2016-04-22 10:52:32');
INSERT INTO `iot_device_log` VALUES ('4298', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-22 10:52:32');
INSERT INTO `iot_device_log` VALUES ('4299', '21', 'TEMPERATURE', '2', '44.9', '44.9', '1', '2016-04-22 10:52:42');
INSERT INTO `iot_device_log` VALUES ('4300', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-22 10:52:42');
INSERT INTO `iot_device_log` VALUES ('4301', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-22 10:52:52');
INSERT INTO `iot_device_log` VALUES ('4302', '21', 'HUMIDITY', '2', '31.84', '31.84', '1', '2016-04-22 10:52:52');
INSERT INTO `iot_device_log` VALUES ('4303', '21', 'TEMPERATURE', '2', '44.54', '44.54', '1', '2016-04-22 10:53:03');
INSERT INTO `iot_device_log` VALUES ('4304', '21', 'HUMIDITY', '2', '31.69', '31.69', '1', '2016-04-22 10:53:03');
INSERT INTO `iot_device_log` VALUES ('4305', '21', 'TEMPERATURE', '2', '44.69', '44.69', '1', '2016-04-22 10:53:12');
INSERT INTO `iot_device_log` VALUES ('4306', '21', 'HUMIDITY', '2', '31.65', '31.65', '1', '2016-04-22 10:53:12');
INSERT INTO `iot_device_log` VALUES ('4307', '21', 'TEMPERATURE', '2', '47.92', '47.92', '1', '2016-04-22 10:53:22');
INSERT INTO `iot_device_log` VALUES ('4308', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-22 10:53:22');
INSERT INTO `iot_device_log` VALUES ('4309', '21', 'TEMPERATURE', '2', '45.52', '45.52', '1', '2016-04-22 10:53:32');
INSERT INTO `iot_device_log` VALUES ('4310', '21', 'HUMIDITY', '2', '31.47', '31.47', '1', '2016-04-22 10:53:32');
INSERT INTO `iot_device_log` VALUES ('4311', '21', 'TEMPERATURE', '2', '45.9', '45.9', '1', '2016-04-22 10:53:42');
INSERT INTO `iot_device_log` VALUES ('4312', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-22 10:53:42');
INSERT INTO `iot_device_log` VALUES ('4313', '21', 'TEMPERATURE', '2', '46.34', '46.34', '1', '2016-04-22 10:53:52');
INSERT INTO `iot_device_log` VALUES ('4314', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-22 10:53:52');
INSERT INTO `iot_device_log` VALUES ('4315', '21', 'TEMPERATURE', '2', '46.55', '46.55', '1', '2016-04-22 10:54:02');
INSERT INTO `iot_device_log` VALUES ('4316', '21', 'HUMIDITY', '2', '31.47', '31.47', '1', '2016-04-22 10:54:02');
INSERT INTO `iot_device_log` VALUES ('4317', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 10:54:15');
INSERT INTO `iot_device_log` VALUES ('4318', '21', 'HUMIDITY', '2', '31.51', '31.51', '1', '2016-04-22 10:54:15');
INSERT INTO `iot_device_log` VALUES ('4319', '21', 'TEMPERATURE', '2', '45.19', '45.19', '1', '2016-04-22 10:54:22');
INSERT INTO `iot_device_log` VALUES ('4320', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-22 10:54:22');
INSERT INTO `iot_device_log` VALUES ('4321', '21', 'TEMPERATURE', '2', '44.96', '44.96', '1', '2016-04-22 10:54:32');
INSERT INTO `iot_device_log` VALUES ('4322', '21', 'HUMIDITY', '2', '31.84', '31.84', '1', '2016-04-22 10:54:32');
INSERT INTO `iot_device_log` VALUES ('4323', '21', 'TEMPERATURE', '2', '44.63', '44.63', '1', '2016-04-22 10:54:42');
INSERT INTO `iot_device_log` VALUES ('4324', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-22 10:54:42');
INSERT INTO `iot_device_log` VALUES ('4325', '21', 'TEMPERATURE', '2', '44.67', '44.67', '1', '2016-04-22 10:54:52');
INSERT INTO `iot_device_log` VALUES ('4326', '21', 'HUMIDITY', '2', '31.96', '31.96', '1', '2016-04-22 10:54:52');
INSERT INTO `iot_device_log` VALUES ('4327', '21', 'TEMPERATURE', '2', '44.36', '44.36', '1', '2016-04-22 10:55:02');
INSERT INTO `iot_device_log` VALUES ('4328', '21', 'HUMIDITY', '2', '32.08', '32.08', '1', '2016-04-22 10:55:02');
INSERT INTO `iot_device_log` VALUES ('4329', '21', 'TEMPERATURE', '2', '44.07', '44.07', '1', '2016-04-22 10:55:12');
INSERT INTO `iot_device_log` VALUES ('4330', '21', 'HUMIDITY', '2', '32.16', '32.16', '1', '2016-04-22 10:55:12');
INSERT INTO `iot_device_log` VALUES ('4331', '21', 'TEMPERATURE', '2', '44.13', '44.13', '1', '2016-04-22 10:55:22');
INSERT INTO `iot_device_log` VALUES ('4332', '21', 'HUMIDITY', '2', '32.14', '32.14', '1', '2016-04-22 10:55:22');
INSERT INTO `iot_device_log` VALUES ('4333', '21', 'TEMPERATURE', '2', '45.28', '45.28', '1', '2016-04-22 10:55:32');
INSERT INTO `iot_device_log` VALUES ('4334', '21', 'HUMIDITY', '2', '32.15', '32.15', '1', '2016-04-22 10:55:32');
INSERT INTO `iot_device_log` VALUES ('4335', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-22 10:55:42');
INSERT INTO `iot_device_log` VALUES ('4336', '21', 'HUMIDITY', '2', '32.16', '32.16', '1', '2016-04-22 10:55:42');
INSERT INTO `iot_device_log` VALUES ('4337', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-22 10:55:52');
INSERT INTO `iot_device_log` VALUES ('4338', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-22 10:55:52');
INSERT INTO `iot_device_log` VALUES ('4339', '21', 'TEMPERATURE', '2', '44.32', '44.32', '1', '2016-04-22 10:56:02');
INSERT INTO `iot_device_log` VALUES ('4340', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-22 10:56:02');
INSERT INTO `iot_device_log` VALUES ('4341', '21', 'TEMPERATURE', '2', '44.48', '44.48', '1', '2016-04-22 10:56:12');
INSERT INTO `iot_device_log` VALUES ('4342', '21', 'HUMIDITY', '2', '31.66', '31.66', '1', '2016-04-22 10:56:12');
INSERT INTO `iot_device_log` VALUES ('4343', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-22 10:56:22');
INSERT INTO `iot_device_log` VALUES ('4344', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-22 10:56:22');
INSERT INTO `iot_device_log` VALUES ('4345', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-22 10:56:32');
INSERT INTO `iot_device_log` VALUES ('4346', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 10:56:32');
INSERT INTO `iot_device_log` VALUES ('4347', '21', 'TEMPERATURE', '2', '44.7', '44.7', '1', '2016-04-22 10:56:42');
INSERT INTO `iot_device_log` VALUES ('4348', '21', 'HUMIDITY', '2', '31.44', '31.44', '1', '2016-04-22 10:56:42');
INSERT INTO `iot_device_log` VALUES ('4349', '21', 'TEMPERATURE', '2', '45', '45', '1', '2016-04-22 10:56:52');
INSERT INTO `iot_device_log` VALUES ('4350', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-22 10:56:52');
INSERT INTO `iot_device_log` VALUES ('4351', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 10:57:02');
INSERT INTO `iot_device_log` VALUES ('4352', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 10:57:02');
INSERT INTO `iot_device_log` VALUES ('4353', '21', 'TEMPERATURE', '2', '45.25', '45.25', '1', '2016-04-22 10:57:12');
INSERT INTO `iot_device_log` VALUES ('4354', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 10:57:12');
INSERT INTO `iot_device_log` VALUES ('4355', '21', 'TEMPERATURE', '2', '45.02', '45.02', '1', '2016-04-22 10:57:22');
INSERT INTO `iot_device_log` VALUES ('4356', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 10:57:22');
INSERT INTO `iot_device_log` VALUES ('4357', '21', 'TEMPERATURE', '2', '45.11', '45.11', '1', '2016-04-22 10:57:32');
INSERT INTO `iot_device_log` VALUES ('4358', '21', 'HUMIDITY', '2', '31.47', '31.47', '1', '2016-04-22 10:57:32');
INSERT INTO `iot_device_log` VALUES ('4359', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 10:57:42');
INSERT INTO `iot_device_log` VALUES ('4360', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 10:57:42');
INSERT INTO `iot_device_log` VALUES ('4361', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 10:57:52');
INSERT INTO `iot_device_log` VALUES ('4362', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 10:57:52');
INSERT INTO `iot_device_log` VALUES ('4363', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 10:58:02');
INSERT INTO `iot_device_log` VALUES ('4364', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 10:58:02');
INSERT INTO `iot_device_log` VALUES ('4365', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 10:58:12');
INSERT INTO `iot_device_log` VALUES ('4366', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-22 10:58:12');
INSERT INTO `iot_device_log` VALUES ('4367', '21', 'TEMPERATURE', '2', '44.88', '44.88', '1', '2016-04-22 10:58:22');
INSERT INTO `iot_device_log` VALUES ('4368', '21', 'HUMIDITY', '2', '31.5', '31.5', '1', '2016-04-22 10:58:22');
INSERT INTO `iot_device_log` VALUES ('4369', '21', 'TEMPERATURE', '2', '44.66', '44.66', '1', '2016-04-22 10:58:35');
INSERT INTO `iot_device_log` VALUES ('4370', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-22 10:58:35');
INSERT INTO `iot_device_log` VALUES ('4371', '21', 'TEMPERATURE', '2', '44.47', '44.47', '1', '2016-04-22 10:58:42');
INSERT INTO `iot_device_log` VALUES ('4372', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-22 10:58:42');
INSERT INTO `iot_device_log` VALUES ('4373', '21', 'TEMPERATURE', '2', '44.53', '44.53', '1', '2016-04-22 10:58:53');
INSERT INTO `iot_device_log` VALUES ('4374', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-22 10:58:53');
INSERT INTO `iot_device_log` VALUES ('4375', '21', 'TEMPERATURE', '2', '44.6', '44.6', '1', '2016-04-22 10:59:03');
INSERT INTO `iot_device_log` VALUES ('4376', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-22 10:59:03');
INSERT INTO `iot_device_log` VALUES ('4377', '21', 'TEMPERATURE', '2', '44.41', '44.41', '1', '2016-04-22 10:59:12');
INSERT INTO `iot_device_log` VALUES ('4378', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-22 10:59:12');
INSERT INTO `iot_device_log` VALUES ('4379', '21', 'TEMPERATURE', '2', '44.53', '44.53', '1', '2016-04-22 10:59:22');
INSERT INTO `iot_device_log` VALUES ('4380', '21', 'HUMIDITY', '2', '31.56', '31.56', '1', '2016-04-22 10:59:22');
INSERT INTO `iot_device_log` VALUES ('4381', '21', 'TEMPERATURE', '2', '44.53', '44.53', '1', '2016-04-22 10:59:32');
INSERT INTO `iot_device_log` VALUES ('4382', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-22 10:59:32');
INSERT INTO `iot_device_log` VALUES ('4383', '21', 'TEMPERATURE', '2', '44.28', '44.28', '1', '2016-04-22 10:59:42');
INSERT INTO `iot_device_log` VALUES ('4384', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 10:59:42');
INSERT INTO `iot_device_log` VALUES ('4385', '21', 'TEMPERATURE', '2', '44.44', '44.44', '1', '2016-04-22 10:59:52');
INSERT INTO `iot_device_log` VALUES ('4386', '21', 'HUMIDITY', '2', '31.65', '31.65', '1', '2016-04-22 10:59:52');
INSERT INTO `iot_device_log` VALUES ('4387', '21', 'TEMPERATURE', '2', '44.46', '44.46', '1', '2016-04-22 11:00:03');
INSERT INTO `iot_device_log` VALUES ('4388', '21', 'HUMIDITY', '2', '31.66', '31.66', '1', '2016-04-22 11:00:03');
INSERT INTO `iot_device_log` VALUES ('4389', '21', 'TEMPERATURE', '2', '46.99', '46.99', '1', '2016-04-22 11:00:12');
INSERT INTO `iot_device_log` VALUES ('4390', '21', 'HUMIDITY', '2', '31.72', '31.72', '1', '2016-04-22 11:00:12');
INSERT INTO `iot_device_log` VALUES ('4391', '21', 'TEMPERATURE', '2', '44.48', '44.48', '1', '2016-04-22 11:00:23');
INSERT INTO `iot_device_log` VALUES ('4392', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-22 11:00:23');
INSERT INTO `iot_device_log` VALUES ('4393', '21', 'TEMPERATURE', '2', '44.83', '44.83', '1', '2016-04-22 11:00:32');
INSERT INTO `iot_device_log` VALUES ('4394', '21', 'HUMIDITY', '2', '31.78', '31.78', '1', '2016-04-22 11:00:32');
INSERT INTO `iot_device_log` VALUES ('4395', '21', 'TEMPERATURE', '2', '44.61', '44.61', '1', '2016-04-22 11:00:42');
INSERT INTO `iot_device_log` VALUES ('4396', '21', 'HUMIDITY', '2', '31.69', '31.69', '1', '2016-04-22 11:00:42');
INSERT INTO `iot_device_log` VALUES ('4397', '21', 'TEMPERATURE', '2', '45.91', '45.91', '1', '2016-04-22 11:00:52');
INSERT INTO `iot_device_log` VALUES ('4398', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 11:00:52');
INSERT INTO `iot_device_log` VALUES ('4399', '21', 'TEMPERATURE', '2', '44.6', '44.6', '1', '2016-04-22 11:01:02');
INSERT INTO `iot_device_log` VALUES ('4400', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 11:01:02');
INSERT INTO `iot_device_log` VALUES ('4401', '21', 'TEMPERATURE', '2', '45.09', '45.09', '1', '2016-04-22 11:01:12');
INSERT INTO `iot_device_log` VALUES ('4402', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-22 11:01:12');
INSERT INTO `iot_device_log` VALUES ('4403', '21', 'TEMPERATURE', '2', '44.94', '44.94', '1', '2016-04-22 11:01:22');
INSERT INTO `iot_device_log` VALUES ('4404', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 11:01:22');
INSERT INTO `iot_device_log` VALUES ('4405', '21', 'TEMPERATURE', '2', '44.66', '44.66', '1', '2016-04-22 11:01:32');
INSERT INTO `iot_device_log` VALUES ('4406', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 11:01:32');
INSERT INTO `iot_device_log` VALUES ('4407', '21', 'TEMPERATURE', '2', '44.86', '44.86', '1', '2016-04-22 11:01:42');
INSERT INTO `iot_device_log` VALUES ('4408', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-22 11:01:42');
INSERT INTO `iot_device_log` VALUES ('4409', '21', 'TEMPERATURE', '2', '44.64', '44.64', '1', '2016-04-22 11:01:53');
INSERT INTO `iot_device_log` VALUES ('4410', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 11:01:53');
INSERT INTO `iot_device_log` VALUES ('4411', '21', 'TEMPERATURE', '2', '42.84', '42.84', '1', '2016-04-22 11:05:24');
INSERT INTO `iot_device_log` VALUES ('4412', '21', 'HUMIDITY', '2', '32.29', '32.29', '1', '2016-04-22 11:05:24');
INSERT INTO `iot_device_log` VALUES ('4413', '21', 'TEMPERATURE', '2', '42.84', '42.84', '1', '2016-04-22 11:05:24');
INSERT INTO `iot_device_log` VALUES ('4414', '21', 'HUMIDITY', '2', '32.29', '32.29', '1', '2016-04-22 11:05:24');
INSERT INTO `iot_device_log` VALUES ('4415', '21', 'TEMPERATURE', '2', '43.16', '43.16', '1', '2016-04-22 11:05:32');
INSERT INTO `iot_device_log` VALUES ('4416', '21', 'HUMIDITY', '2', '32.19', '32.19', '1', '2016-04-22 11:05:32');
INSERT INTO `iot_device_log` VALUES ('4417', '21', 'TEMPERATURE', '2', '43', '43', '1', '2016-04-22 11:05:42');
INSERT INTO `iot_device_log` VALUES ('4418', '21', 'HUMIDITY', '2', '32.4', '32.4', '1', '2016-04-22 11:05:42');
INSERT INTO `iot_device_log` VALUES ('4419', '21', 'TEMPERATURE', '2', '43.53', '43.53', '1', '2016-04-22 11:05:52');
INSERT INTO `iot_device_log` VALUES ('4420', '21', 'HUMIDITY', '2', '32.32', '32.32', '1', '2016-04-22 11:05:52');
INSERT INTO `iot_device_log` VALUES ('4421', '21', 'TEMPERATURE', '2', '43.17', '43.17', '1', '2016-04-22 11:06:08');
INSERT INTO `iot_device_log` VALUES ('4422', '21', 'HUMIDITY', '2', '32.27', '32.27', '1', '2016-04-22 11:06:08');
INSERT INTO `iot_device_log` VALUES ('4423', '21', 'TEMPERATURE', '2', '42.58', '42.58', '1', '2016-04-22 11:06:15');
INSERT INTO `iot_device_log` VALUES ('4424', '21', 'HUMIDITY', '2', '32.33', '32.33', '1', '2016-04-22 11:06:15');
INSERT INTO `iot_device_log` VALUES ('4425', '21', 'TEMPERATURE', '2', '42.75', '42.75', '1', '2016-04-22 11:06:22');
INSERT INTO `iot_device_log` VALUES ('4426', '21', 'HUMIDITY', '2', '32.15', '32.15', '1', '2016-04-22 11:06:22');
INSERT INTO `iot_device_log` VALUES ('4427', '21', 'TEMPERATURE', '2', '42.94', '42.94', '1', '2016-04-22 11:06:33');
INSERT INTO `iot_device_log` VALUES ('4428', '21', 'HUMIDITY', '2', '32.1', '32.1', '1', '2016-04-22 11:06:33');
INSERT INTO `iot_device_log` VALUES ('4429', '21', 'TEMPERATURE', '2', '43.49', '43.49', '1', '2016-04-22 11:06:42');
INSERT INTO `iot_device_log` VALUES ('4430', '21', 'HUMIDITY', '2', '32', '32', '1', '2016-04-22 11:06:42');
INSERT INTO `iot_device_log` VALUES ('4431', '21', 'TEMPERATURE', '2', '43.28', '43.28', '1', '2016-04-22 11:06:52');
INSERT INTO `iot_device_log` VALUES ('4432', '21', 'HUMIDITY', '2', '32.01', '32.01', '1', '2016-04-22 11:06:52');
INSERT INTO `iot_device_log` VALUES ('4433', '21', 'TEMPERATURE', '2', '43.4', '43.4', '1', '2016-04-22 11:07:05');
INSERT INTO `iot_device_log` VALUES ('4434', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-22 11:07:05');
INSERT INTO `iot_device_log` VALUES ('4435', '21', 'TEMPERATURE', '2', '43.19', '43.19', '1', '2016-04-22 11:07:12');
INSERT INTO `iot_device_log` VALUES ('4436', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-22 11:07:12');
INSERT INTO `iot_device_log` VALUES ('4437', '21', 'TEMPERATURE', '2', '43.39', '43.39', '1', '2016-04-22 11:07:22');
INSERT INTO `iot_device_log` VALUES ('4438', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-22 11:07:22');
INSERT INTO `iot_device_log` VALUES ('4439', '21', 'TEMPERATURE', '2', '43.5', '43.5', '1', '2016-04-22 11:07:33');
INSERT INTO `iot_device_log` VALUES ('4440', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-22 11:07:33');
INSERT INTO `iot_device_log` VALUES ('4441', '21', 'TEMPERATURE', '2', '43.76', '43.76', '1', '2016-04-22 11:07:42');
INSERT INTO `iot_device_log` VALUES ('4442', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-22 11:07:42');
INSERT INTO `iot_device_log` VALUES ('4443', '21', 'TEMPERATURE', '2', '43.65', '43.65', '1', '2016-04-22 11:07:52');
INSERT INTO `iot_device_log` VALUES ('4444', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-22 11:07:52');
INSERT INTO `iot_device_log` VALUES ('4445', '21', 'TEMPERATURE', '2', '43.45', '43.45', '1', '2016-04-22 11:08:02');
INSERT INTO `iot_device_log` VALUES ('4446', '21', 'HUMIDITY', '2', '31.99', '31.99', '1', '2016-04-22 11:08:02');
INSERT INTO `iot_device_log` VALUES ('4447', '21', 'TEMPERATURE', '2', '43.67', '43.67', '1', '2016-04-22 11:08:12');
INSERT INTO `iot_device_log` VALUES ('4448', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-22 11:08:12');
INSERT INTO `iot_device_log` VALUES ('4449', '21', 'TEMPERATURE', '2', '43.74', '43.74', '1', '2016-04-22 11:08:23');
INSERT INTO `iot_device_log` VALUES ('4450', '21', 'HUMIDITY', '2', '31.78', '31.78', '1', '2016-04-22 11:08:23');
INSERT INTO `iot_device_log` VALUES ('4451', '21', 'TEMPERATURE', '2', '44.08', '44.08', '1', '2016-04-22 11:08:32');
INSERT INTO `iot_device_log` VALUES ('4452', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-22 11:08:32');
INSERT INTO `iot_device_log` VALUES ('4453', '21', 'TEMPERATURE', '2', '44.03', '44.03', '1', '2016-04-22 11:08:42');
INSERT INTO `iot_device_log` VALUES ('4454', '21', 'HUMIDITY', '2', '31.73', '31.73', '1', '2016-04-22 11:08:42');
INSERT INTO `iot_device_log` VALUES ('4455', '21', 'TEMPERATURE', '2', '44.19', '44.19', '1', '2016-04-22 11:08:52');
INSERT INTO `iot_device_log` VALUES ('4456', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 11:08:52');
INSERT INTO `iot_device_log` VALUES ('4457', '21', 'TEMPERATURE', '2', '44.09', '44.09', '1', '2016-04-22 11:09:02');
INSERT INTO `iot_device_log` VALUES ('4458', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-22 11:09:02');
INSERT INTO `iot_device_log` VALUES ('4459', '21', 'TEMPERATURE', '2', '44.05', '44.05', '1', '2016-04-22 11:09:18');
INSERT INTO `iot_device_log` VALUES ('4460', '21', 'HUMIDITY', '2', '31.72', '31.72', '1', '2016-04-22 11:09:18');
INSERT INTO `iot_device_log` VALUES ('4461', '21', 'TEMPERATURE', '2', '44.05', '44.05', '1', '2016-04-22 11:09:24');
INSERT INTO `iot_device_log` VALUES ('4462', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-22 11:09:24');
INSERT INTO `iot_device_log` VALUES ('4463', '21', 'TEMPERATURE', '2', '43.85', '43.85', '1', '2016-04-22 11:09:35');
INSERT INTO `iot_device_log` VALUES ('4464', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-22 11:09:35');
INSERT INTO `iot_device_log` VALUES ('4465', '21', 'TEMPERATURE', '2', '43.6', '43.6', '1', '2016-04-22 11:09:58');
INSERT INTO `iot_device_log` VALUES ('4466', '21', 'HUMIDITY', '2', '32.04', '32.04', '1', '2016-04-22 11:09:58');
INSERT INTO `iot_device_log` VALUES ('4467', '21', 'TEMPERATURE', '2', '43.96', '43.96', '1', '2016-04-22 11:10:04');
INSERT INTO `iot_device_log` VALUES ('4468', '21', 'HUMIDITY', '2', '32.04', '32.04', '1', '2016-04-22 11:10:04');
INSERT INTO `iot_device_log` VALUES ('4469', '21', 'TEMPERATURE', '2', '43.72', '43.72', '1', '2016-04-22 11:10:12');
INSERT INTO `iot_device_log` VALUES ('4470', '21', 'HUMIDITY', '2', '32', '32', '1', '2016-04-22 11:10:12');
INSERT INTO `iot_device_log` VALUES ('4471', '21', 'TEMPERATURE', '2', '43.54', '43.54', '1', '2016-04-22 11:10:22');
INSERT INTO `iot_device_log` VALUES ('4472', '21', 'HUMIDITY', '2', '32.07', '32.07', '1', '2016-04-22 11:10:22');
INSERT INTO `iot_device_log` VALUES ('4473', '21', 'TEMPERATURE', '2', '43.58', '43.58', '1', '2016-04-22 11:11:19');
INSERT INTO `iot_device_log` VALUES ('4474', '21', 'HUMIDITY', '2', '32.01', '32.01', '1', '2016-04-22 11:11:19');
INSERT INTO `iot_device_log` VALUES ('4475', '21', 'TEMPERATURE', '2', '46.49', '46.49', '1', '2016-04-22 11:11:24');
INSERT INTO `iot_device_log` VALUES ('4476', '21', 'HUMIDITY', '2', '31.51', '31.51', '1', '2016-04-22 11:11:24');
INSERT INTO `iot_device_log` VALUES ('4477', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:24:54');
INSERT INTO `iot_device_log` VALUES ('4478', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 11:24:54');
INSERT INTO `iot_device_log` VALUES ('4479', '21', 'TEMPERATURE', '2', '40.35', '40.35', '1', '2016-04-22 11:25:05');
INSERT INTO `iot_device_log` VALUES ('4480', '21', 'HUMIDITY', '2', '34.86', '34.86', '1', '2016-04-22 11:25:05');
INSERT INTO `iot_device_log` VALUES ('4481', '21', 'TEMPERATURE', '2', '40.68', '40.68', '1', '2016-04-22 11:25:15');
INSERT INTO `iot_device_log` VALUES ('4482', '21', 'HUMIDITY', '2', '34.82', '34.82', '1', '2016-04-22 11:25:15');
INSERT INTO `iot_device_log` VALUES ('4483', '21', 'TEMPERATURE', '2', '48.3', '48.3', '1', '2016-04-22 11:25:26');
INSERT INTO `iot_device_log` VALUES ('4484', '21', 'HUMIDITY', '2', '34.93', '34.93', '1', '2016-04-22 11:25:26');
INSERT INTO `iot_device_log` VALUES ('4485', '21', 'TEMPERATURE', '2', '39.94', '39.94', '1', '2016-04-22 11:26:27');
INSERT INTO `iot_device_log` VALUES ('4486', '21', 'HUMIDITY', '2', '34.05', '34.05', '1', '2016-04-22 11:26:27');
INSERT INTO `iot_device_log` VALUES ('4487', '21', 'TEMPERATURE', '2', '40.02', '40.02', '1', '2016-04-22 11:26:37');
INSERT INTO `iot_device_log` VALUES ('4488', '21', 'HUMIDITY', '2', '33.9', '33.9', '1', '2016-04-22 11:26:37');
INSERT INTO `iot_device_log` VALUES ('4489', '21', 'TEMPERATURE', '2', '40.41', '40.41', '1', '2016-04-22 11:26:47');
INSERT INTO `iot_device_log` VALUES ('4490', '21', 'HUMIDITY', '2', '33.58', '33.58', '1', '2016-04-22 11:26:47');
INSERT INTO `iot_device_log` VALUES ('4491', '21', 'TEMPERATURE', '2', '41.32', '41.32', '1', '2016-04-22 11:26:57');
INSERT INTO `iot_device_log` VALUES ('4492', '21', 'HUMIDITY', '2', '33.19', '33.19', '1', '2016-04-22 11:26:57');
INSERT INTO `iot_device_log` VALUES ('4493', '21', 'TEMPERATURE', '2', '41.43', '41.43', '1', '2016-04-22 11:27:07');
INSERT INTO `iot_device_log` VALUES ('4494', '21', 'HUMIDITY', '2', '33.07', '33.07', '1', '2016-04-22 11:27:07');
INSERT INTO `iot_device_log` VALUES ('4495', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-22 11:27:17');
INSERT INTO `iot_device_log` VALUES ('4496', '21', 'HUMIDITY', '2', '32.91', '32.91', '1', '2016-04-22 11:27:17');
INSERT INTO `iot_device_log` VALUES ('4497', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:52:54');
INSERT INTO `iot_device_log` VALUES ('4498', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 11:52:56');
INSERT INTO `iot_device_log` VALUES ('4499', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:52:57');
INSERT INTO `iot_device_log` VALUES ('4500', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:52:59');
INSERT INTO `iot_device_log` VALUES ('4501', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:53:00');
INSERT INTO `iot_device_log` VALUES ('4502', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:53:02');
INSERT INTO `iot_device_log` VALUES ('4503', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:53:04');
INSERT INTO `iot_device_log` VALUES ('4504', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:53:06');
INSERT INTO `iot_device_log` VALUES ('4505', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:53:08');
INSERT INTO `iot_device_log` VALUES ('4506', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:53:11');
INSERT INTO `iot_device_log` VALUES ('4507', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:53:18');
INSERT INTO `iot_device_log` VALUES ('4508', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:53:18');
INSERT INTO `iot_device_log` VALUES ('4509', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 11:55:06');
INSERT INTO `iot_device_log` VALUES ('4510', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:55:08');
INSERT INTO `iot_device_log` VALUES ('4511', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 11:55:11');
INSERT INTO `iot_device_log` VALUES ('4512', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 11:55:13');
INSERT INTO `iot_device_log` VALUES ('4513', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 11:55:15');
INSERT INTO `iot_device_log` VALUES ('4514', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 11:55:17');
INSERT INTO `iot_device_log` VALUES ('4515', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 11:55:19');
INSERT INTO `iot_device_log` VALUES ('4516', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 11:55:39');
INSERT INTO `iot_device_log` VALUES ('4517', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:55:44');
INSERT INTO `iot_device_log` VALUES ('4518', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:55:47');
INSERT INTO `iot_device_log` VALUES ('4519', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:55:48');
INSERT INTO `iot_device_log` VALUES ('4520', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:55:50');
INSERT INTO `iot_device_log` VALUES ('4521', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:55:51');
INSERT INTO `iot_device_log` VALUES ('4522', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 11:55:54');
INSERT INTO `iot_device_log` VALUES ('4523', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:57:01');
INSERT INTO `iot_device_log` VALUES ('4524', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:57:04');
INSERT INTO `iot_device_log` VALUES ('4525', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 11:57:45');
INSERT INTO `iot_device_log` VALUES ('4526', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 12:00:15');
INSERT INTO `iot_device_log` VALUES ('4527', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 12:00:15');
INSERT INTO `iot_device_log` VALUES ('4528', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 12:00:15');
INSERT INTO `iot_device_log` VALUES ('4529', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 12:00:15');
INSERT INTO `iot_device_log` VALUES ('4530', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 12:58:03');
INSERT INTO `iot_device_log` VALUES ('4531', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 13:02:42');
INSERT INTO `iot_device_log` VALUES ('4532', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 13:02:42');
INSERT INTO `iot_device_log` VALUES ('4533', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 13:02:45');
INSERT INTO `iot_device_log` VALUES ('4534', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:02:51');
INSERT INTO `iot_device_log` VALUES ('4535', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 13:04:27');
INSERT INTO `iot_device_log` VALUES ('4536', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 13:04:32');
INSERT INTO `iot_device_log` VALUES ('4537', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:04:40');
INSERT INTO `iot_device_log` VALUES ('4538', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:04:43');
INSERT INTO `iot_device_log` VALUES ('4539', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:04:45');
INSERT INTO `iot_device_log` VALUES ('4540', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:04:46');
INSERT INTO `iot_device_log` VALUES ('4541', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:04:47');
INSERT INTO `iot_device_log` VALUES ('4542', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:04:48');
INSERT INTO `iot_device_log` VALUES ('4543', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:04:49');
INSERT INTO `iot_device_log` VALUES ('4544', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:04:50');
INSERT INTO `iot_device_log` VALUES ('4545', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 13:06:54');
INSERT INTO `iot_device_log` VALUES ('4546', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 13:07:21');
INSERT INTO `iot_device_log` VALUES ('4547', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:07:54');
INSERT INTO `iot_device_log` VALUES ('4548', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:07:55');
INSERT INTO `iot_device_log` VALUES ('4549', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:07:57');
INSERT INTO `iot_device_log` VALUES ('4550', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:07:58');
INSERT INTO `iot_device_log` VALUES ('4551', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:08:03');
INSERT INTO `iot_device_log` VALUES ('4552', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 13:08:23');
INSERT INTO `iot_device_log` VALUES ('4553', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 13:08:23');
INSERT INTO `iot_device_log` VALUES ('4554', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 13:08:28');
INSERT INTO `iot_device_log` VALUES ('4555', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:08:30');
INSERT INTO `iot_device_log` VALUES ('4556', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:08:32');
INSERT INTO `iot_device_log` VALUES ('4557', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:08:33');
INSERT INTO `iot_device_log` VALUES ('4558', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:08:33');
INSERT INTO `iot_device_log` VALUES ('4559', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:08:34');
INSERT INTO `iot_device_log` VALUES ('4560', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:08:34');
INSERT INTO `iot_device_log` VALUES ('4561', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:08:37');
INSERT INTO `iot_device_log` VALUES ('4562', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:08:39');
INSERT INTO `iot_device_log` VALUES ('4563', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:08:40');
INSERT INTO `iot_device_log` VALUES ('4564', '21', 'TEMPERATURE', '2', '59.95', '59.95', '1', '2016-04-22 13:09:17');
INSERT INTO `iot_device_log` VALUES ('4565', '21', 'HUMIDITY', '2', '28.91', '28.91', '1', '2016-04-22 13:09:17');
INSERT INTO `iot_device_log` VALUES ('4566', '21', 'TEMPERATURE', '2', '57.92', '57.92', '1', '2016-04-22 13:09:27');
INSERT INTO `iot_device_log` VALUES ('4567', '21', 'HUMIDITY', '2', '29.42', '29.42', '1', '2016-04-22 13:09:27');
INSERT INTO `iot_device_log` VALUES ('4568', '21', 'TEMPERATURE', '2', '56.58', '56.58', '1', '2016-04-22 13:09:37');
INSERT INTO `iot_device_log` VALUES ('4569', '21', 'HUMIDITY', '2', '29.69', '29.69', '1', '2016-04-22 13:09:37');
INSERT INTO `iot_device_log` VALUES ('4570', '21', 'TEMPERATURE', '2', '56.7', '56.7', '1', '2016-04-22 13:09:47');
INSERT INTO `iot_device_log` VALUES ('4571', '21', 'HUMIDITY', '2', '29.92', '29.92', '1', '2016-04-22 13:09:47');
INSERT INTO `iot_device_log` VALUES ('4572', '21', 'TEMPERATURE', '2', '55.63', '55.63', '1', '2016-04-22 13:09:57');
INSERT INTO `iot_device_log` VALUES ('4573', '21', 'HUMIDITY', '2', '30.19', '30.19', '1', '2016-04-22 13:09:57');
INSERT INTO `iot_device_log` VALUES ('4574', '21', 'TEMPERATURE', '2', '54.11', '54.11', '1', '2016-04-22 13:10:07');
INSERT INTO `iot_device_log` VALUES ('4575', '21', 'HUMIDITY', '2', '30.25', '30.25', '1', '2016-04-22 13:10:07');
INSERT INTO `iot_device_log` VALUES ('4576', '21', 'TEMPERATURE', '2', '53.87', '53.87', '1', '2016-04-22 13:10:17');
INSERT INTO `iot_device_log` VALUES ('4577', '21', 'HUMIDITY', '2', '30.39', '30.39', '1', '2016-04-22 13:10:17');
INSERT INTO `iot_device_log` VALUES ('4578', '21', 'TEMPERATURE', '2', '52.37', '52.37', '1', '2016-04-22 13:10:27');
INSERT INTO `iot_device_log` VALUES ('4579', '21', 'HUMIDITY', '2', '30.53', '30.53', '1', '2016-04-22 13:10:27');
INSERT INTO `iot_device_log` VALUES ('4580', '21', 'TEMPERATURE', '2', '51.05', '51.05', '1', '2016-04-22 13:10:37');
INSERT INTO `iot_device_log` VALUES ('4581', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-22 13:10:37');
INSERT INTO `iot_device_log` VALUES ('4582', '21', 'TEMPERATURE', '2', '64.88', '64.88', '1', '2016-04-22 13:10:47');
INSERT INTO `iot_device_log` VALUES ('4583', '21', 'HUMIDITY', '2', '32.92', '32.92', '1', '2016-04-22 13:10:47');
INSERT INTO `iot_device_log` VALUES ('4584', '21', 'TEMPERATURE', '2', '63.5', '63.5', '1', '2016-04-22 13:10:57');
INSERT INTO `iot_device_log` VALUES ('4585', '21', 'HUMIDITY', '2', '33.09', '33.09', '1', '2016-04-22 13:10:57');
INSERT INTO `iot_device_log` VALUES ('4586', '21', 'TEMPERATURE', '2', '67.71', '67.71', '1', '2016-04-22 13:11:07');
INSERT INTO `iot_device_log` VALUES ('4587', '21', 'HUMIDITY', '2', '33.72', '33.72', '1', '2016-04-22 13:11:07');
INSERT INTO `iot_device_log` VALUES ('4588', '21', 'TEMPERATURE', '2', '49.71', '49.71', '1', '2016-04-22 13:11:17');
INSERT INTO `iot_device_log` VALUES ('4589', '21', 'HUMIDITY', '2', '33.03', '33.03', '1', '2016-04-22 13:11:17');
INSERT INTO `iot_device_log` VALUES ('4590', '21', 'TEMPERATURE', '2', '49.53', '49.53', '1', '2016-04-22 13:11:27');
INSERT INTO `iot_device_log` VALUES ('4591', '21', 'HUMIDITY', '2', '32.36', '32.36', '1', '2016-04-22 13:11:27');
INSERT INTO `iot_device_log` VALUES ('4592', '21', 'TEMPERATURE', '2', '48.77', '48.77', '1', '2016-04-22 13:11:37');
INSERT INTO `iot_device_log` VALUES ('4593', '21', 'HUMIDITY', '2', '32.12', '32.12', '1', '2016-04-22 13:11:37');
INSERT INTO `iot_device_log` VALUES ('4594', '21', 'TEMPERATURE', '2', '48.9', '48.9', '1', '2016-04-22 13:11:47');
INSERT INTO `iot_device_log` VALUES ('4595', '21', 'HUMIDITY', '2', '31.94', '31.94', '1', '2016-04-22 13:11:47');
INSERT INTO `iot_device_log` VALUES ('4596', '21', 'TEMPERATURE', '2', '53.09', '53.09', '1', '2016-04-22 13:11:57');
INSERT INTO `iot_device_log` VALUES ('4597', '21', 'HUMIDITY', '2', '31.97', '31.97', '1', '2016-04-22 13:11:57');
INSERT INTO `iot_device_log` VALUES ('4598', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:23:43');
INSERT INTO `iot_device_log` VALUES ('4599', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:24:39');
INSERT INTO `iot_device_log` VALUES ('4600', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:24:42');
INSERT INTO `iot_device_log` VALUES ('4601', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 13:24:57');
INSERT INTO `iot_device_log` VALUES ('4602', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:25:00');
INSERT INTO `iot_device_log` VALUES ('4603', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:25:02');
INSERT INTO `iot_device_log` VALUES ('4604', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:25:47');
INSERT INTO `iot_device_log` VALUES ('4605', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:25:49');
INSERT INTO `iot_device_log` VALUES ('4606', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:26:37');
INSERT INTO `iot_device_log` VALUES ('4607', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:28:26');
INSERT INTO `iot_device_log` VALUES ('4608', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:28:28');
INSERT INTO `iot_device_log` VALUES ('4609', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:28:29');
INSERT INTO `iot_device_log` VALUES ('4610', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:28:30');
INSERT INTO `iot_device_log` VALUES ('4611', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:28:30');
INSERT INTO `iot_device_log` VALUES ('4612', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:28:33');
INSERT INTO `iot_device_log` VALUES ('4613', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:28:35');
INSERT INTO `iot_device_log` VALUES ('4614', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:28:36');
INSERT INTO `iot_device_log` VALUES ('4615', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:28:37');
INSERT INTO `iot_device_log` VALUES ('4616', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:28:37');
INSERT INTO `iot_device_log` VALUES ('4617', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:28:39');
INSERT INTO `iot_device_log` VALUES ('4618', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:28:40');
INSERT INTO `iot_device_log` VALUES ('4619', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:28:41');
INSERT INTO `iot_device_log` VALUES ('4620', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 13:28:42');
INSERT INTO `iot_device_log` VALUES ('4621', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 13:28:42');
INSERT INTO `iot_device_log` VALUES ('4622', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 13:28:44');
INSERT INTO `iot_device_log` VALUES ('4623', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 13:28:56');
INSERT INTO `iot_device_log` VALUES ('4624', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:28:59');
INSERT INTO `iot_device_log` VALUES ('4625', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:29:01');
INSERT INTO `iot_device_log` VALUES ('4626', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:29:02');
INSERT INTO `iot_device_log` VALUES ('4627', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:29:26');
INSERT INTO `iot_device_log` VALUES ('4628', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:29:28');
INSERT INTO `iot_device_log` VALUES ('4629', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:29:29');
INSERT INTO `iot_device_log` VALUES ('4630', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:29:30');
INSERT INTO `iot_device_log` VALUES ('4631', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 13:29:30');
INSERT INTO `iot_device_log` VALUES ('4632', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 13:31:42');
INSERT INTO `iot_device_log` VALUES ('4633', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 14:57:46');
INSERT INTO `iot_device_log` VALUES ('4634', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 14:57:50');
INSERT INTO `iot_device_log` VALUES ('4635', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 14:57:53');
INSERT INTO `iot_device_log` VALUES ('4636', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 14:57:54');
INSERT INTO `iot_device_log` VALUES ('4637', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 14:57:56');
INSERT INTO `iot_device_log` VALUES ('4638', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 14:57:57');
INSERT INTO `iot_device_log` VALUES ('4639', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 14:57:58');
INSERT INTO `iot_device_log` VALUES ('4640', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 14:58:02');
INSERT INTO `iot_device_log` VALUES ('4641', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 14:58:04');
INSERT INTO `iot_device_log` VALUES ('4642', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 14:58:06');
INSERT INTO `iot_device_log` VALUES ('4643', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 14:58:07');
INSERT INTO `iot_device_log` VALUES ('4644', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 15:00:55');
INSERT INTO `iot_device_log` VALUES ('4645', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 15:01:01');
INSERT INTO `iot_device_log` VALUES ('4646', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 15:01:05');
INSERT INTO `iot_device_log` VALUES ('4647', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 15:01:05');
INSERT INTO `iot_device_log` VALUES ('4648', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 15:01:06');
INSERT INTO `iot_device_log` VALUES ('4649', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 15:01:07');
INSERT INTO `iot_device_log` VALUES ('4650', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 15:01:12');
INSERT INTO `iot_device_log` VALUES ('4651', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 15:01:13');
INSERT INTO `iot_device_log` VALUES ('4652', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 15:01:15');
INSERT INTO `iot_device_log` VALUES ('4653', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 15:01:17');
INSERT INTO `iot_device_log` VALUES ('4654', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 15:01:20');
INSERT INTO `iot_device_log` VALUES ('4655', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 15:01:22');
INSERT INTO `iot_device_log` VALUES ('4656', '21', 'TEMPERATURE', '2', '45.66', '45.66', '1', '2016-04-22 15:08:23');
INSERT INTO `iot_device_log` VALUES ('4657', '21', 'HUMIDITY', '2', '31.76', '31.76', '1', '2016-04-22 15:08:23');
INSERT INTO `iot_device_log` VALUES ('4658', '21', 'TEMPERATURE', '2', '84.72', '84.72', '1', '2016-04-22 15:08:33');
INSERT INTO `iot_device_log` VALUES ('4659', '21', 'HUMIDITY', '2', '32.92', '32.92', '1', '2016-04-22 15:08:33');
INSERT INTO `iot_device_log` VALUES ('4660', '21', 'TEMPERATURE', '2', '77.62', '77.62', '1', '2016-04-22 15:08:43');
INSERT INTO `iot_device_log` VALUES ('4661', '21', 'HUMIDITY', '2', '34.04', '34.04', '1', '2016-04-22 15:08:43');
INSERT INTO `iot_device_log` VALUES ('4662', '21', 'TEMPERATURE', '2', '50.7', '50.7', '1', '2016-04-22 15:08:53');
INSERT INTO `iot_device_log` VALUES ('4663', '21', 'HUMIDITY', '2', '33', '33', '1', '2016-04-22 15:08:53');
INSERT INTO `iot_device_log` VALUES ('4664', '21', 'TEMPERATURE', '2', '48.55', '48.55', '1', '2016-04-22 15:09:03');
INSERT INTO `iot_device_log` VALUES ('4665', '21', 'HUMIDITY', '2', '32.4', '32.4', '1', '2016-04-22 15:09:03');
INSERT INTO `iot_device_log` VALUES ('4666', '21', 'TEMPERATURE', '2', '47.78', '47.78', '1', '2016-04-22 15:09:13');
INSERT INTO `iot_device_log` VALUES ('4667', '21', 'HUMIDITY', '2', '32.03', '32.03', '1', '2016-04-22 15:09:13');
INSERT INTO `iot_device_log` VALUES ('4668', '21', 'TEMPERATURE', '2', '47.34', '47.34', '1', '2016-04-22 15:09:24');
INSERT INTO `iot_device_log` VALUES ('4669', '21', 'HUMIDITY', '2', '31.93', '31.93', '1', '2016-04-22 15:09:24');
INSERT INTO `iot_device_log` VALUES ('4670', '21', 'TEMPERATURE', '2', '47.22', '47.22', '1', '2016-04-22 15:09:34');
INSERT INTO `iot_device_log` VALUES ('4671', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-22 15:09:34');
INSERT INTO `iot_device_log` VALUES ('4672', '21', 'TEMPERATURE', '2', '47.36', '47.36', '1', '2016-04-22 15:09:44');
INSERT INTO `iot_device_log` VALUES ('4673', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-22 15:09:44');
INSERT INTO `iot_device_log` VALUES ('4674', '21', 'TEMPERATURE', '2', '47.17', '47.17', '1', '2016-04-22 15:09:54');
INSERT INTO `iot_device_log` VALUES ('4675', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-22 15:09:54');
INSERT INTO `iot_device_log` VALUES ('4676', '21', 'TEMPERATURE', '2', '46.98', '46.98', '1', '2016-04-22 15:10:04');
INSERT INTO `iot_device_log` VALUES ('4677', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 15:10:04');
INSERT INTO `iot_device_log` VALUES ('4678', '21', 'TEMPERATURE', '2', '47.27', '47.27', '1', '2016-04-22 15:10:15');
INSERT INTO `iot_device_log` VALUES ('4679', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 15:10:15');
INSERT INTO `iot_device_log` VALUES ('4680', '21', 'TEMPERATURE', '2', '47.25', '47.25', '1', '2016-04-22 15:10:23');
INSERT INTO `iot_device_log` VALUES ('4681', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-22 15:10:23');
INSERT INTO `iot_device_log` VALUES ('4682', '21', 'TEMPERATURE', '2', '47.05', '47.05', '1', '2016-04-22 15:10:33');
INSERT INTO `iot_device_log` VALUES ('4683', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-22 15:10:33');
INSERT INTO `iot_device_log` VALUES ('4684', '21', 'TEMPERATURE', '2', '47.89', '47.89', '1', '2016-04-22 15:10:43');
INSERT INTO `iot_device_log` VALUES ('4685', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 15:10:43');
INSERT INTO `iot_device_log` VALUES ('4686', '21', 'TEMPERATURE', '2', '47.14', '47.14', '1', '2016-04-22 15:10:53');
INSERT INTO `iot_device_log` VALUES ('4687', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 15:10:53');
INSERT INTO `iot_device_log` VALUES ('4688', '21', 'TEMPERATURE', '2', '47.05', '47.05', '1', '2016-04-22 15:11:03');
INSERT INTO `iot_device_log` VALUES ('4689', '21', 'HUMIDITY', '2', '31.12', '31.12', '1', '2016-04-22 15:11:03');
INSERT INTO `iot_device_log` VALUES ('4690', '21', 'TEMPERATURE', '2', '47.09', '47.09', '1', '2016-04-22 15:11:13');
INSERT INTO `iot_device_log` VALUES ('4691', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 15:11:13');
INSERT INTO `iot_device_log` VALUES ('4692', '21', 'TEMPERATURE', '2', '47.21', '47.21', '1', '2016-04-22 15:11:23');
INSERT INTO `iot_device_log` VALUES ('4693', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 15:11:23');
INSERT INTO `iot_device_log` VALUES ('4694', '21', 'TEMPERATURE', '2', '47.01', '47.01', '1', '2016-04-22 15:11:33');
INSERT INTO `iot_device_log` VALUES ('4695', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-22 15:11:33');
INSERT INTO `iot_device_log` VALUES ('4696', '21', 'TEMPERATURE', '2', '47.21', '47.21', '1', '2016-04-22 15:11:43');
INSERT INTO `iot_device_log` VALUES ('4697', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-22 15:11:43');
INSERT INTO `iot_device_log` VALUES ('4698', '21', 'TEMPERATURE', '2', '47.14', '47.14', '1', '2016-04-22 15:11:53');
INSERT INTO `iot_device_log` VALUES ('4699', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-22 15:11:53');
INSERT INTO `iot_device_log` VALUES ('4700', '21', 'TEMPERATURE', '2', '46.64', '46.64', '1', '2016-04-22 15:12:03');
INSERT INTO `iot_device_log` VALUES ('4701', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 15:12:03');
INSERT INTO `iot_device_log` VALUES ('4702', '21', 'TEMPERATURE', '2', '46.07', '46.07', '1', '2016-04-22 15:12:13');
INSERT INTO `iot_device_log` VALUES ('4703', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 15:12:13');
INSERT INTO `iot_device_log` VALUES ('4704', '21', 'TEMPERATURE', '2', '45.98', '45.98', '1', '2016-04-22 15:12:24');
INSERT INTO `iot_device_log` VALUES ('4705', '21', 'HUMIDITY', '2', '31.5', '31.5', '1', '2016-04-22 15:12:24');
INSERT INTO `iot_device_log` VALUES ('4706', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 15:12:33');
INSERT INTO `iot_device_log` VALUES ('4707', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 15:12:33');
INSERT INTO `iot_device_log` VALUES ('4708', '21', 'TEMPERATURE', '2', '45.68', '45.68', '1', '2016-04-22 15:12:43');
INSERT INTO `iot_device_log` VALUES ('4709', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 15:12:43');
INSERT INTO `iot_device_log` VALUES ('4710', '21', 'TEMPERATURE', '2', '45.82', '45.82', '1', '2016-04-22 15:12:53');
INSERT INTO `iot_device_log` VALUES ('4711', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 15:12:53');
INSERT INTO `iot_device_log` VALUES ('4712', '21', 'TEMPERATURE', '2', '46.04', '46.04', '1', '2016-04-22 15:13:03');
INSERT INTO `iot_device_log` VALUES ('4713', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 15:13:03');
INSERT INTO `iot_device_log` VALUES ('4714', '21', 'TEMPERATURE', '2', '46.01', '46.01', '1', '2016-04-22 15:13:14');
INSERT INTO `iot_device_log` VALUES ('4715', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 15:13:14');
INSERT INTO `iot_device_log` VALUES ('4716', '21', 'TEMPERATURE', '2', '46.14', '46.14', '1', '2016-04-22 15:13:24');
INSERT INTO `iot_device_log` VALUES ('4717', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-22 15:13:24');
INSERT INTO `iot_device_log` VALUES ('4718', '21', 'TEMPERATURE', '2', '46.28', '46.28', '1', '2016-04-22 15:13:34');
INSERT INTO `iot_device_log` VALUES ('4719', '21', 'HUMIDITY', '2', '30.73', '30.73', '1', '2016-04-22 15:13:34');
INSERT INTO `iot_device_log` VALUES ('4720', '21', 'TEMPERATURE', '2', '46.18', '46.18', '1', '2016-04-22 15:13:43');
INSERT INTO `iot_device_log` VALUES ('4721', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-22 15:13:43');
INSERT INTO `iot_device_log` VALUES ('4722', '21', 'TEMPERATURE', '2', '46.06', '46.06', '1', '2016-04-22 15:13:54');
INSERT INTO `iot_device_log` VALUES ('4723', '21', 'HUMIDITY', '2', '30.8', '30.8', '1', '2016-04-22 15:13:54');
INSERT INTO `iot_device_log` VALUES ('4724', '21', 'TEMPERATURE', '2', '45.98', '45.98', '1', '2016-04-22 15:14:03');
INSERT INTO `iot_device_log` VALUES ('4725', '21', 'HUMIDITY', '2', '30.82', '30.82', '1', '2016-04-22 15:14:03');
INSERT INTO `iot_device_log` VALUES ('4726', '21', 'TEMPERATURE', '2', '45.96', '45.96', '1', '2016-04-22 15:14:13');
INSERT INTO `iot_device_log` VALUES ('4727', '21', 'HUMIDITY', '2', '30.8', '30.8', '1', '2016-04-22 15:14:13');
INSERT INTO `iot_device_log` VALUES ('4728', '21', 'TEMPERATURE', '2', '46.06', '46.06', '1', '2016-04-22 15:14:23');
INSERT INTO `iot_device_log` VALUES ('4729', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-22 15:14:23');
INSERT INTO `iot_device_log` VALUES ('4730', '21', 'TEMPERATURE', '2', '46.04', '46.04', '1', '2016-04-22 15:14:33');
INSERT INTO `iot_device_log` VALUES ('4731', '21', 'HUMIDITY', '2', '30.8', '30.8', '1', '2016-04-22 15:14:33');
INSERT INTO `iot_device_log` VALUES ('4732', '21', 'TEMPERATURE', '2', '46.04', '46.04', '1', '2016-04-22 15:14:43');
INSERT INTO `iot_device_log` VALUES ('4733', '21', 'HUMIDITY', '2', '30.75', '30.75', '1', '2016-04-22 15:14:43');
INSERT INTO `iot_device_log` VALUES ('4734', '21', 'TEMPERATURE', '2', '45.93', '45.93', '1', '2016-04-22 15:14:53');
INSERT INTO `iot_device_log` VALUES ('4735', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 15:14:53');
INSERT INTO `iot_device_log` VALUES ('4736', '21', 'TEMPERATURE', '2', '45.99', '45.99', '1', '2016-04-22 15:15:03');
INSERT INTO `iot_device_log` VALUES ('4737', '21', 'HUMIDITY', '2', '30.71', '30.71', '1', '2016-04-22 15:15:03');
INSERT INTO `iot_device_log` VALUES ('4738', '21', 'TEMPERATURE', '2', '46.09', '46.09', '1', '2016-04-22 15:15:13');
INSERT INTO `iot_device_log` VALUES ('4739', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 15:15:13');
INSERT INTO `iot_device_log` VALUES ('4740', '21', 'TEMPERATURE', '2', '46.13', '46.13', '1', '2016-04-22 15:15:23');
INSERT INTO `iot_device_log` VALUES ('4741', '21', 'HUMIDITY', '2', '30.63', '30.63', '1', '2016-04-22 15:15:23');
INSERT INTO `iot_device_log` VALUES ('4742', '21', 'TEMPERATURE', '2', '46.24', '46.24', '1', '2016-04-22 15:15:33');
INSERT INTO `iot_device_log` VALUES ('4743', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-22 15:15:33');
INSERT INTO `iot_device_log` VALUES ('4744', '21', 'TEMPERATURE', '2', '46.12', '46.12', '1', '2016-04-22 15:15:43');
INSERT INTO `iot_device_log` VALUES ('4745', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 15:15:43');
INSERT INTO `iot_device_log` VALUES ('4746', '21', 'TEMPERATURE', '2', '46.12', '46.12', '1', '2016-04-22 15:15:53');
INSERT INTO `iot_device_log` VALUES ('4747', '21', 'HUMIDITY', '2', '30.56', '30.56', '1', '2016-04-22 15:15:53');
INSERT INTO `iot_device_log` VALUES ('4748', '21', 'TEMPERATURE', '2', '46.14', '46.14', '1', '2016-04-22 15:16:03');
INSERT INTO `iot_device_log` VALUES ('4749', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-22 15:16:03');
INSERT INTO `iot_device_log` VALUES ('4750', '21', 'TEMPERATURE', '2', '46.14', '46.14', '1', '2016-04-22 15:16:13');
INSERT INTO `iot_device_log` VALUES ('4751', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 15:16:13');
INSERT INTO `iot_device_log` VALUES ('4752', '21', 'TEMPERATURE', '2', '46.32', '46.32', '1', '2016-04-22 15:16:23');
INSERT INTO `iot_device_log` VALUES ('4753', '21', 'HUMIDITY', '2', '30.56', '30.56', '1', '2016-04-22 15:16:23');
INSERT INTO `iot_device_log` VALUES ('4754', '21', 'TEMPERATURE', '2', '46.16', '46.16', '1', '2016-04-22 15:16:33');
INSERT INTO `iot_device_log` VALUES ('4755', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-22 15:16:33');
INSERT INTO `iot_device_log` VALUES ('4756', '21', 'TEMPERATURE', '2', '46.21', '46.21', '1', '2016-04-22 15:16:43');
INSERT INTO `iot_device_log` VALUES ('4757', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-22 15:16:43');
INSERT INTO `iot_device_log` VALUES ('4758', '21', 'TEMPERATURE', '2', '46.13', '46.13', '1', '2016-04-22 15:16:53');
INSERT INTO `iot_device_log` VALUES ('4759', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 15:16:53');
INSERT INTO `iot_device_log` VALUES ('4760', '21', 'TEMPERATURE', '2', '45.79', '45.79', '1', '2016-04-22 15:17:03');
INSERT INTO `iot_device_log` VALUES ('4761', '21', 'HUMIDITY', '2', '30.71', '30.71', '1', '2016-04-22 15:17:03');
INSERT INTO `iot_device_log` VALUES ('4762', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-22 15:17:13');
INSERT INTO `iot_device_log` VALUES ('4763', '21', 'HUMIDITY', '2', '30.82', '30.82', '1', '2016-04-22 15:17:13');
INSERT INTO `iot_device_log` VALUES ('4764', '21', 'TEMPERATURE', '2', '45.47', '45.47', '1', '2016-04-22 15:17:23');
INSERT INTO `iot_device_log` VALUES ('4765', '21', 'HUMIDITY', '2', '30.77', '30.77', '1', '2016-04-22 15:17:23');
INSERT INTO `iot_device_log` VALUES ('4766', '21', 'TEMPERATURE', '2', '45.62', '45.62', '1', '2016-04-22 15:17:33');
INSERT INTO `iot_device_log` VALUES ('4767', '21', 'HUMIDITY', '2', '30.71', '30.71', '1', '2016-04-22 15:17:33');
INSERT INTO `iot_device_log` VALUES ('4768', '21', 'TEMPERATURE', '2', '45.67', '45.67', '1', '2016-04-22 15:17:43');
INSERT INTO `iot_device_log` VALUES ('4769', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 15:17:43');
INSERT INTO `iot_device_log` VALUES ('4770', '21', 'TEMPERATURE', '2', '45.71', '45.71', '1', '2016-04-22 15:17:53');
INSERT INTO `iot_device_log` VALUES ('4771', '21', 'HUMIDITY', '2', '30.69', '30.69', '1', '2016-04-22 15:17:53');
INSERT INTO `iot_device_log` VALUES ('4772', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-22 15:18:03');
INSERT INTO `iot_device_log` VALUES ('4773', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 15:18:03');
INSERT INTO `iot_device_log` VALUES ('4774', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 15:18:14');
INSERT INTO `iot_device_log` VALUES ('4775', '21', 'HUMIDITY', '2', '30.91', '30.91', '1', '2016-04-22 15:18:14');
INSERT INTO `iot_device_log` VALUES ('4776', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 15:18:24');
INSERT INTO `iot_device_log` VALUES ('4777', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-22 15:18:24');
INSERT INTO `iot_device_log` VALUES ('4778', '21', 'TEMPERATURE', '2', '45.52', '45.52', '1', '2016-04-22 15:18:34');
INSERT INTO `iot_device_log` VALUES ('4779', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 15:18:34');
INSERT INTO `iot_device_log` VALUES ('4780', '21', 'TEMPERATURE', '2', '45.6', '45.6', '1', '2016-04-22 15:18:43');
INSERT INTO `iot_device_log` VALUES ('4781', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 15:18:43');
INSERT INTO `iot_device_log` VALUES ('4782', '21', 'TEMPERATURE', '2', '45.68', '45.68', '1', '2016-04-22 15:18:53');
INSERT INTO `iot_device_log` VALUES ('4783', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-22 15:18:53');
INSERT INTO `iot_device_log` VALUES ('4784', '21', 'TEMPERATURE', '2', '45.62', '45.62', '1', '2016-04-22 15:19:03');
INSERT INTO `iot_device_log` VALUES ('4785', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 15:19:03');
INSERT INTO `iot_device_log` VALUES ('4786', '21', 'TEMPERATURE', '2', '45.45', '45.45', '1', '2016-04-22 15:19:13');
INSERT INTO `iot_device_log` VALUES ('4787', '21', 'HUMIDITY', '2', '30.77', '30.77', '1', '2016-04-22 15:19:13');
INSERT INTO `iot_device_log` VALUES ('4788', '21', 'TEMPERATURE', '2', '45.57', '45.57', '1', '2016-04-22 15:19:23');
INSERT INTO `iot_device_log` VALUES ('4789', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 15:19:23');
INSERT INTO `iot_device_log` VALUES ('4790', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 15:19:34');
INSERT INTO `iot_device_log` VALUES ('4791', '21', 'HUMIDITY', '2', '30.53', '30.53', '1', '2016-04-22 15:19:34');
INSERT INTO `iot_device_log` VALUES ('4792', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 15:19:44');
INSERT INTO `iot_device_log` VALUES ('4793', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 15:19:44');
INSERT INTO `iot_device_log` VALUES ('4794', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-22 15:19:53');
INSERT INTO `iot_device_log` VALUES ('4795', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-22 15:19:53');
INSERT INTO `iot_device_log` VALUES ('4796', '21', 'TEMPERATURE', '2', '45.52', '45.52', '1', '2016-04-22 15:20:03');
INSERT INTO `iot_device_log` VALUES ('4797', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 15:20:03');
INSERT INTO `iot_device_log` VALUES ('4798', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 15:20:13');
INSERT INTO `iot_device_log` VALUES ('4799', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-22 15:20:13');
INSERT INTO `iot_device_log` VALUES ('4800', '21', 'TEMPERATURE', '2', '45.56', '45.56', '1', '2016-04-22 15:20:23');
INSERT INTO `iot_device_log` VALUES ('4801', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 15:20:23');
INSERT INTO `iot_device_log` VALUES ('4802', '21', 'TEMPERATURE', '2', '45.56', '45.56', '1', '2016-04-22 15:20:33');
INSERT INTO `iot_device_log` VALUES ('4803', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 15:20:33');
INSERT INTO `iot_device_log` VALUES ('4804', '21', 'TEMPERATURE', '2', '45.48', '45.48', '1', '2016-04-22 15:20:43');
INSERT INTO `iot_device_log` VALUES ('4805', '21', 'HUMIDITY', '2', '30.63', '30.63', '1', '2016-04-22 15:20:43');
INSERT INTO `iot_device_log` VALUES ('4806', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-22 15:20:53');
INSERT INTO `iot_device_log` VALUES ('4807', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 15:20:53');
INSERT INTO `iot_device_log` VALUES ('4808', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 15:21:03');
INSERT INTO `iot_device_log` VALUES ('4809', '21', 'HUMIDITY', '2', '30.71', '30.71', '1', '2016-04-22 15:21:03');
INSERT INTO `iot_device_log` VALUES ('4810', '21', 'TEMPERATURE', '2', '45.41', '45.41', '1', '2016-04-22 15:21:13');
INSERT INTO `iot_device_log` VALUES ('4811', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 15:21:13');
INSERT INTO `iot_device_log` VALUES ('4812', '21', 'TEMPERATURE', '2', '45.49', '45.49', '1', '2016-04-22 15:21:23');
INSERT INTO `iot_device_log` VALUES ('4813', '21', 'HUMIDITY', '2', '30.53', '30.53', '1', '2016-04-22 15:21:23');
INSERT INTO `iot_device_log` VALUES ('4814', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-22 15:21:33');
INSERT INTO `iot_device_log` VALUES ('4815', '21', 'HUMIDITY', '2', '30.48', '30.48', '1', '2016-04-22 15:21:33');
INSERT INTO `iot_device_log` VALUES ('4816', '21', 'TEMPERATURE', '2', '45.69', '45.69', '1', '2016-04-22 15:21:43');
INSERT INTO `iot_device_log` VALUES ('4817', '21', 'HUMIDITY', '2', '30.43', '30.43', '1', '2016-04-22 15:21:43');
INSERT INTO `iot_device_log` VALUES ('4818', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 15:21:53');
INSERT INTO `iot_device_log` VALUES ('4819', '21', 'HUMIDITY', '2', '30.47', '30.47', '1', '2016-04-22 15:21:53');
INSERT INTO `iot_device_log` VALUES ('4820', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-22 15:22:03');
INSERT INTO `iot_device_log` VALUES ('4821', '21', 'HUMIDITY', '2', '30.55', '30.55', '1', '2016-04-22 15:22:03');
INSERT INTO `iot_device_log` VALUES ('4822', '21', 'TEMPERATURE', '2', '45.47', '45.47', '1', '2016-04-22 15:22:13');
INSERT INTO `iot_device_log` VALUES ('4823', '21', 'HUMIDITY', '2', '30.56', '30.56', '1', '2016-04-22 15:22:13');
INSERT INTO `iot_device_log` VALUES ('4824', '21', 'TEMPERATURE', '2', '45.56', '45.56', '1', '2016-04-22 15:22:23');
INSERT INTO `iot_device_log` VALUES ('4825', '21', 'HUMIDITY', '2', '30.44', '30.44', '1', '2016-04-22 15:22:23');
INSERT INTO `iot_device_log` VALUES ('4826', '21', 'TEMPERATURE', '2', '45.67', '45.67', '1', '2016-04-22 15:22:34');
INSERT INTO `iot_device_log` VALUES ('4827', '21', 'HUMIDITY', '2', '30.41', '30.41', '1', '2016-04-22 15:22:34');
INSERT INTO `iot_device_log` VALUES ('4828', '21', 'TEMPERATURE', '2', '45.62', '45.62', '1', '2016-04-22 15:22:43');
INSERT INTO `iot_device_log` VALUES ('4829', '21', 'HUMIDITY', '2', '30.46', '30.46', '1', '2016-04-22 15:22:43');
INSERT INTO `iot_device_log` VALUES ('4830', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 15:22:53');
INSERT INTO `iot_device_log` VALUES ('4831', '21', 'HUMIDITY', '2', '30.48', '30.48', '1', '2016-04-22 15:22:53');
INSERT INTO `iot_device_log` VALUES ('4832', '21', 'TEMPERATURE', '2', '45.43', '45.43', '1', '2016-04-22 15:23:03');
INSERT INTO `iot_device_log` VALUES ('4833', '21', 'HUMIDITY', '2', '30.55', '30.55', '1', '2016-04-22 15:23:03');
INSERT INTO `iot_device_log` VALUES ('4834', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-22 15:23:13');
INSERT INTO `iot_device_log` VALUES ('4835', '21', 'HUMIDITY', '2', '30.55', '30.55', '1', '2016-04-22 15:23:13');
INSERT INTO `iot_device_log` VALUES ('4836', '21', 'TEMPERATURE', '2', '45.43', '45.43', '1', '2016-04-22 15:23:23');
INSERT INTO `iot_device_log` VALUES ('4837', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-22 15:23:23');
INSERT INTO `iot_device_log` VALUES ('4838', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 15:23:33');
INSERT INTO `iot_device_log` VALUES ('4839', '21', 'HUMIDITY', '2', '30.55', '30.55', '1', '2016-04-22 15:23:33');
INSERT INTO `iot_device_log` VALUES ('4840', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 15:23:43');
INSERT INTO `iot_device_log` VALUES ('4841', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 15:23:43');
INSERT INTO `iot_device_log` VALUES ('4842', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 15:23:54');
INSERT INTO `iot_device_log` VALUES ('4843', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-22 15:23:54');
INSERT INTO `iot_device_log` VALUES ('4844', '21', 'TEMPERATURE', '2', '45.38', '45.38', '1', '2016-04-22 15:24:04');
INSERT INTO `iot_device_log` VALUES ('4845', '21', 'HUMIDITY', '2', '30.48', '30.48', '1', '2016-04-22 15:24:04');
INSERT INTO `iot_device_log` VALUES ('4846', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 15:24:13');
INSERT INTO `iot_device_log` VALUES ('4847', '21', 'HUMIDITY', '2', '30.43', '30.43', '1', '2016-04-22 15:24:13');
INSERT INTO `iot_device_log` VALUES ('4848', '21', 'TEMPERATURE', '2', '45.44', '45.44', '1', '2016-04-22 15:24:23');
INSERT INTO `iot_device_log` VALUES ('4849', '21', 'HUMIDITY', '2', '30.41', '30.41', '1', '2016-04-22 15:24:23');
INSERT INTO `iot_device_log` VALUES ('4850', '21', 'TEMPERATURE', '2', '45.47', '45.47', '1', '2016-04-22 15:24:33');
INSERT INTO `iot_device_log` VALUES ('4851', '21', 'HUMIDITY', '2', '30.35', '30.35', '1', '2016-04-22 15:24:33');
INSERT INTO `iot_device_log` VALUES ('4852', '21', 'TEMPERATURE', '2', '45.45', '45.45', '1', '2016-04-22 15:24:43');
INSERT INTO `iot_device_log` VALUES ('4853', '21', 'HUMIDITY', '2', '30.34', '30.34', '1', '2016-04-22 15:24:43');
INSERT INTO `iot_device_log` VALUES ('4854', '21', 'TEMPERATURE', '2', '45.49', '45.49', '1', '2016-04-22 15:24:53');
INSERT INTO `iot_device_log` VALUES ('4855', '21', 'HUMIDITY', '2', '30.34', '30.34', '1', '2016-04-22 15:24:53');
INSERT INTO `iot_device_log` VALUES ('4856', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-22 15:25:03');
INSERT INTO `iot_device_log` VALUES ('4857', '21', 'HUMIDITY', '2', '30.28', '30.28', '1', '2016-04-22 15:25:03');
INSERT INTO `iot_device_log` VALUES ('4858', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 15:25:13');
INSERT INTO `iot_device_log` VALUES ('4859', '21', 'HUMIDITY', '2', '30.28', '30.28', '1', '2016-04-22 15:25:13');
INSERT INTO `iot_device_log` VALUES ('4860', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 15:25:24');
INSERT INTO `iot_device_log` VALUES ('4861', '21', 'HUMIDITY', '2', '30.34', '30.34', '1', '2016-04-22 15:25:24');
INSERT INTO `iot_device_log` VALUES ('4862', '21', 'TEMPERATURE', '2', '45.54', '45.54', '1', '2016-04-22 15:25:33');
INSERT INTO `iot_device_log` VALUES ('4863', '21', 'HUMIDITY', '2', '30.46', '30.46', '1', '2016-04-22 15:25:33');
INSERT INTO `iot_device_log` VALUES ('4864', '21', 'TEMPERATURE', '2', '45.41', '45.41', '1', '2016-04-22 15:25:43');
INSERT INTO `iot_device_log` VALUES ('4865', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 15:25:43');
INSERT INTO `iot_device_log` VALUES ('4866', '21', 'TEMPERATURE', '2', '45.32', '45.32', '1', '2016-04-22 15:25:53');
INSERT INTO `iot_device_log` VALUES ('4867', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-22 15:25:53');
INSERT INTO `iot_device_log` VALUES ('4868', '21', 'TEMPERATURE', '2', '45.23', '45.23', '1', '2016-04-22 15:26:03');
INSERT INTO `iot_device_log` VALUES ('4869', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 15:26:03');
INSERT INTO `iot_device_log` VALUES ('4870', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 15:26:13');
INSERT INTO `iot_device_log` VALUES ('4871', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 15:26:13');
INSERT INTO `iot_device_log` VALUES ('4872', '21', 'TEMPERATURE', '2', '45.14', '45.14', '1', '2016-04-22 15:26:23');
INSERT INTO `iot_device_log` VALUES ('4873', '21', 'HUMIDITY', '2', '30.63', '30.63', '1', '2016-04-22 15:26:23');
INSERT INTO `iot_device_log` VALUES ('4874', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 15:26:33');
INSERT INTO `iot_device_log` VALUES ('4875', '21', 'HUMIDITY', '2', '30.55', '30.55', '1', '2016-04-22 15:26:33');
INSERT INTO `iot_device_log` VALUES ('4876', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 15:26:43');
INSERT INTO `iot_device_log` VALUES ('4877', '21', 'HUMIDITY', '2', '30.47', '30.47', '1', '2016-04-22 15:26:43');
INSERT INTO `iot_device_log` VALUES ('4878', '21', 'TEMPERATURE', '2', '45.32', '45.32', '1', '2016-04-22 15:26:53');
INSERT INTO `iot_device_log` VALUES ('4879', '21', 'HUMIDITY', '2', '30.55', '30.55', '1', '2016-04-22 15:26:53');
INSERT INTO `iot_device_log` VALUES ('4880', '21', 'TEMPERATURE', '2', '45.19', '45.19', '1', '2016-04-22 15:27:03');
INSERT INTO `iot_device_log` VALUES ('4881', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 15:27:03');
INSERT INTO `iot_device_log` VALUES ('4882', '21', 'TEMPERATURE', '2', '45.02', '45.02', '1', '2016-04-22 15:27:13');
INSERT INTO `iot_device_log` VALUES ('4883', '21', 'HUMIDITY', '2', '30.75', '30.75', '1', '2016-04-22 15:27:13');
INSERT INTO `iot_device_log` VALUES ('4884', '21', 'TEMPERATURE', '2', '44.7', '44.7', '1', '2016-04-22 15:27:23');
INSERT INTO `iot_device_log` VALUES ('4885', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 15:27:23');
INSERT INTO `iot_device_log` VALUES ('4886', '21', 'TEMPERATURE', '2', '44.56', '44.56', '1', '2016-04-22 15:27:33');
INSERT INTO `iot_device_log` VALUES ('4887', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 15:27:33');
INSERT INTO `iot_device_log` VALUES ('4888', '21', 'TEMPERATURE', '2', '44.72', '44.72', '1', '2016-04-22 15:27:43');
INSERT INTO `iot_device_log` VALUES ('4889', '21', 'HUMIDITY', '2', '30.73', '30.73', '1', '2016-04-22 15:27:43');
INSERT INTO `iot_device_log` VALUES ('4890', '21', 'TEMPERATURE', '2', '44.72', '44.72', '1', '2016-04-22 15:27:53');
INSERT INTO `iot_device_log` VALUES ('4891', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-22 15:27:53');
INSERT INTO `iot_device_log` VALUES ('4892', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-22 15:28:04');
INSERT INTO `iot_device_log` VALUES ('4893', '21', 'HUMIDITY', '2', '30.91', '30.91', '1', '2016-04-22 15:28:04');
INSERT INTO `iot_device_log` VALUES ('4894', '21', 'TEMPERATURE', '2', '44.68', '44.68', '1', '2016-04-22 15:28:14');
INSERT INTO `iot_device_log` VALUES ('4895', '21', 'HUMIDITY', '2', '30.77', '30.77', '1', '2016-04-22 15:28:14');
INSERT INTO `iot_device_log` VALUES ('4896', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-22 15:28:23');
INSERT INTO `iot_device_log` VALUES ('4897', '21', 'HUMIDITY', '2', '30.73', '30.73', '1', '2016-04-22 15:28:23');
INSERT INTO `iot_device_log` VALUES ('4898', '21', 'TEMPERATURE', '2', '44.89', '44.89', '1', '2016-04-22 15:28:33');
INSERT INTO `iot_device_log` VALUES ('4899', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 15:28:33');
INSERT INTO `iot_device_log` VALUES ('4900', '21', 'TEMPERATURE', '2', '44.94', '44.94', '1', '2016-04-22 15:28:43');
INSERT INTO `iot_device_log` VALUES ('4901', '21', 'HUMIDITY', '2', '30.66', '30.66', '1', '2016-04-22 15:28:43');
INSERT INTO `iot_device_log` VALUES ('4902', '21', 'TEMPERATURE', '2', '44.99', '44.99', '1', '2016-04-22 15:28:53');
INSERT INTO `iot_device_log` VALUES ('4903', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 15:28:53');
INSERT INTO `iot_device_log` VALUES ('4904', '21', 'TEMPERATURE', '2', '45.02', '45.02', '1', '2016-04-22 15:29:03');
INSERT INTO `iot_device_log` VALUES ('4905', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 15:29:03');
INSERT INTO `iot_device_log` VALUES ('4906', '21', 'TEMPERATURE', '2', '45.1', '45.1', '1', '2016-04-22 15:29:13');
INSERT INTO `iot_device_log` VALUES ('4907', '21', 'HUMIDITY', '2', '30.69', '30.69', '1', '2016-04-22 15:29:13');
INSERT INTO `iot_device_log` VALUES ('4908', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-22 15:29:23');
INSERT INTO `iot_device_log` VALUES ('4909', '21', 'HUMIDITY', '2', '30.75', '30.75', '1', '2016-04-22 15:29:23');
INSERT INTO `iot_device_log` VALUES ('4910', '21', 'TEMPERATURE', '2', '44.87', '44.87', '1', '2016-04-22 15:29:33');
INSERT INTO `iot_device_log` VALUES ('4911', '21', 'HUMIDITY', '2', '30.71', '30.71', '1', '2016-04-22 15:29:33');
INSERT INTO `iot_device_log` VALUES ('4912', '21', 'TEMPERATURE', '2', '45.01', '45.01', '1', '2016-04-22 15:29:44');
INSERT INTO `iot_device_log` VALUES ('4913', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 15:29:44');
INSERT INTO `iot_device_log` VALUES ('4914', '21', 'TEMPERATURE', '2', '45.05', '45.05', '1', '2016-04-22 15:29:54');
INSERT INTO `iot_device_log` VALUES ('4915', '21', 'HUMIDITY', '2', '30.55', '30.55', '1', '2016-04-22 15:29:54');
INSERT INTO `iot_device_log` VALUES ('4916', '21', 'TEMPERATURE', '2', '45.07', '45.07', '1', '2016-04-22 15:30:03');
INSERT INTO `iot_device_log` VALUES ('4917', '21', 'HUMIDITY', '2', '30.53', '30.53', '1', '2016-04-22 15:30:03');
INSERT INTO `iot_device_log` VALUES ('4918', '21', 'TEMPERATURE', '2', '45', '45', '1', '2016-04-22 15:30:13');
INSERT INTO `iot_device_log` VALUES ('4919', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-22 15:30:13');
INSERT INTO `iot_device_log` VALUES ('4920', '21', 'TEMPERATURE', '2', '45.05', '45.05', '1', '2016-04-22 15:30:23');
INSERT INTO `iot_device_log` VALUES ('4921', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-22 15:30:23');
INSERT INTO `iot_device_log` VALUES ('4922', '21', 'TEMPERATURE', '2', '45.07', '45.07', '1', '2016-04-22 15:30:33');
INSERT INTO `iot_device_log` VALUES ('4923', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 15:30:33');
INSERT INTO `iot_device_log` VALUES ('4924', '21', 'TEMPERATURE', '2', '45.06', '45.06', '1', '2016-04-22 15:30:43');
INSERT INTO `iot_device_log` VALUES ('4925', '21', 'HUMIDITY', '2', '30.46', '30.46', '1', '2016-04-22 15:30:43');
INSERT INTO `iot_device_log` VALUES ('4926', '21', 'TEMPERATURE', '2', '45.02', '45.02', '1', '2016-04-22 15:30:53');
INSERT INTO `iot_device_log` VALUES ('4927', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-22 15:30:53');
INSERT INTO `iot_device_log` VALUES ('4928', '21', 'TEMPERATURE', '2', '45.01', '45.01', '1', '2016-04-22 15:31:03');
INSERT INTO `iot_device_log` VALUES ('4929', '21', 'HUMIDITY', '2', '30.47', '30.47', '1', '2016-04-22 15:31:03');
INSERT INTO `iot_device_log` VALUES ('4930', '21', 'TEMPERATURE', '2', '45.08', '45.08', '1', '2016-04-22 15:31:13');
INSERT INTO `iot_device_log` VALUES ('4931', '21', 'HUMIDITY', '2', '30.44', '30.44', '1', '2016-04-22 15:31:13');
INSERT INTO `iot_device_log` VALUES ('4932', '21', 'TEMPERATURE', '2', '45.08', '45.08', '1', '2016-04-22 15:31:23');
INSERT INTO `iot_device_log` VALUES ('4933', '21', 'HUMIDITY', '2', '30.44', '30.44', '1', '2016-04-22 15:31:23');
INSERT INTO `iot_device_log` VALUES ('4934', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 15:31:33');
INSERT INTO `iot_device_log` VALUES ('4935', '21', 'HUMIDITY', '2', '30.43', '30.43', '1', '2016-04-22 15:31:33');
INSERT INTO `iot_device_log` VALUES ('4936', '21', 'TEMPERATURE', '2', '45.14', '45.14', '1', '2016-04-22 15:31:43');
INSERT INTO `iot_device_log` VALUES ('4937', '21', 'HUMIDITY', '2', '30.47', '30.47', '1', '2016-04-22 15:31:43');
INSERT INTO `iot_device_log` VALUES ('4938', '21', 'TEMPERATURE', '2', '45.09', '45.09', '1', '2016-04-22 15:31:53');
INSERT INTO `iot_device_log` VALUES ('4939', '21', 'HUMIDITY', '2', '30.52', '30.52', '1', '2016-04-22 15:31:53');
INSERT INTO `iot_device_log` VALUES ('4940', '21', 'TEMPERATURE', '2', '45.05', '45.05', '1', '2016-04-22 15:32:03');
INSERT INTO `iot_device_log` VALUES ('4941', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 15:32:03');
INSERT INTO `iot_device_log` VALUES ('4942', '21', 'TEMPERATURE', '2', '45', '45', '1', '2016-04-22 15:32:13');
INSERT INTO `iot_device_log` VALUES ('4943', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-22 15:32:13');
INSERT INTO `iot_device_log` VALUES ('4944', '21', 'TEMPERATURE', '2', '45.06', '45.06', '1', '2016-04-22 15:32:23');
INSERT INTO `iot_device_log` VALUES ('4945', '21', 'HUMIDITY', '2', '30.48', '30.48', '1', '2016-04-22 15:32:23');
INSERT INTO `iot_device_log` VALUES ('4946', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 15:32:33');
INSERT INTO `iot_device_log` VALUES ('4947', '21', 'HUMIDITY', '2', '30.41', '30.41', '1', '2016-04-22 15:32:33');
INSERT INTO `iot_device_log` VALUES ('4948', '21', 'TEMPERATURE', '2', '45.27', '45.27', '1', '2016-04-22 15:32:43');
INSERT INTO `iot_device_log` VALUES ('4949', '21', 'HUMIDITY', '2', '30.39', '30.39', '1', '2016-04-22 15:32:43');
INSERT INTO `iot_device_log` VALUES ('4950', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 15:32:53');
INSERT INTO `iot_device_log` VALUES ('4951', '21', 'HUMIDITY', '2', '30.44', '30.44', '1', '2016-04-22 15:32:53');
INSERT INTO `iot_device_log` VALUES ('4952', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 15:33:03');
INSERT INTO `iot_device_log` VALUES ('4953', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 15:33:03');
INSERT INTO `iot_device_log` VALUES ('4954', '21', 'TEMPERATURE', '2', '45.07', '45.07', '1', '2016-04-22 15:33:13');
INSERT INTO `iot_device_log` VALUES ('4955', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-22 15:33:13');
INSERT INTO `iot_device_log` VALUES ('4956', '21', 'TEMPERATURE', '2', '45.11', '45.11', '1', '2016-04-22 15:33:23');
INSERT INTO `iot_device_log` VALUES ('4957', '21', 'HUMIDITY', '2', '30.55', '30.55', '1', '2016-04-22 15:33:23');
INSERT INTO `iot_device_log` VALUES ('4958', '21', 'TEMPERATURE', '2', '44.93', '44.93', '1', '2016-04-22 15:33:33');
INSERT INTO `iot_device_log` VALUES ('4959', '21', 'HUMIDITY', '2', '30.56', '30.56', '1', '2016-04-22 15:33:33');
INSERT INTO `iot_device_log` VALUES ('4960', '21', 'TEMPERATURE', '2', '45.07', '45.07', '1', '2016-04-22 15:33:43');
INSERT INTO `iot_device_log` VALUES ('4961', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 15:33:43');
INSERT INTO `iot_device_log` VALUES ('4962', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 15:33:53');
INSERT INTO `iot_device_log` VALUES ('4963', '21', 'HUMIDITY', '2', '30.44', '30.44', '1', '2016-04-22 15:33:53');
INSERT INTO `iot_device_log` VALUES ('4964', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 15:34:04');
INSERT INTO `iot_device_log` VALUES ('4965', '21', 'HUMIDITY', '2', '30.47', '30.47', '1', '2016-04-22 15:34:04');
INSERT INTO `iot_device_log` VALUES ('4966', '21', 'TEMPERATURE', '2', '45.23', '45.23', '1', '2016-04-22 15:34:13');
INSERT INTO `iot_device_log` VALUES ('4967', '21', 'HUMIDITY', '2', '30.43', '30.43', '1', '2016-04-22 15:34:13');
INSERT INTO `iot_device_log` VALUES ('4968', '21', 'TEMPERATURE', '2', '45.29', '45.29', '1', '2016-04-22 15:34:23');
INSERT INTO `iot_device_log` VALUES ('4969', '21', 'HUMIDITY', '2', '30.39', '30.39', '1', '2016-04-22 15:34:23');
INSERT INTO `iot_device_log` VALUES ('4970', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 15:34:33');
INSERT INTO `iot_device_log` VALUES ('4971', '21', 'HUMIDITY', '2', '30.35', '30.35', '1', '2016-04-22 15:34:33');
INSERT INTO `iot_device_log` VALUES ('4972', '21', 'TEMPERATURE', '2', '45.31', '45.31', '1', '2016-04-22 15:34:43');
INSERT INTO `iot_device_log` VALUES ('4973', '21', 'HUMIDITY', '2', '30.39', '30.39', '1', '2016-04-22 15:34:43');
INSERT INTO `iot_device_log` VALUES ('4974', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 15:34:53');
INSERT INTO `iot_device_log` VALUES ('4975', '21', 'HUMIDITY', '2', '30.27', '30.27', '1', '2016-04-22 15:34:53');
INSERT INTO `iot_device_log` VALUES ('4976', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-22 15:35:03');
INSERT INTO `iot_device_log` VALUES ('4977', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 15:35:03');
INSERT INTO `iot_device_log` VALUES ('4978', '21', 'TEMPERATURE', '2', '45.29', '45.29', '1', '2016-04-22 15:35:13');
INSERT INTO `iot_device_log` VALUES ('4979', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 15:35:13');
INSERT INTO `iot_device_log` VALUES ('4980', '21', 'TEMPERATURE', '2', '44.99', '44.99', '1', '2016-04-22 15:35:24');
INSERT INTO `iot_device_log` VALUES ('4981', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-22 15:35:24');
INSERT INTO `iot_device_log` VALUES ('4982', '21', 'TEMPERATURE', '2', '44.57', '44.57', '1', '2016-04-22 15:35:33');
INSERT INTO `iot_device_log` VALUES ('4983', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 15:35:33');
INSERT INTO `iot_device_log` VALUES ('4984', '21', 'TEMPERATURE', '2', '44.28', '44.28', '1', '2016-04-22 15:35:43');
INSERT INTO `iot_device_log` VALUES ('4985', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 15:35:43');
INSERT INTO `iot_device_log` VALUES ('4986', '21', 'TEMPERATURE', '2', '44.16', '44.16', '1', '2016-04-22 15:35:53');
INSERT INTO `iot_device_log` VALUES ('4987', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 15:35:53');
INSERT INTO `iot_device_log` VALUES ('4988', '21', 'TEMPERATURE', '2', '43.94', '43.94', '1', '2016-04-22 15:36:04');
INSERT INTO `iot_device_log` VALUES ('4989', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-22 15:36:04');
INSERT INTO `iot_device_log` VALUES ('4990', '21', 'TEMPERATURE', '2', '43.91', '43.91', '1', '2016-04-22 15:36:13');
INSERT INTO `iot_device_log` VALUES ('4991', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 15:36:13');
INSERT INTO `iot_device_log` VALUES ('4992', '21', 'TEMPERATURE', '2', '43.91', '43.91', '1', '2016-04-22 15:36:23');
INSERT INTO `iot_device_log` VALUES ('4993', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 15:36:23');
INSERT INTO `iot_device_log` VALUES ('4994', '21', 'TEMPERATURE', '2', '43.83', '43.83', '1', '2016-04-22 15:36:33');
INSERT INTO `iot_device_log` VALUES ('4995', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 15:36:33');
INSERT INTO `iot_device_log` VALUES ('4996', '21', 'TEMPERATURE', '2', '43.74', '43.74', '1', '2016-04-22 15:36:43');
INSERT INTO `iot_device_log` VALUES ('4997', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 15:36:43');
INSERT INTO `iot_device_log` VALUES ('4998', '21', 'TEMPERATURE', '2', '43.86', '43.86', '1', '2016-04-22 15:36:53');
INSERT INTO `iot_device_log` VALUES ('4999', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-22 15:36:53');
INSERT INTO `iot_device_log` VALUES ('5000', '21', 'TEMPERATURE', '2', '44.1', '44.1', '1', '2016-04-22 15:37:03');
INSERT INTO `iot_device_log` VALUES ('5001', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 15:37:03');
INSERT INTO `iot_device_log` VALUES ('5002', '21', 'TEMPERATURE', '2', '43.96', '43.96', '1', '2016-04-22 15:37:13');
INSERT INTO `iot_device_log` VALUES ('5003', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 15:37:13');
INSERT INTO `iot_device_log` VALUES ('5004', '21', 'TEMPERATURE', '2', '43.98', '43.98', '1', '2016-04-22 15:37:23');
INSERT INTO `iot_device_log` VALUES ('5005', '21', 'HUMIDITY', '2', '31.12', '31.12', '1', '2016-04-22 15:37:23');
INSERT INTO `iot_device_log` VALUES ('5006', '21', 'TEMPERATURE', '2', '43.99', '43.99', '1', '2016-04-22 15:37:33');
INSERT INTO `iot_device_log` VALUES ('5007', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 15:37:33');
INSERT INTO `iot_device_log` VALUES ('5008', '21', 'TEMPERATURE', '2', '44.09', '44.09', '1', '2016-04-22 15:37:43');
INSERT INTO `iot_device_log` VALUES ('5009', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 15:37:43');
INSERT INTO `iot_device_log` VALUES ('5010', '21', 'TEMPERATURE', '2', '44.22', '44.22', '1', '2016-04-22 15:37:54');
INSERT INTO `iot_device_log` VALUES ('5011', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 15:37:54');
INSERT INTO `iot_device_log` VALUES ('5012', '21', 'TEMPERATURE', '2', '44.69', '44.69', '1', '2016-04-22 15:38:03');
INSERT INTO `iot_device_log` VALUES ('5013', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 15:38:03');
INSERT INTO `iot_device_log` VALUES ('5014', '21', 'TEMPERATURE', '2', '44.14', '44.14', '1', '2016-04-22 15:38:13');
INSERT INTO `iot_device_log` VALUES ('5015', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 15:38:13');
INSERT INTO `iot_device_log` VALUES ('5016', '21', 'TEMPERATURE', '2', '44.09', '44.09', '1', '2016-04-22 15:38:23');
INSERT INTO `iot_device_log` VALUES ('5017', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 15:38:23');
INSERT INTO `iot_device_log` VALUES ('5018', '21', 'TEMPERATURE', '2', '44.28', '44.28', '1', '2016-04-22 15:38:33');
INSERT INTO `iot_device_log` VALUES ('5019', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 15:38:33');
INSERT INTO `iot_device_log` VALUES ('5020', '21', 'TEMPERATURE', '2', '44.3', '44.3', '1', '2016-04-22 15:38:43');
INSERT INTO `iot_device_log` VALUES ('5021', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 15:38:43');
INSERT INTO `iot_device_log` VALUES ('5022', '21', 'TEMPERATURE', '2', '44.21', '44.21', '1', '2016-04-22 15:38:53');
INSERT INTO `iot_device_log` VALUES ('5023', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 15:38:53');
INSERT INTO `iot_device_log` VALUES ('5024', '21', 'TEMPERATURE', '2', '44.23', '44.23', '1', '2016-04-22 15:39:03');
INSERT INTO `iot_device_log` VALUES ('5025', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 15:39:03');
INSERT INTO `iot_device_log` VALUES ('5026', '21', 'TEMPERATURE', '2', '44.26', '44.26', '1', '2016-04-22 15:39:13');
INSERT INTO `iot_device_log` VALUES ('5027', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 15:39:13');
INSERT INTO `iot_device_log` VALUES ('5028', '21', 'TEMPERATURE', '2', '44.37', '44.37', '1', '2016-04-22 15:39:23');
INSERT INTO `iot_device_log` VALUES ('5029', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-22 15:39:23');
INSERT INTO `iot_device_log` VALUES ('5030', '21', 'TEMPERATURE', '2', '44.48', '44.48', '1', '2016-04-22 15:39:33');
INSERT INTO `iot_device_log` VALUES ('5031', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 15:39:33');
INSERT INTO `iot_device_log` VALUES ('5032', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-22 15:39:43');
INSERT INTO `iot_device_log` VALUES ('5033', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 15:39:43');
INSERT INTO `iot_device_log` VALUES ('5034', '21', 'TEMPERATURE', '2', '44.69', '44.69', '1', '2016-04-22 15:39:53');
INSERT INTO `iot_device_log` VALUES ('5035', '21', 'HUMIDITY', '2', '30.66', '30.66', '1', '2016-04-22 15:39:53');
INSERT INTO `iot_device_log` VALUES ('5036', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 15:40:03');
INSERT INTO `iot_device_log` VALUES ('5037', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 15:40:03');
INSERT INTO `iot_device_log` VALUES ('5038', '21', 'TEMPERATURE', '2', '44.66', '44.66', '1', '2016-04-22 15:40:13');
INSERT INTO `iot_device_log` VALUES ('5039', '21', 'HUMIDITY', '2', '30.75', '30.75', '1', '2016-04-22 15:40:13');
INSERT INTO `iot_device_log` VALUES ('5040', '21', 'TEMPERATURE', '2', '44.6', '44.6', '1', '2016-04-22 15:40:23');
INSERT INTO `iot_device_log` VALUES ('5041', '21', 'HUMIDITY', '2', '30.71', '30.71', '1', '2016-04-22 15:40:23');
INSERT INTO `iot_device_log` VALUES ('5042', '21', 'TEMPERATURE', '2', '44.63', '44.63', '1', '2016-04-22 15:40:33');
INSERT INTO `iot_device_log` VALUES ('5043', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 15:40:33');
INSERT INTO `iot_device_log` VALUES ('5044', '21', 'TEMPERATURE', '2', '44.63', '44.63', '1', '2016-04-22 15:40:43');
INSERT INTO `iot_device_log` VALUES ('5045', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 15:40:43');
INSERT INTO `iot_device_log` VALUES ('5046', '21', 'TEMPERATURE', '2', '44.84', '44.84', '1', '2016-04-22 15:40:53');
INSERT INTO `iot_device_log` VALUES ('5047', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 15:40:53');
INSERT INTO `iot_device_log` VALUES ('5048', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 15:41:03');
INSERT INTO `iot_device_log` VALUES ('5049', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-22 15:41:03');
INSERT INTO `iot_device_log` VALUES ('5050', '21', 'TEMPERATURE', '2', '44.83', '44.83', '1', '2016-04-22 15:41:13');
INSERT INTO `iot_device_log` VALUES ('5051', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 15:41:13');
INSERT INTO `iot_device_log` VALUES ('5052', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-22 15:41:23');
INSERT INTO `iot_device_log` VALUES ('5053', '21', 'HUMIDITY', '2', '30.63', '30.63', '1', '2016-04-22 15:41:23');
INSERT INTO `iot_device_log` VALUES ('5054', '21', 'TEMPERATURE', '2', '44.81', '44.81', '1', '2016-04-22 15:41:33');
INSERT INTO `iot_device_log` VALUES ('5055', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 15:41:33');
INSERT INTO `iot_device_log` VALUES ('5056', '21', 'TEMPERATURE', '2', '44.72', '44.72', '1', '2016-04-22 15:41:43');
INSERT INTO `iot_device_log` VALUES ('5057', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 15:41:43');
INSERT INTO `iot_device_log` VALUES ('5058', '21', 'TEMPERATURE', '2', '44.71', '44.71', '1', '2016-04-22 15:41:53');
INSERT INTO `iot_device_log` VALUES ('5059', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 15:41:53');
INSERT INTO `iot_device_log` VALUES ('5060', '21', 'TEMPERATURE', '2', '44.61', '44.61', '1', '2016-04-22 15:42:04');
INSERT INTO `iot_device_log` VALUES ('5061', '21', 'HUMIDITY', '2', '30.69', '30.69', '1', '2016-04-22 15:42:04');
INSERT INTO `iot_device_log` VALUES ('5062', '21', 'TEMPERATURE', '2', '44.62', '44.62', '1', '2016-04-22 15:42:13');
INSERT INTO `iot_device_log` VALUES ('5063', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-22 15:42:13');
INSERT INTO `iot_device_log` VALUES ('5064', '21', 'TEMPERATURE', '2', '44.49', '44.49', '1', '2016-04-22 15:42:23');
INSERT INTO `iot_device_log` VALUES ('5065', '21', 'HUMIDITY', '2', '30.8', '30.8', '1', '2016-04-22 15:42:23');
INSERT INTO `iot_device_log` VALUES ('5066', '21', 'TEMPERATURE', '2', '44.53', '44.53', '1', '2016-04-22 15:42:33');
INSERT INTO `iot_device_log` VALUES ('5067', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-22 15:42:33');
INSERT INTO `iot_device_log` VALUES ('5068', '21', 'TEMPERATURE', '2', '44.53', '44.53', '1', '2016-04-22 15:42:43');
INSERT INTO `iot_device_log` VALUES ('5069', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-22 15:42:43');
INSERT INTO `iot_device_log` VALUES ('5070', '21', 'TEMPERATURE', '2', '44.47', '44.47', '1', '2016-04-22 15:42:54');
INSERT INTO `iot_device_log` VALUES ('5071', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 15:42:54');
INSERT INTO `iot_device_log` VALUES ('5072', '21', 'TEMPERATURE', '2', '44.32', '44.32', '1', '2016-04-22 15:43:03');
INSERT INTO `iot_device_log` VALUES ('5073', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-22 15:43:03');
INSERT INTO `iot_device_log` VALUES ('5074', '21', 'TEMPERATURE', '2', '44.44', '44.44', '1', '2016-04-22 15:43:13');
INSERT INTO `iot_device_log` VALUES ('5075', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 15:43:13');
INSERT INTO `iot_device_log` VALUES ('5076', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-22 15:43:23');
INSERT INTO `iot_device_log` VALUES ('5077', '21', 'HUMIDITY', '2', '30.91', '30.91', '1', '2016-04-22 15:43:23');
INSERT INTO `iot_device_log` VALUES ('5078', '21', 'TEMPERATURE', '2', '44.22', '44.22', '1', '2016-04-22 15:43:33');
INSERT INTO `iot_device_log` VALUES ('5079', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 15:43:33');
INSERT INTO `iot_device_log` VALUES ('5080', '21', 'TEMPERATURE', '2', '44.21', '44.21', '1', '2016-04-22 15:43:43');
INSERT INTO `iot_device_log` VALUES ('5081', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 15:43:43');
INSERT INTO `iot_device_log` VALUES ('5082', '21', 'TEMPERATURE', '2', '44.27', '44.27', '1', '2016-04-22 15:43:53');
INSERT INTO `iot_device_log` VALUES ('5083', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 15:43:53');
INSERT INTO `iot_device_log` VALUES ('5084', '21', 'TEMPERATURE', '2', '44.28', '44.28', '1', '2016-04-22 15:44:03');
INSERT INTO `iot_device_log` VALUES ('5085', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 15:44:03');
INSERT INTO `iot_device_log` VALUES ('5086', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-22 15:44:13');
INSERT INTO `iot_device_log` VALUES ('5087', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 15:44:13');
INSERT INTO `iot_device_log` VALUES ('5088', '21', 'TEMPERATURE', '2', '44.43', '44.43', '1', '2016-04-22 15:44:23');
INSERT INTO `iot_device_log` VALUES ('5089', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 15:44:23');
INSERT INTO `iot_device_log` VALUES ('5090', '21', 'TEMPERATURE', '2', '44.45', '44.45', '1', '2016-04-22 15:44:33');
INSERT INTO `iot_device_log` VALUES ('5091', '21', 'HUMIDITY', '2', '31.03', '31.03', '1', '2016-04-22 15:44:33');
INSERT INTO `iot_device_log` VALUES ('5092', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-22 15:44:43');
INSERT INTO `iot_device_log` VALUES ('5093', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 15:44:43');
INSERT INTO `iot_device_log` VALUES ('5094', '21', 'TEMPERATURE', '2', '44.24', '44.24', '1', '2016-04-22 15:44:53');
INSERT INTO `iot_device_log` VALUES ('5095', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 15:44:53');
INSERT INTO `iot_device_log` VALUES ('5096', '21', 'TEMPERATURE', '2', '44.27', '44.27', '1', '2016-04-22 15:45:03');
INSERT INTO `iot_device_log` VALUES ('5097', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 15:45:03');
INSERT INTO `iot_device_log` VALUES ('5098', '21', 'TEMPERATURE', '2', '44.19', '44.19', '1', '2016-04-22 15:45:13');
INSERT INTO `iot_device_log` VALUES ('5099', '21', 'HUMIDITY', '2', '30.95', '30.95', '1', '2016-04-22 15:45:13');
INSERT INTO `iot_device_log` VALUES ('5100', '21', 'TEMPERATURE', '2', '44.18', '44.18', '1', '2016-04-22 15:45:23');
INSERT INTO `iot_device_log` VALUES ('5101', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-22 15:45:23');
INSERT INTO `iot_device_log` VALUES ('5102', '21', 'TEMPERATURE', '2', '44.02', '44.02', '1', '2016-04-22 15:45:33');
INSERT INTO `iot_device_log` VALUES ('5103', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-22 15:45:33');
INSERT INTO `iot_device_log` VALUES ('5104', '21', 'TEMPERATURE', '2', '44.28', '44.28', '1', '2016-04-22 15:45:43');
INSERT INTO `iot_device_log` VALUES ('5105', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 15:45:43');
INSERT INTO `iot_device_log` VALUES ('5106', '21', 'TEMPERATURE', '2', '44.11', '44.11', '1', '2016-04-22 15:45:53');
INSERT INTO `iot_device_log` VALUES ('5107', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 15:45:53');
INSERT INTO `iot_device_log` VALUES ('5108', '21', 'TEMPERATURE', '2', '44.16', '44.16', '1', '2016-04-22 15:46:03');
INSERT INTO `iot_device_log` VALUES ('5109', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 15:46:03');
INSERT INTO `iot_device_log` VALUES ('5110', '21', 'TEMPERATURE', '2', '44.27', '44.27', '1', '2016-04-22 15:46:13');
INSERT INTO `iot_device_log` VALUES ('5111', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-22 15:46:13');
INSERT INTO `iot_device_log` VALUES ('5112', '21', 'TEMPERATURE', '2', '44.5', '44.5', '1', '2016-04-22 15:46:23');
INSERT INTO `iot_device_log` VALUES ('5113', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-22 15:46:23');
INSERT INTO `iot_device_log` VALUES ('5114', '21', 'TEMPERATURE', '2', '44.51', '44.51', '1', '2016-04-22 15:46:33');
INSERT INTO `iot_device_log` VALUES ('5115', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 15:46:33');
INSERT INTO `iot_device_log` VALUES ('5116', '21', 'TEMPERATURE', '2', '44.72', '44.72', '1', '2016-04-22 15:46:43');
INSERT INTO `iot_device_log` VALUES ('5117', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 15:46:43');
INSERT INTO `iot_device_log` VALUES ('5118', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-22 15:46:53');
INSERT INTO `iot_device_log` VALUES ('5119', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 15:46:53');
INSERT INTO `iot_device_log` VALUES ('5120', '21', 'TEMPERATURE', '2', '44.7', '44.7', '1', '2016-04-22 15:47:03');
INSERT INTO `iot_device_log` VALUES ('5121', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 15:47:03');
INSERT INTO `iot_device_log` VALUES ('5122', '21', 'TEMPERATURE', '2', '44.43', '44.43', '1', '2016-04-22 15:47:13');
INSERT INTO `iot_device_log` VALUES ('5123', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-22 15:47:13');
INSERT INTO `iot_device_log` VALUES ('5124', '21', 'TEMPERATURE', '2', '44.24', '44.24', '1', '2016-04-22 15:47:23');
INSERT INTO `iot_device_log` VALUES ('5125', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 15:47:23');
INSERT INTO `iot_device_log` VALUES ('5126', '21', 'TEMPERATURE', '2', '44.18', '44.18', '1', '2016-04-22 15:47:33');
INSERT INTO `iot_device_log` VALUES ('5127', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 15:47:33');
INSERT INTO `iot_device_log` VALUES ('5128', '21', 'TEMPERATURE', '2', '44.05', '44.05', '1', '2016-04-22 15:47:43');
INSERT INTO `iot_device_log` VALUES ('5129', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 15:47:43');
INSERT INTO `iot_device_log` VALUES ('5130', '21', 'TEMPERATURE', '2', '44.03', '44.03', '1', '2016-04-22 15:47:53');
INSERT INTO `iot_device_log` VALUES ('5131', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 15:47:53');
INSERT INTO `iot_device_log` VALUES ('5132', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 15:48:00');
INSERT INTO `iot_device_log` VALUES ('5133', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 15:48:02');
INSERT INTO `iot_device_log` VALUES ('5134', '21', 'TEMPERATURE', '2', '44.22', '44.22', '1', '2016-04-22 15:48:03');
INSERT INTO `iot_device_log` VALUES ('5135', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 15:48:03');
INSERT INTO `iot_device_log` VALUES ('5136', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 15:48:05');
INSERT INTO `iot_device_log` VALUES ('5137', '21', 'TEMPERATURE', '2', '44.17', '44.17', '1', '2016-04-22 15:48:13');
INSERT INTO `iot_device_log` VALUES ('5138', '21', 'HUMIDITY', '2', '30.95', '30.95', '1', '2016-04-22 15:48:13');
INSERT INTO `iot_device_log` VALUES ('5139', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 15:48:20');
INSERT INTO `iot_device_log` VALUES ('5140', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-22 15:48:23');
INSERT INTO `iot_device_log` VALUES ('5141', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 15:48:23');
INSERT INTO `iot_device_log` VALUES ('5142', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 15:48:26');
INSERT INTO `iot_device_log` VALUES ('5143', '21', 'TEMPERATURE', '2', '44.46', '44.46', '1', '2016-04-22 15:48:33');
INSERT INTO `iot_device_log` VALUES ('5144', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-22 15:48:33');
INSERT INTO `iot_device_log` VALUES ('5145', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 15:48:33');
INSERT INTO `iot_device_log` VALUES ('5146', '21', 'TEMPERATURE', '2', '44.74', '44.74', '1', '2016-04-22 15:48:43');
INSERT INTO `iot_device_log` VALUES ('5147', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-22 15:48:43');
INSERT INTO `iot_device_log` VALUES ('5148', '21', 'TEMPERATURE', '2', '44.74', '44.74', '1', '2016-04-22 15:48:53');
INSERT INTO `iot_device_log` VALUES ('5149', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-22 15:48:53');
INSERT INTO `iot_device_log` VALUES ('5150', '21', 'TEMPERATURE', '2', '44.64', '44.64', '1', '2016-04-22 15:49:03');
INSERT INTO `iot_device_log` VALUES ('5151', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-22 15:49:03');
INSERT INTO `iot_device_log` VALUES ('5152', '21', 'TEMPERATURE', '2', '44.44', '44.44', '1', '2016-04-22 15:49:13');
INSERT INTO `iot_device_log` VALUES ('5153', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 15:49:13');
INSERT INTO `iot_device_log` VALUES ('5154', '21', 'TEMPERATURE', '2', '44.54', '44.54', '1', '2016-04-22 15:49:23');
INSERT INTO `iot_device_log` VALUES ('5155', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 15:49:23');
INSERT INTO `iot_device_log` VALUES ('5156', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-22 15:49:33');
INSERT INTO `iot_device_log` VALUES ('5157', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-22 15:49:33');
INSERT INTO `iot_device_log` VALUES ('5158', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 15:49:43');
INSERT INTO `iot_device_log` VALUES ('5159', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 15:49:43');
INSERT INTO `iot_device_log` VALUES ('5160', '21', 'TEMPERATURE', '2', '44.33', '44.33', '1', '2016-04-22 15:49:53');
INSERT INTO `iot_device_log` VALUES ('5161', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 15:49:53');
INSERT INTO `iot_device_log` VALUES ('5162', '21', 'TEMPERATURE', '2', '44.24', '44.24', '1', '2016-04-22 15:50:03');
INSERT INTO `iot_device_log` VALUES ('5163', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 15:50:03');
INSERT INTO `iot_device_log` VALUES ('5164', '21', 'TEMPERATURE', '2', '44.33', '44.33', '1', '2016-04-22 15:50:13');
INSERT INTO `iot_device_log` VALUES ('5165', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 15:50:13');
INSERT INTO `iot_device_log` VALUES ('5166', '21', 'TEMPERATURE', '2', '44.4', '44.4', '1', '2016-04-22 15:50:23');
INSERT INTO `iot_device_log` VALUES ('5167', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 15:50:23');
INSERT INTO `iot_device_log` VALUES ('5168', '21', 'TEMPERATURE', '2', '45.08', '45.08', '1', '2016-04-22 15:50:33');
INSERT INTO `iot_device_log` VALUES ('5169', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 15:50:33');
INSERT INTO `iot_device_log` VALUES ('5170', '21', 'TEMPERATURE', '2', '44.88', '44.88', '1', '2016-04-22 15:50:43');
INSERT INTO `iot_device_log` VALUES ('5171', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 15:50:43');
INSERT INTO `iot_device_log` VALUES ('5172', '21', 'TEMPERATURE', '2', '44.63', '44.63', '1', '2016-04-22 15:50:53');
INSERT INTO `iot_device_log` VALUES ('5173', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 15:50:53');
INSERT INTO `iot_device_log` VALUES ('5174', '21', 'TEMPERATURE', '2', '44.89', '44.89', '1', '2016-04-22 15:51:03');
INSERT INTO `iot_device_log` VALUES ('5175', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 15:51:03');
INSERT INTO `iot_device_log` VALUES ('5176', '21', 'TEMPERATURE', '2', '44.81', '44.81', '1', '2016-04-22 15:51:13');
INSERT INTO `iot_device_log` VALUES ('5177', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 15:51:13');
INSERT INTO `iot_device_log` VALUES ('5178', '21', 'TEMPERATURE', '2', '99.99', '99.99', '1', '2016-04-22 15:51:23');
INSERT INTO `iot_device_log` VALUES ('5179', '21', 'HUMIDITY', '2', '33.91', '33.91', '1', '2016-04-22 15:51:23');
INSERT INTO `iot_device_log` VALUES ('5180', '21', 'TEMPERATURE', '2', '60.41', '60.41', '1', '2016-04-22 15:51:33');
INSERT INTO `iot_device_log` VALUES ('5181', '21', 'HUMIDITY', '2', '32.55', '32.55', '1', '2016-04-22 15:51:33');
INSERT INTO `iot_device_log` VALUES ('5182', '21', 'TEMPERATURE', '2', '52.98', '52.98', '1', '2016-04-22 15:51:43');
INSERT INTO `iot_device_log` VALUES ('5183', '21', 'HUMIDITY', '2', '32.16', '32.16', '1', '2016-04-22 15:51:43');
INSERT INTO `iot_device_log` VALUES ('5184', '21', 'TEMPERATURE', '2', '50.58', '50.58', '1', '2016-04-22 15:51:53');
INSERT INTO `iot_device_log` VALUES ('5185', '21', 'HUMIDITY', '2', '31.88', '31.88', '1', '2016-04-22 15:51:53');
INSERT INTO `iot_device_log` VALUES ('5186', '21', 'TEMPERATURE', '2', '49.14', '49.14', '1', '2016-04-22 15:52:03');
INSERT INTO `iot_device_log` VALUES ('5187', '21', 'HUMIDITY', '2', '31.66', '31.66', '1', '2016-04-22 15:52:03');
INSERT INTO `iot_device_log` VALUES ('5188', '21', 'TEMPERATURE', '2', '49.42', '49.42', '1', '2016-04-22 15:52:13');
INSERT INTO `iot_device_log` VALUES ('5189', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 15:52:13');
INSERT INTO `iot_device_log` VALUES ('5190', '21', 'TEMPERATURE', '2', '48.4', '48.4', '1', '2016-04-22 15:52:23');
INSERT INTO `iot_device_log` VALUES ('5191', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 15:52:23');
INSERT INTO `iot_device_log` VALUES ('5192', '21', 'TEMPERATURE', '2', '48.15', '48.15', '1', '2016-04-22 15:52:33');
INSERT INTO `iot_device_log` VALUES ('5193', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-22 15:52:33');
INSERT INTO `iot_device_log` VALUES ('5194', '21', 'TEMPERATURE', '2', '47.99', '47.99', '1', '2016-04-22 15:52:43');
INSERT INTO `iot_device_log` VALUES ('5195', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 15:52:43');
INSERT INTO `iot_device_log` VALUES ('5196', '21', 'TEMPERATURE', '2', '48.25', '48.25', '1', '2016-04-22 15:52:53');
INSERT INTO `iot_device_log` VALUES ('5197', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 15:52:53');
INSERT INTO `iot_device_log` VALUES ('5198', '21', 'TEMPERATURE', '2', '48.42', '48.42', '1', '2016-04-22 15:53:03');
INSERT INTO `iot_device_log` VALUES ('5199', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 15:53:03');
INSERT INTO `iot_device_log` VALUES ('5200', '21', 'TEMPERATURE', '2', '49.18', '49.18', '1', '2016-04-22 15:53:13');
INSERT INTO `iot_device_log` VALUES ('5201', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 15:53:13');
INSERT INTO `iot_device_log` VALUES ('5202', '21', 'TEMPERATURE', '2', '47.51', '47.51', '1', '2016-04-22 15:53:23');
INSERT INTO `iot_device_log` VALUES ('5203', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-22 15:53:23');
INSERT INTO `iot_device_log` VALUES ('5204', '21', 'TEMPERATURE', '2', '47.34', '47.34', '1', '2016-04-22 15:53:33');
INSERT INTO `iot_device_log` VALUES ('5205', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 15:53:33');
INSERT INTO `iot_device_log` VALUES ('5206', '21', 'TEMPERATURE', '2', '47.1', '47.1', '1', '2016-04-22 15:53:43');
INSERT INTO `iot_device_log` VALUES ('5207', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 15:53:43');
INSERT INTO `iot_device_log` VALUES ('5208', '21', 'TEMPERATURE', '2', '47.03', '47.03', '1', '2016-04-22 15:53:53');
INSERT INTO `iot_device_log` VALUES ('5209', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 15:53:53');
INSERT INTO `iot_device_log` VALUES ('5210', '21', 'TEMPERATURE', '2', '47.01', '47.01', '1', '2016-04-22 15:54:03');
INSERT INTO `iot_device_log` VALUES ('5211', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-22 15:54:03');
INSERT INTO `iot_device_log` VALUES ('5212', '21', 'TEMPERATURE', '2', '47.15', '47.15', '1', '2016-04-22 15:54:14');
INSERT INTO `iot_device_log` VALUES ('5213', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 15:54:14');
INSERT INTO `iot_device_log` VALUES ('5214', '21', 'TEMPERATURE', '2', '47.97', '47.97', '1', '2016-04-22 15:54:24');
INSERT INTO `iot_device_log` VALUES ('5215', '21', 'HUMIDITY', '2', '30.66', '30.66', '1', '2016-04-22 15:54:24');
INSERT INTO `iot_device_log` VALUES ('5216', '21', 'TEMPERATURE', '2', '47.26', '47.26', '1', '2016-04-22 15:54:33');
INSERT INTO `iot_device_log` VALUES ('5217', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 15:54:33');
INSERT INTO `iot_device_log` VALUES ('5218', '21', 'TEMPERATURE', '2', '47.26', '47.26', '1', '2016-04-22 15:54:43');
INSERT INTO `iot_device_log` VALUES ('5219', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 15:54:43');
INSERT INTO `iot_device_log` VALUES ('5220', '21', 'TEMPERATURE', '2', '47.13', '47.13', '1', '2016-04-22 15:54:53');
INSERT INTO `iot_device_log` VALUES ('5221', '21', 'HUMIDITY', '2', '30.73', '30.73', '1', '2016-04-22 15:54:53');
INSERT INTO `iot_device_log` VALUES ('5222', '21', 'TEMPERATURE', '2', '46.99', '46.99', '1', '2016-04-22 15:55:03');
INSERT INTO `iot_device_log` VALUES ('5223', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-22 15:55:03');
INSERT INTO `iot_device_log` VALUES ('5224', '21', 'TEMPERATURE', '2', '46.96', '46.96', '1', '2016-04-22 15:55:13');
INSERT INTO `iot_device_log` VALUES ('5225', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-22 15:55:13');
INSERT INTO `iot_device_log` VALUES ('5226', '21', 'TEMPERATURE', '2', '46.62', '46.62', '1', '2016-04-22 15:55:23');
INSERT INTO `iot_device_log` VALUES ('5227', '21', 'HUMIDITY', '2', '31.03', '31.03', '1', '2016-04-22 15:55:23');
INSERT INTO `iot_device_log` VALUES ('5228', '21', 'TEMPERATURE', '2', '46.42', '46.42', '1', '2016-04-22 15:55:33');
INSERT INTO `iot_device_log` VALUES ('5229', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-22 15:55:33');
INSERT INTO `iot_device_log` VALUES ('5230', '21', 'TEMPERATURE', '2', '46.31', '46.31', '1', '2016-04-22 15:55:43');
INSERT INTO `iot_device_log` VALUES ('5231', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 15:55:43');
INSERT INTO `iot_device_log` VALUES ('5232', '21', 'TEMPERATURE', '2', '46.33', '46.33', '1', '2016-04-22 15:55:53');
INSERT INTO `iot_device_log` VALUES ('5233', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 15:55:53');
INSERT INTO `iot_device_log` VALUES ('5234', '21', 'TEMPERATURE', '2', '46.38', '46.38', '1', '2016-04-22 15:56:03');
INSERT INTO `iot_device_log` VALUES ('5235', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 15:56:03');
INSERT INTO `iot_device_log` VALUES ('5236', '21', 'TEMPERATURE', '2', '46.35', '46.35', '1', '2016-04-22 15:56:13');
INSERT INTO `iot_device_log` VALUES ('5237', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 15:56:13');
INSERT INTO `iot_device_log` VALUES ('5238', '21', 'TEMPERATURE', '2', '46.21', '46.21', '1', '2016-04-22 15:56:23');
INSERT INTO `iot_device_log` VALUES ('5239', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 15:56:23');
INSERT INTO `iot_device_log` VALUES ('5240', '21', 'TEMPERATURE', '2', '46.01', '46.01', '1', '2016-04-22 15:56:33');
INSERT INTO `iot_device_log` VALUES ('5241', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 15:56:33');
INSERT INTO `iot_device_log` VALUES ('5242', '21', 'TEMPERATURE', '2', '45.76', '45.76', '1', '2016-04-22 15:56:43');
INSERT INTO `iot_device_log` VALUES ('5243', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 15:56:43');
INSERT INTO `iot_device_log` VALUES ('5244', '21', 'TEMPERATURE', '2', '45.82', '45.82', '1', '2016-04-22 15:57:02');
INSERT INTO `iot_device_log` VALUES ('5245', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 15:57:02');
INSERT INTO `iot_device_log` VALUES ('5246', '21', 'TEMPERATURE', '2', '45.3', '45.3', '1', '2016-04-22 15:57:12');
INSERT INTO `iot_device_log` VALUES ('5247', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 15:57:12');
INSERT INTO `iot_device_log` VALUES ('5248', '21', 'TEMPERATURE', '2', '45.01', '45.01', '1', '2016-04-22 15:57:22');
INSERT INTO `iot_device_log` VALUES ('5249', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 15:57:22');
INSERT INTO `iot_device_log` VALUES ('5250', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-22 15:57:32');
INSERT INTO `iot_device_log` VALUES ('5251', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 15:57:32');
INSERT INTO `iot_device_log` VALUES ('5252', '21', 'TEMPERATURE', '2', '44.9', '44.9', '1', '2016-04-22 15:57:42');
INSERT INTO `iot_device_log` VALUES ('5253', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 15:57:42');
INSERT INTO `iot_device_log` VALUES ('5254', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-22 15:57:53');
INSERT INTO `iot_device_log` VALUES ('5255', '21', 'HUMIDITY', '2', '31.41', '31.41', '1', '2016-04-22 15:57:53');
INSERT INTO `iot_device_log` VALUES ('5256', '21', 'TEMPERATURE', '2', '45.1', '45.1', '1', '2016-04-22 15:58:03');
INSERT INTO `iot_device_log` VALUES ('5257', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-22 15:58:03');
INSERT INTO `iot_device_log` VALUES ('5258', '21', 'TEMPERATURE', '2', '44.83', '44.83', '1', '2016-04-22 15:58:12');
INSERT INTO `iot_device_log` VALUES ('5259', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-22 15:58:12');
INSERT INTO `iot_device_log` VALUES ('5260', '21', 'TEMPERATURE', '2', '44.51', '44.51', '1', '2016-04-22 15:58:22');
INSERT INTO `iot_device_log` VALUES ('5261', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-22 15:58:22');
INSERT INTO `iot_device_log` VALUES ('5262', '21', 'TEMPERATURE', '2', '44.72', '44.72', '1', '2016-04-22 15:58:32');
INSERT INTO `iot_device_log` VALUES ('5263', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 15:58:32');
INSERT INTO `iot_device_log` VALUES ('5264', '21', 'TEMPERATURE', '2', '45.08', '45.08', '1', '2016-04-22 15:58:42');
INSERT INTO `iot_device_log` VALUES ('5265', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 15:58:42');
INSERT INTO `iot_device_log` VALUES ('5266', '21', 'TEMPERATURE', '2', '45.61', '45.61', '1', '2016-04-22 15:58:52');
INSERT INTO `iot_device_log` VALUES ('5267', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 15:58:52');
INSERT INTO `iot_device_log` VALUES ('5268', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 15:59:02');
INSERT INTO `iot_device_log` VALUES ('5269', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-22 15:59:02');
INSERT INTO `iot_device_log` VALUES ('5270', '21', 'TEMPERATURE', '2', '45.56', '45.56', '1', '2016-04-22 15:59:12');
INSERT INTO `iot_device_log` VALUES ('5271', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-22 15:59:12');
INSERT INTO `iot_device_log` VALUES ('5272', '21', 'TEMPERATURE', '2', '46.89', '46.89', '1', '2016-04-22 15:59:22');
INSERT INTO `iot_device_log` VALUES ('5273', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-22 15:59:22');
INSERT INTO `iot_device_log` VALUES ('5274', '21', 'TEMPERATURE', '2', '45.49', '45.49', '1', '2016-04-22 15:59:32');
INSERT INTO `iot_device_log` VALUES ('5275', '21', 'HUMIDITY', '2', '31.25', '31.25', '1', '2016-04-22 15:59:32');
INSERT INTO `iot_device_log` VALUES ('5276', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-22 15:59:42');
INSERT INTO `iot_device_log` VALUES ('5277', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-22 15:59:42');
INSERT INTO `iot_device_log` VALUES ('5278', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 15:59:52');
INSERT INTO `iot_device_log` VALUES ('5279', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 15:59:52');
INSERT INTO `iot_device_log` VALUES ('5280', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 16:00:03');
INSERT INTO `iot_device_log` VALUES ('5281', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:00:03');
INSERT INTO `iot_device_log` VALUES ('5282', '21', 'TEMPERATURE', '2', '45.67', '45.67', '1', '2016-04-22 16:00:12');
INSERT INTO `iot_device_log` VALUES ('5283', '21', 'HUMIDITY', '2', '30.95', '30.95', '1', '2016-04-22 16:00:12');
INSERT INTO `iot_device_log` VALUES ('5284', '21', 'TEMPERATURE', '2', '45.77', '45.77', '1', '2016-04-22 16:00:22');
INSERT INTO `iot_device_log` VALUES ('5285', '21', 'HUMIDITY', '2', '30.8', '30.8', '1', '2016-04-22 16:00:22');
INSERT INTO `iot_device_log` VALUES ('5286', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-22 16:00:32');
INSERT INTO `iot_device_log` VALUES ('5287', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-22 16:00:32');
INSERT INTO `iot_device_log` VALUES ('5288', '21', 'TEMPERATURE', '2', '45.98', '45.98', '1', '2016-04-22 16:00:42');
INSERT INTO `iot_device_log` VALUES ('5289', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:00:42');
INSERT INTO `iot_device_log` VALUES ('5290', '21', 'TEMPERATURE', '2', '45.68', '45.68', '1', '2016-04-22 16:00:52');
INSERT INTO `iot_device_log` VALUES ('5291', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:00:52');
INSERT INTO `iot_device_log` VALUES ('5292', '21', 'TEMPERATURE', '2', '45.41', '45.41', '1', '2016-04-22 16:01:02');
INSERT INTO `iot_device_log` VALUES ('5293', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:01:02');
INSERT INTO `iot_device_log` VALUES ('5294', '21', 'TEMPERATURE', '2', '45.45', '45.45', '1', '2016-04-22 16:01:12');
INSERT INTO `iot_device_log` VALUES ('5295', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:01:12');
INSERT INTO `iot_device_log` VALUES ('5296', '21', 'TEMPERATURE', '2', '45.32', '45.32', '1', '2016-04-22 16:01:22');
INSERT INTO `iot_device_log` VALUES ('5297', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 16:01:22');
INSERT INTO `iot_device_log` VALUES ('5298', '21', 'TEMPERATURE', '2', '45.32', '45.32', '1', '2016-04-22 16:01:32');
INSERT INTO `iot_device_log` VALUES ('5299', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 16:01:32');
INSERT INTO `iot_device_log` VALUES ('5300', '21', 'TEMPERATURE', '2', '45.18', '45.18', '1', '2016-04-22 16:01:42');
INSERT INTO `iot_device_log` VALUES ('5301', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-22 16:01:42');
INSERT INTO `iot_device_log` VALUES ('5302', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 16:01:52');
INSERT INTO `iot_device_log` VALUES ('5303', '21', 'HUMIDITY', '2', '31.03', '31.03', '1', '2016-04-22 16:01:52');
INSERT INTO `iot_device_log` VALUES ('5304', '21', 'TEMPERATURE', '2', '45.04', '45.04', '1', '2016-04-22 16:02:03');
INSERT INTO `iot_device_log` VALUES ('5305', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-22 16:02:03');
INSERT INTO `iot_device_log` VALUES ('5306', '21', 'TEMPERATURE', '2', '45.15', '45.15', '1', '2016-04-22 16:02:13');
INSERT INTO `iot_device_log` VALUES ('5307', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 16:02:13');
INSERT INTO `iot_device_log` VALUES ('5308', '21', 'TEMPERATURE', '2', '45.01', '45.01', '1', '2016-04-22 16:02:23');
INSERT INTO `iot_device_log` VALUES ('5309', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 16:02:23');
INSERT INTO `iot_device_log` VALUES ('5310', '21', 'TEMPERATURE', '2', '45.14', '45.14', '1', '2016-04-22 16:02:32');
INSERT INTO `iot_device_log` VALUES ('5311', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:02:32');
INSERT INTO `iot_device_log` VALUES ('5312', '21', 'TEMPERATURE', '2', '45.27', '45.27', '1', '2016-04-22 16:02:42');
INSERT INTO `iot_device_log` VALUES ('5313', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 16:02:42');
INSERT INTO `iot_device_log` VALUES ('5314', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-22 16:02:52');
INSERT INTO `iot_device_log` VALUES ('5315', '21', 'HUMIDITY', '2', '30.77', '30.77', '1', '2016-04-22 16:02:52');
INSERT INTO `iot_device_log` VALUES ('5316', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 16:03:02');
INSERT INTO `iot_device_log` VALUES ('5317', '21', 'HUMIDITY', '2', '30.82', '30.82', '1', '2016-04-22 16:03:02');
INSERT INTO `iot_device_log` VALUES ('5318', '21', 'TEMPERATURE', '2', '45.49', '45.49', '1', '2016-04-22 16:03:12');
INSERT INTO `iot_device_log` VALUES ('5319', '21', 'HUMIDITY', '2', '30.82', '30.82', '1', '2016-04-22 16:03:12');
INSERT INTO `iot_device_log` VALUES ('5320', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 16:03:22');
INSERT INTO `iot_device_log` VALUES ('5321', '21', 'HUMIDITY', '2', '30.82', '30.82', '1', '2016-04-22 16:03:22');
INSERT INTO `iot_device_log` VALUES ('5322', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 16:03:32');
INSERT INTO `iot_device_log` VALUES ('5323', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-22 16:03:32');
INSERT INTO `iot_device_log` VALUES ('5324', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 16:03:42');
INSERT INTO `iot_device_log` VALUES ('5325', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-22 16:03:42');
INSERT INTO `iot_device_log` VALUES ('5326', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-22 16:03:52');
INSERT INTO `iot_device_log` VALUES ('5327', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-22 16:03:52');
INSERT INTO `iot_device_log` VALUES ('5328', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:04:02');
INSERT INTO `iot_device_log` VALUES ('5329', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 16:04:02');
INSERT INTO `iot_device_log` VALUES ('5330', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 16:04:12');
INSERT INTO `iot_device_log` VALUES ('5331', '21', 'HUMIDITY', '2', '30.64', '30.64', '1', '2016-04-22 16:04:12');
INSERT INTO `iot_device_log` VALUES ('5332', '21', 'TEMPERATURE', '2', '45.66', '45.66', '1', '2016-04-22 16:04:22');
INSERT INTO `iot_device_log` VALUES ('5333', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 16:04:22');
INSERT INTO `iot_device_log` VALUES ('5334', '21', 'TEMPERATURE', '2', '45.77', '45.77', '1', '2016-04-22 16:04:32');
INSERT INTO `iot_device_log` VALUES ('5335', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-22 16:04:32');
INSERT INTO `iot_device_log` VALUES ('5336', '21', 'TEMPERATURE', '2', '45.76', '45.76', '1', '2016-04-22 16:04:42');
INSERT INTO `iot_device_log` VALUES ('5337', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 16:04:42');
INSERT INTO `iot_device_log` VALUES ('5338', '21', 'TEMPERATURE', '2', '45.87', '45.87', '1', '2016-04-22 16:04:52');
INSERT INTO `iot_device_log` VALUES ('5339', '21', 'HUMIDITY', '2', '30.55', '30.55', '1', '2016-04-22 16:04:52');
INSERT INTO `iot_device_log` VALUES ('5340', '21', 'TEMPERATURE', '2', '46.46', '46.46', '1', '2016-04-22 16:05:02');
INSERT INTO `iot_device_log` VALUES ('5341', '21', 'HUMIDITY', '2', '30.48', '30.48', '1', '2016-04-22 16:05:02');
INSERT INTO `iot_device_log` VALUES ('5342', '21', 'TEMPERATURE', '2', '45.96', '45.96', '1', '2016-04-22 16:05:12');
INSERT INTO `iot_device_log` VALUES ('5343', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 16:05:12');
INSERT INTO `iot_device_log` VALUES ('5344', '21', 'TEMPERATURE', '2', '45.98', '45.98', '1', '2016-04-22 16:05:22');
INSERT INTO `iot_device_log` VALUES ('5345', '21', 'HUMIDITY', '2', '30.48', '30.48', '1', '2016-04-22 16:05:22');
INSERT INTO `iot_device_log` VALUES ('5346', '21', 'TEMPERATURE', '2', '46', '46', '1', '2016-04-22 16:05:32');
INSERT INTO `iot_device_log` VALUES ('5347', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 16:05:32');
INSERT INTO `iot_device_log` VALUES ('5348', '21', 'TEMPERATURE', '2', '45.91', '45.91', '1', '2016-04-22 16:05:42');
INSERT INTO `iot_device_log` VALUES ('5349', '21', 'HUMIDITY', '2', '30.53', '30.53', '1', '2016-04-22 16:05:42');
INSERT INTO `iot_device_log` VALUES ('5350', '21', 'TEMPERATURE', '2', '45.91', '45.91', '1', '2016-04-22 16:05:53');
INSERT INTO `iot_device_log` VALUES ('5351', '21', 'HUMIDITY', '2', '30.53', '30.53', '1', '2016-04-22 16:05:53');
INSERT INTO `iot_device_log` VALUES ('5352', '21', 'TEMPERATURE', '2', '45.93', '45.93', '1', '2016-04-22 16:06:02');
INSERT INTO `iot_device_log` VALUES ('5353', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 16:06:02');
INSERT INTO `iot_device_log` VALUES ('5354', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-22 16:06:12');
INSERT INTO `iot_device_log` VALUES ('5355', '21', 'HUMIDITY', '2', '30.53', '30.53', '1', '2016-04-22 16:06:12');
INSERT INTO `iot_device_log` VALUES ('5356', '21', 'TEMPERATURE', '2', '45.66', '45.66', '1', '2016-04-22 16:06:22');
INSERT INTO `iot_device_log` VALUES ('5357', '21', 'HUMIDITY', '2', '30.6', '30.6', '1', '2016-04-22 16:06:22');
INSERT INTO `iot_device_log` VALUES ('5358', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-22 16:06:32');
INSERT INTO `iot_device_log` VALUES ('5359', '21', 'HUMIDITY', '2', '30.63', '30.63', '1', '2016-04-22 16:06:32');
INSERT INTO `iot_device_log` VALUES ('5360', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:06:42');
INSERT INTO `iot_device_log` VALUES ('5361', '21', 'HUMIDITY', '2', '30.67', '30.67', '1', '2016-04-22 16:06:42');
INSERT INTO `iot_device_log` VALUES ('5362', '21', 'TEMPERATURE', '2', '45.7', '45.7', '1', '2016-04-22 16:06:52');
INSERT INTO `iot_device_log` VALUES ('5363', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-22 16:06:52');
INSERT INTO `iot_device_log` VALUES ('5364', '21', 'TEMPERATURE', '2', '45.87', '45.87', '1', '2016-04-22 16:07:02');
INSERT INTO `iot_device_log` VALUES ('5365', '21', 'HUMIDITY', '2', '30.56', '30.56', '1', '2016-04-22 16:07:02');
INSERT INTO `iot_device_log` VALUES ('5366', '21', 'TEMPERATURE', '2', '45.93', '45.93', '1', '2016-04-22 16:07:12');
INSERT INTO `iot_device_log` VALUES ('5367', '21', 'HUMIDITY', '2', '30.55', '30.55', '1', '2016-04-22 16:07:12');
INSERT INTO `iot_device_log` VALUES ('5368', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 16:07:22');
INSERT INTO `iot_device_log` VALUES ('5369', '21', 'HUMIDITY', '2', '30.58', '30.58', '1', '2016-04-22 16:07:22');
INSERT INTO `iot_device_log` VALUES ('5370', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:07:32');
INSERT INTO `iot_device_log` VALUES ('5371', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-22 16:07:32');
INSERT INTO `iot_device_log` VALUES ('5372', '21', 'TEMPERATURE', '2', '45.69', '45.69', '1', '2016-04-22 16:07:42');
INSERT INTO `iot_device_log` VALUES ('5373', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 16:07:42');
INSERT INTO `iot_device_log` VALUES ('5374', '21', 'TEMPERATURE', '2', '45.74', '45.74', '1', '2016-04-22 16:07:52');
INSERT INTO `iot_device_log` VALUES ('5375', '21', 'HUMIDITY', '2', '30.59', '30.59', '1', '2016-04-22 16:07:52');
INSERT INTO `iot_device_log` VALUES ('5376', '21', 'TEMPERATURE', '2', '45.93', '45.93', '1', '2016-04-22 16:08:03');
INSERT INTO `iot_device_log` VALUES ('5377', '21', 'HUMIDITY', '2', '30.5', '30.5', '1', '2016-04-22 16:08:03');
INSERT INTO `iot_device_log` VALUES ('5378', '21', 'TEMPERATURE', '2', '46.27', '46.27', '1', '2016-04-22 16:08:13');
INSERT INTO `iot_device_log` VALUES ('5379', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 16:08:13');
INSERT INTO `iot_device_log` VALUES ('5380', '21', 'TEMPERATURE', '2', '46.12', '46.12', '1', '2016-04-22 16:08:22');
INSERT INTO `iot_device_log` VALUES ('5381', '21', 'HUMIDITY', '2', '30.56', '30.56', '1', '2016-04-22 16:08:22');
INSERT INTO `iot_device_log` VALUES ('5382', '21', 'TEMPERATURE', '2', '46.19', '46.19', '1', '2016-04-22 16:08:32');
INSERT INTO `iot_device_log` VALUES ('5383', '21', 'HUMIDITY', '2', '30.62', '30.62', '1', '2016-04-22 16:08:32');
INSERT INTO `iot_device_log` VALUES ('5384', '21', 'TEMPERATURE', '2', '46.09', '46.09', '1', '2016-04-22 16:08:42');
INSERT INTO `iot_device_log` VALUES ('5385', '21', 'HUMIDITY', '2', '30.7', '30.7', '1', '2016-04-22 16:08:42');
INSERT INTO `iot_device_log` VALUES ('5386', '21', 'TEMPERATURE', '2', '46.02', '46.02', '1', '2016-04-22 16:08:52');
INSERT INTO `iot_device_log` VALUES ('5387', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 16:08:52');
INSERT INTO `iot_device_log` VALUES ('5388', '21', 'TEMPERATURE', '2', '45.9', '45.9', '1', '2016-04-22 16:09:02');
INSERT INTO `iot_device_log` VALUES ('5389', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 16:09:02');
INSERT INTO `iot_device_log` VALUES ('5390', '21', 'TEMPERATURE', '2', '45.73', '45.73', '1', '2016-04-22 16:09:12');
INSERT INTO `iot_device_log` VALUES ('5391', '21', 'HUMIDITY', '2', '30.93', '30.93', '1', '2016-04-22 16:09:12');
INSERT INTO `iot_device_log` VALUES ('5392', '21', 'TEMPERATURE', '2', '45.67', '45.67', '1', '2016-04-22 16:09:22');
INSERT INTO `iot_device_log` VALUES ('5393', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:09:22');
INSERT INTO `iot_device_log` VALUES ('5394', '21', 'TEMPERATURE', '2', '45.41', '45.41', '1', '2016-04-22 16:09:32');
INSERT INTO `iot_device_log` VALUES ('5395', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 16:09:32');
INSERT INTO `iot_device_log` VALUES ('5396', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:09:43');
INSERT INTO `iot_device_log` VALUES ('5397', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 16:09:43');
INSERT INTO `iot_device_log` VALUES ('5398', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 16:09:52');
INSERT INTO `iot_device_log` VALUES ('5399', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:09:52');
INSERT INTO `iot_device_log` VALUES ('5400', '21', 'TEMPERATURE', '2', '45.6', '45.6', '1', '2016-04-22 16:10:02');
INSERT INTO `iot_device_log` VALUES ('5401', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 16:10:02');
INSERT INTO `iot_device_log` VALUES ('5402', '21', 'TEMPERATURE', '2', '45.43', '45.43', '1', '2016-04-22 16:10:12');
INSERT INTO `iot_device_log` VALUES ('5403', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 16:10:12');
INSERT INTO `iot_device_log` VALUES ('5404', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:10:22');
INSERT INTO `iot_device_log` VALUES ('5405', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 16:10:22');
INSERT INTO `iot_device_log` VALUES ('5406', '21', 'TEMPERATURE', '2', '45.28', '45.28', '1', '2016-04-22 16:10:32');
INSERT INTO `iot_device_log` VALUES ('5407', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:10:32');
INSERT INTO `iot_device_log` VALUES ('5408', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-22 16:10:42');
INSERT INTO `iot_device_log` VALUES ('5409', '21', 'HUMIDITY', '2', '31.03', '31.03', '1', '2016-04-22 16:10:42');
INSERT INTO `iot_device_log` VALUES ('5410', '21', 'TEMPERATURE', '2', '45.77', '45.77', '1', '2016-04-22 16:10:52');
INSERT INTO `iot_device_log` VALUES ('5411', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:10:52');
INSERT INTO `iot_device_log` VALUES ('5412', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:11:02');
INSERT INTO `iot_device_log` VALUES ('5413', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-22 16:11:02');
INSERT INTO `iot_device_log` VALUES ('5414', '21', 'TEMPERATURE', '2', '45.45', '45.45', '1', '2016-04-22 16:11:12');
INSERT INTO `iot_device_log` VALUES ('5415', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:11:12');
INSERT INTO `iot_device_log` VALUES ('5416', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 16:11:22');
INSERT INTO `iot_device_log` VALUES ('5417', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:11:22');
INSERT INTO `iot_device_log` VALUES ('5418', '21', 'TEMPERATURE', '2', '45.26', '45.26', '1', '2016-04-22 16:11:32');
INSERT INTO `iot_device_log` VALUES ('5419', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 16:11:32');
INSERT INTO `iot_device_log` VALUES ('5420', '21', 'TEMPERATURE', '2', '45.15', '45.15', '1', '2016-04-22 16:11:42');
INSERT INTO `iot_device_log` VALUES ('5421', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 16:11:42');
INSERT INTO `iot_device_log` VALUES ('5422', '21', 'TEMPERATURE', '2', '45.06', '45.06', '1', '2016-04-22 16:11:52');
INSERT INTO `iot_device_log` VALUES ('5423', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:11:52');
INSERT INTO `iot_device_log` VALUES ('5424', '21', 'TEMPERATURE', '2', '45.75', '45.75', '1', '2016-04-22 16:12:03');
INSERT INTO `iot_device_log` VALUES ('5425', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-22 16:12:03');
INSERT INTO `iot_device_log` VALUES ('5426', '21', 'TEMPERATURE', '2', '45.57', '45.57', '1', '2016-04-22 16:12:12');
INSERT INTO `iot_device_log` VALUES ('5427', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 16:12:12');
INSERT INTO `iot_device_log` VALUES ('5428', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 16:12:22');
INSERT INTO `iot_device_log` VALUES ('5429', '21', 'HUMIDITY', '2', '30.95', '30.95', '1', '2016-04-22 16:12:22');
INSERT INTO `iot_device_log` VALUES ('5430', '21', 'TEMPERATURE', '2', '45.47', '45.47', '1', '2016-04-22 16:12:32');
INSERT INTO `iot_device_log` VALUES ('5431', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 16:12:32');
INSERT INTO `iot_device_log` VALUES ('5432', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 16:12:42');
INSERT INTO `iot_device_log` VALUES ('5433', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 16:12:42');
INSERT INTO `iot_device_log` VALUES ('5434', '21', 'TEMPERATURE', '2', '45.6', '45.6', '1', '2016-04-22 16:12:52');
INSERT INTO `iot_device_log` VALUES ('5435', '21', 'HUMIDITY', '2', '30.86', '30.86', '1', '2016-04-22 16:12:52');
INSERT INTO `iot_device_log` VALUES ('5436', '21', 'TEMPERATURE', '2', '45.29', '45.29', '1', '2016-04-22 16:13:02');
INSERT INTO `iot_device_log` VALUES ('5437', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-22 16:13:02');
INSERT INTO `iot_device_log` VALUES ('5438', '21', 'TEMPERATURE', '2', '45.38', '45.38', '1', '2016-04-22 16:13:12');
INSERT INTO `iot_device_log` VALUES ('5439', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:13:12');
INSERT INTO `iot_device_log` VALUES ('5440', '21', 'TEMPERATURE', '2', '46.38', '46.38', '1', '2016-04-22 16:13:22');
INSERT INTO `iot_device_log` VALUES ('5441', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:13:22');
INSERT INTO `iot_device_log` VALUES ('5442', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 16:13:32');
INSERT INTO `iot_device_log` VALUES ('5443', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-22 16:13:32');
INSERT INTO `iot_device_log` VALUES ('5444', '21', 'TEMPERATURE', '2', '44.95', '44.95', '1', '2016-04-22 16:13:42');
INSERT INTO `iot_device_log` VALUES ('5445', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 16:13:42');
INSERT INTO `iot_device_log` VALUES ('5446', '21', 'TEMPERATURE', '2', '44.98', '44.98', '1', '2016-04-22 16:13:52');
INSERT INTO `iot_device_log` VALUES ('5447', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-22 16:13:52');
INSERT INTO `iot_device_log` VALUES ('5448', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-22 16:14:02');
INSERT INTO `iot_device_log` VALUES ('5449', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 16:14:02');
INSERT INTO `iot_device_log` VALUES ('5450', '21', 'TEMPERATURE', '2', '44.63', '44.63', '1', '2016-04-22 16:14:12');
INSERT INTO `iot_device_log` VALUES ('5451', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-22 16:14:12');
INSERT INTO `iot_device_log` VALUES ('5452', '21', 'TEMPERATURE', '2', '44.74', '44.74', '1', '2016-04-22 16:14:22');
INSERT INTO `iot_device_log` VALUES ('5453', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 16:14:22');
INSERT INTO `iot_device_log` VALUES ('5454', '21', 'TEMPERATURE', '2', '44.64', '44.64', '1', '2016-04-22 16:14:32');
INSERT INTO `iot_device_log` VALUES ('5455', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-22 16:14:32');
INSERT INTO `iot_device_log` VALUES ('5456', '21', 'TEMPERATURE', '2', '44.48', '44.48', '1', '2016-04-22 16:14:42');
INSERT INTO `iot_device_log` VALUES ('5457', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-22 16:14:42');
INSERT INTO `iot_device_log` VALUES ('5458', '21', 'TEMPERATURE', '2', '44.16', '44.16', '1', '2016-04-22 16:14:53');
INSERT INTO `iot_device_log` VALUES ('5459', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-22 16:14:53');
INSERT INTO `iot_device_log` VALUES ('5460', '21', 'TEMPERATURE', '2', '44', '44', '1', '2016-04-22 16:15:02');
INSERT INTO `iot_device_log` VALUES ('5461', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 16:15:02');
INSERT INTO `iot_device_log` VALUES ('5462', '21', 'TEMPERATURE', '2', '43.97', '43.97', '1', '2016-04-22 16:15:12');
INSERT INTO `iot_device_log` VALUES ('5463', '21', 'HUMIDITY', '2', '31.65', '31.65', '1', '2016-04-22 16:15:12');
INSERT INTO `iot_device_log` VALUES ('5464', '21', 'TEMPERATURE', '2', '43.88', '43.88', '1', '2016-04-22 16:15:22');
INSERT INTO `iot_device_log` VALUES ('5465', '21', 'HUMIDITY', '2', '31.56', '31.56', '1', '2016-04-22 16:15:22');
INSERT INTO `iot_device_log` VALUES ('5466', '21', 'TEMPERATURE', '2', '44.09', '44.09', '1', '2016-04-22 16:15:32');
INSERT INTO `iot_device_log` VALUES ('5467', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-22 16:15:32');
INSERT INTO `iot_device_log` VALUES ('5468', '21', 'TEMPERATURE', '2', '44.11', '44.11', '1', '2016-04-22 16:15:42');
INSERT INTO `iot_device_log` VALUES ('5469', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-22 16:15:42');
INSERT INTO `iot_device_log` VALUES ('5470', '21', 'TEMPERATURE', '2', '44.23', '44.23', '1', '2016-04-22 16:15:52');
INSERT INTO `iot_device_log` VALUES ('5471', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-22 16:15:52');
INSERT INTO `iot_device_log` VALUES ('5472', '21', 'TEMPERATURE', '2', '44.6', '44.6', '1', '2016-04-22 16:16:02');
INSERT INTO `iot_device_log` VALUES ('5473', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-22 16:16:02');
INSERT INTO `iot_device_log` VALUES ('5474', '21', 'TEMPERATURE', '2', '44.81', '44.81', '1', '2016-04-22 16:16:12');
INSERT INTO `iot_device_log` VALUES ('5475', '21', 'HUMIDITY', '2', '31.07', '31.07', '1', '2016-04-22 16:16:12');
INSERT INTO `iot_device_log` VALUES ('5476', '21', 'TEMPERATURE', '2', '44.87', '44.87', '1', '2016-04-22 16:16:22');
INSERT INTO `iot_device_log` VALUES ('5477', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:16:22');
INSERT INTO `iot_device_log` VALUES ('5478', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-22 16:16:32');
INSERT INTO `iot_device_log` VALUES ('5479', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-22 16:16:32');
INSERT INTO `iot_device_log` VALUES ('5480', '21', 'TEMPERATURE', '2', '44.9', '44.9', '1', '2016-04-22 16:16:42');
INSERT INTO `iot_device_log` VALUES ('5481', '21', 'HUMIDITY', '2', '30.95', '30.95', '1', '2016-04-22 16:16:42');
INSERT INTO `iot_device_log` VALUES ('5482', '21', 'TEMPERATURE', '2', '44.87', '44.87', '1', '2016-04-22 16:16:52');
INSERT INTO `iot_device_log` VALUES ('5483', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 16:16:52');
INSERT INTO `iot_device_log` VALUES ('5484', '21', 'TEMPERATURE', '2', '44.85', '44.85', '1', '2016-04-22 16:17:02');
INSERT INTO `iot_device_log` VALUES ('5485', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 16:17:02');
INSERT INTO `iot_device_log` VALUES ('5486', '21', 'TEMPERATURE', '2', '44.89', '44.89', '1', '2016-04-22 16:17:12');
INSERT INTO `iot_device_log` VALUES ('5487', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:17:12');
INSERT INTO `iot_device_log` VALUES ('5488', '21', 'TEMPERATURE', '2', '45.05', '45.05', '1', '2016-04-22 16:17:23');
INSERT INTO `iot_device_log` VALUES ('5489', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-22 16:17:23');
INSERT INTO `iot_device_log` VALUES ('5490', '21', 'TEMPERATURE', '2', '45.1', '45.1', '1', '2016-04-22 16:17:32');
INSERT INTO `iot_device_log` VALUES ('5491', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-22 16:17:32');
INSERT INTO `iot_device_log` VALUES ('5492', '21', 'TEMPERATURE', '2', '45.02', '45.02', '1', '2016-04-22 16:17:42');
INSERT INTO `iot_device_log` VALUES ('5493', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-22 16:17:42');
INSERT INTO `iot_device_log` VALUES ('5494', '21', 'TEMPERATURE', '2', '45', '45', '1', '2016-04-22 16:17:52');
INSERT INTO `iot_device_log` VALUES ('5495', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 16:17:52');
INSERT INTO `iot_device_log` VALUES ('5496', '21', 'TEMPERATURE', '2', '45', '45', '1', '2016-04-22 16:18:02');
INSERT INTO `iot_device_log` VALUES ('5497', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:18:02');
INSERT INTO `iot_device_log` VALUES ('5498', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-22 16:18:12');
INSERT INTO `iot_device_log` VALUES ('5499', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-22 16:18:12');
INSERT INTO `iot_device_log` VALUES ('5500', '21', 'TEMPERATURE', '2', '45', '45', '1', '2016-04-22 16:18:22');
INSERT INTO `iot_device_log` VALUES ('5501', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:18:22');
INSERT INTO `iot_device_log` VALUES ('5502', '21', 'TEMPERATURE', '2', '45.09', '45.09', '1', '2016-04-22 16:18:32');
INSERT INTO `iot_device_log` VALUES ('5503', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-22 16:18:32');
INSERT INTO `iot_device_log` VALUES ('5504', '21', 'TEMPERATURE', '2', '44.95', '44.95', '1', '2016-04-22 16:18:42');
INSERT INTO `iot_device_log` VALUES ('5505', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 16:18:42');
INSERT INTO `iot_device_log` VALUES ('5506', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-22 16:18:52');
INSERT INTO `iot_device_log` VALUES ('5507', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 16:18:52');
INSERT INTO `iot_device_log` VALUES ('5508', '21', 'TEMPERATURE', '2', '44.55', '44.55', '1', '2016-04-22 16:19:02');
INSERT INTO `iot_device_log` VALUES ('5509', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-22 16:19:02');
INSERT INTO `iot_device_log` VALUES ('5510', '21', 'TEMPERATURE', '2', '44.74', '44.74', '1', '2016-04-22 16:19:12');
INSERT INTO `iot_device_log` VALUES ('5511', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-22 16:19:12');
INSERT INTO `iot_device_log` VALUES ('5512', '21', 'TEMPERATURE', '2', '44.56', '44.56', '1', '2016-04-22 16:19:22');
INSERT INTO `iot_device_log` VALUES ('5513', '21', 'HUMIDITY', '2', '31.51', '31.51', '1', '2016-04-22 16:19:22');
INSERT INTO `iot_device_log` VALUES ('5514', '21', 'TEMPERATURE', '2', '44.28', '44.28', '1', '2016-04-22 16:19:32');
INSERT INTO `iot_device_log` VALUES ('5515', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-22 16:19:32');
INSERT INTO `iot_device_log` VALUES ('5516', '21', 'TEMPERATURE', '2', '44.32', '44.32', '1', '2016-04-22 16:19:42');
INSERT INTO `iot_device_log` VALUES ('5517', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-22 16:19:42');
INSERT INTO `iot_device_log` VALUES ('5518', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-22 16:19:52');
INSERT INTO `iot_device_log` VALUES ('5519', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-22 16:19:52');
INSERT INTO `iot_device_log` VALUES ('5520', '21', 'TEMPERATURE', '2', '44.54', '44.54', '1', '2016-04-22 16:20:02');
INSERT INTO `iot_device_log` VALUES ('5521', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 16:20:02');
INSERT INTO `iot_device_log` VALUES ('5522', '21', 'TEMPERATURE', '2', '44.75', '44.75', '1', '2016-04-22 16:20:12');
INSERT INTO `iot_device_log` VALUES ('5523', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 16:20:12');
INSERT INTO `iot_device_log` VALUES ('5524', '21', 'TEMPERATURE', '2', '44.96', '44.96', '1', '2016-04-22 16:20:22');
INSERT INTO `iot_device_log` VALUES ('5525', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:20:22');
INSERT INTO `iot_device_log` VALUES ('5526', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-22 16:20:32');
INSERT INTO `iot_device_log` VALUES ('5527', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:20:32');
INSERT INTO `iot_device_log` VALUES ('5528', '21', 'TEMPERATURE', '2', '44.83', '44.83', '1', '2016-04-22 16:20:42');
INSERT INTO `iot_device_log` VALUES ('5529', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-22 16:20:42');
INSERT INTO `iot_device_log` VALUES ('5530', '21', 'TEMPERATURE', '2', '44.71', '44.71', '1', '2016-04-22 16:20:52');
INSERT INTO `iot_device_log` VALUES ('5531', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 16:20:52');
INSERT INTO `iot_device_log` VALUES ('5532', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-22 16:21:03');
INSERT INTO `iot_device_log` VALUES ('5533', '21', 'HUMIDITY', '2', '31.12', '31.12', '1', '2016-04-22 16:21:03');
INSERT INTO `iot_device_log` VALUES ('5534', '21', 'TEMPERATURE', '2', '44.63', '44.63', '1', '2016-04-22 16:21:13');
INSERT INTO `iot_device_log` VALUES ('5535', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 16:21:13');
INSERT INTO `iot_device_log` VALUES ('5536', '21', 'TEMPERATURE', '2', '44.64', '44.64', '1', '2016-04-22 16:21:22');
INSERT INTO `iot_device_log` VALUES ('5537', '21', 'HUMIDITY', '2', '31.03', '31.03', '1', '2016-04-22 16:21:22');
INSERT INTO `iot_device_log` VALUES ('5538', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-22 16:21:32');
INSERT INTO `iot_device_log` VALUES ('5539', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 16:21:32');
INSERT INTO `iot_device_log` VALUES ('5540', '21', 'TEMPERATURE', '2', '44.65', '44.65', '1', '2016-04-22 16:21:42');
INSERT INTO `iot_device_log` VALUES ('5541', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-22 16:21:42');
INSERT INTO `iot_device_log` VALUES ('5542', '21', 'TEMPERATURE', '2', '44.66', '44.66', '1', '2016-04-22 16:21:52');
INSERT INTO `iot_device_log` VALUES ('5543', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 16:21:52');
INSERT INTO `iot_device_log` VALUES ('5544', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-22 16:22:02');
INSERT INTO `iot_device_log` VALUES ('5545', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-22 16:22:02');
INSERT INTO `iot_device_log` VALUES ('5546', '21', 'TEMPERATURE', '2', '44.72', '44.72', '1', '2016-04-22 16:22:12');
INSERT INTO `iot_device_log` VALUES ('5547', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-22 16:22:12');
INSERT INTO `iot_device_log` VALUES ('5548', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-22 16:22:22');
INSERT INTO `iot_device_log` VALUES ('5549', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 16:22:22');
INSERT INTO `iot_device_log` VALUES ('5550', '21', 'TEMPERATURE', '2', '44.81', '44.81', '1', '2016-04-22 16:22:32');
INSERT INTO `iot_device_log` VALUES ('5551', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 16:22:32');
INSERT INTO `iot_device_log` VALUES ('5552', '21', 'TEMPERATURE', '2', '44.84', '44.84', '1', '2016-04-22 16:22:42');
INSERT INTO `iot_device_log` VALUES ('5553', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:22:42');
INSERT INTO `iot_device_log` VALUES ('5554', '21', 'TEMPERATURE', '2', '44.77', '44.77', '1', '2016-04-22 16:22:52');
INSERT INTO `iot_device_log` VALUES ('5555', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:22:52');
INSERT INTO `iot_device_log` VALUES ('5556', '21', 'TEMPERATURE', '2', '45.01', '45.01', '1', '2016-04-22 16:23:02');
INSERT INTO `iot_device_log` VALUES ('5557', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-22 16:23:02');
INSERT INTO `iot_device_log` VALUES ('5558', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 16:23:12');
INSERT INTO `iot_device_log` VALUES ('5559', '21', 'HUMIDITY', '2', '30.77', '30.77', '1', '2016-04-22 16:23:12');
INSERT INTO `iot_device_log` VALUES ('5560', '21', 'TEMPERATURE', '2', '45.32', '45.32', '1', '2016-04-22 16:23:22');
INSERT INTO `iot_device_log` VALUES ('5561', '21', 'HUMIDITY', '2', '30.82', '30.82', '1', '2016-04-22 16:23:22');
INSERT INTO `iot_device_log` VALUES ('5562', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 16:23:32');
INSERT INTO `iot_device_log` VALUES ('5563', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:23:32');
INSERT INTO `iot_device_log` VALUES ('5564', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 16:23:42');
INSERT INTO `iot_device_log` VALUES ('5565', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:23:42');
INSERT INTO `iot_device_log` VALUES ('5566', '21', 'TEMPERATURE', '2', '45.29', '45.29', '1', '2016-04-22 16:23:52');
INSERT INTO `iot_device_log` VALUES ('5567', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 16:23:52');
INSERT INTO `iot_device_log` VALUES ('5568', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 16:24:02');
INSERT INTO `iot_device_log` VALUES ('5569', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 16:24:02');
INSERT INTO `iot_device_log` VALUES ('5570', '21', 'TEMPERATURE', '2', '45.45', '45.45', '1', '2016-04-22 16:24:12');
INSERT INTO `iot_device_log` VALUES ('5571', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 16:24:12');
INSERT INTO `iot_device_log` VALUES ('5572', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-22 16:24:23');
INSERT INTO `iot_device_log` VALUES ('5573', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 16:24:23');
INSERT INTO `iot_device_log` VALUES ('5574', '21', 'TEMPERATURE', '2', '45.67', '45.67', '1', '2016-04-22 16:24:32');
INSERT INTO `iot_device_log` VALUES ('5575', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:24:32');
INSERT INTO `iot_device_log` VALUES ('5576', '21', 'TEMPERATURE', '2', '45.19', '45.19', '1', '2016-04-22 16:24:42');
INSERT INTO `iot_device_log` VALUES ('5577', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 16:24:42');
INSERT INTO `iot_device_log` VALUES ('5578', '21', 'TEMPERATURE', '2', '45.19', '45.19', '1', '2016-04-22 16:24:52');
INSERT INTO `iot_device_log` VALUES ('5579', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 16:24:52');
INSERT INTO `iot_device_log` VALUES ('5580', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 16:25:02');
INSERT INTO `iot_device_log` VALUES ('5581', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:25:02');
INSERT INTO `iot_device_log` VALUES ('5582', '21', 'TEMPERATURE', '2', '45.24', '45.24', '1', '2016-04-22 16:25:12');
INSERT INTO `iot_device_log` VALUES ('5583', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 16:25:12');
INSERT INTO `iot_device_log` VALUES ('5584', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 16:25:22');
INSERT INTO `iot_device_log` VALUES ('5585', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 16:25:22');
INSERT INTO `iot_device_log` VALUES ('5586', '21', 'TEMPERATURE', '2', '45.41', '45.41', '1', '2016-04-22 16:25:32');
INSERT INTO `iot_device_log` VALUES ('5587', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 16:25:32');
INSERT INTO `iot_device_log` VALUES ('5588', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 16:25:42');
INSERT INTO `iot_device_log` VALUES ('5589', '21', 'HUMIDITY', '2', '31.12', '31.12', '1', '2016-04-22 16:25:42');
INSERT INTO `iot_device_log` VALUES ('5590', '21', 'TEMPERATURE', '2', '45.15', '45.15', '1', '2016-04-22 16:25:52');
INSERT INTO `iot_device_log` VALUES ('5591', '21', 'HUMIDITY', '2', '31.03', '31.03', '1', '2016-04-22 16:25:52');
INSERT INTO `iot_device_log` VALUES ('5592', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 16:26:02');
INSERT INTO `iot_device_log` VALUES ('5593', '21', 'HUMIDITY', '2', '30.95', '30.95', '1', '2016-04-22 16:26:02');
INSERT INTO `iot_device_log` VALUES ('5594', '21', 'TEMPERATURE', '2', '45.28', '45.28', '1', '2016-04-22 16:26:12');
INSERT INTO `iot_device_log` VALUES ('5595', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:26:12');
INSERT INTO `iot_device_log` VALUES ('5596', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 16:26:22');
INSERT INTO `iot_device_log` VALUES ('5597', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 16:26:22');
INSERT INTO `iot_device_log` VALUES ('5598', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 16:26:32');
INSERT INTO `iot_device_log` VALUES ('5599', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:26:32');
INSERT INTO `iot_device_log` VALUES ('5600', '21', 'TEMPERATURE', '2', '45.56', '45.56', '1', '2016-04-22 16:26:42');
INSERT INTO `iot_device_log` VALUES ('5601', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-22 16:26:42');
INSERT INTO `iot_device_log` VALUES ('5602', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-22 16:26:52');
INSERT INTO `iot_device_log` VALUES ('5603', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 16:26:52');
INSERT INTO `iot_device_log` VALUES ('5604', '21', 'TEMPERATURE', '2', '44.79', '44.79', '1', '2016-04-22 16:27:02');
INSERT INTO `iot_device_log` VALUES ('5605', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-22 16:27:02');
INSERT INTO `iot_device_log` VALUES ('5606', '21', 'TEMPERATURE', '2', '44.85', '44.85', '1', '2016-04-22 16:27:12');
INSERT INTO `iot_device_log` VALUES ('5607', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 16:27:12');
INSERT INTO `iot_device_log` VALUES ('5608', '21', 'TEMPERATURE', '2', '44.8', '44.8', '1', '2016-04-22 16:27:22');
INSERT INTO `iot_device_log` VALUES ('5609', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-22 16:27:22');
INSERT INTO `iot_device_log` VALUES ('5610', '21', 'TEMPERATURE', '2', '45.32', '45.32', '1', '2016-04-22 16:27:32');
INSERT INTO `iot_device_log` VALUES ('5611', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 16:27:32');
INSERT INTO `iot_device_log` VALUES ('5612', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 16:27:42');
INSERT INTO `iot_device_log` VALUES ('5613', '21', 'HUMIDITY', '2', '30.99', '30.99', '1', '2016-04-22 16:27:42');
INSERT INTO `iot_device_log` VALUES ('5614', '21', 'TEMPERATURE', '2', '45.21', '45.21', '1', '2016-04-22 16:27:52');
INSERT INTO `iot_device_log` VALUES ('5615', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 16:27:52');
INSERT INTO `iot_device_log` VALUES ('5616', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 16:28:02');
INSERT INTO `iot_device_log` VALUES ('5617', '21', 'HUMIDITY', '2', '31.12', '31.12', '1', '2016-04-22 16:28:02');
INSERT INTO `iot_device_log` VALUES ('5618', '21', 'TEMPERATURE', '2', '45.24', '45.24', '1', '2016-04-22 16:28:12');
INSERT INTO `iot_device_log` VALUES ('5619', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:28:12');
INSERT INTO `iot_device_log` VALUES ('5620', '21', 'TEMPERATURE', '2', '45.48', '45.48', '1', '2016-04-22 16:28:22');
INSERT INTO `iot_device_log` VALUES ('5621', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 16:28:22');
INSERT INTO `iot_device_log` VALUES ('5622', '21', 'TEMPERATURE', '2', '45.24', '45.24', '1', '2016-04-22 16:28:32');
INSERT INTO `iot_device_log` VALUES ('5623', '21', 'HUMIDITY', '2', '30.96', '30.96', '1', '2016-04-22 16:28:32');
INSERT INTO `iot_device_log` VALUES ('5624', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 16:28:43');
INSERT INTO `iot_device_log` VALUES ('5625', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-22 16:28:43');
INSERT INTO `iot_device_log` VALUES ('5626', '21', 'TEMPERATURE', '2', '45.49', '45.49', '1', '2016-04-22 16:28:53');
INSERT INTO `iot_device_log` VALUES ('5627', '21', 'HUMIDITY', '2', '30.81', '30.81', '1', '2016-04-22 16:28:53');
INSERT INTO `iot_device_log` VALUES ('5628', '21', 'TEMPERATURE', '2', '45.38', '45.38', '1', '2016-04-22 16:29:03');
INSERT INTO `iot_device_log` VALUES ('5629', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-22 16:29:03');
INSERT INTO `iot_device_log` VALUES ('5630', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 16:29:13');
INSERT INTO `iot_device_log` VALUES ('5631', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-22 16:29:13');
INSERT INTO `iot_device_log` VALUES ('5632', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:29:22');
INSERT INTO `iot_device_log` VALUES ('5633', '21', 'HUMIDITY', '2', '30.74', '30.74', '1', '2016-04-22 16:29:22');
INSERT INTO `iot_device_log` VALUES ('5634', '21', 'TEMPERATURE', '2', '45.7', '45.7', '1', '2016-04-22 16:29:32');
INSERT INTO `iot_device_log` VALUES ('5635', '21', 'HUMIDITY', '2', '30.75', '30.75', '1', '2016-04-22 16:29:32');
INSERT INTO `iot_device_log` VALUES ('5636', '21', 'TEMPERATURE', '2', '45.42', '45.42', '1', '2016-04-22 16:29:42');
INSERT INTO `iot_device_log` VALUES ('5637', '21', 'HUMIDITY', '2', '30.88', '30.88', '1', '2016-04-22 16:29:42');
INSERT INTO `iot_device_log` VALUES ('5638', '21', 'TEMPERATURE', '2', '45.37', '45.37', '1', '2016-04-22 16:29:52');
INSERT INTO `iot_device_log` VALUES ('5639', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:29:52');
INSERT INTO `iot_device_log` VALUES ('5640', '21', 'TEMPERATURE', '2', '45.98', '45.98', '1', '2016-04-22 16:30:02');
INSERT INTO `iot_device_log` VALUES ('5641', '21', 'HUMIDITY', '2', '31.04', '31.04', '1', '2016-04-22 16:30:02');
INSERT INTO `iot_device_log` VALUES ('5642', '21', 'TEMPERATURE', '2', '45.4', '45.4', '1', '2016-04-22 16:30:12');
INSERT INTO `iot_device_log` VALUES ('5643', '21', 'HUMIDITY', '2', '31.17', '31.17', '1', '2016-04-22 16:30:12');
INSERT INTO `iot_device_log` VALUES ('5644', '21', 'TEMPERATURE', '2', '44.8', '44.8', '1', '2016-04-22 16:30:22');
INSERT INTO `iot_device_log` VALUES ('5645', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-22 16:30:22');
INSERT INTO `iot_device_log` VALUES ('5646', '21', 'TEMPERATURE', '2', '44.44', '44.44', '1', '2016-04-22 16:30:32');
INSERT INTO `iot_device_log` VALUES ('5647', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 16:30:32');
INSERT INTO `iot_device_log` VALUES ('5648', '21', 'TEMPERATURE', '2', '44.51', '44.51', '1', '2016-04-22 16:30:42');
INSERT INTO `iot_device_log` VALUES ('5649', '21', 'HUMIDITY', '2', '31.56', '31.56', '1', '2016-04-22 16:30:42');
INSERT INTO `iot_device_log` VALUES ('5650', '21', 'TEMPERATURE', '2', '44.33', '44.33', '1', '2016-04-22 16:30:52');
INSERT INTO `iot_device_log` VALUES ('5651', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 16:30:52');
INSERT INTO `iot_device_log` VALUES ('5652', '21', 'TEMPERATURE', '2', '44.16', '44.16', '1', '2016-04-22 16:31:02');
INSERT INTO `iot_device_log` VALUES ('5653', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 16:31:02');
INSERT INTO `iot_device_log` VALUES ('5654', '21', 'TEMPERATURE', '2', '44.09', '44.09', '1', '2016-04-22 16:31:12');
INSERT INTO `iot_device_log` VALUES ('5655', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-22 16:31:12');
INSERT INTO `iot_device_log` VALUES ('5656', '21', 'TEMPERATURE', '2', '44.23', '44.23', '1', '2016-04-22 16:31:22');
INSERT INTO `iot_device_log` VALUES ('5657', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 16:31:22');
INSERT INTO `iot_device_log` VALUES ('5658', '21', 'TEMPERATURE', '2', '44.19', '44.19', '1', '2016-04-22 16:31:32');
INSERT INTO `iot_device_log` VALUES ('5659', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 16:31:32');
INSERT INTO `iot_device_log` VALUES ('5660', '21', 'TEMPERATURE', '2', '44.58', '44.58', '1', '2016-04-22 16:31:42');
INSERT INTO `iot_device_log` VALUES ('5661', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-22 16:31:42');
INSERT INTO `iot_device_log` VALUES ('5662', '21', 'TEMPERATURE', '2', '44.38', '44.38', '1', '2016-04-22 16:31:52');
INSERT INTO `iot_device_log` VALUES ('5663', '21', 'HUMIDITY', '2', '31.47', '31.47', '1', '2016-04-22 16:31:52');
INSERT INTO `iot_device_log` VALUES ('5664', '21', 'TEMPERATURE', '2', '44.32', '44.32', '1', '2016-04-22 16:32:02');
INSERT INTO `iot_device_log` VALUES ('5665', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 16:32:02');
INSERT INTO `iot_device_log` VALUES ('5666', '21', 'TEMPERATURE', '2', '44.44', '44.44', '1', '2016-04-22 16:32:12');
INSERT INTO `iot_device_log` VALUES ('5667', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 16:32:12');
INSERT INTO `iot_device_log` VALUES ('5668', '21', 'TEMPERATURE', '2', '44.67', '44.67', '1', '2016-04-22 16:32:22');
INSERT INTO `iot_device_log` VALUES ('5669', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 16:32:22');
INSERT INTO `iot_device_log` VALUES ('5670', '21', 'TEMPERATURE', '2', '44.28', '44.28', '1', '2016-04-22 16:32:32');
INSERT INTO `iot_device_log` VALUES ('5671', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-22 16:32:32');
INSERT INTO `iot_device_log` VALUES ('5672', '21', 'TEMPERATURE', '2', '44.14', '44.14', '1', '2016-04-22 16:32:42');
INSERT INTO `iot_device_log` VALUES ('5673', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-22 16:32:42');
INSERT INTO `iot_device_log` VALUES ('5674', '21', 'TEMPERATURE', '2', '44.1', '44.1', '1', '2016-04-22 16:32:52');
INSERT INTO `iot_device_log` VALUES ('5675', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-22 16:32:52');
INSERT INTO `iot_device_log` VALUES ('5676', '21', 'TEMPERATURE', '2', '43.88', '43.88', '1', '2016-04-22 16:33:02');
INSERT INTO `iot_device_log` VALUES ('5677', '21', 'HUMIDITY', '2', '31.85', '31.85', '1', '2016-04-22 16:33:02');
INSERT INTO `iot_device_log` VALUES ('5678', '21', 'TEMPERATURE', '2', '43.88', '43.88', '1', '2016-04-22 16:33:12');
INSERT INTO `iot_device_log` VALUES ('5679', '21', 'HUMIDITY', '2', '31.76', '31.76', '1', '2016-04-22 16:33:12');
INSERT INTO `iot_device_log` VALUES ('5680', '21', 'TEMPERATURE', '2', '43.77', '43.77', '1', '2016-04-22 16:33:23');
INSERT INTO `iot_device_log` VALUES ('5681', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-22 16:33:23');
INSERT INTO `iot_device_log` VALUES ('5682', '21', 'TEMPERATURE', '2', '43.75', '43.75', '1', '2016-04-22 16:33:33');
INSERT INTO `iot_device_log` VALUES ('5683', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-22 16:33:33');
INSERT INTO `iot_device_log` VALUES ('5684', '21', 'TEMPERATURE', '2', '43.86', '43.86', '1', '2016-04-22 16:33:43');
INSERT INTO `iot_device_log` VALUES ('5685', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-22 16:33:43');
INSERT INTO `iot_device_log` VALUES ('5686', '21', 'TEMPERATURE', '2', '43.84', '43.84', '1', '2016-04-22 16:33:53');
INSERT INTO `iot_device_log` VALUES ('5687', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-22 16:33:53');
INSERT INTO `iot_device_log` VALUES ('5688', '21', 'TEMPERATURE', '2', '43.95', '43.95', '1', '2016-04-22 16:34:02');
INSERT INTO `iot_device_log` VALUES ('5689', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-22 16:34:02');
INSERT INTO `iot_device_log` VALUES ('5690', '21', 'TEMPERATURE', '2', '44.02', '44.02', '1', '2016-04-22 16:34:12');
INSERT INTO `iot_device_log` VALUES ('5691', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-22 16:34:12');
INSERT INTO `iot_device_log` VALUES ('5692', '21', 'TEMPERATURE', '2', '44.03', '44.03', '1', '2016-04-22 16:34:22');
INSERT INTO `iot_device_log` VALUES ('5693', '21', 'HUMIDITY', '2', '31.73', '31.73', '1', '2016-04-22 16:34:22');
INSERT INTO `iot_device_log` VALUES ('5694', '21', 'TEMPERATURE', '2', '44.03', '44.03', '1', '2016-04-22 16:34:32');
INSERT INTO `iot_device_log` VALUES ('5695', '21', 'HUMIDITY', '2', '31.69', '31.69', '1', '2016-04-22 16:34:32');
INSERT INTO `iot_device_log` VALUES ('5696', '21', 'TEMPERATURE', '2', '44.63', '44.63', '1', '2016-04-22 16:34:42');
INSERT INTO `iot_device_log` VALUES ('5697', '21', 'HUMIDITY', '2', '31.73', '31.73', '1', '2016-04-22 16:34:42');
INSERT INTO `iot_device_log` VALUES ('5698', '21', 'TEMPERATURE', '2', '44.22', '44.22', '1', '2016-04-22 16:34:52');
INSERT INTO `iot_device_log` VALUES ('5699', '21', 'HUMIDITY', '2', '31.72', '31.72', '1', '2016-04-22 16:34:52');
INSERT INTO `iot_device_log` VALUES ('5700', '21', 'TEMPERATURE', '2', '44.05', '44.05', '1', '2016-04-22 16:35:02');
INSERT INTO `iot_device_log` VALUES ('5701', '21', 'HUMIDITY', '2', '31.76', '31.76', '1', '2016-04-22 16:35:02');
INSERT INTO `iot_device_log` VALUES ('5702', '21', 'TEMPERATURE', '2', '44.19', '44.19', '1', '2016-04-22 16:35:13');
INSERT INTO `iot_device_log` VALUES ('5703', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-22 16:35:13');
INSERT INTO `iot_device_log` VALUES ('5704', '21', 'TEMPERATURE', '2', '44.3', '44.3', '1', '2016-04-22 16:35:22');
INSERT INTO `iot_device_log` VALUES ('5705', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 16:35:22');
INSERT INTO `iot_device_log` VALUES ('5706', '21', 'TEMPERATURE', '2', '44.4', '44.4', '1', '2016-04-22 16:35:32');
INSERT INTO `iot_device_log` VALUES ('5707', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 16:35:32');
INSERT INTO `iot_device_log` VALUES ('5708', '21', 'TEMPERATURE', '2', '44.3', '44.3', '1', '2016-04-22 16:35:42');
INSERT INTO `iot_device_log` VALUES ('5709', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-22 16:35:42');
INSERT INTO `iot_device_log` VALUES ('5710', '21', 'TEMPERATURE', '2', '44.3', '44.3', '1', '2016-04-22 16:35:52');
INSERT INTO `iot_device_log` VALUES ('5711', '21', 'HUMIDITY', '2', '31.66', '31.66', '1', '2016-04-22 16:35:52');
INSERT INTO `iot_device_log` VALUES ('5712', '21', 'TEMPERATURE', '2', '44.52', '44.52', '1', '2016-04-22 16:36:02');
INSERT INTO `iot_device_log` VALUES ('5713', '21', 'HUMIDITY', '2', '31.66', '31.66', '1', '2016-04-22 16:36:02');
INSERT INTO `iot_device_log` VALUES ('5714', '21', 'TEMPERATURE', '2', '44.3', '44.3', '1', '2016-04-22 16:36:12');
INSERT INTO `iot_device_log` VALUES ('5715', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-22 16:36:12');
INSERT INTO `iot_device_log` VALUES ('5716', '21', 'TEMPERATURE', '2', '44.35', '44.35', '1', '2016-04-22 16:36:22');
INSERT INTO `iot_device_log` VALUES ('5717', '21', 'HUMIDITY', '2', '31.76', '31.76', '1', '2016-04-22 16:36:22');
INSERT INTO `iot_device_log` VALUES ('5718', '21', 'TEMPERATURE', '2', '44.33', '44.33', '1', '2016-04-22 16:36:32');
INSERT INTO `iot_device_log` VALUES ('5719', '21', 'HUMIDITY', '2', '31.91', '31.91', '1', '2016-04-22 16:36:32');
INSERT INTO `iot_device_log` VALUES ('5720', '21', 'TEMPERATURE', '2', '43.91', '43.91', '1', '2016-04-22 16:36:42');
INSERT INTO `iot_device_log` VALUES ('5721', '21', 'HUMIDITY', '2', '32.11', '32.11', '1', '2016-04-22 16:36:42');
INSERT INTO `iot_device_log` VALUES ('5722', '21', 'TEMPERATURE', '2', '43.94', '43.94', '1', '2016-04-22 16:36:52');
INSERT INTO `iot_device_log` VALUES ('5723', '21', 'HUMIDITY', '2', '32.05', '32.05', '1', '2016-04-22 16:36:52');
INSERT INTO `iot_device_log` VALUES ('5724', '21', 'TEMPERATURE', '2', '43.97', '43.97', '1', '2016-04-22 16:37:02');
INSERT INTO `iot_device_log` VALUES ('5725', '21', 'HUMIDITY', '2', '31.94', '31.94', '1', '2016-04-22 16:37:02');
INSERT INTO `iot_device_log` VALUES ('5726', '21', 'TEMPERATURE', '2', '44.32', '44.32', '1', '2016-04-22 16:37:12');
INSERT INTO `iot_device_log` VALUES ('5727', '21', 'HUMIDITY', '2', '31.76', '31.76', '1', '2016-04-22 16:37:12');
INSERT INTO `iot_device_log` VALUES ('5728', '21', 'TEMPERATURE', '2', '44.66', '44.66', '1', '2016-04-22 16:37:22');
INSERT INTO `iot_device_log` VALUES ('5729', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-22 16:37:22');
INSERT INTO `iot_device_log` VALUES ('5730', '21', 'TEMPERATURE', '2', '44.74', '44.74', '1', '2016-04-22 16:37:32');
INSERT INTO `iot_device_log` VALUES ('5731', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-22 16:37:32');
INSERT INTO `iot_device_log` VALUES ('5732', '21', 'TEMPERATURE', '2', '44.93', '44.93', '1', '2016-04-22 16:37:42');
INSERT INTO `iot_device_log` VALUES ('5733', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-22 16:37:42');
INSERT INTO `iot_device_log` VALUES ('5734', '21', 'TEMPERATURE', '2', '44.86', '44.86', '1', '2016-04-22 16:37:52');
INSERT INTO `iot_device_log` VALUES ('5735', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 16:37:52');
INSERT INTO `iot_device_log` VALUES ('5736', '21', 'TEMPERATURE', '2', '44.9', '44.9', '1', '2016-04-22 16:38:02');
INSERT INTO `iot_device_log` VALUES ('5737', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 16:38:02');
INSERT INTO `iot_device_log` VALUES ('5738', '21', 'TEMPERATURE', '2', '44.98', '44.98', '1', '2016-04-22 16:38:12');
INSERT INTO `iot_device_log` VALUES ('5739', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-22 16:38:12');
INSERT INTO `iot_device_log` VALUES ('5740', '21', 'TEMPERATURE', '2', '45.16', '45.16', '1', '2016-04-22 16:38:22');
INSERT INTO `iot_device_log` VALUES ('5741', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-22 16:38:22');
INSERT INTO `iot_device_log` VALUES ('5742', '21', 'TEMPERATURE', '2', '45.47', '45.47', '1', '2016-04-22 16:38:32');
INSERT INTO `iot_device_log` VALUES ('5743', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 16:38:32');
INSERT INTO `iot_device_log` VALUES ('5744', '21', 'TEMPERATURE', '2', '45.47', '45.47', '1', '2016-04-22 16:38:42');
INSERT INTO `iot_device_log` VALUES ('5745', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 16:38:42');
INSERT INTO `iot_device_log` VALUES ('5746', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:38:53');
INSERT INTO `iot_device_log` VALUES ('5747', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 16:38:53');
INSERT INTO `iot_device_log` VALUES ('5748', '21', 'TEMPERATURE', '2', '45.58', '45.58', '1', '2016-04-22 16:39:03');
INSERT INTO `iot_device_log` VALUES ('5749', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 16:39:03');
INSERT INTO `iot_device_log` VALUES ('5750', '21', 'TEMPERATURE', '2', '45.48', '45.48', '1', '2016-04-22 16:39:12');
INSERT INTO `iot_device_log` VALUES ('5751', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 16:39:12');
INSERT INTO `iot_device_log` VALUES ('5752', '21', 'TEMPERATURE', '2', '45.56', '45.56', '1', '2016-04-22 16:39:22');
INSERT INTO `iot_device_log` VALUES ('5753', '21', 'HUMIDITY', '2', '31.11', '31.11', '1', '2016-04-22 16:39:22');
INSERT INTO `iot_device_log` VALUES ('5754', '21', 'TEMPERATURE', '2', '45.72', '45.72', '1', '2016-04-22 16:39:32');
INSERT INTO `iot_device_log` VALUES ('5755', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 16:39:32');
INSERT INTO `iot_device_log` VALUES ('5756', '21', 'TEMPERATURE', '2', '45.7', '45.7', '1', '2016-04-22 16:39:42');
INSERT INTO `iot_device_log` VALUES ('5757', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-22 16:39:42');
INSERT INTO `iot_device_log` VALUES ('5758', '21', 'TEMPERATURE', '2', '46.01', '46.01', '1', '2016-04-22 16:39:52');
INSERT INTO `iot_device_log` VALUES ('5759', '21', 'HUMIDITY', '2', '30.95', '30.95', '1', '2016-04-22 16:39:52');
INSERT INTO `iot_device_log` VALUES ('5760', '21', 'TEMPERATURE', '2', '46.16', '46.16', '1', '2016-04-22 16:40:02');
INSERT INTO `iot_device_log` VALUES ('5761', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:40:02');
INSERT INTO `iot_device_log` VALUES ('5762', '21', 'TEMPERATURE', '2', '46.09', '46.09', '1', '2016-04-22 16:40:12');
INSERT INTO `iot_device_log` VALUES ('5763', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-22 16:40:12');
INSERT INTO `iot_device_log` VALUES ('5764', '21', 'TEMPERATURE', '2', '46', '46', '1', '2016-04-22 16:40:22');
INSERT INTO `iot_device_log` VALUES ('5765', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 16:40:22');
INSERT INTO `iot_device_log` VALUES ('5766', '21', 'TEMPERATURE', '2', '46.15', '46.15', '1', '2016-04-22 16:40:32');
INSERT INTO `iot_device_log` VALUES ('5767', '21', 'HUMIDITY', '2', '31.18', '31.18', '1', '2016-04-22 16:40:32');
INSERT INTO `iot_device_log` VALUES ('5768', '21', 'TEMPERATURE', '2', '46.33', '46.33', '1', '2016-04-22 16:40:43');
INSERT INTO `iot_device_log` VALUES ('5769', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 16:40:43');
INSERT INTO `iot_device_log` VALUES ('5770', '21', 'TEMPERATURE', '2', '45.99', '45.99', '1', '2016-04-22 16:40:52');
INSERT INTO `iot_device_log` VALUES ('5771', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 16:40:52');
INSERT INTO `iot_device_log` VALUES ('5772', '21', 'TEMPERATURE', '2', '46.12', '46.12', '1', '2016-04-22 16:41:02');
INSERT INTO `iot_device_log` VALUES ('5773', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-22 16:41:02');
INSERT INTO `iot_device_log` VALUES ('5774', '21', 'TEMPERATURE', '2', '46.15', '46.15', '1', '2016-04-22 16:41:12');
INSERT INTO `iot_device_log` VALUES ('5775', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 16:41:12');
INSERT INTO `iot_device_log` VALUES ('5776', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:41:22');
INSERT INTO `iot_device_log` VALUES ('5777', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-22 16:41:22');
INSERT INTO `iot_device_log` VALUES ('5778', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 16:41:32');
INSERT INTO `iot_device_log` VALUES ('5779', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-22 16:41:32');
INSERT INTO `iot_device_log` VALUES ('5780', '21', 'TEMPERATURE', '2', '45.1', '45.1', '1', '2016-04-22 16:41:42');
INSERT INTO `iot_device_log` VALUES ('5781', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-22 16:41:42');
INSERT INTO `iot_device_log` VALUES ('5782', '21', 'TEMPERATURE', '2', '45.08', '45.08', '1', '2016-04-22 16:41:52');
INSERT INTO `iot_device_log` VALUES ('5783', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-22 16:41:52');
INSERT INTO `iot_device_log` VALUES ('5784', '21', 'TEMPERATURE', '2', '44.91', '44.91', '1', '2016-04-22 16:42:02');
INSERT INTO `iot_device_log` VALUES ('5785', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 16:42:02');
INSERT INTO `iot_device_log` VALUES ('5786', '21', 'TEMPERATURE', '2', '45.47', '45.47', '1', '2016-04-22 16:42:12');
INSERT INTO `iot_device_log` VALUES ('5787', '21', 'HUMIDITY', '2', '31.72', '31.72', '1', '2016-04-22 16:42:12');
INSERT INTO `iot_device_log` VALUES ('5788', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 16:42:22');
INSERT INTO `iot_device_log` VALUES ('5789', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-22 16:42:22');
INSERT INTO `iot_device_log` VALUES ('5790', '21', 'TEMPERATURE', '2', '45.08', '45.08', '1', '2016-04-22 16:42:32');
INSERT INTO `iot_device_log` VALUES ('5791', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-22 16:42:32');
INSERT INTO `iot_device_log` VALUES ('5792', '21', 'TEMPERATURE', '2', '45.29', '45.29', '1', '2016-04-22 16:42:42');
INSERT INTO `iot_device_log` VALUES ('5793', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-22 16:42:42');
INSERT INTO `iot_device_log` VALUES ('5794', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:42:52');
INSERT INTO `iot_device_log` VALUES ('5795', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-22 16:42:52');
INSERT INTO `iot_device_log` VALUES ('5796', '21', 'TEMPERATURE', '2', '45.44', '45.44', '1', '2016-04-22 16:43:02');
INSERT INTO `iot_device_log` VALUES ('5797', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 16:43:02');
INSERT INTO `iot_device_log` VALUES ('5798', '21', 'TEMPERATURE', '2', '45.54', '45.54', '1', '2016-04-22 16:43:12');
INSERT INTO `iot_device_log` VALUES ('5799', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-22 16:43:12');
INSERT INTO `iot_device_log` VALUES ('5800', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 16:43:22');
INSERT INTO `iot_device_log` VALUES ('5801', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 16:43:22');
INSERT INTO `iot_device_log` VALUES ('5802', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:43:24');
INSERT INTO `iot_device_log` VALUES ('5803', '21', 'TEMPERATURE', '2', '45.54', '45.54', '1', '2016-04-22 16:43:32');
INSERT INTO `iot_device_log` VALUES ('5804', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-22 16:43:32');
INSERT INTO `iot_device_log` VALUES ('5805', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 16:43:42');
INSERT INTO `iot_device_log` VALUES ('5806', '21', 'HUMIDITY', '2', '31.43', '31.43', '1', '2016-04-22 16:43:42');
INSERT INTO `iot_device_log` VALUES ('5807', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:43:42');
INSERT INTO `iot_device_log` VALUES ('5808', '21', 'TEMPERATURE', '2', '45.6', '45.6', '1', '2016-04-22 16:43:52');
INSERT INTO `iot_device_log` VALUES ('5809', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 16:43:52');
INSERT INTO `iot_device_log` VALUES ('5810', '21', 'TEMPERATURE', '2', '45.8', '45.8', '1', '2016-04-22 16:44:02');
INSERT INTO `iot_device_log` VALUES ('5811', '21', 'HUMIDITY', '2', '31.5', '31.5', '1', '2016-04-22 16:44:02');
INSERT INTO `iot_device_log` VALUES ('5812', '21', 'TEMPERATURE', '2', '45.98', '45.98', '1', '2016-04-22 16:44:12');
INSERT INTO `iot_device_log` VALUES ('5813', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-22 16:44:12');
INSERT INTO `iot_device_log` VALUES ('5814', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:44:14');
INSERT INTO `iot_device_log` VALUES ('5815', '21', 'TEMPERATURE', '2', '46.12', '46.12', '1', '2016-04-22 16:44:23');
INSERT INTO `iot_device_log` VALUES ('5816', '21', 'HUMIDITY', '2', '31.23', '31.23', '1', '2016-04-22 16:44:23');
INSERT INTO `iot_device_log` VALUES ('5817', '21', 'TEMPERATURE', '2', '46.1', '46.1', '1', '2016-04-22 16:44:32');
INSERT INTO `iot_device_log` VALUES ('5818', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 16:44:32');
INSERT INTO `iot_device_log` VALUES ('5819', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 16:44:34');
INSERT INTO `iot_device_log` VALUES ('5820', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 16:44:36');
INSERT INTO `iot_device_log` VALUES ('5821', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 16:44:37');
INSERT INTO `iot_device_log` VALUES ('5822', '21', 'TEMPERATURE', '2', '46.23', '46.23', '1', '2016-04-22 16:44:42');
INSERT INTO `iot_device_log` VALUES ('5823', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 16:44:42');
INSERT INTO `iot_device_log` VALUES ('5824', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:44:44');
INSERT INTO `iot_device_log` VALUES ('5825', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:44:47');
INSERT INTO `iot_device_log` VALUES ('5826', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:44:49');
INSERT INTO `iot_device_log` VALUES ('5827', '21', 'TEMPERATURE', '2', '46.35', '46.35', '1', '2016-04-22 16:44:52');
INSERT INTO `iot_device_log` VALUES ('5828', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:44:52');
INSERT INTO `iot_device_log` VALUES ('5829', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:44:54');
INSERT INTO `iot_device_log` VALUES ('5830', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:44:57');
INSERT INTO `iot_device_log` VALUES ('5831', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:44:59');
INSERT INTO `iot_device_log` VALUES ('5832', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:45:02');
INSERT INTO `iot_device_log` VALUES ('5833', '21', 'TEMPERATURE', '2', '46.46', '46.46', '1', '2016-04-22 16:45:02');
INSERT INTO `iot_device_log` VALUES ('5834', '21', 'HUMIDITY', '2', '31.01', '31.01', '1', '2016-04-22 16:45:02');
INSERT INTO `iot_device_log` VALUES ('5835', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:45:04');
INSERT INTO `iot_device_log` VALUES ('5836', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:45:05');
INSERT INTO `iot_device_log` VALUES ('5837', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:45:12');
INSERT INTO `iot_device_log` VALUES ('5838', '21', 'TEMPERATURE', '2', '46.5', '46.5', '1', '2016-04-22 16:45:12');
INSERT INTO `iot_device_log` VALUES ('5839', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:45:12');
INSERT INTO `iot_device_log` VALUES ('5840', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:45:14');
INSERT INTO `iot_device_log` VALUES ('5841', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:45:17');
INSERT INTO `iot_device_log` VALUES ('5842', '21', 'TEMPERATURE', '2', '46.89', '46.89', '1', '2016-04-22 16:45:22');
INSERT INTO `iot_device_log` VALUES ('5843', '21', 'HUMIDITY', '2', '30.89', '30.89', '1', '2016-04-22 16:45:22');
INSERT INTO `iot_device_log` VALUES ('5844', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:45:24');
INSERT INTO `iot_device_log` VALUES ('5845', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:45:27');
INSERT INTO `iot_device_log` VALUES ('5846', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:45:29');
INSERT INTO `iot_device_log` VALUES ('5847', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:45:31');
INSERT INTO `iot_device_log` VALUES ('5848', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:45:32');
INSERT INTO `iot_device_log` VALUES ('5849', '21', 'TEMPERATURE', '2', '47.27', '47.27', '1', '2016-04-22 16:45:32');
INSERT INTO `iot_device_log` VALUES ('5850', '21', 'HUMIDITY', '2', '31', '31', '1', '2016-04-22 16:45:32');
INSERT INTO `iot_device_log` VALUES ('5851', '21', 'TEMPERATURE', '2', '46.45', '46.45', '1', '2016-04-22 16:45:43');
INSERT INTO `iot_device_log` VALUES ('5852', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 16:45:43');
INSERT INTO `iot_device_log` VALUES ('5853', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 16:45:46');
INSERT INTO `iot_device_log` VALUES ('5854', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 16:45:48');
INSERT INTO `iot_device_log` VALUES ('5855', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:45:50');
INSERT INTO `iot_device_log` VALUES ('5856', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:45:52');
INSERT INTO `iot_device_log` VALUES ('5857', '21', 'TEMPERATURE', '2', '46.68', '46.68', '1', '2016-04-22 16:45:53');
INSERT INTO `iot_device_log` VALUES ('5858', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-22 16:45:53');
INSERT INTO `iot_device_log` VALUES ('5859', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:45:53');
INSERT INTO `iot_device_log` VALUES ('5860', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:45:54');
INSERT INTO `iot_device_log` VALUES ('5861', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:45:59');
INSERT INTO `iot_device_log` VALUES ('5862', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:46:00');
INSERT INTO `iot_device_log` VALUES ('5863', '21', 'TEMPERATURE', '2', '45.62', '45.62', '1', '2016-04-22 16:46:02');
INSERT INTO `iot_device_log` VALUES ('5864', '21', 'HUMIDITY', '2', '31.47', '31.47', '1', '2016-04-22 16:46:02');
INSERT INTO `iot_device_log` VALUES ('5865', '21', 'TEMPERATURE', '2', '46.14', '46.14', '1', '2016-04-22 16:46:12');
INSERT INTO `iot_device_log` VALUES ('5866', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-22 16:46:12');
INSERT INTO `iot_device_log` VALUES ('5867', '21', 'TEMPERATURE', '2', '50.82', '50.82', '1', '2016-04-22 16:46:22');
INSERT INTO `iot_device_log` VALUES ('5868', '21', 'HUMIDITY', '2', '31.85', '31.85', '1', '2016-04-22 16:46:22');
INSERT INTO `iot_device_log` VALUES ('5869', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 16:46:32');
INSERT INTO `iot_device_log` VALUES ('5870', '21', 'HUMIDITY', '2', '32.23', '32.23', '1', '2016-04-22 16:46:32');
INSERT INTO `iot_device_log` VALUES ('5871', '21', 'TEMPERATURE', '2', '45.57', '45.57', '1', '2016-04-22 16:46:42');
INSERT INTO `iot_device_log` VALUES ('5872', '21', 'HUMIDITY', '2', '31.93', '31.93', '1', '2016-04-22 16:46:42');
INSERT INTO `iot_device_log` VALUES ('5873', '21', 'TEMPERATURE', '2', '45.86', '45.86', '1', '2016-04-22 16:46:52');
INSERT INTO `iot_device_log` VALUES ('5874', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-22 16:46:52');
INSERT INTO `iot_device_log` VALUES ('5875', '21', 'TEMPERATURE', '2', '45.84', '45.84', '1', '2016-04-22 16:47:02');
INSERT INTO `iot_device_log` VALUES ('5876', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-22 16:47:02');
INSERT INTO `iot_device_log` VALUES ('5877', '21', 'TEMPERATURE', '2', '46.16', '46.16', '1', '2016-04-22 16:47:12');
INSERT INTO `iot_device_log` VALUES ('5878', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-22 16:47:12');
INSERT INTO `iot_device_log` VALUES ('5879', '21', 'TEMPERATURE', '2', '45.75', '45.75', '1', '2016-04-22 16:47:22');
INSERT INTO `iot_device_log` VALUES ('5880', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-22 16:47:22');
INSERT INTO `iot_device_log` VALUES ('5881', '21', 'TEMPERATURE', '2', '45.7', '45.7', '1', '2016-04-22 16:47:32');
INSERT INTO `iot_device_log` VALUES ('5882', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-22 16:47:32');
INSERT INTO `iot_device_log` VALUES ('5883', '21', 'TEMPERATURE', '2', '45.44', '45.44', '1', '2016-04-22 16:47:42');
INSERT INTO `iot_device_log` VALUES ('5884', '21', 'HUMIDITY', '2', '31.81', '31.81', '1', '2016-04-22 16:47:42');
INSERT INTO `iot_device_log` VALUES ('5885', '21', 'TEMPERATURE', '2', '45.1', '45.1', '1', '2016-04-22 16:47:52');
INSERT INTO `iot_device_log` VALUES ('5886', '21', 'HUMIDITY', '2', '31.85', '31.85', '1', '2016-04-22 16:47:52');
INSERT INTO `iot_device_log` VALUES ('5887', '21', 'TEMPERATURE', '2', '45', '45', '1', '2016-04-22 16:48:02');
INSERT INTO `iot_device_log` VALUES ('5888', '21', 'HUMIDITY', '2', '31.91', '31.91', '1', '2016-04-22 16:48:02');
INSERT INTO `iot_device_log` VALUES ('5889', '21', 'TEMPERATURE', '2', '45.44', '45.44', '1', '2016-04-22 16:48:12');
INSERT INTO `iot_device_log` VALUES ('5890', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-22 16:48:12');
INSERT INTO `iot_device_log` VALUES ('5891', '21', 'TEMPERATURE', '2', '45.29', '45.29', '1', '2016-04-22 16:48:22');
INSERT INTO `iot_device_log` VALUES ('5892', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-22 16:48:22');
INSERT INTO `iot_device_log` VALUES ('5893', '21', 'TEMPERATURE', '2', '45.23', '45.23', '1', '2016-04-22 16:48:32');
INSERT INTO `iot_device_log` VALUES ('5894', '21', 'HUMIDITY', '2', '31.77', '31.77', '1', '2016-04-22 16:48:32');
INSERT INTO `iot_device_log` VALUES ('5895', '21', 'TEMPERATURE', '2', '45.6', '45.6', '1', '2016-04-22 16:48:42');
INSERT INTO `iot_device_log` VALUES ('5896', '21', 'HUMIDITY', '2', '31.63', '31.63', '1', '2016-04-22 16:48:42');
INSERT INTO `iot_device_log` VALUES ('5897', '21', 'TEMPERATURE', '2', '45.76', '45.76', '1', '2016-04-22 16:48:52');
INSERT INTO `iot_device_log` VALUES ('5898', '21', 'HUMIDITY', '2', '31.59', '31.59', '1', '2016-04-22 16:48:52');
INSERT INTO `iot_device_log` VALUES ('5899', '21', 'TEMPERATURE', '2', '45.76', '45.76', '1', '2016-04-22 16:49:02');
INSERT INTO `iot_device_log` VALUES ('5900', '21', 'HUMIDITY', '2', '31.58', '31.58', '1', '2016-04-22 16:49:02');
INSERT INTO `iot_device_log` VALUES ('5901', '21', 'TEMPERATURE', '2', '45.72', '45.72', '1', '2016-04-22 16:49:12');
INSERT INTO `iot_device_log` VALUES ('5902', '21', 'HUMIDITY', '2', '31.55', '31.55', '1', '2016-04-22 16:49:12');
INSERT INTO `iot_device_log` VALUES ('5903', '21', 'TEMPERATURE', '2', '45.45', '45.45', '1', '2016-04-22 16:49:22');
INSERT INTO `iot_device_log` VALUES ('5904', '21', 'HUMIDITY', '2', '31.5', '31.5', '1', '2016-04-22 16:49:22');
INSERT INTO `iot_device_log` VALUES ('5905', '21', 'TEMPERATURE', '2', '45.82', '45.82', '1', '2016-04-22 16:49:32');
INSERT INTO `iot_device_log` VALUES ('5906', '21', 'HUMIDITY', '2', '31.5', '31.5', '1', '2016-04-22 16:49:32');
INSERT INTO `iot_device_log` VALUES ('5907', '21', 'TEMPERATURE', '2', '45.45', '45.45', '1', '2016-04-22 16:49:42');
INSERT INTO `iot_device_log` VALUES ('5908', '21', 'HUMIDITY', '2', '31.52', '31.52', '1', '2016-04-22 16:49:42');
INSERT INTO `iot_device_log` VALUES ('5909', '21', 'TEMPERATURE', '2', '45.38', '45.38', '1', '2016-04-22 16:49:52');
INSERT INTO `iot_device_log` VALUES ('5910', '21', 'HUMIDITY', '2', '31.62', '31.62', '1', '2016-04-22 16:49:52');
INSERT INTO `iot_device_log` VALUES ('5911', '21', 'TEMPERATURE', '2', '45.62', '45.62', '1', '2016-04-22 16:50:02');
INSERT INTO `iot_device_log` VALUES ('5912', '21', 'HUMIDITY', '2', '31.51', '31.51', '1', '2016-04-22 16:50:02');
INSERT INTO `iot_device_log` VALUES ('5913', '21', 'TEMPERATURE', '2', '45.9', '45.9', '1', '2016-04-22 16:50:12');
INSERT INTO `iot_device_log` VALUES ('5914', '21', 'HUMIDITY', '2', '31.37', '31.37', '1', '2016-04-22 16:50:12');
INSERT INTO `iot_device_log` VALUES ('5915', '21', 'TEMPERATURE', '2', '45.51', '45.51', '1', '2016-04-22 16:50:22');
INSERT INTO `iot_device_log` VALUES ('5916', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-22 16:50:22');
INSERT INTO `iot_device_log` VALUES ('5917', '21', 'TEMPERATURE', '2', '46', '46', '1', '2016-04-22 16:50:32');
INSERT INTO `iot_device_log` VALUES ('5918', '21', 'HUMIDITY', '2', '31.22', '31.22', '1', '2016-04-22 16:50:32');
INSERT INTO `iot_device_log` VALUES ('5919', '21', 'TEMPERATURE', '2', '46.2', '46.2', '1', '2016-04-22 16:50:42');
INSERT INTO `iot_device_log` VALUES ('5920', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 16:50:42');
INSERT INTO `iot_device_log` VALUES ('5921', '21', 'TEMPERATURE', '2', '46.26', '46.26', '1', '2016-04-22 16:50:52');
INSERT INTO `iot_device_log` VALUES ('5922', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:50:52');
INSERT INTO `iot_device_log` VALUES ('5923', '21', 'TEMPERATURE', '2', '46.54', '46.54', '1', '2016-04-22 16:51:02');
INSERT INTO `iot_device_log` VALUES ('5924', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:51:02');
INSERT INTO `iot_device_log` VALUES ('5925', '21', 'TEMPERATURE', '2', '46.85', '46.85', '1', '2016-04-22 16:51:12');
INSERT INTO `iot_device_log` VALUES ('5926', '21', 'HUMIDITY', '2', '30.78', '30.78', '1', '2016-04-22 16:51:12');
INSERT INTO `iot_device_log` VALUES ('5927', '21', 'TEMPERATURE', '2', '46.87', '46.87', '1', '2016-04-22 16:51:22');
INSERT INTO `iot_device_log` VALUES ('5928', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 16:51:22');
INSERT INTO `iot_device_log` VALUES ('5929', '21', 'TEMPERATURE', '2', '47.09', '47.09', '1', '2016-04-22 16:51:32');
INSERT INTO `iot_device_log` VALUES ('5930', '21', 'HUMIDITY', '2', '30.85', '30.85', '1', '2016-04-22 16:51:32');
INSERT INTO `iot_device_log` VALUES ('5931', '21', 'TEMPERATURE', '2', '47.12', '47.12', '1', '2016-04-22 16:51:42');
INSERT INTO `iot_device_log` VALUES ('5932', '21', 'HUMIDITY', '2', '30.84', '30.84', '1', '2016-04-22 16:51:42');
INSERT INTO `iot_device_log` VALUES ('5933', '21', 'TEMPERATURE', '2', '47.34', '47.34', '1', '2016-04-22 16:51:52');
INSERT INTO `iot_device_log` VALUES ('5934', '21', 'HUMIDITY', '2', '30.92', '30.92', '1', '2016-04-22 16:51:52');
INSERT INTO `iot_device_log` VALUES ('5935', '21', 'TEMPERATURE', '2', '46.94', '46.94', '1', '2016-04-22 16:52:02');
INSERT INTO `iot_device_log` VALUES ('5936', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 16:52:02');
INSERT INTO `iot_device_log` VALUES ('5937', '21', 'TEMPERATURE', '2', '46.71', '46.71', '1', '2016-04-22 16:52:12');
INSERT INTO `iot_device_log` VALUES ('5938', '21', 'HUMIDITY', '2', '31.08', '31.08', '1', '2016-04-22 16:52:12');
INSERT INTO `iot_device_log` VALUES ('5939', '21', 'TEMPERATURE', '2', '46.21', '46.21', '1', '2016-04-22 16:52:22');
INSERT INTO `iot_device_log` VALUES ('5940', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 16:52:22');
INSERT INTO `iot_device_log` VALUES ('5941', '21', 'TEMPERATURE', '2', '46.09', '46.09', '1', '2016-04-22 16:52:32');
INSERT INTO `iot_device_log` VALUES ('5942', '21', 'HUMIDITY', '2', '31.39', '31.39', '1', '2016-04-22 16:52:32');
INSERT INTO `iot_device_log` VALUES ('5943', '21', 'TEMPERATURE', '2', '46.32', '46.32', '1', '2016-04-22 16:52:43');
INSERT INTO `iot_device_log` VALUES ('5944', '21', 'HUMIDITY', '2', '31.48', '31.48', '1', '2016-04-22 16:52:43');
INSERT INTO `iot_device_log` VALUES ('5945', '21', 'TEMPERATURE', '2', '46.49', '46.49', '1', '2016-04-22 16:52:52');
INSERT INTO `iot_device_log` VALUES ('5946', '21', 'HUMIDITY', '2', '31.33', '31.33', '1', '2016-04-22 16:52:52');
INSERT INTO `iot_device_log` VALUES ('5947', '21', 'TEMPERATURE', '2', '46.52', '46.52', '1', '2016-04-22 16:53:02');
INSERT INTO `iot_device_log` VALUES ('5948', '21', 'HUMIDITY', '2', '31.41', '31.41', '1', '2016-04-22 16:53:02');
INSERT INTO `iot_device_log` VALUES ('5949', '21', 'TEMPERATURE', '2', '45.79', '45.79', '1', '2016-04-22 16:53:12');
INSERT INTO `iot_device_log` VALUES ('5950', '21', 'HUMIDITY', '2', '31.67', '31.67', '1', '2016-04-22 16:53:12');
INSERT INTO `iot_device_log` VALUES ('5951', '21', 'TEMPERATURE', '2', '46.11', '46.11', '1', '2016-04-22 16:53:22');
INSERT INTO `iot_device_log` VALUES ('5952', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-22 16:53:22');
INSERT INTO `iot_device_log` VALUES ('5953', '21', 'TEMPERATURE', '2', '46.07', '46.07', '1', '2016-04-22 16:53:32');
INSERT INTO `iot_device_log` VALUES ('5954', '21', 'HUMIDITY', '2', '31.7', '31.7', '1', '2016-04-22 16:53:32');
INSERT INTO `iot_device_log` VALUES ('5955', '21', 'TEMPERATURE', '2', '45.82', '45.82', '1', '2016-04-22 16:53:42');
INSERT INTO `iot_device_log` VALUES ('5956', '21', 'HUMIDITY', '2', '31.73', '31.73', '1', '2016-04-22 16:53:42');
INSERT INTO `iot_device_log` VALUES ('5957', '21', 'TEMPERATURE', '2', '45.75', '45.75', '1', '2016-04-22 16:53:52');
INSERT INTO `iot_device_log` VALUES ('5958', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-22 16:53:52');
INSERT INTO `iot_device_log` VALUES ('5959', '21', 'TEMPERATURE', '2', '45.46', '45.46', '1', '2016-04-22 16:54:02');
INSERT INTO `iot_device_log` VALUES ('5960', '21', 'HUMIDITY', '2', '31.8', '31.8', '1', '2016-04-22 16:54:02');
INSERT INTO `iot_device_log` VALUES ('5961', '21', 'TEMPERATURE', '2', '45.55', '45.55', '1', '2016-04-22 16:54:12');
INSERT INTO `iot_device_log` VALUES ('5962', '21', 'HUMIDITY', '2', '31.74', '31.74', '1', '2016-04-22 16:54:12');
INSERT INTO `iot_device_log` VALUES ('5963', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 16:54:14');
INSERT INTO `iot_device_log` VALUES ('5964', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:54:16');
INSERT INTO `iot_device_log` VALUES ('5965', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 16:54:19');
INSERT INTO `iot_device_log` VALUES ('5966', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 16:54:21');
INSERT INTO `iot_device_log` VALUES ('5967', '21', 'TEMPERATURE', '2', '45.61', '45.61', '1', '2016-04-22 16:54:22');
INSERT INTO `iot_device_log` VALUES ('5968', '21', 'HUMIDITY', '2', '31.73', '31.73', '1', '2016-04-22 16:54:22');
INSERT INTO `iot_device_log` VALUES ('5969', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 16:54:24');
INSERT INTO `iot_device_log` VALUES ('5970', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:54:28');
INSERT INTO `iot_device_log` VALUES ('5971', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:54:30');
INSERT INTO `iot_device_log` VALUES ('5972', '21', 'TEMPERATURE', '2', '45.69', '45.69', '1', '2016-04-22 16:54:32');
INSERT INTO `iot_device_log` VALUES ('5973', '21', 'HUMIDITY', '2', '31.72', '31.72', '1', '2016-04-22 16:54:32');
INSERT INTO `iot_device_log` VALUES ('5974', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 16:54:42');
INSERT INTO `iot_device_log` VALUES ('5975', '21', 'HUMIDITY', '2', '31.87', '31.87', '1', '2016-04-22 16:54:42');
INSERT INTO `iot_device_log` VALUES ('5976', '21', 'TEMPERATURE', '2', '45.26', '45.26', '1', '2016-04-22 16:54:52');
INSERT INTO `iot_device_log` VALUES ('5977', '21', 'HUMIDITY', '2', '31.89', '31.89', '1', '2016-04-22 16:54:52');
INSERT INTO `iot_device_log` VALUES ('5978', '21', 'TEMPERATURE', '2', '45.38', '45.38', '1', '2016-04-22 16:55:02');
INSERT INTO `iot_device_log` VALUES ('5979', '21', 'HUMIDITY', '2', '31.82', '31.82', '1', '2016-04-22 16:55:02');
INSERT INTO `iot_device_log` VALUES ('5980', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:55:07');
INSERT INTO `iot_device_log` VALUES ('5981', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:55:08');
INSERT INTO `iot_device_log` VALUES ('5982', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:55:10');
INSERT INTO `iot_device_log` VALUES ('5983', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:55:12');
INSERT INTO `iot_device_log` VALUES ('5984', '21', 'TEMPERATURE', '2', '45.26', '45.26', '1', '2016-04-22 16:55:12');
INSERT INTO `iot_device_log` VALUES ('5985', '21', 'HUMIDITY', '2', '31.69', '31.69', '1', '2016-04-22 16:55:12');
INSERT INTO `iot_device_log` VALUES ('5986', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:55:17');
INSERT INTO `iot_device_log` VALUES ('5987', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:55:18');
INSERT INTO `iot_device_log` VALUES ('5988', '21', 'TEMPERATURE', '2', '45.42', '45.42', '1', '2016-04-22 16:55:22');
INSERT INTO `iot_device_log` VALUES ('5989', '21', 'HUMIDITY', '2', '31.61', '31.61', '1', '2016-04-22 16:55:22');
INSERT INTO `iot_device_log` VALUES ('5990', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:55:25');
INSERT INTO `iot_device_log` VALUES ('5991', '21', 'TEMPERATURE', '2', '45.32', '45.32', '1', '2016-04-22 16:55:32');
INSERT INTO `iot_device_log` VALUES ('5992', '21', 'HUMIDITY', '2', '31.51', '31.51', '1', '2016-04-22 16:55:32');
INSERT INTO `iot_device_log` VALUES ('5993', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:55:37');
INSERT INTO `iot_device_log` VALUES ('5994', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 16:55:40');
INSERT INTO `iot_device_log` VALUES ('5995', '21', 'TEMPERATURE', '2', '45.67', '45.67', '1', '2016-04-22 16:55:42');
INSERT INTO `iot_device_log` VALUES ('5996', '21', 'HUMIDITY', '2', '31.36', '31.36', '1', '2016-04-22 16:55:42');
INSERT INTO `iot_device_log` VALUES ('5997', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 16:55:45');
INSERT INTO `iot_device_log` VALUES ('5998', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 16:55:50');
INSERT INTO `iot_device_log` VALUES ('5999', '21', 'TEMPERATURE', '2', '45.63', '45.63', '1', '2016-04-22 16:55:52');
INSERT INTO `iot_device_log` VALUES ('6000', '21', 'HUMIDITY', '2', '31.32', '31.32', '1', '2016-04-22 16:55:52');
INSERT INTO `iot_device_log` VALUES ('6001', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:55:52');
INSERT INTO `iot_device_log` VALUES ('6002', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:55:55');
INSERT INTO `iot_device_log` VALUES ('6003', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:55:57');
INSERT INTO `iot_device_log` VALUES ('6004', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 16:55:59');
INSERT INTO `iot_device_log` VALUES ('6005', '21', 'TEMPERATURE', '2', '45.85', '45.85', '1', '2016-04-22 16:56:02');
INSERT INTO `iot_device_log` VALUES ('6006', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-22 16:56:02');
INSERT INTO `iot_device_log` VALUES ('6007', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:56:02');
INSERT INTO `iot_device_log` VALUES ('6008', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:56:03');
INSERT INTO `iot_device_log` VALUES ('6009', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:56:04');
INSERT INTO `iot_device_log` VALUES ('6010', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:56:04');
INSERT INTO `iot_device_log` VALUES ('6011', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:56:05');
INSERT INTO `iot_device_log` VALUES ('6012', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:56:10');
INSERT INTO `iot_device_log` VALUES ('6013', '21', 'TEMPERATURE', '2', '45.68', '45.68', '1', '2016-04-22 16:56:12');
INSERT INTO `iot_device_log` VALUES ('6014', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-22 16:56:12');
INSERT INTO `iot_device_log` VALUES ('6015', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:56:14');
INSERT INTO `iot_device_log` VALUES ('6016', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:56:16');
INSERT INTO `iot_device_log` VALUES ('6017', '21', 'TEMPERATURE', '2', '45.35', '45.35', '1', '2016-04-22 16:56:22');
INSERT INTO `iot_device_log` VALUES ('6018', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-22 16:56:22');
INSERT INTO `iot_device_log` VALUES ('6019', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:56:28');
INSERT INTO `iot_device_log` VALUES ('6020', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 16:56:29');
INSERT INTO `iot_device_log` VALUES ('6021', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:56:29');
INSERT INTO `iot_device_log` VALUES ('6022', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 16:56:32');
INSERT INTO `iot_device_log` VALUES ('6023', '21', 'TEMPERATURE', '2', '45.33', '45.33', '1', '2016-04-22 16:56:32');
INSERT INTO `iot_device_log` VALUES ('6024', '21', 'HUMIDITY', '2', '31.29', '31.29', '1', '2016-04-22 16:56:32');
INSERT INTO `iot_device_log` VALUES ('6025', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:56:40');
INSERT INTO `iot_device_log` VALUES ('6026', '21', 'TEMPERATURE', '2', '45.65', '45.65', '1', '2016-04-22 16:56:42');
INSERT INTO `iot_device_log` VALUES ('6027', '21', 'HUMIDITY', '2', '31.26', '31.26', '1', '2016-04-22 16:56:42');
INSERT INTO `iot_device_log` VALUES ('6028', '21', 'TEMPERATURE', '2', '46.03', '46.03', '1', '2016-04-22 16:56:52');
INSERT INTO `iot_device_log` VALUES ('6029', '21', 'HUMIDITY', '2', '31.12', '31.12', '1', '2016-04-22 16:56:52');
INSERT INTO `iot_device_log` VALUES ('6030', '21', 'TEMPERATURE', '2', '46.52', '46.52', '1', '2016-04-22 16:57:02');
INSERT INTO `iot_device_log` VALUES ('6031', '21', 'HUMIDITY', '2', '31.15', '31.15', '1', '2016-04-22 16:57:02');
INSERT INTO `iot_device_log` VALUES ('6032', '21', 'TEMPERATURE', '2', '46.24', '46.24', '1', '2016-04-22 16:57:12');
INSERT INTO `iot_device_log` VALUES ('6033', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 16:57:12');
INSERT INTO `iot_device_log` VALUES ('6034', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:12');
INSERT INTO `iot_device_log` VALUES ('6035', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:13');
INSERT INTO `iot_device_log` VALUES ('6036', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:16');
INSERT INTO `iot_device_log` VALUES ('6037', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:17');
INSERT INTO `iot_device_log` VALUES ('6038', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:19');
INSERT INTO `iot_device_log` VALUES ('6039', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:21');
INSERT INTO `iot_device_log` VALUES ('6040', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:22');
INSERT INTO `iot_device_log` VALUES ('6041', '21', 'TEMPERATURE', '2', '46.48', '46.48', '1', '2016-04-22 16:57:22');
INSERT INTO `iot_device_log` VALUES ('6042', '21', 'HUMIDITY', '2', '31.03', '31.03', '1', '2016-04-22 16:57:22');
INSERT INTO `iot_device_log` VALUES ('6043', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:23');
INSERT INTO `iot_device_log` VALUES ('6044', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:24');
INSERT INTO `iot_device_log` VALUES ('6045', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:26');
INSERT INTO `iot_device_log` VALUES ('6046', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:28');
INSERT INTO `iot_device_log` VALUES ('6047', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:31');
INSERT INTO `iot_device_log` VALUES ('6048', '21', 'TEMPERATURE', '2', '46.3', '46.3', '1', '2016-04-22 16:57:32');
INSERT INTO `iot_device_log` VALUES ('6049', '21', 'HUMIDITY', '2', '31.1', '31.1', '1', '2016-04-22 16:57:32');
INSERT INTO `iot_device_log` VALUES ('6050', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:32');
INSERT INTO `iot_device_log` VALUES ('6051', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:34');
INSERT INTO `iot_device_log` VALUES ('6052', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:35');
INSERT INTO `iot_device_log` VALUES ('6053', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:39');
INSERT INTO `iot_device_log` VALUES ('6054', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:41');
INSERT INTO `iot_device_log` VALUES ('6055', '21', 'TEMPERATURE', '2', '46.57', '46.57', '1', '2016-04-22 16:57:43');
INSERT INTO `iot_device_log` VALUES ('6056', '21', 'HUMIDITY', '2', '30.97', '30.97', '1', '2016-04-22 16:57:43');
INSERT INTO `iot_device_log` VALUES ('6057', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:43');
INSERT INTO `iot_device_log` VALUES ('6058', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:44');
INSERT INTO `iot_device_log` VALUES ('6059', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:47');
INSERT INTO `iot_device_log` VALUES ('6060', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:48');
INSERT INTO `iot_device_log` VALUES ('6061', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:49');
INSERT INTO `iot_device_log` VALUES ('6062', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:51');
INSERT INTO `iot_device_log` VALUES ('6063', '21', 'TEMPERATURE', '2', '46.48', '46.48', '1', '2016-04-22 16:57:54');
INSERT INTO `iot_device_log` VALUES ('6064', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 16:57:54');
INSERT INTO `iot_device_log` VALUES ('6065', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:54');
INSERT INTO `iot_device_log` VALUES ('6066', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:55');
INSERT INTO `iot_device_log` VALUES ('6067', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:55');
INSERT INTO `iot_device_log` VALUES ('6068', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:56');
INSERT INTO `iot_device_log` VALUES ('6069', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:57:59');
INSERT INTO `iot_device_log` VALUES ('6070', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:58:00');
INSERT INTO `iot_device_log` VALUES ('6071', '21', 'TEMPERATURE', '2', '46.62', '46.62', '1', '2016-04-22 16:58:03');
INSERT INTO `iot_device_log` VALUES ('6072', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 16:58:03');
INSERT INTO `iot_device_log` VALUES ('6073', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:58:03');
INSERT INTO `iot_device_log` VALUES ('6074', '21', 'TEMPERATURE', '2', '46.29', '46.29', '1', '2016-04-22 16:58:13');
INSERT INTO `iot_device_log` VALUES ('6075', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 16:58:13');
INSERT INTO `iot_device_log` VALUES ('6076', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 16:58:22');
INSERT INTO `iot_device_log` VALUES ('6077', '21', 'TEMPERATURE', '2', '46.26', '46.26', '1', '2016-04-22 16:58:22');
INSERT INTO `iot_device_log` VALUES ('6078', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 16:58:22');
INSERT INTO `iot_device_log` VALUES ('6079', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:58:25');
INSERT INTO `iot_device_log` VALUES ('6080', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:58:27');
INSERT INTO `iot_device_log` VALUES ('6081', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:58:29');
INSERT INTO `iot_device_log` VALUES ('6082', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:58:30');
INSERT INTO `iot_device_log` VALUES ('6083', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:58:32');
INSERT INTO `iot_device_log` VALUES ('6084', '21', 'TEMPERATURE', '2', '46.23', '46.23', '1', '2016-04-22 16:58:32');
INSERT INTO `iot_device_log` VALUES ('6085', '21', 'HUMIDITY', '2', '31.3', '31.3', '1', '2016-04-22 16:58:32');
INSERT INTO `iot_device_log` VALUES ('6086', '21', 'TEMPERATURE', '2', '46.05', '46.05', '1', '2016-04-22 16:58:42');
INSERT INTO `iot_device_log` VALUES ('6087', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-22 16:58:42');
INSERT INTO `iot_device_log` VALUES ('6088', '21', 'TEMPERATURE', '2', '46.01', '46.01', '1', '2016-04-22 16:58:52');
INSERT INTO `iot_device_log` VALUES ('6089', '21', 'HUMIDITY', '2', '31.34', '31.34', '1', '2016-04-22 16:58:52');
INSERT INTO `iot_device_log` VALUES ('6090', '21', 'TEMPERATURE', '2', '46.33', '46.33', '1', '2016-04-22 16:59:02');
INSERT INTO `iot_device_log` VALUES ('6091', '21', 'HUMIDITY', '2', '31.28', '31.28', '1', '2016-04-22 16:59:02');
INSERT INTO `iot_device_log` VALUES ('6092', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:59:04');
INSERT INTO `iot_device_log` VALUES ('6093', '21', 'TEMPERATURE', '2', '46.48', '46.48', '1', '2016-04-22 16:59:12');
INSERT INTO `iot_device_log` VALUES ('6094', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 16:59:12');
INSERT INTO `iot_device_log` VALUES ('6095', '22', 'BUTTON_PUSH', '3', '3', '3', '1', '2016-04-22 16:59:13');
INSERT INTO `iot_device_log` VALUES ('6096', '21', 'TEMPERATURE', '2', '46.4', '46.4', '1', '2016-04-22 16:59:22');
INSERT INTO `iot_device_log` VALUES ('6097', '21', 'HUMIDITY', '2', '31.21', '31.21', '1', '2016-04-22 16:59:22');
INSERT INTO `iot_device_log` VALUES ('6098', '21', 'TEMPERATURE', '2', '46.45', '46.45', '1', '2016-04-22 16:59:32');
INSERT INTO `iot_device_log` VALUES ('6099', '21', 'HUMIDITY', '2', '31.19', '31.19', '1', '2016-04-22 16:59:32');
INSERT INTO `iot_device_log` VALUES ('6100', '21', 'TEMPERATURE', '2', '46.51', '46.51', '1', '2016-04-22 16:59:42');
INSERT INTO `iot_device_log` VALUES ('6101', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 16:59:42');
INSERT INTO `iot_device_log` VALUES ('6102', '21', 'TEMPERATURE', '2', '46.65', '46.65', '1', '2016-04-22 16:59:52');
INSERT INTO `iot_device_log` VALUES ('6103', '21', 'HUMIDITY', '2', '31.14', '31.14', '1', '2016-04-22 16:59:52');
INSERT INTO `iot_device_log` VALUES ('6104', '21', 'TEMPERATURE', '2', '48.38', '48.38', '1', '2016-04-22 17:00:22');
INSERT INTO `iot_device_log` VALUES ('6105', '21', 'HUMIDITY', '2', '31.06', '31.06', '1', '2016-04-22 17:00:22');
INSERT INTO `iot_device_log` VALUES ('6106', '21', 'TEMPERATURE', '2', '46.99', '46.99', '1', '2016-04-22 17:00:32');
INSERT INTO `iot_device_log` VALUES ('6107', '21', 'HUMIDITY', '2', '31.4', '31.4', '1', '2016-04-22 17:00:32');
INSERT INTO `iot_device_log` VALUES ('6108', '21', 'TEMPERATURE', '2', '46.31', '46.31', '1', '2016-04-22 17:00:42');
INSERT INTO `iot_device_log` VALUES ('6109', '21', 'HUMIDITY', '2', '31.54', '31.54', '1', '2016-04-22 17:00:42');
INSERT INTO `iot_device_log` VALUES ('6110', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 17:00:48');
INSERT INTO `iot_device_log` VALUES ('6111', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 17:00:51');
INSERT INTO `iot_device_log` VALUES ('6112', '21', 'TEMPERATURE', '2', '46.31', '46.31', '1', '2016-04-22 17:00:52');
INSERT INTO `iot_device_log` VALUES ('6113', '21', 'HUMIDITY', '2', '31.45', '31.45', '1', '2016-04-22 17:00:52');
INSERT INTO `iot_device_log` VALUES ('6114', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 17:00:54');
INSERT INTO `iot_device_log` VALUES ('6115', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 17:00:56');
INSERT INTO `iot_device_log` VALUES ('6116', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 17:00:58');
INSERT INTO `iot_device_log` VALUES ('6117', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 17:00:59');
INSERT INTO `iot_device_log` VALUES ('6118', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 17:01:08');
INSERT INTO `iot_device_log` VALUES ('6119', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 17:01:10');
INSERT INTO `iot_device_log` VALUES ('6120', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 17:01:15');
INSERT INTO `iot_device_log` VALUES ('6121', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 17:01:31');
INSERT INTO `iot_device_log` VALUES ('6122', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 17:01:33');
INSERT INTO `iot_device_log` VALUES ('6123', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 17:01:36');
INSERT INTO `iot_device_log` VALUES ('6124', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 17:04:09');
INSERT INTO `iot_device_log` VALUES ('6125', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 17:04:11');
INSERT INTO `iot_device_log` VALUES ('6126', '22', 'BUTTON_PUSH', '3', '1', '1', '1', '2016-04-22 17:04:13');
INSERT INTO `iot_device_log` VALUES ('6127', '22', 'BUTTON_PUSH', '3', '2', '2', '1', '2016-04-22 17:04:17');
INSERT INTO `iot_device_log` VALUES ('6128', '22', 'BUTTON_PUSH', '3', '4', '4', '1', '2016-04-22 17:04:22');

-- -----------------------------
-- Table structure for `iot_device_mac`
-- -----------------------------
DROP TABLE IF EXISTS `iot_device_mac`;
CREATE TABLE `iot_device_mac` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_sn` varchar(32) NOT NULL,
  `device_mac` varchar(32) NOT NULL,
  `product_id` int(11) NOT NULL,
  `device_wifi_mod` char(10) DEFAULT NULL,
  `device_produce_batch` char(10) DEFAULT NULL,
  `register_flg` char(10) DEFAULT NULL,
  `update_userid` char(10) DEFAULT NULL,
  `update_timestamp` char(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_device_mac`
-- -----------------------------
INSERT INTO `iot_device_mac` VALUES ('5', 'TESTBYLUYUANXSWQAZ', 'TESTBYLUYUANXSWQAZ', '5', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('6', 'TEST4SICO6X2ST2POXUY', 'TEST4SICO6X2ST2POXUY', '8', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('7', 'TEST4LIGHT222XSS12S12', 'TEST4LIGHT222XSS12S12', '9', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('9', '18FE34ED8823', '18FE34ED8823', '9', '', '', '', '', '1460972150');
INSERT INTO `iot_device_mac` VALUES ('10', '18FE349D82A3', '18FE349D82A3', '10', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('11', '18FE34980402', '18FE34980402', '9', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('12', '18FE349EC5AB', '18FE349EC5AB', '9', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('13', '18FE34A107FA', '18FE34A107FA', '9', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('14', '18FE3497EC7C', '18FE3497EC7C', '11', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('15', '1AFE34FA026D', '1AFE34FA026D', '12', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('16', '18FE34FA026D', '18FE34FA026D', '12', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('17', '18FE34A1090C', '18FE34A1090C', '9', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('18', '18FE34A108A0', '18FE34A108A0', '9', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('21', '18FE34F6715D', '18FE34F6715D', '10', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('20', '18FE34A1065B', '18FE34A1065B', '9', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('22', '18FE34A02543', '18FE34A02543', '9', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('23', '18FE34A107E3', '18FE34A107E3', '9', '', '', '', '', '');
INSERT INTO `iot_device_mac` VALUES ('24', '18FE349EC967', '18FE349EC967', '9', '', '', '', '', '');

-- -----------------------------
-- Table structure for `iot_device_mac_file`
-- -----------------------------
DROP TABLE IF EXISTS `iot_device_mac_file`;
CREATE TABLE `iot_device_mac_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) DEFAULT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_device_user`
-- -----------------------------
DROP TABLE IF EXISTS `iot_device_user`;
CREATE TABLE `iot_device_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `auth_level` char(10) DEFAULT NULL,
  `relation_type` tinyint(4) NOT NULL,
  `reg_time` char(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=159 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_device_user`
-- -----------------------------
INSERT INTO `iot_device_user` VALUES ('119', '23', '1', '', '2', '');
INSERT INTO `iot_device_user` VALUES ('117', '24', '1', '', '2', '');
INSERT INTO `iot_device_user` VALUES ('120', '21', '1', '', '2', '');
INSERT INTO `iot_device_user` VALUES ('126', '22', '1', '', '2', '');
INSERT INTO `iot_device_user` VALUES ('118', '25', '1', '', '2', '');
INSERT INTO `iot_device_user` VALUES ('138', '25', '106', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('148', '24', '106', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('125', '20', '1', '', '2', '');
INSERT INTO `iot_device_user` VALUES ('147', '23', '106', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('146', '20', '106', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('151', '20', '109', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('134', '21', '100', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('135', '20', '100', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('136', '21', '106', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('145', '22', '106', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('152', '23', '109', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('153', '24', '109', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('158', '26', '1', '', '2', '');
INSERT INTO `iot_device_user` VALUES ('155', '25', '109', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('156', '21', '109', '', '3', '');
INSERT INTO `iot_device_user` VALUES ('157', '22', '109', '', '3', '');

-- -----------------------------
-- Table structure for `iot_digital_parse_rule`
-- -----------------------------
DROP TABLE IF EXISTS `iot_digital_parse_rule`;
CREATE TABLE `iot_digital_parse_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `metadata_id` int(11) NOT NULL,
  `part_no` int(11) NOT NULL,
  `part_type` varchar(16) NOT NULL,
  `part_length` int(11) NOT NULL,
  `part_value` varchar(16) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_metadata_parse_relation` (`metadata_id`),
  KEY `FK_product_parse_rule` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=239 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_digital_parse_rule`
-- -----------------------------
INSERT INTO `iot_digital_parse_rule` VALUES ('172', '5', '7', '4', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('178', '5', '6', '5', 'chksum', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('177', '5', '6', '4', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('176', '5', '6', '3', 'content', '4', '0000', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('175', '5', '6', '2', 'command', '4', '1101', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('174', '5', '6', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('111', '8', '5', '6', 'chksum', '2', '', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('110', '8', '5', '5', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('109', '8', '5', '4', 'content', '2', '', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('108', '8', '5', '3', 'length', '2', '', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('107', '8', '5', '2', 'command', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('106', '8', '5', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('183', '5', '5', '5', 'chksum', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('182', '5', '5', '4', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('181', '5', '5', '3', 'content', '4', '1100', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('180', '5', '5', '2', 'command', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('179', '5', '5', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('171', '5', '7', '3', 'content', '4', '0000', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('170', '5', '7', '2', 'command', '4', '1100', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('169', '5', '7', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('154', '5', '8', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('155', '5', '8', '2', 'command', '4', '1011', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('156', '5', '8', '3', 'content', '4', '0000', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('157', '5', '8', '4', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('158', '5', '8', '5', 'chksum', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('167', '5', '10', '4', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('166', '5', '10', '3', 'content', '4', '0000', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('165', '5', '10', '2', 'command', '4', '1111', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('164', '5', '10', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('168', '5', '10', '5', 'chksum', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('173', '5', '7', '5', 'chksum', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('191', '8', '12', '3', 'content', '4', '0001', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('190', '8', '12', '2', 'command', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('189', '8', '12', '1', 'head', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('192', '8', '12', '4', 'chksum', '2', '02', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('193', '8', '12', '5', 'tail', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('194', '8', '13', '1', 'head', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('195', '8', '13', '2', 'command', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('196', '8', '13', '3', 'content', '4', '0000', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('197', '8', '13', '4', 'chksum', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('198', '8', '13', '5', 'tail', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('199', '8', '14', '1', 'head', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('200', '8', '14', '2', 'command', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('201', '8', '14', '3', 'content', '4', '0001', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('202', '8', '14', '4', 'chksum', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('203', '8', '14', '5', 'tail', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('223', '8', '7', '5', 'tail', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('222', '8', '7', '4', 'chksum', '2', 'XX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('221', '8', '7', '3', 'content', '4', 'XXXX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('220', '8', '7', '2', 'command', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('219', '8', '7', '1', 'head', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('214', '8', '6', '1', 'head', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('215', '8', '6', '2', 'command', '2', '0A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('216', '8', '6', '3', 'content', '4', 'XXXX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('217', '8', '6', '4', 'chksum', '2', 'XX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('218', '8', '6', '5', 'tail', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('224', '8', '15', '1', 'head', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('225', '8', '15', '2', 'command', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('226', '8', '15', '3', 'content', '4', '000A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('227', '8', '15', '4', 'chksum', '2', '0A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('228', '8', '15', '5', 'tail', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('229', '8', '16', '1', 'head', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('230', '8', '16', '2', 'command', '2', '0C', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('231', '8', '16', '3', 'content', '4', 'XXXX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('232', '8', '16', '4', 'chksum', '2', 'XX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('233', '8', '16', '5', 'tail', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('234', '8', '17', '1', 'head', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('235', '8', '17', '2', 'command', '2', '02', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('236', '8', '17', '3', 'content', '4', '0001', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('237', '8', '17', '4', 'chksum', '2', '03', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('238', '8', '17', '5', 'tail', '2', '55', '0', '0', '0');

-- -----------------------------
-- Table structure for `iot_engine_action`
-- -----------------------------
DROP TABLE IF EXISTS `iot_engine_action`;
CREATE TABLE `iot_engine_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine_id` int(11) NOT NULL,
  `device_mac` varchar(32) DEFAULT NULL,
  `md_code` varchar(32) DEFAULT NULL,
  `eigen_value` varchar(256) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_engine_action`
-- -----------------------------
INSERT INTO `iot_engine_action` VALUES ('5', '5', '18FE34A107FA', 'POWER_ON', '', '1', '2016-04-20 15:27:18', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('6', '6', '18FE34A1090C', 'POWER_OFF', '{\"rgb\":{\"red\":50,\"green\":500,\"blue\":100,\"white\":100}}', '1', '2016-04-21 18:53:10', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('7', '5', '18FE34A108A0', 'POWER_ON', '', '2', '2016-04-21 18:50:05', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('8', '6', '18FE34A107FA', 'POWER_OFF', '', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('9', '5', '18FE34A1090C', 'POWER_ON', '', '3', '2016-04-21 18:50:14', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('10', '6', '18FE34A108A0', 'POWER_OFF', '', '0', '2016-04-21 18:50:42', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('11', '7', '18FE34A107FA', 'POWER_ON', '', '1', '2016-04-21 15:40:01', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('12', '7', '18FE34A108A0', 'POWER_ON', '', '2', '2016-04-21 18:54:22', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('13', '8', '18FE34A107FA', 'POWER_OFF', '', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('14', '8', '18FE34A108A0', 'POWER_OFF', '', '2', '2016-04-21 18:53:51', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('15', '9', '18FE34A107FA', 'LIGHT_COLOR', 'class:Product\\Common\\LightColorGenerator', '1', '2016-04-21 19:00:18', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('16', '8', '18FE34A1090C', 'LIGHT_COLOR', '{\"rgb\":{\"red\":50,\"green\":500,\"blue\":100,\"white\":100}}', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('17', '7', '18FE34A1090C', 'POWER_ON', '', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('18', '9', '18FE34A1090C', 'LIGHT_COLOR', 'class:Product\\Common\\LightColorGenerator', '2', '2016-04-21 19:00:13', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('19', '9', '18FE34A108A0', 'LIGHT_COLOR', 'class:Product\\Common\\LightColorGenerator', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_action` VALUES ('20', '10', '18FE34A1065B', 'LIGHT_COLOR', 'class:Product\\Common\\LightColorGenerator', '0', '2016-04-22 13:28:21', '0000-00-00 00:00:00');

-- -----------------------------
-- Table structure for `iot_engine_condition`
-- -----------------------------
DROP TABLE IF EXISTS `iot_engine_condition`;
CREATE TABLE `iot_engine_condition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine_id` int(11) NOT NULL,
  `device_mac` varchar(32) DEFAULT NULL,
  `md_code` varchar(32) DEFAULT NULL,
  `eigen_value` varchar(256) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_engine_condition`
-- -----------------------------
INSERT INTO `iot_engine_condition` VALUES ('5', '7', '18FE34FA026D', 'BUTTON_PUSH', '1', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_condition` VALUES ('6', '8', '18FE34FA026D', 'BUTTON_PUSH', '2', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_condition` VALUES ('7', '9', '18FE34FA026D', 'BUTTON_PUSH', '3', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `iot_engine_condition` VALUES ('8', '10', '18FE34FA026D', 'BUTTON_PUSH', '4', '0', '2016-04-22 13:29:20', '0000-00-00 00:00:00');

-- -----------------------------
-- Table structure for `iot_field`
-- -----------------------------
DROP TABLE IF EXISTS `iot_field`;
CREATE TABLE `iot_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `field_data` varchar(1000) NOT NULL,
  `createTime` int(11) NOT NULL,
  `changeTime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_field_group`
-- -----------------------------
DROP TABLE IF EXISTS `iot_field_group`;
CREATE TABLE `iot_field_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_name` varchar(25) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `createTime` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `visiable` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_field_group`
-- -----------------------------
INSERT INTO `iot_field_group` VALUES ('1', '个人资料', '1', '1403847366', '0', '1');
INSERT INTO `iot_field_group` VALUES ('2', '开发者资料', '1', '1423537648', '0', '0');
INSERT INTO `iot_field_group` VALUES ('3', '开源中国资料', '1', '1423538446', '0', '0');

-- -----------------------------
-- Table structure for `iot_field_setting`
-- -----------------------------
DROP TABLE IF EXISTS `iot_field_setting`;
CREATE TABLE `iot_field_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_name` varchar(25) NOT NULL,
  `profile_group_id` int(11) NOT NULL,
  `visiable` tinyint(4) NOT NULL DEFAULT '1',
  `required` tinyint(4) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL,
  `form_type` varchar(25) NOT NULL,
  `form_default_value` varchar(200) NOT NULL,
  `validation` varchar(25) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `createTime` int(11) NOT NULL,
  `child_form_type` varchar(25) NOT NULL,
  `input_tips` varchar(100) NOT NULL COMMENT '输入提示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_field_setting`
-- -----------------------------
INSERT INTO `iot_field_setting` VALUES ('1', 'qq', '1', '1', '1', '0', 'input', '', '', '1', '1409045825', 'string', '');
INSERT INTO `iot_field_setting` VALUES ('2', '生日', '1', '1', '1', '0', 'time', '', '', '1', '1423537409', '', '');
INSERT INTO `iot_field_setting` VALUES ('3', '擅长语言', '2', '1', '1', '0', 'select', 'Java|C++|Python|php|object c|ruby', '', '1', '1423537693', '', '');
INSERT INTO `iot_field_setting` VALUES ('4', '承接项目', '2', '1', '1', '0', 'radio', '是|否', '', '1', '1423537733', '', '');
INSERT INTO `iot_field_setting` VALUES ('5', '简介', '2', '1', '1', '0', 'textarea', '', '', '1', '1423537770', '', '简单介绍入行以来的工作经验，项目经验');
INSERT INTO `iot_field_setting` VALUES ('6', '其他技能', '2', '1', '1', '0', 'checkbox', 'PhotoShop|Flash', '', '1', '1423537834', '', '');
INSERT INTO `iot_field_setting` VALUES ('7', '昵称', '3', '1', '1', '0', 'input', '', '', '1', '1423704462', 'string', 'OSC账号昵称');

-- -----------------------------
-- Table structure for `iot_file`
-- -----------------------------
DROP TABLE IF EXISTS `iot_file`;
CREATE TABLE `iot_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  `driver` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `iot_file`
-- -----------------------------
INSERT INTO `iot_file` VALUES ('1', '566ecaefaf3d1.txt', '566ecaefaf3d1.txt', '2015-12-14/', 'txt', 'text/plain', '251', '712b95c8fa2b2ef36ed9010c2a49e393', 'bd9de20cff667f585d4e5a21ca6b2c4fbe48093d', '0', '1450101487', 'local');
INSERT INTO `iot_file` VALUES ('2', '566ecb5839503.txt', '566ecb5839503.txt', '2015-12-14/', 'txt', 'text/plain', '255', 'f6246fbf48e1d322747d7c0ebaa8fc75', 'e180a60c1ed03677283b29db844f7546d9abd8b3', '0', '1450101592', 'local');
INSERT INTO `iot_file` VALUES ('3', '56721c429b3ce.zip', '56721c429b3ce.zip', '2015-12-17/', 'zip', 'application/x-zip-compressed', '1037', '4b54f8e34af240e9b8b5ebd648238b26', '43e3138d1933b92b1839320c4eadeac9fe385635', '0', '1450318914', 'local');
INSERT INTO `iot_file` VALUES ('4', '56933ce6a6913.txt', '56933ce6a6913.txt', '2016-01-11/', 'txt', 'text/plain', '1312', '427c1104cc365b289dc14e19c7928aed', '776ec22650113cbcb8161b8182126c0e453fc23d', '0', '1452489958', 'local');
INSERT INTO `iot_file` VALUES ('5', '56933cf59c6c3.txt', '56933cf59c6c3.txt', '2016-01-11/', 'txt', 'text/plain', '758', '9bd17a93cdedad5734fa98ac0fc142fb', '8aa70fd5619858f7f58500d6bf2ff9303712b569', '0', '1452489973', 'local');
INSERT INTO `iot_file` VALUES ('6', '57217706e7e6c.txt', '57217706e7e6c.txt', '2016-04-28/', 'txt', 'text/plain', '588', '8d1002587309036f97bcdd3807b833cf', '7784f8312d943bd32ee34e06cf95bee20cf31dc2', '0', '1461810950', 'local');
INSERT INTO `iot_file` VALUES ('7', '5721902d41006.txt', '5721902d41006.txt', '2016-04-28/', 'txt', 'text/plain', '9', '19538aeadc43b2529f303b635a376a73', '6de9e8f57e221271055f855985092e81507dc6a8', '0', '1461817389', 'local');

-- -----------------------------
-- Table structure for `iot_follow`
-- -----------------------------
DROP TABLE IF EXISTS `iot_follow`;
CREATE TABLE `iot_follow` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `follow_who` int(11) NOT NULL COMMENT '关注谁',
  `who_follow` int(11) NOT NULL COMMENT '谁关注',
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='关注表';


-- -----------------------------
-- Table structure for `iot_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `iot_hooks`;
CREATE TABLE `iot_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_hooks`
-- -----------------------------
INSERT INTO `iot_hooks` VALUES ('38', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '');
INSERT INTO `iot_hooks` VALUES ('39', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'SuperLinks');
INSERT INTO `iot_hooks` VALUES ('40', 'adminEditor', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin');
INSERT INTO `iot_hooks` VALUES ('41', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SyncLogin,DevTeam,SystemInfo');
INSERT INTO `iot_hooks` VALUES ('42', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', '');
INSERT INTO `iot_hooks` VALUES ('43', 'app_begin', '应用开始', '2', '1384481614', 'Iswaf');
INSERT INTO `iot_hooks` VALUES ('44', 'checkIn', '签到', '1', '1395371353', '');
INSERT INTO `iot_hooks` VALUES ('45', 'Rank', '签到排名钩子', '1', '1395387442', 'Rank_checkin');
INSERT INTO `iot_hooks` VALUES ('46', 'support', '赞', '1', '1398264759', '');
INSERT INTO `iot_hooks` VALUES ('47', 'localComment', '本地评论插件', '1', '1399440321', 'LocalComment');
INSERT INTO `iot_hooks` VALUES ('48', 'weiboType', '微博类型', '1', '1409121894', '');
INSERT INTO `iot_hooks` VALUES ('49', 'repost', '转发钩子', '1', '1403668286', '');
INSERT INTO `iot_hooks` VALUES ('50', 'syncLogin', '第三方登陆位置', '1', '1403700579', 'SyncLogin');
INSERT INTO `iot_hooks` VALUES ('51', 'syncMeta', '第三方登陆meta接口', '1', '1403700633', 'SyncLogin');
INSERT INTO `iot_hooks` VALUES ('52', 'J_China_City', '每个系统都需要的一个中国省市区三级联动插件。', '1', '1403841931', 'ChinaCity');
INSERT INTO `iot_hooks` VALUES ('53', 'Advs', '广告位插件', '1', '1406687667', '');
INSERT INTO `iot_hooks` VALUES ('54', 'imageSlider', '图片轮播钩子', '1', '1407144022', '');
INSERT INTO `iot_hooks` VALUES ('55', 'friendLink', '友情链接插件', '1', '1407156413', 'SuperLinks');
INSERT INTO `iot_hooks` VALUES ('56', 'beforeSendWeibo', '在发微博之前预处理微博', '2', '1408084504', 'InsertFile');
INSERT INTO `iot_hooks` VALUES ('57', 'beforeSendRepost', '转发微博前的预处理钩子', '2', '1408085689', '');
INSERT INTO `iot_hooks` VALUES ('58', 'parseWeiboContent', '解析微博内容钩子', '2', '1409121261', '');
INSERT INTO `iot_hooks` VALUES ('59', 'userConfig', '用户配置页面钩子', '1', '1417137557', 'SyncLogin');
INSERT INTO `iot_hooks` VALUES ('60', 'weiboSide', '微博侧边钩子', '1', '1417063425', 'Retopic');
INSERT INTO `iot_hooks` VALUES ('61', 'personalMenus', '顶部导航栏个人下拉菜单', '1', '1417146501', '');
INSERT INTO `iot_hooks` VALUES ('62', 'dealPicture', '上传图片处理', '2', '1417139975', '');
INSERT INTO `iot_hooks` VALUES ('63', 'ucenterSideMenu', '用户中心左侧菜单', '1', '1417161205', '');
INSERT INTO `iot_hooks` VALUES ('64', 'afterTop', '顶部导航之后的钩子，调用公告等', '1', '1429671392', '');

-- -----------------------------
-- Table structure for `iot_invite`
-- -----------------------------
DROP TABLE IF EXISTS `iot_invite`;
CREATE TABLE `iot_invite` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY_KEY',
  `invite_type` int(11) NOT NULL COMMENT '邀请类型id',
  `code` varchar(25) NOT NULL COMMENT '邀请码',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `can_num` int(10) NOT NULL COMMENT '可以注册用户（含升级）',
  `already_num` int(10) NOT NULL COMMENT '已经注册用户（含升级）',
  `end_time` int(11) NOT NULL COMMENT '有效期至',
  `status` tinyint(2) NOT NULL COMMENT '0：已用完，1：还可注册，2：用户取消邀请，-1：管理员删除',
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邀请码表';


-- -----------------------------
-- Table structure for `iot_invite_buy_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_invite_buy_log`;
CREATE TABLE `iot_invite_buy_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY_KEY',
  `invite_type` int(11) NOT NULL COMMENT '邀请类型id',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `num` int(10) NOT NULL COMMENT '可邀请名额',
  `content` varchar(200) NOT NULL COMMENT '记录信息',
  `create_time` int(11) NOT NULL COMMENT '创建时间（做频率用）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户购买邀请名额记录';


-- -----------------------------
-- Table structure for `iot_invite_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_invite_log`;
CREATE TABLE `iot_invite_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY_KEY',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `inviter_id` int(11) NOT NULL COMMENT '邀请人id',
  `invite_id` int(11) NOT NULL COMMENT '邀请码id',
  `content` varchar(200) NOT NULL COMMENT '记录内容',
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邀请注册成功记录表';


-- -----------------------------
-- Table structure for `iot_invite_type`
-- -----------------------------
DROP TABLE IF EXISTS `iot_invite_type`;
CREATE TABLE `iot_invite_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY_KEY',
  `title` varchar(25) NOT NULL COMMENT '标题',
  `length` int(10) NOT NULL DEFAULT '11' COMMENT '验证码长度',
  `time` varchar(50) NOT NULL COMMENT '有效时长，带单位的时间',
  `cycle_num` int(10) NOT NULL COMMENT '周期内可购买个数',
  `cycle_time` varchar(50) NOT NULL COMMENT '周期时长，带单位的时间',
  `roles` varchar(50) NOT NULL COMMENT '绑定角色ids',
  `auth_groups` varchar(50) NOT NULL COMMENT '允许购买的用户组ids',
  `pay_score` int(10) NOT NULL COMMENT '购买消耗积分',
  `pay_score_type` int(11) NOT NULL COMMENT '购买消耗积分类型',
  `income_score` int(10) NOT NULL COMMENT '每邀请成功一个用户，邀请者增加积分',
  `income_score_type` int(11) NOT NULL COMMENT '邀请成功后增加积分类型id',
  `is_follow` tinyint(2) NOT NULL COMMENT '邀请成功后是否互相关注',
  `status` tinyint(2) NOT NULL,
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  `update_time` int(11) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邀请注册码类型表';


-- -----------------------------
-- Table structure for `iot_invite_user_info`
-- -----------------------------
DROP TABLE IF EXISTS `iot_invite_user_info`;
CREATE TABLE `iot_invite_user_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY_KEY',
  `invite_type` int(11) NOT NULL COMMENT '邀请类型id',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `num` int(11) NOT NULL COMMENT '可邀请名额',
  `already_num` int(11) NOT NULL COMMENT '已邀请名额',
  `success_num` int(11) NOT NULL COMMENT '成功邀请名额',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邀请注册用户信息';


-- -----------------------------
-- Table structure for `iot_local_comment`
-- -----------------------------
DROP TABLE IF EXISTS `iot_local_comment`;
CREATE TABLE `iot_local_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `app` text NOT NULL,
  `mod` text NOT NULL,
  `row_id` int(11) NOT NULL,
  `parse` int(11) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `create_time` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_member`
-- -----------------------------
DROP TABLE IF EXISTS `iot_member`;
CREATE TABLE `iot_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(32) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  `last_login_role` int(11) NOT NULL,
  `show_role` int(11) NOT NULL COMMENT '个人主页显示角色',
  `signature` text NOT NULL,
  `pos_province` int(11) NOT NULL,
  `pos_city` int(11) NOT NULL,
  `pos_district` int(11) NOT NULL,
  `pos_community` int(11) NOT NULL,
  `score1` float DEFAULT '0' COMMENT '用户积分',
  `score2` float DEFAULT '0' COMMENT 'score2',
  `score3` float DEFAULT '0' COMMENT 'score3',
  `score4` float DEFAULT '0' COMMENT 'score4',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`),
  KEY `name` (`nickname`)
) ENGINE=MyISAM AUTO_INCREMENT=110 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `iot_member`
-- -----------------------------
INSERT INTO `iot_member` VALUES ('1', 'admin', '0', '0000-00-00', '', '90', '0', '1450079699', '1780875274', '1462328332', '1', '0', '0', '', '0', '0', '0', '0', '10', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('100', 'test', '0', '0000-00-00', '', '10', '0', '1450703702', '1022852494', '1452485216', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('101', 'luyuan', '0', '0000-00-00', '', '0', '0', '1450704396', '0', '0', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('102', 'qinhao', '0', '0000-00-00', '', '1', '0', '1451026953', '0', '1451027282', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('103', 'yuhai', '0', '0000-00-00', '', '0', '0', '1451027516', '0', '0', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('104', 'testqq', '0', '0000-00-00', '', '0', '1022852504', '1460081415', '0', '0', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('105', '瓢虫235', '0', '0000-00-00', '', '0', '1022848972', '1460689517', '0', '0', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('106', 'sicon', '0', '0000-00-00', '', '0', '1022848972', '1460713722', '0', '0', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('107', 'sicon001', '0', '0000-00-00', '', '0', '3546230162', '1461209391', '0', '0', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('108', '瓢虫', '0', '0000-00-00', '', '0', '3748136431', '1461292334', '0', '0', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('109', 'chenyux', '0', '0000-00-00', '', '0', '3748136426', '1461314384', '0', '0', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `iot_menu`
-- -----------------------------
DROP TABLE IF EXISTS `iot_menu`;
CREATE TABLE `iot_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `icon` varchar(20) DEFAULT NULL COMMENT '导航图标',
  `module` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=360 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_menu`
-- -----------------------------
INSERT INTO `iot_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0', 'home', '');
INSERT INTO `iot_menu` VALUES ('2', '用户', '0', '2', 'User/index', '0', '', '', '0', 'user', '');
INSERT INTO `iot_menu` VALUES ('3', '用户信息', '2', '0', 'User/index', '0', '', '用户管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('4', '用户行为', '2', '0', 'User/action', '0', '', '行为管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('5', '新增用户行为', '4', '0', 'User/addaction', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('6', '编辑用户行为', '4', '0', 'User/editaction', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('7', '保存用户行为', '4', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('8', '变更行为状态', '4', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('9', '禁用会员', '4', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('10', '启用会员', '4', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('11', '删除会员', '4', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('12', '权限管理', '2', '0', 'AuthManager/index', '0', '', '权限管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('13', '删除', '12', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('14', '禁用', '12', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('15', '恢复', '12', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('16', '新增', '12', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('17', '编辑', '12', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('18', '保存用户组', '12', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('19', '授权', '12', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('20', '访问授权', '12', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('21', '成员授权', '12', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('22', '解除授权', '12', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('23', '保存成员授权', '12', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('24', '分类授权', '12', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('25', '保存分类授权', '12', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('26', '模型授权', '12', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('27', '保存模型授权', '12', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('28', '新增权限节点', '12', '0', 'AuthManager/addNode', '1', '', '', '1', '', '');
INSERT INTO `iot_menu` VALUES ('29', '前台权限管理', '12', '0', 'AuthManager/accessUser', '1', '', '权限管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('30', '删除权限节点', '12', '0', 'AuthManager/deleteNode', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('31', '行为日志', '2', '0', 'Action/actionlog', '0', '', '行为管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('32', '查看行为日志', '31', '0', 'action/edit', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('33', '修改密码', '2', '0', 'User/updatePassword', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('34', '修改昵称', '2', '0', 'User/updateNickname', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('35', '查看用户', '2', '0', 'Rank/userList', '1', '', '头衔管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('36', '用户头衔列表', '35', '0', 'Rank/userRankList', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('37', '关联新头衔', '35', '0', 'Rank/userAddRank', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('38', '编辑头衔关联', '35', '0', 'Rank/userChangeRank', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('39', '扩展资料', '2', '0', 'Admin/User/profile', '0', '', '用户管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('40', '添加、编辑分组', '39', '0', 'Admin/User/editProfile', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('41', '分组排序', '39', '0', 'Admin/User/sortProfile', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('42', '字段列表', '39', '0', 'Admin/User/field', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('43', '添加、编辑字段', '39', '0', 'Admin/User/editFieldSetting', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('44', '字段排序', '39', '0', 'Admin/User/sortField', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('45', '用户扩展资料列表', '2', '0', 'Admin/User/expandinfo_select', '0', '', '用户管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('46', '扩展资料详情', '45', '0', 'User/expandinfo_details', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('47', '待审核用户头衔', '2', '0', 'Rank/rankVerify', '1', '', '头衔管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('48', '被驳回的头衔申请', '2', '0', 'Rank/rankVerifyFailure', '1', '', '头衔管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('49', '转移用户组', '2', '0', 'User/changeGroup', '1', '批量转移用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('50', '用户注册配置', '2', '0', 'UserConfig/index', '0', '', '注册配置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('51', '积分类型列表', '2', '0', 'User/scoreList', '0', '', '行为管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('52', '新增/编辑类型', '2', '0', 'user/editScoreType', '1', '', '行为管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('53', '充值积分', '2', '0', 'user/recharge', '1', '', '', '0', '用户管理', '');
INSERT INTO `iot_menu` VALUES ('54', '头衔列表', '2', '10', 'Rank/index', '1', '', '头衔管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('55', '添加头衔', '2', '2', 'Rank/editRank', '1', '', '头衔管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('56', '插件', '0', '5', 'Addons/index', '1', '', '', '0', 'cogs', '');
INSERT INTO `iot_menu` VALUES ('57', '插件管理', '56', '1', 'Addons/index', '0', '', '扩展', '0', '', '');
INSERT INTO `iot_menu` VALUES ('58', '钩子管理', '56', '2', 'Addons/hooks', '0', '', '扩展', '0', '', '');
INSERT INTO `iot_menu` VALUES ('59', '创建', '57', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('60', '检测创建', '57', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('61', '预览', '57', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('62', '快速生成插件', '57', '0', 'Addons/build', '0', '开始生成插件结构', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('64', '设置', '57', '0', 'Addons/config', '0', '设置插件配置', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('65', '禁用', '57', '0', 'Addons/disable', '0', '禁用插件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('66', '启用', '57', '0', 'Addons/enable', '0', '启用插件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('67', '安装', '57', '0', 'Addons/install', '0', '安装插件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('68', '卸载', '57', '0', 'Addons/uninstall', '0', '卸载插件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('69', '更新配置', '57', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('70', '插件后台列表', '57', '0', 'Addons/adminList', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('71', 'URL方式访问插件', '57', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('72', '新增钩子', '58', '0', 'Addons/addHook', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('73', '编辑钩子', '58', '0', 'Addons/edithook', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('74', '系统', '0', '6', 'Config/group', '0', '', '', '0', 'windows', '');
INSERT INTO `iot_menu` VALUES ('75', '网站设置', '74', '1', 'Config/group', '0', '', '系统设置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('76', '配置管理', '74', '4', 'Config/index', '0', '', '系统设置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('77', '编辑', '76', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('78', '删除', '76', '0', 'Config/del', '0', '删除配置', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('79', '新增', '76', '0', 'Config/add', '0', '新增配置', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('80', '保存', '76', '0', 'Config/save', '0', '保存配置', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('81', '排序', '76', '0', 'Config/sort', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('82', '菜单管理', '2', '5', 'Menu/index', '0', '', '权限管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('83', '新增', '82', '0', 'Menu/add', '0', '', '系统设置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('84', '编辑', '82', '0', 'Menu/edit', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('85', '导入', '82', '0', 'Menu/import', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('86', '排序', '82', '0', 'Menu/sort', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('87', '导航管理', '74', '6', 'Channel/index', '0', '', '系统设置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('88', '新增', '87', '0', 'Channel/add', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('89', '编辑', '87', '0', 'Channel/edit', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('90', '删除', '87', '0', 'Channel/del', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('91', '排序', '87', '0', 'Channel/sort', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('92', '备份数据库', '74', '20', 'Database/index?type=export', '0', '', '数据备份', '0', '', '');
INSERT INTO `iot_menu` VALUES ('93', '备份', '92', '0', 'Database/export', '0', '备份数据库', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('94', '优化表', '92', '0', 'Database/optimize', '0', '优化数据表', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('95', '修复表', '92', '0', 'Database/repair', '0', '修复数据表', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('96', '还原数据库', '74', '0', 'Database/index?type=import', '0', '', '数据备份', '0', '', '');
INSERT INTO `iot_menu` VALUES ('97', '恢复', '96', '0', 'Database/import', '0', '数据库恢复', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('98', '删除', '96', '0', 'Database/del', '0', '删除备份文件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('99', 'SEO规则管理', '74', '0', 'SEO/index', '0', '', 'SEO规则', '0', '', '');
INSERT INTO `iot_menu` VALUES ('100', '新增、编辑', '99', '0', 'SEO/editRule', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('101', '排序', '99', '0', 'SEO/sortRule', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('102', 'SEO规则回收站', '74', '0', 'SEO/ruleTrash', '0', '', 'SEO规则', '0', '', '');
INSERT INTO `iot_menu` VALUES ('103', '全部补丁', '74', '0', 'Admin/Update/quick', '0', '', '升级补丁', '0', '', '');
INSERT INTO `iot_menu` VALUES ('104', '新增补丁', '74', '0', 'Admin/Update/addpack', '1', '', '升级补丁', '0', '', '');
INSERT INTO `iot_menu` VALUES ('105', '云市场', '0', '5', 'module/lists', '1', '', '', '0', 'cloud', '');
INSERT INTO `iot_menu` VALUES ('106', '模块安装', '105', '0', 'module/install', '1', '', '云市场', '0', '', '');
INSERT INTO `iot_menu` VALUES ('107', '模块管理', '105', '0', 'module/lists', '0', '', '云市场', '0', '', '');
INSERT INTO `iot_menu` VALUES ('108', '卸载模块', '105', '0', 'module/uninstall', '1', '', '云市场', '0', '', '');
INSERT INTO `iot_menu` VALUES ('109', '授权', '0', '3', 'authorize/ssoSetting', '0', '', '', '0', 'lock', '');
INSERT INTO `iot_menu` VALUES ('110', '单点登录配置', '109', '0', 'Authorize/ssoSetting', '0', '', '单点登录', '0', '', '');
INSERT INTO `iot_menu` VALUES ('111', '应用列表', '109', '0', 'Authorize/ssolist', '0', '', '单点登录', '0', '', '');
INSERT INTO `iot_menu` VALUES ('112', '新增/编辑应用', '109', '0', 'authorize/editssoapp', '1', '', '单点登录', '0', '', '');
INSERT INTO `iot_menu` VALUES ('113', '安全', '0', '4', 'ActionLimit/limitList', '0', '', '', '0', 'shield', '');
INSERT INTO `iot_menu` VALUES ('114', '行为限制列表', '113', '0', 'ActionLimit/limitList', '0', '', '行为限制', '0', '', '');
INSERT INTO `iot_menu` VALUES ('115', '新增/编辑行为限制', '113', '0', 'ActionLimit/editLimit', '1', '', '行为限制', '0', '', '');
INSERT INTO `iot_menu` VALUES ('116', '角色', '0', '3', 'Role/index', '0', '', '', '0', 'group', '');
INSERT INTO `iot_menu` VALUES ('117', '角色列表', '116', '0', 'Role/index', '0', '', '角色管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('118', '编辑角色', '116', '0', 'Role/editRole', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('119', '启用、禁用、删除角色', '116', '0', 'Role/setStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('120', '角色排序', '116', '0', 'Role/sort', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('121', '默认积分配置', '117', '0', 'Role/configScore', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('122', '默认权限配置', '117', '0', 'Role/configAuth', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('123', '默认头像配置', '117', '0', 'Role/configAvatar', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('124', '默认头衔配置', '117', '0', 'Role/configRank', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('125', '默认字段管理', '117', '0', 'Role/configField', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('126', '角色分组', '116', '0', 'Role/group', '0', '', '角色管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('127', '编辑分组', '126', '0', 'Role/editGroup', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('128', '删除分组', '126', '0', 'Role/deleteGroup', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('129', '角色基本信息配置', '116', '0', 'Role/config', '1', '', '角色管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('130', '用户列表', '116', '0', 'Role/userList', '0', '', '角色用户管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('131', '设置用户状态', '130', '0', 'Role/setUserStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('132', '审核用户', '130', '0', 'Role/setUserAudit', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('133', '迁移用户', '130', '0', 'Role/changeRole', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('134', '上传默认头像', '123', '0', 'Role/uploadPicture', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('135', '类型管理', '116', '0', 'Invite/index', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('136', '邀请码管理', '116', '0', 'Invite/invite', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('137', '基础配置', '116', '0', 'Invite/config', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('138', '兑换记录', '116', '0', 'Invite/buyLog', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('139', '邀请记录', '116', '0', 'Invite/inviteLog', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('140', '用户信息', '116', '0', 'Invite/userInfo', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('141', '编辑邀请注册类型', '135', '0', 'Invite/edit', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('142', '删除邀请', '135', '0', 'Invite/setStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('143', '删除邀请码', '136', '0', 'Invite/delete', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('144', '生成邀请码', '136', '0', 'Invite/createCode', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('145', '删除无用邀请码', '136', '0', 'Invite/deleteTrue', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('146', '导出cvs', '136', '0', 'Invite/cvs', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('147', '用户信息编辑', '140', '0', 'Invite/editUserInfo', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('148', '删除日志', '31', '0', 'Action/remove', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('149', '清空日志', '31', '0', 'Action/clear', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('150', '设置积分状态', '51', '0', 'User/setTypeStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('151', '删除积分类型', '51', '0', 'User/delType', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('152', '充值积分', '53', '0', 'User/getNickname', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('153', '删除菜单', '82', '0', 'Menu/del', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('154', '设置开发者模式可见', '82', '0', 'Menu/toogleDev', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('155', '设置显示隐藏', '82', '0', 'Menu/toogleHide', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('156', '行为限制启用、禁用、删除', '114', '0', 'ActionLimit/setLimitStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('157', '启用、禁用、删除、回收站还原', '99', '0', 'SEO/setRuleStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('158', '回收站彻底删除', '102', '0', 'SEO/doClear', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('159', '初始化无角色用户', '130', '0', 'Role/initUnhaveUser', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('160', '删除钩子', '58', '0', 'Addons/delHook', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('161', '使用补丁', '103', '0', 'Update/usePack', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('162', '查看补丁', '103', '0', 'Update/view', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('163', '删除补丁', '103', '0', 'Update/delPack', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('164', '标签列表', '2', '0', 'UserTag/userTag', '1', '', '用户标签管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('165', '添加分类、标签', '164', '0', 'UserTag/add', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('166', '设置分类、标签状态', '164', '0', 'UserTag/setStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('167', '分类、标签回收站', '164', '0', 'UserTag/tagTrash', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('168', '测底删除回收站内容', '164', '0', 'UserTag/userTagClear', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('169', '可拥有标签配置', '116', '0', 'role/configusertag', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('170', '编辑模块', '107', '0', 'Module/edit', '1', '', '模块管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('171', '网站信息', '74', '0', 'Config/website', '0', '', '系统设置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('210', '智能硬件', '0', '60', 'Product/index', '0', '', '', '0', 'wrench', 'product');
INSERT INTO `iot_menu` VALUES ('211', '所有元数据', '210', '11', 'Product/metadatas', '0', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('212', '功能类', '211', '12', '/Product/metadatas/md_type/1', '0', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('213', '传感类', '211', '13', '/Product/metadatas/md_type/2', '0', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('214', '状态类', '211', '14', '/Product/metadatas/md_type/3', '0', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('215', '异常类', '211', '15', '/Product/metadatas/md_type/4', '0', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('216', '编辑传感类元素据', '211', '16', 'Product/editMetadata', '1', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('217', '产品管理', '210', '20', 'Product/index', '0', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('218', '产品添加修改', '217', '21', 'Product/addProduct', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('219', '日志配置列表', '217', '22', 'Product/listLogConfig', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('220', '日志配置修改', '217', '23', 'Product/addLogConfig', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('221', '产品元数据列表', '217', '25', 'Product/listMetadata', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('222', '产品导航', '210', '26', 'Product/wizard', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('223', '产品分类', '210', '27', 'Product/categories', '0', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('224', '产品分类编辑', '223', '28', 'Product/addCategories', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('225', '联网模组', '210', '31', 'Product/listConnectModule', '0', '', '固件管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('226', '模组添加修改', '225', '32', 'Product/addConnectModule', '1', '', '固件管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('227', '固件维护', '210', '33', 'Product/listFirmware', '0', '', '固件管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('228', '固件添加修改', '227', '34', 'Product/addFirmware', '1', '', '固件管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('229', '新增管理员', '2', '0', 'User/addNewAdmin', '0', '', '用户管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('230', '接口管理', '113', '60', 'OpenAPI/apiList', '0', '', '接口安全', '0', 'book', 'OpenAPI');
INSERT INTO `iot_menu` VALUES ('355', '编辑智能', '344', '31', 'Device/editSmartEngins', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('354', '设备智能', '344', '30', 'Device/listSmartEngins', '0', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('351', '设备日志', '344', '7', 'Device/listDeviceLog', '0', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('352', 'MAC文件上传', '344', '9', 'Device/uploadCSVfile', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('353', '设备用户', '344', '22', 'Device/listDeviceUser', '1', '', '设备授权', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('242', 'App管理', '0', '60', 'Appmgr/Appmgr', '1', '', '', '0', 'wrench', '');
INSERT INTO `iot_menu` VALUES ('267', 'App管理', '0', '60', 'Appmgr/Appmgr', '1', '', '', '0', 'wrench', '');
INSERT INTO `iot_menu` VALUES ('244', '新增APP', '242', '21', 'Appmgr/addAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('245', 'listAPP', '242', '22', 'Appmgr/listAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('246', 'removeAPP', '242', '23', 'Appmgr/removeAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('247', '消息管理', '242', '3', 'Appmgr/listSmsMessage', '0', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('248', 'listSmsMessage', '242', '31', 'Appmgr/listSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('249', '添加消息', '242', '32', 'Appmgr/addSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('275', 'App管理', '0', '60', 'Appmgr/Appmgr', '1', '', '', '0', 'wrench', '');
INSERT INTO `iot_menu` VALUES ('269', '新增APP', '267', '21', 'Appmgr/addAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('270', 'listAPP', '267', '22', 'Appmgr/listAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('271', 'removeAPP', '267', '23', 'Appmgr/removeAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('272', '消息管理', '267', '3', 'Appmgr/listSmsMessage', '0', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('273', 'listSmsMessage', '267', '31', 'Appmgr/listSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('274', '添加消息', '267', '32', 'Appmgr/addSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('293', 'App管理', '0', '60', 'Appmgr/Appmgr', '1', '', '', '0', 'wrench', '');
INSERT INTO `iot_menu` VALUES ('277', '新增APP', '275', '21', 'Appmgr/addAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('278', 'listAPP', '275', '22', 'Appmgr/listAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('279', 'removeAPP', '275', '23', 'Appmgr/removeAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('280', '消息管理', '275', '3', 'Appmgr/listSmsMessage', '0', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('281', 'listSmsMessage', '275', '31', 'Appmgr/listSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('282', '添加消息', '275', '32', 'Appmgr/addSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('350', '设备用户编辑', '344', '6', 'Device/editDeviceUser', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('294', 'App管理', '293', '2', 'Appmgr/index', '0', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('295', '新增APP', '293', '21', 'Appmgr/addAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('296', 'listAPP', '293', '22', 'Appmgr/listAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('297', 'removeAPP', '293', '23', 'Appmgr/removeAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('298', '消息管理', '293', '3', 'Appmgr/listSmsMessage', '0', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('299', 'listSmsMessage', '293', '31', 'Appmgr/listSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('300', '添加消息', '293', '32', 'Appmgr/addSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('349', '设备控制', '344', '4', 'Device/controlDevice', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('347', 'MAC地址添加', '344', '3', 'Device/addDeviceMac', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('346', 'MAC地址', '344', '1', 'Device/listDeviceMac', '0', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('345', '设备一览', '344', '1', 'Device/index', '0', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('344', '设备管理', '0', '55', 'Device/index', '1', '', '', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('356', '引擎条件', '344', '32', 'Device/listEnginCondtions', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('357', '编辑引擎条件', '344', '33', 'Device/editEnginCondtion', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('358', '引擎动作', '344', '34', 'Device/listEnginActions', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('359', '编辑引擎动作', '344', '35', 'Device/editEnginAction', '1', '', '设备管理', '0', '', 'device');

-- -----------------------------
-- Table structure for `iot_message`
-- -----------------------------
DROP TABLE IF EXISTS `iot_message`;
CREATE TABLE `iot_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_uid` int(11) NOT NULL,
  `to_uid` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `create_time` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '0系统消息,1用户消息,2应用消息',
  `is_read` tinyint(4) NOT NULL,
  `last_toast` int(11) NOT NULL,
  `url` varchar(400) NOT NULL,
  `talk_id` int(11) NOT NULL,
  `appname` varchar(30) NOT NULL,
  `apptype` varchar(30) NOT NULL,
  `source_id` int(11) NOT NULL,
  `find_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='thinkox新增消息表';


-- -----------------------------
-- Table structure for `iot_metadata`
-- -----------------------------
DROP TABLE IF EXISTS `iot_metadata`;
CREATE TABLE `iot_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `md_type` tinyint(4) NOT NULL,
  `md_code` varchar(16) NOT NULL,
  `md_name` varchar(32) NOT NULL,
  `md_value_type` varchar(16) NOT NULL,
  `md_scope` varchar(16) NOT NULL,
  `md_description` longtext,
  `md_owner_code` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_metadata`
-- -----------------------------
INSERT INTO `iot_metadata` VALUES ('5', '1', '1450082577', '1450082577', '1', 'POWER_ONOFF', '开关机', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('6', '1', '1452223402', '1452223402', '2', 'TEMPERATURE', '温度', '1', '1', '', 'admin');
INSERT INTO `iot_metadata` VALUES ('7', '1', '1452223456', '1452223456', '3', 'POWER_STATUS', '开关机状态', '3', '2', '', 'admin');
INSERT INTO `iot_metadata` VALUES ('8', '1', '1452654624', '1452654624', '1', 'SWITCH_MODE', '切换模式', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('9', '-1', '1452668946', '1452823288', '1', 'SWITCH_MODE', '切换模式', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('10', '1', '1452668984', '1452668984', '2', 'HUMIDITY', '湿度', '1', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('11', '1', '1452669115', '1452669183', '4', 'LOW_POWER', '电量不足', '2', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('12', '1', '1452821565', '1461233362', '1', 'POWER_ON', '开', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('13', '1', '1452821586', '1461233368', '1', 'POWER_OFF', '关', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('14', '1', '1452822333', '1452822333', '1', 'QUERY_POWER', '查询开关机状态', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('15', '1', '1452823240', '1452823240', '1', 'QUERY_TEMPERATUR', '查询温度', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('16', '1', '1452838803', '1452838803', '2', 'PM25', '空气指标', '1', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('17', '1', '1452841457', '1452841457', '1', 'OPEN_ION', '开启负离子', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('18', '1', '1460687110', '1460687110', '1', 'LIGHT_COLOR', '调整灯色', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('19', '1', '1461046289', '1461135515', '3', 'COLOR_RED', '灯红色值', '1', '2', '', '');
INSERT INTO `iot_metadata` VALUES ('20', '1', '1461144714', '1461144761', '3', 'BUTTON_1', '第一个按钮', '2', '2', '智能button的按钮', '');
INSERT INTO `iot_metadata` VALUES ('21', '1', '1461144749', '1461144749', '3', 'BUTTON_2', '第二个按钮', '2', '2', '', '');
INSERT INTO `iot_metadata` VALUES ('22', '1', '1461144786', '1461144786', '3', 'BUTTON_3', '第三个按钮', '2', '2', '', '');
INSERT INTO `iot_metadata` VALUES ('23', '1', '1461144808', '1461144808', '3', 'BUTTON_4', '第四个按钮', '0', '2', '', '');
INSERT INTO `iot_metadata` VALUES ('24', '1', '1461219266', '1461219266', '3', 'BUTTON_PUSH', '按钮点击', '1', '2', '', '');

-- -----------------------------
-- Table structure for `iot_module`
-- -----------------------------
DROP TABLE IF EXISTS `iot_module`;
CREATE TABLE `iot_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL COMMENT '模块名',
  `alias` varchar(30) NOT NULL COMMENT '中文名',
  `version` varchar(20) NOT NULL COMMENT '版本号',
  `is_com` tinyint(4) NOT NULL COMMENT '是否商业版',
  `show_nav` tinyint(4) NOT NULL COMMENT '是否显示在导航栏中',
  `summary` varchar(200) NOT NULL COMMENT '简介',
  `developer` varchar(50) NOT NULL COMMENT '开发者',
  `website` varchar(200) NOT NULL COMMENT '网址',
  `entry` varchar(50) NOT NULL COMMENT '前台入口',
  `is_setup` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否已安装',
  `sort` int(11) NOT NULL COMMENT '模块排序',
  `icon` varchar(20) NOT NULL,
  `can_uninstall` tinyint(4) NOT NULL,
  `admin_entry` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `name_2` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='模块管理表';

-- -----------------------------
-- Records of `iot_module`
-- -----------------------------
INSERT INTO `iot_module` VALUES ('1', 'Appmgr', 'App管理', '1.0.0', '0', '1', '对App应用的版本管理，消息推送管理等', 'xxxx科技有限公司', 'http://www.xxxx.com', '', '1', '0', 'mobile', '1', 'Admin/Appmgr/index');
INSERT INTO `iot_module` VALUES ('2', 'Device', '设备监控', '1.0.0', '0', '1', '用于接入设备的管理及监控', 'xxxx科技有限公司', 'http://www.xxxx.com', '', '1', '0', 'mobile', '1', 'Admin/Device/index');
INSERT INTO `iot_module` VALUES ('3', 'Home', '网站主页', '1.0.0', '0', '1', '首页模块，主要用于展示网站内容', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Home/index/index', '1', '0', 'home', '0', 'Admin/index/index');
INSERT INTO `iot_module` VALUES ('4', 'Issue', '专辑', '1.0.0', '0', '1', '专辑模块，适用于精品内容展示', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Issue/index/index', '0', '0', 'th', '1', 'Admin/Issue/contents');
INSERT INTO `iot_module` VALUES ('5', 'Metadata', '硬件元数据', '1.0.0', '0', '1', '用于智能硬件产品元数据的定义，管理', 'xxxx科技有限公司', 'http://www.xxxx.com', '', '0', '0', 'th', '1', 'Admin/Metadata/index');
INSERT INTO `iot_module` VALUES ('6', 'People', '会员展示', '1.0.0', '0', '1', '会员展示模块，可以用于会员的查找', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'People/index/index', '0', '0', 'group', '1', 'Admin/index/index');
INSERT INTO `iot_module` VALUES ('7', 'Product', '智能硬件', '1.0.0', '0', '1', '用于智能硬件产品的定义，管理', 'xxxx科技有限公司', 'http://www.xxxx.com', 'Product/index/index', '1', '0', 'wrench', '1', 'Admin/Product/index');
INSERT INTO `iot_module` VALUES ('8', 'Security', '授权管理', '1.0.0', '0', '1', '对物联网的设备，用户，API做授权管理及配置', 'xxxx科技有限公司', 'http://www.xxxx.com', '', '0', '0', 'mobile', '1', 'Admin/Security/index');
INSERT INTO `iot_module` VALUES ('9', 'Ucenter', '用户中心', '1.0.0', '0', '1', '用户中心模块，系统核心模块', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Ucenter/index/index', '1', '0', 'user', '0', 'Admin/User/index');
INSERT INTO `iot_module` VALUES ('10', 'OpenAPI', '开放接口', '1.0.0', '0', '1', '提供智能设备PaaS相关的开放接口，并提供接口的管理', '帕启拉科技有限公司', 'http://www.pachila.cn', 'index/openapi', '1', '0', 'book', '1', 'OpenApi/apiList');
INSERT INTO `iot_module` VALUES ('11', 'Guser', '开发者中心', '1.0.0', '0', '1', '给开发者登陆的平台', 'XXXX信息科技有限公司', 'http://www.ourstu.com', 'Guser/index/index', '1', '0', 'user', '0', '');

-- -----------------------------
-- Table structure for `iot_module_firmware`
-- -----------------------------
DROP TABLE IF EXISTS `iot_module_firmware`;
CREATE TABLE `iot_module_firmware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `firmware_name` varchar(64) NOT NULL,
  `firmware_version` varchar(32) NOT NULL,
  `file_ids` varchar(64) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_firmware_module` (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_module_firmware`
-- -----------------------------
INSERT INTO `iot_module_firmware` VALUES ('15', '15', '测试版本', '1.0.0.1', '1,2,3', '1450156456', '1450318921', '1');

-- -----------------------------
-- Table structure for `iot_ota_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_ota_log`;
CREATE TABLE `iot_ota_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `ota_status` tinyint(4) NOT NULL,
  `request_uid` int(11) DEFAULT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_picture`
-- -----------------------------
DROP TABLE IF EXISTS `iot_picture`;
CREATE TABLE `iot_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `type` varchar(50) NOT NULL,
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_picture`
-- -----------------------------
INSERT INTO `iot_picture` VALUES ('1', 'local', '/Uploads/Picture/2015-12-15/566fa107c622d.png', '', 'dcb6cf77ec3dc98fba0ba559e3fbcbb8', '7c6c4154824466fc4ce4ac9eb11634444c5e1a4b', '1', '1450156295');
INSERT INTO `iot_picture` VALUES ('2', 'local', '/Uploads/Picture/2015-12-18/5673a97bab629.png', '', '4927ef2717e7dd767020b24eb3cb5ccd', 'f4f92330efd92ce53278c1bc623763b1127707b3', '1', '1450420603');
INSERT INTO `iot_picture` VALUES ('3', 'local', '/Uploads/Picture/2015-12-19/567517612a746.png', '', '1deee7a99bd40e8373a684a87ed53541', 'e018be4c5205bacf9ea66db326c26c32f1a2b625', '1', '1450514273');
INSERT INTO `iot_picture` VALUES ('4', 'local', '/Uploads/Picture/2016-01-10/56920a7da2f0b.png', '', '6eaadd160869f740fb7fa111d96cfc17', 'b96ede86ff5f2836069b418cf4fb564d5a20c9b3', '1', '1452411517');
INSERT INTO `iot_picture` VALUES ('5', 'local', '/Uploads/Picture/2016-04-15/5710508a8c842.png', '', 'a7bfef681f67d63891121f99e4195d0a', 'fe5864accdc12c602c032c77c2dbc2b558514578', '1', '1460686986');
INSERT INTO `iot_picture` VALUES ('6', 'local', '/Uploads/Picture/2016-04-19/5715da5133589.png', '', '900ef4b7571e41587b75a6910ad9c8b6', '24a4b84e52165e930bf50d2a4e2b9816d491f5f1', '1', '1461049936');
INSERT INTO `iot_picture` VALUES ('7', 'local', '/Uploads/Picture/2016-04-19/5715dcd24eff1.png', '', 'e6acb747bc28dc190408b938b9263924', '8e3f299238e77e169002239be816a7853b1572ea', '1', '1461050578');
INSERT INTO `iot_picture` VALUES ('8', 'local', '/Uploads/Picture/2016-04-19/5715f68a57f92.png', '', '4313c06eb1d30c6cc3fe83cfaeeff71e', 'be1dfb1752eccd8c25ebc7f94dee95347b0f65da', '1', '1461057162');
INSERT INTO `iot_picture` VALUES ('9', 'local', '/Uploads/Picture/2016-04-19/5715f91e62ee7.png', '', 'e9895d86193446fd87b9c0d54cfb74d6', 'eda4e72455903e79d8e940bf0bf7a9c68fa7cf17', '1', '1461057822');
INSERT INTO `iot_picture` VALUES ('10', 'local', '/Uploads/Picture/2016-04-19/5715f930333fb.png', '', 'a61791a44449732b36a66d312982cd28', '93050d455334bb7efef02621a03fc5688dc171e7', '1', '1461057839');
INSERT INTO `iot_picture` VALUES ('11', 'local', '/Uploads/Picture/2016-04-20/57173dc67e7ff.png', '', '8479fd45a9d1d9d0ce6be0dd2aa097ac', '2af323a896185ee0d7674f8093889268a61cf6ad', '1', '1461140934');
INSERT INTO `iot_picture` VALUES ('12', 'local', '/Uploads/Picture/2016-04-20/57173e472fe2b.png', '', '51e5d427b8e2f2a10abfcf58c3a7e0ee', '339f68b93058dca30dd5104e278ccac62cc20962', '1', '1461141062');
INSERT INTO `iot_picture` VALUES ('13', 'local', '/Uploads/Picture/2016-04-21/571887cdb06c7.png', '', '353cd7f8db597774bcd4eec15def032e', '6763c0d6711720ab98bee863804bfdcfc7496702', '1', '1461225421');
INSERT INTO `iot_picture` VALUES ('14', 'local', '/Uploads/Picture/2016-04-21/571888659d7d1.png', '', '87095c62a1a9fc525fc693b25e06ba34', '7f37e4e8007abc793316f4826374bb0164f9651e', '1', '1461225573');
INSERT INTO `iot_picture` VALUES ('15', 'local', '/Uploads/Picture/2016-04-21/571888898da54.png', '', '441b91a37f7362c7e67c7c71b14196f7', '3aff00c0bcbd488b41352ffd3d56ccc214fb5d98', '1', '1461225609');

-- -----------------------------
-- Table structure for `iot_product`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product`;
CREATE TABLE `iot_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_category` int(11) NOT NULL,
  `product_code` varchar(16) NOT NULL,
  `product_name` varchar(32) DEFAULT NULL,
  `connect_type` tinyint(4) DEFAULT NULL,
  `logo_img` varchar(32) DEFAULT NULL,
  `logo_length` int(11) DEFAULT NULL,
  `logo_height` int(11) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `owner_code` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_FK_proudct_type` (`product_category`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product`
-- -----------------------------
INSERT INTO `iot_product` VALUES ('5', '15', 'TEST', '测试商品', '1', '1', '0', '0', '1450154658', '1452669003', '1', 'admin');
INSERT INTO `iot_product` VALUES ('8', '15', 'FLYCO_AIRCLEANER', '飞科空静', '1', '4', '0', '0', '1450159752', '1452841473', '1', 'admin');
INSERT INTO `iot_product` VALUES ('9', '15', 'SMART_LIGHT', '智能灯', '1', '11', '', '', '1460686991', '1461141077', '1', 'admin');
INSERT INTO `iot_product` VALUES ('10', '15', 'SMART_PLUG', '智能插座', '1', '6', '', '', '1461049645', '1461243403', '1', 'admin');
INSERT INTO `iot_product` VALUES ('11', '15', 'THERMOMETER', '温度计', '1', '7', '', '', '1461050580', '1461142375', '1', 'admin');
INSERT INTO `iot_product` VALUES ('12', '15', 'SMART_BUTTON', '智能按钮', '1', '15', '', '', '1461050657', '1461225611', '1', 'admin');

-- -----------------------------
-- Table structure for `iot_product_category`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_category`;
CREATE TABLE `iot_product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `pid` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_category`
-- -----------------------------
INSERT INTO `iot_product_category` VALUES ('15', '家电', '0', '0', '1450082433', '1450082433', '1');
INSERT INTO `iot_product_category` VALUES ('16', '穿戴设备', '0', '0', '1450082450', '1450082450', '1');
INSERT INTO `iot_product_category` VALUES ('17', '其他智能单品', '0', '0', '1450082477', '1450082477', '1');
INSERT INTO `iot_product_category` VALUES ('18', '空气净化器', '15', '0', '1450082493', '1450082493', '1');
INSERT INTO `iot_product_category` VALUES ('19', '运动手环', '16', '0', '1450082505', '1450082505', '1');
INSERT INTO `iot_product_category` VALUES ('20', '水净化器', '15', '0', '1450082519', '1450082519', '1');

-- -----------------------------
-- Table structure for `iot_product_enum`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_enum`;
CREATE TABLE `iot_product_enum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metadata_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `enum_key` char(10) DEFAULT NULL,
  `enum_value` varchar(32) DEFAULT NULL,
  `display_value` varchar(32) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_metadata_enum_relation` (`metadata_id`),
  KEY `FK_product_enum_relation` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_enum`
-- -----------------------------
INSERT INTO `iot_product_enum` VALUES ('6', '7', '5', '1001', 'ON', '开机', '0', '0', '0');
INSERT INTO `iot_product_enum` VALUES ('7', '7', '5', '1002', 'OFF', '关机', '0', '0', '0');
INSERT INTO `iot_product_enum` VALUES ('8', '7', '8', '0001', 'ON', '开机', '0', '0', '0');
INSERT INTO `iot_product_enum` VALUES ('9', '7', '8', '0000', 'OFF', '关机', '0', '0', '0');

-- -----------------------------
-- Table structure for `iot_product_firmware`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_firmware`;
CREATE TABLE `iot_product_firmware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `firmware_id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_product_firmware_lef` (`product_id`),
  KEY `FK_product_firware_right` (`firmware_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_firmware`
-- -----------------------------
INSERT INTO `iot_product_firmware` VALUES ('18', '8', '15', '1450318921', '1450318921', '1');
INSERT INTO `iot_product_firmware` VALUES ('17', '5', '15', '1450318921', '1450318921', '1');

-- -----------------------------
-- Table structure for `iot_product_logconfig`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_logconfig`;
CREATE TABLE `iot_product_logconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metadata_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `log_required` char(10) DEFAULT NULL,
  `log_condition_type` tinyint(4) DEFAULT NULL,
  `log_condition_value` varchar(32) DEFAULT NULL,
  `log_format` varchar(64) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_metadata_logconfig_relation` (`metadata_id`),
  KEY `FK_product_logconfig_relation` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_logconfig`
-- -----------------------------
INSERT INTO `iot_product_logconfig` VALUES ('5', '5', '5', '1', '1', '', '{$VALUE}', '1450674043', '1450674481', '1');

-- -----------------------------
-- Table structure for `iot_product_metadata`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_metadata`;
CREATE TABLE `iot_product_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `metadata_id` int(11) NOT NULL,
  `parser_type` tinyint(4) NOT NULL,
  `parser_attr_1` varchar(128) DEFAULT NULL,
  `parser_attr_2` varchar(128) DEFAULT NULL,
  `parser_attr_3` varchar(128) DEFAULT NULL,
  `ext_attr_1` varchar(128) DEFAULT NULL,
  `ext_attr_2` varchar(128) DEFAULT NULL,
  `ext_attr_3` varchar(128) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_proudct_metadata_left` (`product_id`),
  KEY `FK_proudct_metadata_right` (`metadata_id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_metadata`
-- -----------------------------
INSERT INTO `iot_product_metadata` VALUES ('15', '5', '5', '1', '', '', '', '', '', '', '0', '0', '1452133352');
INSERT INTO `iot_product_metadata` VALUES ('17', '5', '6', '1', '', '', '', '', '', '', '0', '0', '1452223554');
INSERT INTO `iot_product_metadata` VALUES ('18', '5', '7', '1', '', '', '', '', '', '', '0', '0', '1452223559');
INSERT INTO `iot_product_metadata` VALUES ('19', '8', '6', '1', '', '', '', '', '', '', '0', '0', '1452823040');
INSERT INTO `iot_product_metadata` VALUES ('20', '8', '7', '1', '', '', '', '', '', '', '0', '0', '1452823050');
INSERT INTO `iot_product_metadata` VALUES ('21', '5', '8', '1', '', '', '', '', '', '', '0', '0', '1452669232');
INSERT INTO `iot_product_metadata` VALUES ('22', '5', '10', '1', '', '', '', '', '', '', '0', '0', '1452669248');
INSERT INTO `iot_product_metadata` VALUES ('23', '8', '13', '1', '', '', '', '', '', '', '0', '0', '1452823060');
INSERT INTO `iot_product_metadata` VALUES ('24', '8', '12', '1', '', '', '', '', '', '', '0', '0', '1452823072');
INSERT INTO `iot_product_metadata` VALUES ('25', '8', '14', '1', '', '', '', '', '', '', '0', '0', '1452823086');
INSERT INTO `iot_product_metadata` VALUES ('26', '8', '15', '1', '', '', '', '', '', '', '0', '0', '1452823401');
INSERT INTO `iot_product_metadata` VALUES ('27', '8', '16', '1', '', '', '', '', '', '', '0', '0', '1452838916');
INSERT INTO `iot_product_metadata` VALUES ('28', '8', '17', '1', '', '', '', '', '', '', '0', '0', '1452841491');
INSERT INTO `iot_product_metadata` VALUES ('29', '9', '18', '2', '', '', '', '', '', '', '0', '0', '1460687144');
INSERT INTO `iot_product_metadata` VALUES ('30', '9', '13', '2', '{\"rgb\":{\"red\":0,\"green\":0,\"blue\":0,\"white\":0}}', '', '', '', '', '', '0', '0', '1461040451');
INSERT INTO `iot_product_metadata` VALUES ('31', '9', '12', '2', '{\"rgb\":{\"red\":5000,\"green\":5000,\"blue\":5000,\"white\":5000}}', '', '', '', '', '', '0', '0', '1461231205');
INSERT INTO `iot_product_metadata` VALUES ('32', '10', '13', '2', '{\"swh\":{\"on\":0}} ', '', '', '', '', '', '0', '0', '1461206478');
INSERT INTO `iot_product_metadata` VALUES ('33', '10', '12', '2', '{\"swh\":{\"on\":1}} ', '', '', '', '', '', '0', '0', '1461206490');
INSERT INTO `iot_product_metadata` VALUES ('34', '11', '10', '2', '#hum#x', '', '', '', '', '', '0', '0', '1461144266');
INSERT INTO `iot_product_metadata` VALUES ('35', '9', '19', '2', '#rgb#red', '', '', '', '', '', '0', '0', '1461135632');
INSERT INTO `iot_product_metadata` VALUES ('36', '11', '6', '2', '#hum#y', '', '', '', '', '', '0', '0', '1461144274');
INSERT INTO `iot_product_metadata` VALUES ('41', '12', '24', '2', '#butt#num', '', '', '', '', '', '0', '0', '1461219316');

-- -----------------------------
-- Table structure for `iot_product_module`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_module`;
CREATE TABLE `iot_product_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_product_module_left` (`product_id`),
  KEY `FK_product_module_right` (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_module`
-- -----------------------------
INSERT INTO `iot_product_module` VALUES ('15', '5', '15', '0', '0', '0');
INSERT INTO `iot_product_module` VALUES ('16', '5', '15', '1450156300', '1450156300', '1');
INSERT INTO `iot_product_module` VALUES ('17', '8', '15', '1450159773', '1450159773', '1');
INSERT INTO `iot_product_module` VALUES ('18', '8', '15', '1450513715', '1450513715', '1');
INSERT INTO `iot_product_module` VALUES ('19', '8', '15', '1450514276', '1450514276', '1');
INSERT INTO `iot_product_module` VALUES ('20', '5', '15', '1452223474', '1452223474', '1');
INSERT INTO `iot_product_module` VALUES ('21', '8', '15', '1452411497', '1452411497', '1');
INSERT INTO `iot_product_module` VALUES ('22', '8', '15', '1452411519', '1452411519', '1');
INSERT INTO `iot_product_module` VALUES ('23', '5', '15', '1452669003', '1452669003', '1');
INSERT INTO `iot_product_module` VALUES ('24', '8', '15', '1452822505', '1452822505', '1');
INSERT INTO `iot_product_module` VALUES ('25', '8', '15', '1452823270', '1452823270', '1');
INSERT INTO `iot_product_module` VALUES ('26', '8', '15', '1452838815', '1452838815', '1');
INSERT INTO `iot_product_module` VALUES ('27', '8', '15', '1452841473', '1452841473', '1');
INSERT INTO `iot_product_module` VALUES ('28', '9', '15', '1460686991', '1460686991', '1');
INSERT INTO `iot_product_module` VALUES ('29', '9', '15', '1460687130', '1460687130', '1');
INSERT INTO `iot_product_module` VALUES ('30', '9', '15', '1461034940', '1461034940', '1');
INSERT INTO `iot_product_module` VALUES ('31', '10', '15', '1461049645', '1461049645', '1');
INSERT INTO `iot_product_module` VALUES ('32', '10', '15', '1461049939', '1461049939', '1');
INSERT INTO `iot_product_module` VALUES ('33', '11', '15', '1461050580', '1461050580', '1');
INSERT INTO `iot_product_module` VALUES ('34', '9', '15', '1461135553', '1461135553', '1');
INSERT INTO `iot_product_module` VALUES ('35', '9', '15', '1461141077', '1461141077', '1');
INSERT INTO `iot_product_module` VALUES ('36', '11', '15', '1461142375', '1461142375', '1');
INSERT INTO `iot_product_module` VALUES ('37', '10', '15', '1461243403', '1461243403', '1');

-- -----------------------------
-- Table structure for `iot_rank`
-- -----------------------------
DROP TABLE IF EXISTS `iot_rank`;
CREATE TABLE `iot_rank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '上传者id',
  `title` varchar(50) NOT NULL,
  `logo` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `types` tinyint(2) NOT NULL DEFAULT '1' COMMENT '前台是否可申请',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_rank_user`
-- -----------------------------
DROP TABLE IF EXISTS `iot_rank_user`;
CREATE TABLE `iot_rank_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `rank_id` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `is_show` tinyint(4) NOT NULL COMMENT '是否显示在昵称右侧（必须有图片才可）',
  `create_time` int(11) NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_role`
-- -----------------------------
DROP TABLE IF EXISTS `iot_role`;
CREATE TABLE `iot_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL COMMENT '角色组id',
  `name` varchar(25) NOT NULL COMMENT '英文标识',
  `title` varchar(25) NOT NULL COMMENT '中文标题',
  `description` varchar(500) NOT NULL COMMENT '描述',
  `user_groups` varchar(200) NOT NULL COMMENT '默认用户组ids',
  `invite` tinyint(4) NOT NULL COMMENT '预留字段(类型：是否需要邀请注册等)',
  `audit` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否需要审核',
  `sort` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色表';

-- -----------------------------
-- Records of `iot_role`
-- -----------------------------
INSERT INTO `iot_role` VALUES ('1', '1', 'default', '普通用户', '普通用户', '1,2', '0', '0', '0', '1', '1450079699', '1450422848');

-- -----------------------------
-- Table structure for `iot_role_config`
-- -----------------------------
DROP TABLE IF EXISTS `iot_role_config`;
CREATE TABLE `iot_role_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL COMMENT '标识',
  `category` varchar(25) NOT NULL COMMENT '归类标识',
  `value` text NOT NULL COMMENT '配置值',
  `data` text NOT NULL COMMENT '该配置的其它值',
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='角色配置表';

-- -----------------------------
-- Records of `iot_role_config`
-- -----------------------------
INSERT INTO `iot_role_config` VALUES ('1', '1', 'score', '', '{\"score1\":10,\"score2\":10,\"score3\":10,\"score4\":10}', '', '1450421156');
INSERT INTO `iot_role_config` VALUES ('2', '1', 'avatar', '', '1', '', '1450421270');
INSERT INTO `iot_role_config` VALUES ('3', '1', 'expend_field', 'expend_field', '1,2', '', '1450421321');
INSERT INTO `iot_role_config` VALUES ('4', '1', 'register_expend_field', 'expend_field', '1,2', '', '1450421332');

-- -----------------------------
-- Table structure for `iot_role_group`
-- -----------------------------
DROP TABLE IF EXISTS `iot_role_group`;
CREATE TABLE `iot_role_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色分组';

-- -----------------------------
-- Records of `iot_role_group`
-- -----------------------------
INSERT INTO `iot_role_group` VALUES ('1', '默认分组', '1450422435');

-- -----------------------------
-- Table structure for `iot_seo_rule`
-- -----------------------------
DROP TABLE IF EXISTS `iot_seo_rule`;
CREATE TABLE `iot_seo_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `app` varchar(40) NOT NULL,
  `controller` varchar(40) NOT NULL,
  `action` varchar(40) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `seo_keywords` text NOT NULL,
  `seo_description` text NOT NULL,
  `seo_title` text NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_seo_rule`
-- -----------------------------
INSERT INTO `iot_seo_rule` VALUES ('1', '整站标题', '', '', '', '1', '', '', 'OpenCenter', '7');
INSERT INTO `iot_seo_rule` VALUES ('2', '论坛版块页', 'forum', 'index', 'forum', '-1', '{$forum.title} ', '{$forum.title} ', '{$forum.title} —— ThinkOX论坛', '2');
INSERT INTO `iot_seo_rule` VALUES ('3', '微博首页', '', 'Index', 'index', '1', '微博', '微博首页', 'OpenCenter轻量化社交框架', '5');
INSERT INTO `iot_seo_rule` VALUES ('4', '微博详情页', '', 'Index', 'weiboDetail', '1', '{$weibo.title|op_t},OpenCenter,oc,微博', '{$weibo.content|op_t}\r\n', '{$weibo.content|op_t}——OpenCenter微博', '6');
INSERT INTO `iot_seo_rule` VALUES ('5', '用户中心', 'Ucenter', 'index', 'index', '1', '{$user_info.nickname|op_t},OpenCenter', '{$user_info.username|op_t}的个人主页', '{$user_info.nickname|op_t}的个人主页', '3');
INSERT INTO `iot_seo_rule` VALUES ('6', '会员页面', 'people', 'index', 'index', '1', '会员', '会员', '会员', '4');
INSERT INTO `iot_seo_rule` VALUES ('7', '论坛帖子详情页', 'forum', 'index', 'detail', '-1', '{$post.title|op_t},论坛,thinkox', '{$post.title|op_t}', '{$post.title|op_t} —— ThinkOX论坛', '1');
INSERT INTO `iot_seo_rule` VALUES ('8', '商城首页', 'shop', 'index', 'index', '-1', '商城,积分', '积分商城', '商城首页——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('9', '商城商品详情页', 'shop', 'index', 'goodsdetail', '-1', '{$content.goods_name|op_t},商城', '{$content.goods_name|op_t}', '{$content.goods_name|op_t}——ThinkOX商城', '0');
INSERT INTO `iot_seo_rule` VALUES ('10', '资讯首页', 'blog', 'index', 'index', '-1', '资讯首页', '资讯首页\r\n', '资讯——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('11', '资讯列表页', 'blog', 'article', 'lists', '-1', '{$category.title|op_t}', '{$category.title|op_t}', '{$category.title|op_t}', '0');
INSERT INTO `iot_seo_rule` VALUES ('12', '资讯文章页', 'blog', 'article', 'detail', '-1', '{$info.title|op_t}', '{$info.title|op_t}', '{$info.title|op_t}——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('13', '活动首页', 'event', 'index', 'index', '-1', '活动', '活动首页', '活动首页——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('14', '活动详情页', 'event', 'index', 'detail', '-1', '{$content.title|op_t}', '{$content.title|op_t}', '{$content.title|op_t}——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('15', '专辑首页', 'issue', 'index', 'index', '-1', '专辑', '专辑首页', '专辑首页——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('16', '专辑详情页', 'issue', 'index', 'issuecontentdetail', '-1', '{$content.title|op_t}', '{$content.title|op_t}', '{$content.title|op_t}——ThinkOX', '0');

-- -----------------------------
-- Table structure for `iot_smart_engine`
-- -----------------------------
DROP TABLE IF EXISTS `iot_smart_engine`;
CREATE TABLE `iot_smart_engine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine_type` tinyint(4) NOT NULL,
  `engine_name` varchar(32) DEFAULT NULL,
  `owner_uid` int(11) DEFAULT NULL,
  `engine_memo` varchar(256) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_smart_engine`
-- -----------------------------
INSERT INTO `iot_smart_engine` VALUES ('5', '1', '会客模式', '1', '家里来客人时活动区域的灯全开', '2016-04-20 10:16:04', '0000-00-00 00:00:00');
INSERT INTO `iot_smart_engine` VALUES ('6', '1', '睡眠模式', '1', '关闭大部分设备，保留睡眠灯', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `iot_smart_engine` VALUES ('7', '2', '按钮触发-1', '1', '第1个按钮触发操作', '2016-04-21 15:49:58', '0000-00-00 00:00:00');
INSERT INTO `iot_smart_engine` VALUES ('8', '2', '按钮触发-2', '1', '第2个按钮触发操作', '2016-04-21 15:49:41', '0000-00-00 00:00:00');
INSERT INTO `iot_smart_engine` VALUES ('9', '2', '按钮触发-3', '1', '第3个按钮触发操作', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `iot_smart_engine` VALUES ('10', '2', '按钮触发-4', '1', '第4个按钮触发操作', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- -----------------------------
-- Table structure for `iot_sms_category`
-- -----------------------------
DROP TABLE IF EXISTS `iot_sms_category`;
CREATE TABLE `iot_sms_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `pid` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_sms_category`
-- -----------------------------
INSERT INTO `iot_sms_category` VALUES ('102', 'danger', '3', '3', '20151223', '20151223', '1');
INSERT INTO `iot_sms_category` VALUES ('101', 'warning', '2', '2', '20151223', '20151223', '1');
INSERT INTO `iot_sms_category` VALUES ('100', 'info', '1', '1', '20151223', '20151223', '1');

-- -----------------------------
-- Table structure for `iot_sms_message`
-- -----------------------------
DROP TABLE IF EXISTS `iot_sms_message`;
CREATE TABLE `iot_sms_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_category` int(11) NOT NULL,
  `sms_title` varchar(64) NOT NULL,
  `sms_content` varchar(200) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_sms_message`
-- -----------------------------
INSERT INTO `iot_sms_message` VALUES ('1', '102', '空气质量差', 'PM2.5 大于500，请密闭门窗，开启空气净化器', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_message` VALUES ('2', '101', '滤芯使用期限超限', '滤芯使用期限超过半年，请及时更换滤芯，否则会影响净化后的空气质量', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_message` VALUES ('3', '100', '手机App升级', '手机App新增社交功能，请马上升级，立刻拥有更好的用户体验', '1452671032', '1452671032', '1');

-- -----------------------------
-- Table structure for `iot_sms_send_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_sms_send_log`;
CREATE TABLE `iot_sms_send_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `read_status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_sms_send_log`
-- -----------------------------
INSERT INTO `iot_sms_send_log` VALUES ('1', '1', '1', '1', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_send_log` VALUES ('2', '1', '101', '0', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_send_log` VALUES ('3', '1', '102', '0', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_send_log` VALUES ('4', '1', '100', '0', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_send_log` VALUES ('5', '1', '103', '0', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_send_log` VALUES ('6', '2', '1', '1', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_send_log` VALUES ('7', '2', '101', '0', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_send_log` VALUES ('8', '2', '102', '0', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_send_log` VALUES ('9', '2', '100', '0', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_send_log` VALUES ('10', '2', '103', '0', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_send_log` VALUES ('11', '3', '1', '1', '1452671032', '1452671032', '1');
INSERT INTO `iot_sms_send_log` VALUES ('12', '3', '101', '0', '1452671032', '1452671032', '1');
INSERT INTO `iot_sms_send_log` VALUES ('13', '3', '102', '0', '1452671032', '1452671032', '1');
INSERT INTO `iot_sms_send_log` VALUES ('14', '3', '100', '1', '1452671032', '1452671032', '1');
INSERT INTO `iot_sms_send_log` VALUES ('15', '3', '103', '0', '1452671032', '1452671032', '1');

-- -----------------------------
-- Table structure for `iot_sso_app`
-- -----------------------------
DROP TABLE IF EXISTS `iot_sso_app`;
CREATE TABLE `iot_sso_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `config` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_super_links`
-- -----------------------------
DROP TABLE IF EXISTS `iot_super_links`;
CREATE TABLE `iot_super_links` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '类别（1：图片，2：普通）',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '站点名称',
  `cover_id` int(10) NOT NULL COMMENT '图片ID',
  `link` char(140) NOT NULL DEFAULT '' COMMENT '链接地址',
  `level` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '优先级',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用，1：正常）',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='友情连接表';


-- -----------------------------
-- Table structure for `iot_support`
-- -----------------------------
DROP TABLE IF EXISTS `iot_support`;
CREATE TABLE `iot_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appname` varchar(20) NOT NULL COMMENT '应用名',
  `row` int(11) NOT NULL COMMENT '应用标识',
  `uid` int(11) NOT NULL COMMENT '用户',
  `create_time` int(11) NOT NULL COMMENT '发布时间',
  `table` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='支持的表';


-- -----------------------------
-- Table structure for `iot_sync_login`
-- -----------------------------
DROP TABLE IF EXISTS `iot_sync_login`;
CREATE TABLE `iot_sync_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type_uid` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `oauth_token` varchar(255) NOT NULL,
  `oauth_token_secret` varchar(255) NOT NULL,
  `is_sync` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_talk`
-- -----------------------------
DROP TABLE IF EXISTS `iot_talk`;
CREATE TABLE `iot_talk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) NOT NULL,
  `uids` varchar(100) NOT NULL,
  `appname` varchar(30) NOT NULL,
  `apptype` varchar(30) NOT NULL,
  `source_id` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `source_title` varchar(100) NOT NULL,
  `source_content` text NOT NULL,
  `source_url` varchar(200) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `message_id` int(11) NOT NULL,
  `other_uid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会话表';


-- -----------------------------
-- Table structure for `iot_talk_message`
-- -----------------------------
DROP TABLE IF EXISTS `iot_talk_message`;
CREATE TABLE `iot_talk_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(500) NOT NULL,
  `uid` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `talk_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天消息表';


-- -----------------------------
-- Table structure for `iot_talk_message_push`
-- -----------------------------
DROP TABLE IF EXISTS `iot_talk_message_push`;
CREATE TABLE `iot_talk_message_push` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `source_id` int(11) NOT NULL COMMENT '来源消息id',
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  `status` tinyint(4) NOT NULL,
  `talk_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk COMMENT='状态，0为未提示，1为未点击，-1为已点击';


-- -----------------------------
-- Table structure for `iot_talk_push`
-- -----------------------------
DROP TABLE IF EXISTS `iot_talk_push`;
CREATE TABLE `iot_talk_push` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '接收推送的用户id',
  `source_id` int(11) NOT NULL COMMENT '来源id',
  `create_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '状态，0为未提示，1为未点击，-1为已点击',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='对话推送表';


-- -----------------------------
-- Table structure for `iot_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `iot_ucenter_admin`;
CREATE TABLE `iot_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `iot_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `iot_ucenter_member`;
CREATE TABLE `iot_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(32) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  `type` tinyint(4) NOT NULL COMMENT '1为用户名注册，2为邮箱注册，3为手机注册',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=110 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `iot_ucenter_member`
-- -----------------------------
INSERT INTO `iot_ucenter_member` VALUES ('1', 'admin', 'bc116985c4b87b77d3de1e0e449be91d', 'admin@admin.com', '', '1450079699', '0', '1462328332', '1780875274', '1450079699', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('100', 'test', 'bc116985c4b87b77d3de1e0e449be91d', 'test@qq.com', '', '1450703702', '0', '1461309794', '1918346210', '1450703702', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('101', 'luyuan', 'bc116985c4b87b77d3de1e0e449be91d', '', '', '1450704396', '0', '1452482740', '1022852489', '1450704396', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('102', 'qinhao', 'bc116985c4b87b77d3de1e0e449be91d', '', '', '1451026953', '0', '1451027282', '0', '1451026953', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('103', 'yuhai', 'bc116985c4b87b77d3de1e0e449be91d', '', '', '1451027516', '0', '0', '0', '1451027516', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('104', 'qquinion_id', 'ddf20fb1e4605544ecf739168390e4e9', '', '', '1460081415', '1022852504', '0', '0', '1460081415', '1', '4');
INSERT INTO `iot_ucenter_member` VALUES ('105', 'oGOQbxLPLeOOZ99PiZiNR_n1GfX8', '4315e9375956079ed0d0aedaf1fb93ff', '', '', '1460689517', '1022848972', '0', '0', '1460689517', '1', '5');
INSERT INTO `iot_ucenter_member` VALUES ('106', 'sicon', 'a808eccf027e9f3bed17eb1b0a473139', '', '', '1460713722', '1022848972', '1461915110', '3748136417', '1460713722', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('107', 'sicon001', 'a808eccf027e9f3bed17eb1b0a473139', '', '', '1461209391', '3546230162', '1461209407', '3546230162', '1461209391', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('108', 'o8A5Zv11Ly9glTzHIyPypITfcRu4', '0b8b2eddbfcd2705a08781720ba02526', '', '', '1461292334', '3748136431', '0', '0', '1461292334', '1', '5');
INSERT INTO `iot_ucenter_member` VALUES ('109', 'chenyux', '5021fa2adabddb1ec58c29803273833a', '', '', '1461314384', '3748136426', '1461314397', '3748136426', '1461314384', '1', '1');

-- -----------------------------
-- Table structure for `iot_ucenter_score_type`
-- -----------------------------
DROP TABLE IF EXISTS `iot_ucenter_score_type`;
CREATE TABLE `iot_ucenter_score_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `unit` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_ucenter_score_type`
-- -----------------------------
INSERT INTO `iot_ucenter_score_type` VALUES ('1', '积分', '1', '分');
INSERT INTO `iot_ucenter_score_type` VALUES ('2', '威望', '1', '点');
INSERT INTO `iot_ucenter_score_type` VALUES ('3', '贡献', '1', '元');
INSERT INTO `iot_ucenter_score_type` VALUES ('4', '余额', '1', '点');

-- -----------------------------
-- Table structure for `iot_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `iot_ucenter_setting`;
CREATE TABLE `iot_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `iot_url`
-- -----------------------------
DROP TABLE IF EXISTS `iot_url`;
CREATE TABLE `iot_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `iot_user_config`
-- -----------------------------
DROP TABLE IF EXISTS `iot_user_config`;
CREATE TABLE `iot_user_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `model` varchar(30) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户配置信息表';


-- -----------------------------
-- Table structure for `iot_user_role`
-- -----------------------------
DROP TABLE IF EXISTS `iot_user_role`;
CREATE TABLE `iot_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '2：未审核，1:启用，0：禁用，-1：删除',
  `step` varchar(50) NOT NULL COMMENT '记录当前执行步骤',
  `init` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否初始化',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户角色关联';

-- -----------------------------
-- Records of `iot_user_role`
-- -----------------------------
INSERT INTO `iot_user_role` VALUES ('1', '1', '1', '1', 'finish', '1');

-- -----------------------------
-- Table structure for `iot_user_tag`
-- -----------------------------
DROP TABLE IF EXISTS `iot_user_tag`;
CREATE TABLE `iot_user_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `pid` int(11) NOT NULL,
  `sort` tinyint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='标签分类表';

-- -----------------------------
-- Records of `iot_user_tag`
-- -----------------------------
INSERT INTO `iot_user_tag` VALUES ('1', '默认', '1', '0', '0');
INSERT INTO `iot_user_tag` VALUES ('2', '开发者', '1', '1', '0');
INSERT INTO `iot_user_tag` VALUES ('3', '站长', '1', '1', '0');

-- -----------------------------
-- Table structure for `iot_user_tag_link`
-- -----------------------------
DROP TABLE IF EXISTS `iot_user_tag_link`;
CREATE TABLE `iot_user_tag_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `tags` varchar(200) NOT NULL COMMENT '标签ids',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户标签关联表';


-- -----------------------------
-- Table structure for `iot_user_token`
-- -----------------------------
DROP TABLE IF EXISTS `iot_user_token`;
CREATE TABLE `iot_user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_user_token`
-- -----------------------------
INSERT INTO `iot_user_token` VALUES ('11', '107', 'qEXaDL6Jcms4nv0H2xMFutlzfy7bPo1SVYQ5wreg', '1461209391');
INSERT INTO `iot_user_token` VALUES ('2', '103', 'mEyIOerDqXsJN0HA2gWl1pjPRMfLkwVYUzBou5Zi', '1451027516');
INSERT INTO `iot_user_token` VALUES ('3', '101', 'GH8ZoPV2ckKyzD4tmbExjwslrWquv3YB6O7RJeMg', '1452482672');
INSERT INTO `iot_user_token` VALUES ('4', '104', 'eVBha45Nz6IPKSOCQpv71wqZbyWcxjt3r8kHJfsM', '1460081415');
INSERT INTO `iot_user_token` VALUES ('5', '0', 'mhnPgyzvJYMN3ZOAU0adW81KuDx5HpwLFC9ScEqf', '1460686510');
INSERT INTO `iot_user_token` VALUES ('7', '0', 'BWE9ma4LDP1xJor2vUklFenCMIsZbgduXKA0j7t8', '1460688132');
INSERT INTO `iot_user_token` VALUES ('8', '105', 'SqiEBnzRQrJ1geCZGvpdlt3fasbc0mj2TOV46D9y', '1460689517');
INSERT INTO `iot_user_token` VALUES ('81', '106', 'kEnbe9ZW23HlfKMygwXSOma50NdApq6YJ8cus1Gt', '1461642832');
INSERT INTO `iot_user_token` VALUES ('21', '0', '6jxliSfAs0CgnWLw3NeK4TqF7EVtvpO2DZQy9UkB', '1461228815');
INSERT INTO `iot_user_token` VALUES ('75', '0', 'DbMxyH8e6s4N2CEXjiRgfrz7vVG0YFchKJ1wSPnT', '1461309785');
INSERT INTO `iot_user_token` VALUES ('69', '0', '1So5UxaLprn6ODk0cmwJh4gAYBdQPyvz7EWq3T8i', '1461291369');
INSERT INTO `iot_user_token` VALUES ('70', '0', 'CpJ6QBMfk7UoWNndjiAFZ1SEub4rwHg9Iz8YDR5O', '1461291374');
INSERT INTO `iot_user_token` VALUES ('76', '100', '7EwPUg1dKVBq6e0htrxDAlyzM5vCoY3O9cWHaGmj', '1461309794');
INSERT INTO `iot_user_token` VALUES ('78', '1', '5mJHOYkjKq4Nyurn6Vpb3RBiGMxSFEUh9AgoZzwl', '1461314979');

-- -----------------------------
-- Table structure for `iot_verify`
-- -----------------------------
DROP TABLE IF EXISTS `iot_verify`;
CREATE TABLE `iot_verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `account` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `verify` varchar(50) NOT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

