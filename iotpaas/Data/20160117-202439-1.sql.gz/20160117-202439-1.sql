-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : opencenter
-- 
-- Part : #1
-- Date : 2016-01-17 20:24:39
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `iot_action`
-- -----------------------------
DROP TABLE IF EXISTS `iot_action`;
CREATE TABLE `iot_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `module` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `iot_action`
-- -----------------------------
INSERT INTO `iot_action` VALUES ('1', 'reg', '用户注册', '用户注册', '', '', '1', '1', '1426070545', '');
INSERT INTO `iot_action` VALUES ('2', 'input_password', '输入密码', '记录输入密码的次数。', '', '', '1', '1', '1426122119', '');
INSERT INTO `iot_action` VALUES ('3', 'user_login', '用户登录', '积分+10，每天一次', 'a:1:{i:0;a:5:{s:5:\"table\";s:6:\"member\";s:5:\"field\";s:1:\"1\";s:4:\"rule\";s:2:\"10\";s:5:\"cycle\";s:2:\"24\";s:3:\"max\";s:1:\"1\";}}', '[user|get_nickname]在[time|time_format]登录了账号', '1', '1', '1428397656', '');
INSERT INTO `iot_action` VALUES ('4', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988', '');
INSERT INTO `iot_action` VALUES ('5', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057', '');
INSERT INTO `iot_action` VALUES ('6', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963', '');
INSERT INTO `iot_action` VALUES ('7', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301', '');
INSERT INTO `iot_action` VALUES ('8', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392', '');
INSERT INTO `iot_action` VALUES ('9', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765', '');

-- -----------------------------
-- Table structure for `iot_action_limit`
-- -----------------------------
DROP TABLE IF EXISTS `iot_action_limit`;
CREATE TABLE `iot_action_limit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `frequency` int(11) NOT NULL,
  `time_number` int(11) NOT NULL,
  `time_unit` varchar(50) NOT NULL,
  `punish` text NOT NULL,
  `if_message` tinyint(4) NOT NULL,
  `message_content` text NOT NULL,
  `action_list` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `module` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_action_limit`
-- -----------------------------
INSERT INTO `iot_action_limit` VALUES ('1', 'reg', '注册限制', '1', '1', 'minute', 'warning', '0', '', '[reg]', '1', '0', '');
INSERT INTO `iot_action_limit` VALUES ('2', 'input_password', '输密码', '3', '1', 'minute', 'warning', '0', '', '[input_password]', '1', '0', '');

-- -----------------------------
-- Table structure for `iot_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_action_log`;
CREATE TABLE `iot_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=228 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `iot_action_log`
-- -----------------------------
INSERT INTO `iot_action_log` VALUES ('1', '3', '1', '0', 'member', '1', 'admin在2015-12-14 15:55登录了账号【积分：10分】', '1', '1450079708');
INSERT INTO `iot_action_log` VALUES ('2', '3', '1', '0', 'member', '1', 'admin在2015-12-14 16:44登录了账号', '1', '1450082676');
INSERT INTO `iot_action_log` VALUES ('3', '3', '1', '0', 'member', '1', 'admin在2015-12-14 17:14登录了账号', '1', '1450084499');
INSERT INTO `iot_action_log` VALUES ('4', '3', '1', '0', 'member', '1', 'admin在2015-12-14 20:42登录了账号', '1', '1450096960');
INSERT INTO `iot_action_log` VALUES ('5', '4', '1', '0', 'config', '20', '操作url：/opencenter/index.php?s=/Admin/Config/edit.html', '1', '1450097812');
INSERT INTO `iot_action_log` VALUES ('6', '3', '1', '0', 'member', '1', 'admin在2015-12-16 08:41登录了账号【积分：10分】', '1', '1450226476');
INSERT INTO `iot_action_log` VALUES ('7', '4', '1', '0', 'config', '47', '操作url：/opencenter/index.php?s=/Admin/Config/edit.html', '1', '1450234484');
INSERT INTO `iot_action_log` VALUES ('8', '3', '1', '0', 'member', '1', 'admin在2015-12-17 10:17登录了账号【积分：10分】', '1', '1450318632');
INSERT INTO `iot_action_log` VALUES ('9', '3', '1', '0', 'member', '1', 'admin在2015-12-17 10:20登录了账号', '1', '1450318842');
INSERT INTO `iot_action_log` VALUES ('10', '3', '1', '0', 'member', '1', 'admin在2015-12-17 14:12登录了账号', '1', '1450332735');
INSERT INTO `iot_action_log` VALUES ('11', '3', '1', '0', 'member', '1', 'admin在2015-12-18 16:26登录了账号【积分：10分】', '1', '1450427195');
INSERT INTO `iot_action_log` VALUES ('12', '2', '1', '0', 'ucenter_member', '1', '操作url：/opencenter/index.php?s=/Admin/Public/login.html', '1', '1450514650');
INSERT INTO `iot_action_log` VALUES ('13', '3', '1', '0', 'member', '1', 'admin在2015-12-19 16:44登录了账号【积分：10分】', '1', '1450514657');
INSERT INTO `iot_action_log` VALUES ('14', '8', '1', '0', 'Menu', '220', '操作url：/opencenter/index.php?s=/Admin/Menu/edit.html', '1', '1450609158');
INSERT INTO `iot_action_log` VALUES ('15', '8', '1', '0', 'Menu', '219', '操作url：/opencenter/index.php?s=/Admin/Menu/edit.html', '1', '1450609190');
INSERT INTO `iot_action_log` VALUES ('16', '4', '1', '0', 'config', '5', '操作url：/opencenter/index.php?s=/Admin/Config/edit.html', '1', '1450669835');
INSERT INTO `iot_action_log` VALUES ('17', '8', '1', '0', 'Menu', '229', '操作url：/opencenter/admin.php?s=/Menu/add.html', '1', '1450685471');
INSERT INTO `iot_action_log` VALUES ('18', '1', '1', '0', 'ucenter_member', '1', '操作url：/opencenter/admin.php?s=/User/addNewAdmin.html', '1', '1450703702');
INSERT INTO `iot_action_log` VALUES ('19', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:15登录了账号【积分：10分】', '1', '1450703744');
INSERT INTO `iot_action_log` VALUES ('20', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:16登录了账号【积分：10分】', '1', '1450703766');
INSERT INTO `iot_action_log` VALUES ('21', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:17登录了账号', '1', '1450703821');
INSERT INTO `iot_action_log` VALUES ('22', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:17登录了账号', '1', '1450703829');
INSERT INTO `iot_action_log` VALUES ('23', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:18登录了账号', '1', '1450703890');
INSERT INTO `iot_action_log` VALUES ('24', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:18登录了账号', '1', '1450703916');
INSERT INTO `iot_action_log` VALUES ('25', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:20登录了账号', '1', '1450704027');
INSERT INTO `iot_action_log` VALUES ('26', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:23登录了账号', '1', '1450704195');
INSERT INTO `iot_action_log` VALUES ('27', '1', '1', '0', 'ucenter_member', '1', '操作url：/opencenter/admin.php?s=/User/addNewAdmin.html', '1', '1450704396');
INSERT INTO `iot_action_log` VALUES ('28', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:31登录了账号', '1', '1450704710');
INSERT INTO `iot_action_log` VALUES ('29', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:32登录了账号', '1', '1450704737');
INSERT INTO `iot_action_log` VALUES ('30', '8', '1', '0', 'Menu', '210', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450704763');
INSERT INTO `iot_action_log` VALUES ('31', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:33登录了账号', '1', '1450704780');
INSERT INTO `iot_action_log` VALUES ('32', '3', '1', '0', 'member', '1', 'admin在2015-12-21 21:33登录了账号', '1', '1450704800');
INSERT INTO `iot_action_log` VALUES ('33', '3', '100', '0', 'member', '100', 'test在2015-12-21 21:33登录了账号', '1', '1450704837');
INSERT INTO `iot_action_log` VALUES ('34', '3', '100', '0', 'member', '100', 'test在2015-12-21 22:27登录了账号', '1', '1450708058');
INSERT INTO `iot_action_log` VALUES ('35', '3', '1', '0', 'member', '1', 'admin在2015-12-21 22:27登录了账号', '1', '1450708075');
INSERT INTO `iot_action_log` VALUES ('36', '8', '1', '0', 'Menu', '212', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708107');
INSERT INTO `iot_action_log` VALUES ('37', '8', '1', '0', 'Menu', '211', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708119');
INSERT INTO `iot_action_log` VALUES ('38', '8', '1', '0', 'Menu', '213', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708134');
INSERT INTO `iot_action_log` VALUES ('39', '8', '1', '0', 'Menu', '214', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708146');
INSERT INTO `iot_action_log` VALUES ('40', '8', '1', '0', 'Menu', '215', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708156');
INSERT INTO `iot_action_log` VALUES ('41', '8', '1', '0', 'Menu', '216', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708171');
INSERT INTO `iot_action_log` VALUES ('42', '8', '1', '0', 'Menu', '218', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708184');
INSERT INTO `iot_action_log` VALUES ('43', '8', '1', '0', 'Menu', '219', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708194');
INSERT INTO `iot_action_log` VALUES ('44', '8', '1', '0', 'Menu', '220', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708203');
INSERT INTO `iot_action_log` VALUES ('45', '8', '1', '0', 'Menu', '221', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708214');
INSERT INTO `iot_action_log` VALUES ('46', '8', '1', '0', 'Menu', '224', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708231');
INSERT INTO `iot_action_log` VALUES ('47', '8', '1', '0', 'Menu', '226', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708242');
INSERT INTO `iot_action_log` VALUES ('48', '8', '1', '0', 'Menu', '228', '操作url：/opencenter/admin.php?s=/Menu/edit.html', '1', '1450708258');
INSERT INTO `iot_action_log` VALUES ('49', '3', '1', '0', 'member', '1', 'admin在2015-12-22 14:42登录了账号', '1', '1450766536');
INSERT INTO `iot_action_log` VALUES ('50', '3', '100', '0', 'member', '100', 'test在2015-12-22 17:11登录了账号', '1', '1450775512');
INSERT INTO `iot_action_log` VALUES ('51', '3', '1', '0', 'member', '1', 'admin在2015-12-22 17:12登录了账号', '1', '1450775529');
INSERT INTO `iot_action_log` VALUES ('52', '3', '1', '0', 'member', '1', 'admin在2015-12-24 16:44登录了账号【积分：10分】', '1', '1450946687');
INSERT INTO `iot_action_log` VALUES ('53', '3', '1', '0', 'member', '1', 'admin在2015-12-24 16:45登录了账号', '1', '1450946747');
INSERT INTO `iot_action_log` VALUES ('54', '3', '1', '0', 'member', '1', 'admin在2015-12-24 16:54登录了账号', '1', '1450947272');
INSERT INTO `iot_action_log` VALUES ('55', '3', '1', '0', 'member', '1', 'admin在2015-12-24 17:02登录了账号', '1', '1450947728');
INSERT INTO `iot_action_log` VALUES ('56', '3', '1', '0', 'member', '1', 'admin在2015-12-24 17:04登录了账号', '1', '1450947887');
INSERT INTO `iot_action_log` VALUES ('57', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:03登录了账号', '1', '1451009020');
INSERT INTO `iot_action_log` VALUES ('58', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:05登录了账号', '1', '1451009155');
INSERT INTO `iot_action_log` VALUES ('59', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:07登录了账号', '1', '1451009240');
INSERT INTO `iot_action_log` VALUES ('60', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:11登录了账号', '1', '1451009491');
INSERT INTO `iot_action_log` VALUES ('61', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:15登录了账号', '1', '1451009743');
INSERT INTO `iot_action_log` VALUES ('62', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:19登录了账号', '1', '1451009997');
INSERT INTO `iot_action_log` VALUES ('63', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:21登录了账号', '1', '1451010103');
INSERT INTO `iot_action_log` VALUES ('64', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:23登录了账号', '1', '1451010208');
INSERT INTO `iot_action_log` VALUES ('65', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:25登录了账号', '1', '1451010305');
INSERT INTO `iot_action_log` VALUES ('66', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:26登录了账号', '1', '1451010418');
INSERT INTO `iot_action_log` VALUES ('67', '3', '1', '0', 'member', '1', 'admin在2015-12-25 10:32登录了账号', '1', '1451010733');
INSERT INTO `iot_action_log` VALUES ('68', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:11登录了账号', '1', '1451013064');
INSERT INTO `iot_action_log` VALUES ('69', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:12登录了账号', '1', '1451013148');
INSERT INTO `iot_action_log` VALUES ('70', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:13登录了账号', '1', '1451013234');
INSERT INTO `iot_action_log` VALUES ('71', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:16登录了账号', '1', '1451013415');
INSERT INTO `iot_action_log` VALUES ('72', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:17登录了账号', '1', '1451013442');
INSERT INTO `iot_action_log` VALUES ('73', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:19登录了账号', '1', '1451013598');
INSERT INTO `iot_action_log` VALUES ('74', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:21登录了账号', '1', '1451013690');
INSERT INTO `iot_action_log` VALUES ('75', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:27登录了账号', '1', '1451014028');
INSERT INTO `iot_action_log` VALUES ('76', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:28登录了账号', '1', '1451014133');
INSERT INTO `iot_action_log` VALUES ('77', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:30登录了账号', '1', '1451014257');
INSERT INTO `iot_action_log` VALUES ('78', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:31登录了账号', '1', '1451014281');
INSERT INTO `iot_action_log` VALUES ('79', '3', '1', '0', 'member', '1', 'admin在2015-12-25 11:53登录了账号', '1', '1451015583');
INSERT INTO `iot_action_log` VALUES ('80', '1', '1', '0', 'ucenter_member', '1', '操作url：/opencenter/api.php?s=/users/reg', '1', '1451026953');
INSERT INTO `iot_action_log` VALUES ('81', '3', '102', '0', 'member', '102', 'qinhao在2015-12-25 15:08登录了账号【积分：10分】', '1', '1451027282');
INSERT INTO `iot_action_log` VALUES ('82', '1', '1', '0', 'ucenter_member', '1', '操作url：/opencenter/api.php?s=/users/reg', '1', '1451027516');
INSERT INTO `iot_action_log` VALUES ('83', '3', '1', '0', 'member', '1', 'admin在2015-12-27 20:30登录了账号【积分：10分】', '1', '1451219403');
INSERT INTO `iot_action_log` VALUES ('84', '3', '1', '0', 'member', '1', 'admin在2015-12-28 10:07登录了账号', '1', '1451268469');
INSERT INTO `iot_action_log` VALUES ('85', '3', '1', '0', 'member', '1', 'admin在2015-12-28 16:31登录了账号', '1', '1451291483');
INSERT INTO `iot_action_log` VALUES ('86', '3', '1', '0', 'member', '1', 'admin在2015-12-31 09:31登录了账号【积分：10分】', '1', '1451525503');
INSERT INTO `iot_action_log` VALUES ('87', '3', '1', '0', 'member', '1', 'admin在2015-12-31 09:37登录了账号', '1', '1451525850');
INSERT INTO `iot_action_log` VALUES ('88', '3', '1', '0', 'member', '1', 'admin在2015-12-31 09:37登录了账号', '1', '1451525867');
INSERT INTO `iot_action_log` VALUES ('89', '3', '1', '0', 'member', '1', 'admin在2015-12-31 09:39登录了账号', '1', '1451525969');
INSERT INTO `iot_action_log` VALUES ('90', '3', '1', '0', 'member', '1', 'admin在2016-01-04 15:25登录了账号【积分：10分】', '1', '1451892351');
INSERT INTO `iot_action_log` VALUES ('91', '3', '1', '0', 'member', '1', 'admin在2016-01-04 15:26登录了账号', '1', '1451892390');
INSERT INTO `iot_action_log` VALUES ('92', '3', '1', '0', 'member', '1', 'admin在2016-01-04 16:04登录了账号', '1', '1451894657');
INSERT INTO `iot_action_log` VALUES ('93', '3', '1', '0', 'member', '1', 'admin在2016-01-05 14:42登录了账号', '1', '1451976148');
INSERT INTO `iot_action_log` VALUES ('94', '3', '1', '0', 'member', '1', 'admin在2016-01-05 14:57登录了账号', '1', '1451977024');
INSERT INTO `iot_action_log` VALUES ('95', '3', '1', '0', 'member', '1', 'admin在2016-01-05 15:00登录了账号', '1', '1451977225');
INSERT INTO `iot_action_log` VALUES ('96', '3', '1', '0', 'member', '1', 'admin在2016-01-07 09:40登录了账号【积分：10分】', '1', '1452130809');
INSERT INTO `iot_action_log` VALUES ('97', '3', '1', '0', 'member', '1', 'admin在2016-01-08 11:20登录了账号【积分：10分】', '1', '1452223202');
INSERT INTO `iot_action_log` VALUES ('98', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:37登录了账号【积分：10分】', '1', '1452404254');
INSERT INTO `iot_action_log` VALUES ('99', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:39登录了账号', '1', '1452404380');
INSERT INTO `iot_action_log` VALUES ('100', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:43登录了账号', '1', '1452404637');
INSERT INTO `iot_action_log` VALUES ('101', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:47登录了账号', '1', '1452404830');
INSERT INTO `iot_action_log` VALUES ('102', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:47登录了账号', '1', '1452404844');
INSERT INTO `iot_action_log` VALUES ('103', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:52登录了账号', '1', '1452405123');
INSERT INTO `iot_action_log` VALUES ('104', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:53登录了账号', '1', '1452405215');
INSERT INTO `iot_action_log` VALUES ('105', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:53登录了账号', '1', '1452405232');
INSERT INTO `iot_action_log` VALUES ('106', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:55登录了账号', '1', '1452405305');
INSERT INTO `iot_action_log` VALUES ('107', '3', '1', '0', 'member', '1', 'admin在2016-01-10 13:57登录了账号', '1', '1452405462');
INSERT INTO `iot_action_log` VALUES ('108', '3', '101', '1022852489', 'member', '101', 'luyuan在2016-01-11 11:24登录了账号【积分：10分】', '1', '1452482672');
INSERT INTO `iot_action_log` VALUES ('109', '3', '101', '1022852489', 'member', '101', 'luyuan在2016-01-11 11:25登录了账号', '1', '1452482740');
INSERT INTO `iot_action_log` VALUES ('110', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 12:06登录了账号', '1', '1452485171');
INSERT INTO `iot_action_log` VALUES ('111', '3', '100', '1022852494', 'member', '100', 'test在2016-01-11 12:06登录了账号【积分：10分】', '1', '1452485216');
INSERT INTO `iot_action_log` VALUES ('112', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 12:07登录了账号', '1', '1452485234');
INSERT INTO `iot_action_log` VALUES ('113', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 13:25登录了账号', '1', '1452489905');
INSERT INTO `iot_action_log` VALUES ('114', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:29登录了账号', '1', '1452493759');
INSERT INTO `iot_action_log` VALUES ('115', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:30登录了账号', '1', '1452493843');
INSERT INTO `iot_action_log` VALUES ('116', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:33登录了账号', '1', '1452493999');
INSERT INTO `iot_action_log` VALUES ('117', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:34登录了账号', '1', '1452494049');
INSERT INTO `iot_action_log` VALUES ('118', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:36登录了账号', '1', '1452494214');
INSERT INTO `iot_action_log` VALUES ('119', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 14:37登录了账号', '1', '1452494259');
INSERT INTO `iot_action_log` VALUES ('120', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 14:41登录了账号', '1', '1452494463');
INSERT INTO `iot_action_log` VALUES ('121', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:22登录了账号', '1', '1452496959');
INSERT INTO `iot_action_log` VALUES ('122', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:25登录了账号', '1', '1452497159');
INSERT INTO `iot_action_log` VALUES ('123', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:25登录了账号', '1', '1452497159');
INSERT INTO `iot_action_log` VALUES ('124', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:25登录了账号', '1', '1452497159');
INSERT INTO `iot_action_log` VALUES ('125', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497164');
INSERT INTO `iot_action_log` VALUES ('126', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497186');
INSERT INTO `iot_action_log` VALUES ('127', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('128', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('129', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('130', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('131', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('132', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497187');
INSERT INTO `iot_action_log` VALUES ('133', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497188');
INSERT INTO `iot_action_log` VALUES ('134', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497188');
INSERT INTO `iot_action_log` VALUES ('135', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497188');
INSERT INTO `iot_action_log` VALUES ('136', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 15:26登录了账号', '1', '1452497193');
INSERT INTO `iot_action_log` VALUES ('137', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 16:33登录了账号', '1', '1452501191');
INSERT INTO `iot_action_log` VALUES ('138', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:35登录了账号', '1', '1452501345');
INSERT INTO `iot_action_log` VALUES ('139', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:39登录了账号', '1', '1452501564');
INSERT INTO `iot_action_log` VALUES ('140', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:40登录了账号', '1', '1452501649');
INSERT INTO `iot_action_log` VALUES ('141', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:41登录了账号', '1', '1452501688');
INSERT INTO `iot_action_log` VALUES ('142', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:42登录了账号', '1', '1452501728');
INSERT INTO `iot_action_log` VALUES ('143', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:42登录了账号', '1', '1452501755');
INSERT INTO `iot_action_log` VALUES ('144', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:44登录了账号', '1', '1452501881');
INSERT INTO `iot_action_log` VALUES ('145', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:46登录了账号', '1', '1452501965');
INSERT INTO `iot_action_log` VALUES ('146', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:46登录了账号', '1', '1452501965');
INSERT INTO `iot_action_log` VALUES ('147', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:46登录了账号', '1', '1452501965');
INSERT INTO `iot_action_log` VALUES ('148', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:46登录了账号', '1', '1452501965');
INSERT INTO `iot_action_log` VALUES ('149', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:47登录了账号', '1', '1452502021');
INSERT INTO `iot_action_log` VALUES ('150', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:47登录了账号', '1', '1452502064');
INSERT INTO `iot_action_log` VALUES ('151', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 16:47登录了账号', '1', '1452502078');
INSERT INTO `iot_action_log` VALUES ('152', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:07登录了账号', '1', '1452503246');
INSERT INTO `iot_action_log` VALUES ('153', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:10登录了账号', '1', '1452503410');
INSERT INTO `iot_action_log` VALUES ('154', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-11 17:11登录了账号', '1', '1452503463');
INSERT INTO `iot_action_log` VALUES ('155', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:16登录了账号', '1', '1452503812');
INSERT INTO `iot_action_log` VALUES ('156', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:19登录了账号', '1', '1452503961');
INSERT INTO `iot_action_log` VALUES ('157', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:37登录了账号', '1', '1452505023');
INSERT INTO `iot_action_log` VALUES ('158', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:37登录了账号', '1', '1452505027');
INSERT INTO `iot_action_log` VALUES ('159', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-11 17:37登录了账号', '1', '1452505038');
INSERT INTO `iot_action_log` VALUES ('160', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-11 17:39登录了账号', '1', '1452505163');
INSERT INTO `iot_action_log` VALUES ('161', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-12 08:58登录了账号', '1', '1452560337');
INSERT INTO `iot_action_log` VALUES ('162', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-12 09:42登录了账号', '1', '1452562974');
INSERT INTO `iot_action_log` VALUES ('163', '3', '1', '1917976229', 'member', '1', 'admin在2016-01-12 11:08登录了账号', '1', '1452568117');
INSERT INTO `iot_action_log` VALUES ('164', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:10登录了账号', '1', '1452568219');
INSERT INTO `iot_action_log` VALUES ('165', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:10登录了账号', '1', '1452568234');
INSERT INTO `iot_action_log` VALUES ('166', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:12登录了账号', '1', '1452568331');
INSERT INTO `iot_action_log` VALUES ('167', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:13登录了账号', '1', '1452568423');
INSERT INTO `iot_action_log` VALUES ('168', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:13登录了账号', '1', '1452568433');
INSERT INTO `iot_action_log` VALUES ('169', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 11:18登录了账号', '1', '1452568697');
INSERT INTO `iot_action_log` VALUES ('170', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 13:17登录了账号', '1', '1452575859');
INSERT INTO `iot_action_log` VALUES ('171', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 13:38登录了账号', '1', '1452577110');
INSERT INTO `iot_action_log` VALUES ('172', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 13:38登录了账号', '1', '1452577115');
INSERT INTO `iot_action_log` VALUES ('173', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 13:38登录了账号', '1', '1452577127');
INSERT INTO `iot_action_log` VALUES ('174', '2', '1', '1022852489', 'ucenter_member', '1', '操作url：/opencenter/admin.php?s=/Public/login.html', '1', '1452583282');
INSERT INTO `iot_action_log` VALUES ('175', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-12 15:21登录了账号', '1', '1452583287');
INSERT INTO `iot_action_log` VALUES ('176', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:25登录了账号', '1', '1452583547');
INSERT INTO `iot_action_log` VALUES ('177', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:28登录了账号', '1', '1452583691');
INSERT INTO `iot_action_log` VALUES ('178', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:34登录了账号', '1', '1452584084');
INSERT INTO `iot_action_log` VALUES ('179', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:38登录了账号', '1', '1452584308');
INSERT INTO `iot_action_log` VALUES ('180', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:42登录了账号', '1', '1452584530');
INSERT INTO `iot_action_log` VALUES ('181', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:42登录了账号', '1', '1452584536');
INSERT INTO `iot_action_log` VALUES ('182', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-12 15:42登录了账号', '1', '1452584546');
INSERT INTO `iot_action_log` VALUES ('183', '3', '1', '2070349967', 'member', '1', 'admin在2016-01-12 16:11登录了账号', '1', '1452586263');
INSERT INTO `iot_action_log` VALUES ('184', '3', '1', '1022852496', 'member', '1', 'admin在2016-01-13 11:07登录了账号', '1', '1452654466');
INSERT INTO `iot_action_log` VALUES ('185', '3', '1', '1022852491', 'member', '1', 'admin在2016-01-13 11:33登录了账号', '1', '1452656008');
INSERT INTO `iot_action_log` VALUES ('186', '3', '1', '1022852492', 'member', '1', 'admin在2016-01-13 13:56登录了账号', '1', '1452664615');
INSERT INTO `iot_action_log` VALUES ('187', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 14:12登录了账号', '1', '1452665522');
INSERT INTO `iot_action_log` VALUES ('188', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 14:35登录了账号', '1', '1452666901');
INSERT INTO `iot_action_log` VALUES ('189', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:15登录了账号', '1', '1452669320');
INSERT INTO `iot_action_log` VALUES ('190', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-13 15:16登录了账号', '1', '1452669364');
INSERT INTO `iot_action_log` VALUES ('191', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:20登录了账号', '1', '1452669641');
INSERT INTO `iot_action_log` VALUES ('192', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:20登录了账号', '1', '1452669644');
INSERT INTO `iot_action_log` VALUES ('193', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:20登录了账号', '1', '1452669646');
INSERT INTO `iot_action_log` VALUES ('194', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:23登录了账号', '1', '1452669804');
INSERT INTO `iot_action_log` VALUES ('195', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-13 15:30登录了账号', '1', '1452670250');
INSERT INTO `iot_action_log` VALUES ('196', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-13 15:31登录了账号', '1', '1452670280');
INSERT INTO `iot_action_log` VALUES ('197', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:33登录了账号', '1', '1452670385');
INSERT INTO `iot_action_log` VALUES ('198', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:33登录了账号', '1', '1452670385');
INSERT INTO `iot_action_log` VALUES ('199', '3', '1', '1022852490', 'member', '1', 'admin在2016-01-13 15:34登录了账号', '1', '1452670440');
INSERT INTO `iot_action_log` VALUES ('200', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-13 15:45登录了账号', '1', '1452671113');
INSERT INTO `iot_action_log` VALUES ('201', '3', '1', '3026302676', 'member', '1', 'admin在2016-01-13 16:23登录了账号', '1', '1452673403');
INSERT INTO `iot_action_log` VALUES ('202', '3', '1', '1022852492', 'member', '1', 'admin在2016-01-13 18:03登录了账号', '1', '1452679390');
INSERT INTO `iot_action_log` VALUES ('203', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 17:33登录了账号', '1', '1452764008');
INSERT INTO `iot_action_log` VALUES ('204', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 17:33登录了账号', '1', '1452764015');
INSERT INTO `iot_action_log` VALUES ('205', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 17:33登录了账号', '1', '1452764021');
INSERT INTO `iot_action_log` VALUES ('206', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:02登录了账号', '1', '1452769347');
INSERT INTO `iot_action_log` VALUES ('207', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:03登录了账号', '1', '1452769439');
INSERT INTO `iot_action_log` VALUES ('208', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:04登录了账号', '1', '1452769457');
INSERT INTO `iot_action_log` VALUES ('209', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:05登录了账号', '1', '1452769500');
INSERT INTO `iot_action_log` VALUES ('210', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:05登录了账号', '1', '1452769538');
INSERT INTO `iot_action_log` VALUES ('211', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:19登录了账号', '1', '1452770385');
INSERT INTO `iot_action_log` VALUES ('212', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:19登录了账号', '1', '1452770388');
INSERT INTO `iot_action_log` VALUES ('213', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:21登录了账号', '1', '1452770512');
INSERT INTO `iot_action_log` VALUES ('214', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:22登录了账号', '1', '1452770572');
INSERT INTO `iot_action_log` VALUES ('215', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 19:29登录了账号', '1', '1452770997');
INSERT INTO `iot_action_log` VALUES ('216', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-14 20:38登录了账号', '1', '1452775084');
INSERT INTO `iot_action_log` VALUES ('217', '3', '1', '992823891', 'member', '1', 'admin在2016-01-14 21:46登录了账号', '1', '1452779210');
INSERT INTO `iot_action_log` VALUES ('218', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-15 09:32登录了账号', '1', '1452821533');
INSERT INTO `iot_action_log` VALUES ('219', '3', '1', '3026302644', 'member', '1', 'admin在2016-01-15 11:47登录了账号', '1', '1452829652');
INSERT INTO `iot_action_log` VALUES ('220', '3', '1', '3026302644', 'member', '1', 'admin在2016-01-15 11:47登录了账号', '1', '1452829653');
INSERT INTO `iot_action_log` VALUES ('221', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-15 13:06登录了账号', '1', '1452834409');
INSERT INTO `iot_action_log` VALUES ('222', '3', '1', '1022852489', 'member', '1', 'admin在2016-01-15 14:12登录了账号', '1', '1452838357');
INSERT INTO `iot_action_log` VALUES ('223', '3', '1', '3026302629', 'member', '1', 'admin在2016-01-15 14:57登录了账号', '1', '1452841045');
INSERT INTO `iot_action_log` VALUES ('224', '2', '1', '1022852494', 'ucenter_member', '1', '操作url：/opencenter/admin.php?s=/Public/login.html', '1', '1452842108');
INSERT INTO `iot_action_log` VALUES ('225', '3', '1', '1022852494', 'member', '1', 'admin在2016-01-15 15:15登录了账号', '1', '1452842113');
INSERT INTO `iot_action_log` VALUES ('226', '3', '1', '3752215593', 'member', '1', 'admin在2016-01-16 19:43登录了账号【积分：10分】', '1', '1452944600');
INSERT INTO `iot_action_log` VALUES ('227', '3', '1', '1918707630', 'member', '1', 'admin在2016-01-17 20:23登录了账号【积分：10分】', '1', '1453033410');

-- -----------------------------
-- Table structure for `iot_addons`
-- -----------------------------
DROP TABLE IF EXISTS `iot_addons`;
CREATE TABLE `iot_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `iot_addons`
-- -----------------------------
INSERT INTO `iot_addons` VALUES ('7', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `iot_addons` VALUES ('8', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"6\",\"display\":\"1\"}', 'thinkphp', '0.1', '1420609113', '0');
INSERT INTO `iot_addons` VALUES ('9', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"ThinkOX\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"6\",\"display\":\"1\"}', 'thinkphp', '0.1', '1420609089', '0');
INSERT INTO `iot_addons` VALUES ('10', 'SyncLogin', '同步登陆', '同步登陆', '1', '{\"type\":null,\"meta\":\"\",\"bind\":\"0\",\"QqKEY\":\"\",\"QqSecret\":\"\",\"SinaKEY\":\"\",\"SinaSecret\":\"\"}', 'xjw129xjt', '0.1', '1406598876', '0');
INSERT INTO `iot_addons` VALUES ('11', 'LocalComment', '本地评论', '本地评论插件，不依赖社会化评论平台', '1', '{\"can_guest_comment\":\"1\"}', 'caipeichao', '0.1', '1399440324', '0');

-- -----------------------------
-- Table structure for `iot_app`
-- -----------------------------
DROP TABLE IF EXISTS `iot_app`;
CREATE TABLE `iot_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_type` varchar(64) NOT NULL,
  `business_type` varchar(64) NOT NULL,
  `app_name` varchar(64) NOT NULL,
  `app_version` varchar(32) NOT NULL,
  `app_update_comment` varchar(200) NOT NULL,
  `file_num` int(11) DEFAULT NULL,
  `file_name` varchar(64) DEFAULT NULL,
  `file_path` varchar(256) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `iot_attachment`;
CREATE TABLE `iot_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `iot_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `iot_auth_extend`;
CREATE TABLE `iot_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `iot_auth_extend`
-- -----------------------------
INSERT INTO `iot_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `iot_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `iot_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `iot_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `iot_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `iot_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `iot_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `iot_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `iot_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `iot_auth_group`;
CREATE TABLE `iot_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` text NOT NULL COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_auth_group`
-- -----------------------------
INSERT INTO `iot_auth_group` VALUES ('1', 'admin', '1', '普通用户', '', '1', ',433,435,436,437,438,439,1,404,406,407,408,412,413,423,424,426,427,434,440,441,443,444,445,446,447,448');
INSERT INTO `iot_auth_group` VALUES ('2', 'admin', '1', 'VIP', '', '1', '');

-- -----------------------------
-- Table structure for `iot_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `iot_auth_group_access`;
CREATE TABLE `iot_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_auth_group_access`
-- -----------------------------
INSERT INTO `iot_auth_group_access` VALUES ('1', '1');
INSERT INTO `iot_auth_group_access` VALUES ('100', '1');
INSERT INTO `iot_auth_group_access` VALUES ('101', '1');

-- -----------------------------
-- Table structure for `iot_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `iot_auth_rule`;
CREATE TABLE `iot_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=450 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_auth_rule`
-- -----------------------------
INSERT INTO `iot_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/mydocument', '资讯', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '插件', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('17', 'admin', '1', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('217', 'admin', '1', 'Admin/Forum/forum', '板块管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('218', 'admin', '1', 'Admin/Forum/post', '帖子管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('219', 'admin', '1', 'Admin/Forum/editForum', '编辑／发表帖子', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('220', 'admin', '1', 'Admin/Forum/editPost', 'edit pots', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('221', 'admin', '2', 'Admin//Admin/Forum/index', '讨论区', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('222', 'admin', '2', 'Admin//Admin/Weibo/index', '微博', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('223', 'admin', '1', 'Admin/Forum/sortForum', '排序', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('224', 'admin', '1', 'Admin/SEO/editRule', '新增、编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('225', 'admin', '1', 'Admin/SEO/sortRule', '排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('226', 'admin', '1', 'Admin/SEO/index', 'SEO规则管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('227', 'admin', '1', 'Admin/Forum/editReply', '新增 编辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('228', 'admin', '1', 'Admin/Weibo/editComment', '编辑回复', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('229', 'admin', '1', 'Admin/Weibo/editWeibo', '编辑微博', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('230', 'admin', '1', 'Admin/SEO/ruleTrash', 'SEO规则回收站', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('231', 'admin', '1', 'Admin/Rank/userList', '查看用户', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('232', 'admin', '1', 'Admin/Rank/userRankList', '用户头衔列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('233', 'admin', '1', 'Admin/Rank/userAddRank', '关联新头衔', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('234', 'admin', '1', 'Admin/Rank/userChangeRank', '编辑头衔关联', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('235', 'admin', '1', 'Admin/Issue/add', '编辑专辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('236', 'admin', '1', 'Admin/Issue/issue', '专辑管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('237', 'admin', '1', 'Admin/Issue/operate', '专辑操作', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('238', 'admin', '1', 'Admin/Weibo/weibo', '微博管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('239', 'admin', '1', 'Admin/Rank/index', '头衔列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('240', 'admin', '1', 'Admin/Forum/forumTrash', '板块回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('241', 'admin', '1', 'Admin/Weibo/weiboTrash', '微博回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('242', 'admin', '1', 'Admin/Rank/editRank', '添加头衔', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('243', 'admin', '1', 'Admin/Weibo/comment', '回复管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('244', 'admin', '1', 'Admin/Forum/postTrash', '帖子回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('245', 'admin', '1', 'Admin/Weibo/commentTrash', '回复回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('246', 'admin', '1', 'Admin/Issue/issueTrash', '专辑回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('247', 'admin', '1', 'Admin//Admin/Forum/reply', '回复管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('248', 'admin', '1', 'Admin/Forum/replyTrash', '回复回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('249', 'admin', '2', 'Admin/Forum/index', '贴吧', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('250', 'admin', '2', 'Admin/Weibo/weibo', '微博', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('251', 'admin', '2', 'Admin/SEO/index', 'SEO', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('252', 'admin', '2', 'Admin/Rank/index', '头衔', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('253', 'admin', '2', 'Admin/Issue/issue', '专辑', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('254', 'admin', '1', 'Admin/Issue/contents', '内容管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('255', 'admin', '1', 'Admin/User/profile', '扩展资料', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('256', 'admin', '1', 'Admin/User/editProfile', '添加、编辑分组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('257', 'admin', '1', 'Admin/User/sortProfile', '分组排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('258', 'admin', '1', 'Admin/User/field', '字段列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('259', 'admin', '1', 'Admin/User/editFieldSetting', '添加、编辑字段', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('260', 'admin', '1', 'Admin/User/sortField', '字段排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('261', 'admin', '1', 'Admin/Update/quick', '全部补丁', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('262', 'admin', '1', 'Admin/Update/addpack', '新增补丁', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('263', 'admin', '1', 'Admin/User/expandinfo_select', '用户扩展资料列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('264', 'admin', '1', 'Admin/User/expandinfo_details', '扩展资料详情', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('265', 'admin', '1', 'Admin/Shop/shopLog', '商城信息记录', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('266', 'admin', '1', 'Admin/Shop/setStatus', '商品分类状态设置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('267', 'admin', '1', 'Admin/Shop/setGoodsStatus', '商品状态设置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('268', 'admin', '1', 'Admin/Shop/operate', '商品分类操作', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('269', 'admin', '1', 'Admin/Shop/add', '商品分类添加', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('270', 'admin', '1', 'Admin/Shop/goodsEdit', '添加、编辑商品', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('271', 'admin', '1', 'Admin/Shop/hotSellConfig', '热销商品阀值配置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('272', 'admin', '1', 'Admin/Shop/setNew', '设置新品', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('273', 'admin', '1', 'Admin/EventType/index', '活动分类管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('274', 'admin', '1', 'Admin/Event/event', '内容管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('275', 'admin', '1', 'Admin/EventType/eventTypeTrash', '活动分类回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('276', 'admin', '1', 'Admin/Event/verify', '内容审核', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('277', 'admin', '1', 'Admin/Event/contentTrash', '内容回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('278', 'admin', '1', 'Admin/Rank/rankVerify', '待审核用户头衔', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('279', 'admin', '1', 'Admin/Rank/rankVerifyFailure', '被驳回的头衔申请', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('280', 'admin', '1', 'Admin/Weibo/config', '微博设置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('281', 'admin', '1', 'Admin/Issue/verify', '内容审核', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('282', 'admin', '1', 'Admin/Shop/goodsList', '商品列表', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('283', 'admin', '1', 'Admin/Shop/shopCategory', '商品分类配置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('284', 'admin', '1', 'Admin/Shop/categoryTrash', '商品分类回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('285', 'admin', '1', 'Admin/Shop/verify', '待发货交易', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('286', 'admin', '1', 'Admin/Issue/contentTrash', '内容回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('287', 'admin', '1', 'Admin/Shop/goodsBuySuccess', '交易成功记录', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('288', 'admin', '1', 'Admin/Shop/goodsTrash', '商品回收站', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('289', 'admin', '1', 'Admin/Shop/toxMoneyConfig', '货币配置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('290', 'admin', '2', 'Admin/Shop/shopCategory', '商城', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('291', 'admin', '2', 'Admin/EventType/index', '活动', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('337', 'Weibo', '1', 'manageTopic', '管理话题', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('297', 'Home', '1', 'deleteLocalComment', '删除本地评论', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('342', 'admin', '1', 'Admin/user/editScoreType', '新增/编辑类型', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('341', 'admin', '1', 'Admin/User/scoreList', '积分类型列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('336', 'Weibo', '1', 'beTopicAdmin', '抢先成为话题主持人', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('335', 'Weibo', '1', 'setWeiboTop', '微博置顶', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('334', 'Weibo', '1', 'deleteWeibo', '删除微博', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('333', 'Weibo', '1', 'sendWeibo', '发微博', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('313', 'admin', '1', 'Admin/module/install', '模块安装', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('315', 'admin', '1', 'Admin/module/lists', '模块管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('316', 'admin', '1', 'Admin/module/uninstall', '卸载模块', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('317', 'admin', '1', 'Admin/AuthManager/addNode', '新增权限节点', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('318', 'admin', '1', 'Admin/AuthManager/accessUser', '前台权限管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('319', 'admin', '1', 'Admin/User/changeGroup', '转移用户组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('320', 'admin', '1', 'Admin/AuthManager/deleteNode', '删除权限节点', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('321', 'admin', '1', 'Admin/Issue/config', '专辑设置', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('322', 'admin', '2', 'Admin/module/lists', '云市场', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('340', 'admin', '1', 'Admin/UserConfig/index', '用户注册配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('343', 'admin', '1', 'Admin/user/recharge', '充值积分', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('344', 'admin', '1', 'Admin/Authorize/ssoSetting', '单点登录配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('345', 'admin', '1', 'Admin/Authorize/ssolist', '应用列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('346', 'admin', '1', 'Admin/authorize/editssoapp', '新增/编辑应用', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('347', 'admin', '1', 'Admin/ActionLimit/limitList', '行为限制列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('348', 'admin', '1', 'Admin/ActionLimit/editLimit', '新增/编辑行为限制', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('349', 'admin', '1', 'Admin/Role/index', '角色列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('350', 'admin', '1', 'Admin/Role/editRole', '编辑角色', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('351', 'admin', '1', 'Admin/Role/setStatus', '启用、禁用、删除角色', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('352', 'admin', '1', 'Admin/Role/sort', '角色排序', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('353', 'admin', '1', 'Admin/Role/configScore', '默认积分配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('354', 'admin', '1', 'Admin/Role/configAuth', '默认权限配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('355', 'admin', '1', 'Admin/Role/configAvatar', '默认头像配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('356', 'admin', '1', 'Admin/Role/configRank', '默认头衔配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('357', 'admin', '1', 'Admin/Role/configField', '默认字段管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('358', 'admin', '1', 'Admin/Role/group', '角色分组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('359', 'admin', '1', 'Admin/Role/editGroup', '编辑分组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('360', 'admin', '1', 'Admin/Role/deleteGroup', '删除分组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('361', 'admin', '1', 'Admin/Role/config', '角色基本信息配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('362', 'admin', '1', 'Admin/Role/userList', '用户列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('363', 'admin', '1', 'Admin/Role/setUserStatus', '设置用户状态', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('364', 'admin', '1', 'Admin/Role/setUserAudit', '审核用户', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('365', 'admin', '1', 'Admin/Role/changeRole', '迁移用户', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('366', 'admin', '1', 'Admin/Role/uploadPicture', '上传默认头像', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('367', 'admin', '1', 'Admin/Invite/index', '类型管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('368', 'admin', '1', 'Admin/Invite/invite', '邀请码管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('369', 'admin', '1', 'Admin/Invite/config', '基础配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('370', 'admin', '1', 'Admin/Invite/buyLog', '兑换记录', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('371', 'admin', '1', 'Admin/Invite/inviteLog', '邀请记录', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('372', 'admin', '1', 'Admin/Invite/userInfo', '用户信息', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('373', 'admin', '1', 'Admin/Invite/edit', '编辑邀请注册类型', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('374', 'admin', '1', 'Admin/Invite/setStatus', '删除邀请', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('375', 'admin', '1', 'Admin/Invite/delete', '删除邀请码', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('376', 'admin', '1', 'Admin/Invite/createCode', '生成邀请码', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('377', 'admin', '1', 'Admin/Invite/deleteTrue', '删除无用邀请码', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('378', 'admin', '1', 'Admin/Invite/cvs', '导出cvs', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('379', 'admin', '1', 'Admin/Invite/editUserInfo', '用户信息编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('380', 'admin', '1', 'Admin/Action/remove', '删除日志', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('381', 'admin', '1', 'Admin/Action/clear', '清空日志', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('382', 'admin', '1', 'Admin/User/setTypeStatus', '设置积分状态', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('383', 'admin', '1', 'Admin/User/delType', '删除积分类型', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('384', 'admin', '1', 'Admin/User/getNickname', '充值积分', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('385', 'admin', '1', 'Admin/Menu/del', '删除菜单', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('386', 'admin', '1', 'Admin/Menu/toogleDev', '设置开发者模式可见', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('387', 'admin', '1', 'Admin/Menu/toogleHide', '设置显示隐藏', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('388', 'admin', '1', 'Admin/ActionLimit/setLimitStatus', '行为限制启用、禁用、删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('389', 'admin', '1', 'Admin/SEO/setRuleStatus', '启用、禁用、删除、回收站还原', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('390', 'admin', '1', 'Admin/SEO/doClear', '回收站彻底删除', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('391', 'admin', '1', 'Admin/Role/initUnhaveUser', '初始化无角色用户', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('392', 'admin', '1', 'Admin/Addons/delHook', '删除钩子', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('393', 'admin', '1', 'Admin/Update/usePack', '使用补丁', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('394', 'admin', '1', 'Admin/Update/view', '查看补丁', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('395', 'admin', '1', 'Admin/Update/delPack', '删除补丁', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('396', 'admin', '1', 'Admin/UserTag/userTag', '标签列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('397', 'admin', '1', 'Admin/UserTag/add', '添加分类、标签', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('398', 'admin', '1', 'Admin/UserTag/setStatus', '设置分类、标签状态', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('399', 'admin', '1', 'Admin/UserTag/tagTrash', '分类、标签回收站', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('400', 'admin', '1', 'Admin/UserTag/userTagClear', '测底删除回收站内容', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('401', 'admin', '1', 'Admin/role/configusertag', '可拥有标签配置', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('402', 'admin', '1', 'Admin/Module/edit', '编辑模块', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('403', 'admin', '1', 'Admin/Config/website', '网站信息', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('404', 'admin', '1', 'Admin/Product/wizard', '产品导航', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('405', 'admin', '1', 'Admin/Device/index', '总体视图', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('406', 'admin', '1', 'Admin/Product/index', '产品管理', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('407', 'admin', '1', 'Admin/Product/addProduct', '产品添加修改', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('408', 'admin', '1', 'Admin/Product/listMetadata', '产品元数据列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('409', 'admin', '1', 'Admin/Device/list', '设备管理', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('410', 'admin', '2', 'Admin/authorize/ssoSetting', '授权', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('411', 'admin', '2', 'Admin/Role/index', '角色', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('412', 'admin', '1', 'Admin/Product/categories', '产品分类', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('413', 'admin', '1', 'Admin/Product/addCategories', '产品分类编辑', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('414', 'admin', '2', 'Admin/ActionLimit/limitList', '安全', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('415', 'admin', '1', 'Admin/Metadata/index', '所有', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('416', 'admin', '1', 'Admin/DeviceOperation/index', '操作日志', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('417', 'admin', '1', 'Admin//Admin/Metadata/index/md_type/1', '功能类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('418', 'admin', '1', 'Admin//Admin/Metadata/edit', '添加传感类元素据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('419', 'admin', '1', 'Admin/DeviceData/index', '数据日志', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('420', 'admin', '1', 'Admin//Admin/Metadata/index/md_type/2', '传感类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('421', 'admin', '1', 'Admin//Admin/Metadata/index/md_type/3', '状态类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('422', 'admin', '1', 'Admin//Admin/Metadata/index/md_type/4', '异常类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('423', 'admin', '1', 'Admin/Product/listConnectModule', '联网模组', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('424', 'admin', '1', 'Admin/Product/addConnectModule', '模组添加修改', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('425', 'admin', '1', 'Admin/DeviceMac/index', 'MAC维护', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('426', 'admin', '1', 'Admin/Product/listFirmware', '固件维护', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('427', 'admin', '1', 'Admin/Product/addFirmware', '固件添加修改', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('428', 'admin', '1', 'Admin/DeviceOwner/index', '授权维护', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('429', 'admin', '1', 'Admin/DeviceReport/activities', '活跃数统计', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('430', 'admin', '1', 'Admin/DeviceReport/index', 'XXX统计', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('431', 'admin', '2', 'Admin/Metadata/metadata', '硬件元数据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('432', 'admin', '2', 'Admin/Device/index', '设备监控', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('433', 'admin', '2', 'Admin/Product/product', '智能硬件', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('434', 'admin', '1', 'Admin/Product/metadatas', '所有元数据', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('435', 'admin', '1', 'Admin//Admin/Product/metadatas/md_type/1', '功能类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('436', 'admin', '1', 'Admin//Admin/Product/metadatas/md_type/2', '传感类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('437', 'admin', '1', 'Admin//Admin/Product/metadatas/md_type/3', '状态类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('438', 'admin', '1', 'Admin//Admin/Product/metadatas/md_type/4', '异常类', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('439', 'admin', '1', 'Admin//Admin/Product/editMetadata', '编辑传感类元素据', '-1', '');
INSERT INTO `iot_auth_rule` VALUES ('440', 'admin', '1', 'Admin/Product/listLogConfig', '日志配置列表', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('441', 'admin', '1', 'Admin/Product/addLogConfig', '日志配置修改', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('442', 'admin', '1', 'Admin/User/addNewAdmin', '新增管理员', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('443', 'admin', '2', 'Admin/Product/index', '智能硬件', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('444', 'admin', '1', 'Admin//Product/metadatas/md_type/1', '功能类', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('445', 'admin', '1', 'Admin//Product/metadatas/md_type/2', '传感类', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('446', 'admin', '1', 'Admin//Product/metadatas/md_type/3', '状态类', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('447', 'admin', '1', 'Admin//Product/metadatas/md_type/4', '异常类', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('448', 'admin', '1', 'Admin/Product/editMetadata', '编辑传感类元素据', '1', '');
INSERT INTO `iot_auth_rule` VALUES ('449', 'admin', '1', 'Admin/OpenAPI/apiList', '接口管理', '1', '');

-- -----------------------------
-- Table structure for `iot_avatar`
-- -----------------------------
DROP TABLE IF EXISTS `iot_avatar`;
CREATE TABLE `iot_avatar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `path` varchar(200) NOT NULL,
  `create_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `is_temp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_channel`
-- -----------------------------
DROP TABLE IF EXISTS `iot_channel`;
CREATE TABLE `iot_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  `color` varchar(30) NOT NULL,
  `band_color` varchar(30) NOT NULL,
  `band_text` varchar(30) NOT NULL,
  `icon` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_channel`
-- -----------------------------
INSERT INTO `iot_channel` VALUES ('1', '0', '首页', 'Home/Index/index', '1', '0', '0', '1', '0', '#000000', '#000000', '', 'home');

-- -----------------------------
-- Table structure for `iot_config`
-- -----------------------------
DROP TABLE IF EXISTS `iot_config`;
CREATE TABLE `iot_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_config`
-- -----------------------------
INSERT INTO `iot_config` VALUES ('1', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `iot_config` VALUES ('2', 'SITE_LOGO', '7', '网站LOGO', '1', '', '网站的logo设置，建议尺寸156*50', '1388332311', '1388501500', '1', '2', '3');
INSERT INTO `iot_config` VALUES ('3', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举\r\n8:多选框', '8');
INSERT INTO `iot_config` VALUES ('4', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '沪CP备XX号', '12');
INSERT INTO `iot_config` VALUES ('5', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1450669835', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统\r\n5:邮件\r\n6:物联网', '15');
INSERT INTO `iot_config` VALUES ('6', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '17');
INSERT INTO `iot_config` VALUES ('7', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '20');
INSERT INTO `iot_config` VALUES ('9', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '24');
INSERT INTO `iot_config` VALUES ('11', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '13');
INSERT INTO `iot_config` VALUES ('12', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '16');
INSERT INTO `iot_config` VALUES ('13', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '18');
INSERT INTO `iot_config` VALUES ('14', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '22');
INSERT INTO `iot_config` VALUES ('15', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '25');
INSERT INTO `iot_config` VALUES ('16', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '26');
INSERT INTO `iot_config` VALUES ('17', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '2');
INSERT INTO `iot_config` VALUES ('18', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '3');
INSERT INTO `iot_config` VALUES ('19', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '27');
INSERT INTO `iot_config` VALUES ('20', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1450097812', '1', '1', '7');
INSERT INTO `iot_config` VALUES ('21', 'WEB_SITE', '1', '网站名称', '1', '', '用于邮件,短信,站内信显示', '1388332311', '1388501500', '1', '帕奇拉物联', '3');
INSERT INTO `iot_config` VALUES ('22', 'MAIL_TYPE', '4', '邮件类型', '5', '1:SMTP 模块发送\r\n2:mail() 函数发送', '如果您选择了采用服务器内置的 Mail 服务，您不需要填写下面的内容', '1388332882', '1388931416', '1', '1', '0');
INSERT INTO `iot_config` VALUES ('23', 'MAIL_SMTP_HOST', '1', 'SMTP 服务器', '5', '', 'SMTP服务器', '1388332932', '1388332932', '1', '', '0');
INSERT INTO `iot_config` VALUES ('24', 'MAIL_SMTP_PORT', '0', 'SMTP服务器端口', '5', '', '默认25', '1388332975', '1388332975', '1', '25', '0');
INSERT INTO `iot_config` VALUES ('25', 'MAIL_SMTP_USER', '1', 'SMTP服务器用户名', '5', '', '填写完整用户名', '1388333010', '1388333010', '1', '', '0');
INSERT INTO `iot_config` VALUES ('26', 'MAIL_SMTP_PASS', '6', 'SMTP服务器密码', '5', '', '填写您的密码', '1388333057', '1389187088', '1', '', '0');
INSERT INTO `iot_config` VALUES ('27', 'MAIL_USER_PASS', '5', '密码找回模板', '0', '', '支持HTML代码', '1388583989', '1388672614', '1', '密码找回111223333555111', '0');
INSERT INTO `iot_config` VALUES ('28', 'PIC_FILE_PATH', '1', '图片文件保存根目录', '4', '', '图片文件保存根目录./目录/', '1388673255', '1388673255', '1', './Uploads/', '0');
INSERT INTO `iot_config` VALUES ('29', 'COUNT_DAY', '0', '后台首页统计用户增长天数', '0', '', '默认统计最近半个月的用户数增长情况', '1420791945', '1420876261', '1', '15', '0');
INSERT INTO `iot_config` VALUES ('30', 'MAIL_USER_REG', '5', '注册邮件模板', '3', '', '支持HTML代码', '1388337307', '1389532335', '1', '<a href=\"http://3spp.cn\" target=\"_blank\">点击进入</a><span style=\"color:#E53333;\">当您收到这封邮件，表明您已注册成功，以上为您的用户名和密码。。。。祝您生活愉快····</span>', '55');
INSERT INTO `iot_config` VALUES ('31', 'USER_NAME_BAOLIU', '1', '保留用户名', '3', '', '禁止注册用户名,用\" , \"号隔开', '1388845937', '1388845937', '1', '管理员,测试,admin,垃圾', '0');
INSERT INTO `iot_config` VALUES ('33', 'VERIFY_OPEN', '8', '验证码配置', '4', 'reg:注册显示\r\nlogin:登陆显示\r\nreset:找回密码', '验证码配置', '1388500332', '1405561711', '1', '', '0');
INSERT INTO `iot_config` VALUES ('34', 'VERIFY_TYPE', '4', '验证码类型', '4', '1:中文\r\n2:英文\r\n3:数字\r\n4:英文+数字', '验证码类型', '1388500873', '1405561731', '1', '4', '0');
INSERT INTO `iot_config` VALUES ('35', 'NO_BODY_TLE', '2', '空白说明', '2', '', '空白说明', '1392216444', '1392981305', '1', '呵呵，暂时没有内容哦！！', '0');
INSERT INTO `iot_config` VALUES ('36', 'USER_RESPASS', '5', '密码找回模板', '3', '', '密码找回文本', '1396191234', '1396191234', '1', '<span style=\"color:#009900;\">请点击以下链接找回密码，如无反应，请将链接地址复制到浏览器中打开(下次登录前有效)</span>', '0');
INSERT INTO `iot_config` VALUES ('37', 'COUNT_CODE', '2', '统计代码', '1', '', '用于统计网站访问量的第三方代码，推荐CNZZ统计', '1403058890', '1403058890', '1', '', '4');
INSERT INTO `iot_config` VALUES ('38', 'AFTER_LOGIN_JUMP_URL', '2', '登陆后跳转的Url', '1', '', '支持形如weibo/index/index的ThinkPhp路由写法，支持普通的url写法', '1407145718', '1407154887', '1', 'Home/index/index', '7');
INSERT INTO `iot_config` VALUES ('40', 'URL_MODEL', '4', 'URL模式', '4', '1:PATHINFO模式\r\n2:REWRITE模式(开启伪静态)\r\n3:兼容模式', '选择Rewrite模式则开启伪静态，默认建议开启兼容模式', '1421027546', '1421027676', '1', '3', '0');
INSERT INTO `iot_config` VALUES ('41', 'DEFUALT_HOME_URL', '1', '默认首页Url', '1', '', '支持形如weibo/index/index的ThinkPhp路由写法，支持普通的url写法，不填则显示默认聚合首页', '1417509438', '1417509501', '1', '', '0');
INSERT INTO `iot_config` VALUES ('60', '_USERCONFIG_REG_SWITCH', '0', '', '0', '', '', '1450419564', '1450419564', '1', 'username', '0');
INSERT INTO `iot_config` VALUES ('74', 'MD_SCOPE', '3', '作用域', '6', '', '元素据作用域范围', '1379228036', '1384418383', '1', '1:公共型\n2:私有型 ', '53');
INSERT INTO `iot_config` VALUES ('72', 'MD_TYPE', '3', '元素据类型', '6', '', '元素据分类', '1379228036', '1384418383', '1', '1:功能\n2:传感\n3:状态\n4:错误', '51');
INSERT INTO `iot_config` VALUES ('73', 'MD_VALUE_TYPE', '3', '值类型', '6', '', '元素据值类型', '1379228036', '1384418383', '1', '0:N/A\n1:数值型\n2:字符型\n3:枚举型 ', '52');
INSERT INTO `iot_config` VALUES ('46', 'PARSER_TYPE', '3', '解析类别', '6', '', '针对该元数据的解析方式', '1379228036', '1384418383', '1', '1:16进制数值信号\n2:JSON文本\n3:流媒体', '61');
INSERT INTO `iot_config` VALUES ('47', 'PART_TYPE', '3', '片段类型', '6', '', '解析中定义的数据片段', '1379228036', '1450234484', '1', 'head:帧头\r\ncommand:命令域\r\nlength:内容长\r\ncontent:内容域\r\ntail:帧尾\r\nchksum:校验值', '62');
INSERT INTO `iot_config` VALUES ('48', 'MODULE_TYPE', '3', '模组分类', '6', '', '联网模组的分类', '1379228036', '1384418383', '1', '1:WIFI模组\n2:蓝牙模组\n3:SIM卡\n4:ZIGBEE', '63');
INSERT INTO `iot_config` VALUES ('61', '_USERCONFIG_EMAIL_VERIFY_TYPE', '0', '', '0', '', '', '1450419564', '1450419564', '1', '1', '0');
INSERT INTO `iot_config` VALUES ('62', '_USERCONFIG_MOBILE_VERIFY_TYPE', '0', '', '0', '', '', '1450419564', '1450419564', '1', '0', '0');
INSERT INTO `iot_config` VALUES ('63', '_USERCONFIG_REG_STEP', '0', '', '0', '', '', '1450419564', '1450419564', '1', '[{\"data-id\":\"disable\",\"title\":\"\\u7981\\u7528\",\"items\":[{\"data-id\":\"change_avatar\",\"title\":\"\\u4fee\\u6539\\u5934\\u50cf\"},{\"data-id\":\"expand_info\",\"title\":\"\\u586b\\u5199\\u6269\\u5c55\\u8d44\\u6599\"}]},{\"data-id\":\"enable\",\"title\":\"\\u542f\\u7528\",\"items\":[]}]', '0');
INSERT INTO `iot_config` VALUES ('64', '_USERCONFIG_REG_CAN_SKIP', '0', '', '0', '', '', '1450419564', '1450419564', '1', '', '0');
INSERT INTO `iot_config` VALUES ('65', '_USERCONFIG_OPEN_QUICK_LOGIN', '0', '', '0', '', '', '1450419564', '1450419564', '1', '0', '0');
INSERT INTO `iot_config` VALUES ('66', '_USERCONFIG_SMS_HTTP', '0', '', '0', '', '', '1450419564', '1450419564', '1', '', '0');
INSERT INTO `iot_config` VALUES ('67', '_USERCONFIG_SMS_UID', '0', '', '0', '', '', '1450419564', '1450419564', '1', '', '0');
INSERT INTO `iot_config` VALUES ('68', '_USERCONFIG_SMS_PWD', '0', '', '0', '', '', '1450419564', '1450419564', '1', '', '0');
INSERT INTO `iot_config` VALUES ('69', '_USERCONFIG_SMS_CONTENT', '0', '', '0', '', '', '1450419564', '1450419564', '1', '', '0');
INSERT INTO `iot_config` VALUES ('70', '_USERCONFIG_LEVEL', '0', '', '0', '', '', '1450419564', '1450419564', '1', '0:Lv1 实习\r\n50:Lv2 试用\r\n100:Lv3 转正\r\n200:Lv4 助理\r\n400:Lv 5 经理\r\n800:Lv6 董事\r\n1600:Lv7 董事长', '0');
INSERT INTO `iot_config` VALUES ('71', '_INVITE_REGISTER_TYPE', '0', '', '0', '', '', '1450422564', '1450422564', '1', 'normal,invite', '0');
INSERT INTO `iot_config` VALUES ('75', 'LOG_CONDITION_TYPE', '3', '日志记录类型', '6', '', '日志记录类型', '1379228036', '1384418383', '1', '1:直接记录\n2:变化超过阀值记录', '64');
INSERT INTO `iot_config` VALUES ('76', 'API_ERROR_MSG', '3', '值类型', '6', '', '接口返回错误', '1379228036', '1384418383', '1', 'PASSWORD_ERR_ENCRIPT:密码加密错误,\nSYSTEM_ERROR:系统错误', '52');
INSERT INTO `iot_config` VALUES ('82', 'BUSINESS_TYPE', '3', 'business_type', '0', '', '', '1452050491', '1452050727', '1', 'SmartAppliance:SmartAppliance\r\nChargingPiles:ChargingPiles\r\nBracelet:Bracelet', '0');
INSERT INTO `iot_config` VALUES ('81', 'APP_TYPE', '3', 'app_type', '0', '', '', '1452050455', '1452050455', '1', 'Android:Android\r\nIos:Ios', '0');

-- -----------------------------
-- Table structure for `iot_connect_module`
-- -----------------------------
DROP TABLE IF EXISTS `iot_connect_module`;
CREATE TABLE `iot_connect_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_type` tinyint(4) NOT NULL,
  `module_name` varchar(64) DEFAULT NULL,
  `vendor_name` varchar(64) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_connect_module`
-- -----------------------------
INSERT INTO `iot_connect_module` VALUES ('15', '1', 'ESP8266', '乐鑫', '1450150559', '1450150559', '1');
INSERT INTO `iot_connect_module` VALUES ('16', '1', 'EMW3238', '庆科', '1450675742', '1450675742', '1');

-- -----------------------------
-- Table structure for `iot_device`
-- -----------------------------
DROP TABLE IF EXISTS `iot_device`;
CREATE TABLE `iot_device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `device_sn` varchar(32) DEFAULT NULL,
  `device_mac` varchar(32) DEFAULT NULL,
  `device_name` varchar(32) DEFAULT NULL,
  `device_reg_uid` int(11) DEFAULT NULL,
  `device_reg_addr` text,
  `device_reg_flg` int(11) DEFAULT NULL,
  `device_addr` text,
  `device_ip_addr` text,
  `device_current_status` varchar(32) DEFAULT NULL,
  `device_online_status` varchar(32) DEFAULT NULL,
  `device_firmware_ver` varchar(32) DEFAULT NULL,
  `device_firmware_updatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_device`
-- -----------------------------
INSERT INTO `iot_device` VALUES ('5', '5', '82NTESTMAC', '82NTESTMAC', '客厅设备', '1', '', '1', '', '', '', '', '', '2016-01-13 14:27:13');
INSERT INTO `iot_device` VALUES ('6', '5', '81NTESTMAC', '81NTESTMAC', '卧室设备', '1', '', '0', '', '', '', '', '', '2016-01-13 15:19:42');
INSERT INTO `iot_device` VALUES ('7', '8', 'TEST4FLYCO', 'TEST4FLYCO', '', '1', '', '1', '', '', '', '', '', '2016-01-15 10:24:21');
INSERT INTO `iot_device` VALUES ('8', '8', '18FE34A2E9B0', '18FE34A2E9B0', '', '1', '', '1', '', '', '', '', '', '2016-01-15 14:13:35');

-- -----------------------------
-- Table structure for `iot_device_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_device_log`;
CREATE TABLE `iot_device_log` (
  `id` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  `md_code` varchar(6) DEFAULT NULL,
  `md_type` int(11) DEFAULT NULL,
  `log_value` varchar(30) DEFAULT NULL,
  `log_display_txt` varchar(30) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_device_log`
-- -----------------------------
INSERT INTO `iot_device_log` VALUES ('0', '8', 'OPEN_I', '1', '', '', '1', '2016-01-15 15:05:06');

-- -----------------------------
-- Table structure for `iot_device_mac`
-- -----------------------------
DROP TABLE IF EXISTS `iot_device_mac`;
CREATE TABLE `iot_device_mac` (
  `device_sn` varchar(32) NOT NULL,
  `device_mac` varchar(32) NOT NULL,
  `device_wifi_mod` char(10) DEFAULT NULL,
  `device_produce_batch` char(10) DEFAULT NULL,
  `register_flg` char(10) DEFAULT NULL,
  `update_userid` char(10) DEFAULT NULL,
  `update_timestamp` char(10) DEFAULT NULL,
  PRIMARY KEY (`device_sn`,`device_mac`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_device_user`
-- -----------------------------
DROP TABLE IF EXISTS `iot_device_user`;
CREATE TABLE `iot_device_user` (
  `device_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `auth_level` char(10) DEFAULT NULL,
  `user_type` char(10) DEFAULT NULL,
  `reg_time` char(10) DEFAULT NULL,
  PRIMARY KEY (`device_id`,`person_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_device_user`
-- -----------------------------
INSERT INTO `iot_device_user` VALUES ('8', '1', '', '', '');
INSERT INTO `iot_device_user` VALUES ('7', '1', '-1', '0', '');
INSERT INTO `iot_device_user` VALUES ('5', '1', '-1', '0', '');

-- -----------------------------
-- Table structure for `iot_digital_parse_rule`
-- -----------------------------
DROP TABLE IF EXISTS `iot_digital_parse_rule`;
CREATE TABLE `iot_digital_parse_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `metadata_id` int(11) NOT NULL,
  `part_no` int(11) NOT NULL,
  `part_type` varchar(16) NOT NULL,
  `part_length` int(11) NOT NULL,
  `part_value` varchar(16) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_metadata_parse_relation` (`metadata_id`),
  KEY `FK_product_parse_rule` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=239 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_digital_parse_rule`
-- -----------------------------
INSERT INTO `iot_digital_parse_rule` VALUES ('172', '5', '7', '4', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('178', '5', '6', '5', 'chksum', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('177', '5', '6', '4', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('176', '5', '6', '3', 'content', '4', '0000', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('175', '5', '6', '2', 'command', '4', '1101', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('174', '5', '6', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('111', '8', '5', '6', 'chksum', '2', '', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('110', '8', '5', '5', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('109', '8', '5', '4', 'content', '2', '', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('108', '8', '5', '3', 'length', '2', '', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('107', '8', '5', '2', 'command', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('106', '8', '5', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('183', '5', '5', '5', 'chksum', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('182', '5', '5', '4', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('181', '5', '5', '3', 'content', '4', '1100', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('180', '5', '5', '2', 'command', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('179', '5', '5', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('171', '5', '7', '3', 'content', '4', '0000', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('170', '5', '7', '2', 'command', '4', '1100', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('169', '5', '7', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('154', '5', '8', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('155', '5', '8', '2', 'command', '4', '1011', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('156', '5', '8', '3', 'content', '4', '0000', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('157', '5', '8', '4', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('158', '5', '8', '5', 'chksum', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('167', '5', '10', '4', 'tail', '2', '5A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('166', '5', '10', '3', 'content', '4', '0000', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('165', '5', '10', '2', 'command', '4', '1111', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('164', '5', '10', '1', 'head', '2', 'A5', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('168', '5', '10', '5', 'chksum', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('173', '5', '7', '5', 'chksum', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('191', '8', '12', '3', 'content', '4', '0001', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('190', '8', '12', '2', 'command', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('189', '8', '12', '1', 'head', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('192', '8', '12', '4', 'chksum', '2', '02', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('193', '8', '12', '5', 'tail', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('194', '8', '13', '1', 'head', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('195', '8', '13', '2', 'command', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('196', '8', '13', '3', 'content', '4', '0000', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('197', '8', '13', '4', 'chksum', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('198', '8', '13', '5', 'tail', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('199', '8', '14', '1', 'head', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('200', '8', '14', '2', 'command', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('201', '8', '14', '3', 'content', '4', '0001', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('202', '8', '14', '4', 'chksum', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('203', '8', '14', '5', 'tail', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('223', '8', '7', '5', 'tail', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('222', '8', '7', '4', 'chksum', '2', 'XX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('221', '8', '7', '3', 'content', '4', 'XXXX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('220', '8', '7', '2', 'command', '2', '01', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('219', '8', '7', '1', 'head', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('214', '8', '6', '1', 'head', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('215', '8', '6', '2', 'command', '2', '0A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('216', '8', '6', '3', 'content', '4', 'XXXX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('217', '8', '6', '4', 'chksum', '2', 'XX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('218', '8', '6', '5', 'tail', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('224', '8', '15', '1', 'head', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('225', '8', '15', '2', 'command', '2', '00', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('226', '8', '15', '3', 'content', '4', '000A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('227', '8', '15', '4', 'chksum', '2', '0A', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('228', '8', '15', '5', 'tail', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('229', '8', '16', '1', 'head', '2', '55', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('230', '8', '16', '2', 'command', '2', '0C', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('231', '8', '16', '3', 'content', '4', 'XXXX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('232', '8', '16', '4', 'chksum', '2', 'XX', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('233', '8', '16', '5', 'tail', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('234', '8', '17', '1', 'head', '2', 'AA', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('235', '8', '17', '2', 'command', '2', '02', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('236', '8', '17', '3', 'content', '4', '0001', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('237', '8', '17', '4', 'chksum', '2', '03', '0', '0', '0');
INSERT INTO `iot_digital_parse_rule` VALUES ('238', '8', '17', '5', 'tail', '2', '55', '0', '0', '0');

-- -----------------------------
-- Table structure for `iot_field`
-- -----------------------------
DROP TABLE IF EXISTS `iot_field`;
CREATE TABLE `iot_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `field_data` varchar(1000) NOT NULL,
  `createTime` int(11) NOT NULL,
  `changeTime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_field_group`
-- -----------------------------
DROP TABLE IF EXISTS `iot_field_group`;
CREATE TABLE `iot_field_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_name` varchar(25) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `createTime` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `visiable` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_field_group`
-- -----------------------------
INSERT INTO `iot_field_group` VALUES ('1', '个人资料', '1', '1403847366', '0', '1');
INSERT INTO `iot_field_group` VALUES ('2', '开发者资料', '1', '1423537648', '0', '0');
INSERT INTO `iot_field_group` VALUES ('3', '开源中国资料', '1', '1423538446', '0', '0');

-- -----------------------------
-- Table structure for `iot_field_setting`
-- -----------------------------
DROP TABLE IF EXISTS `iot_field_setting`;
CREATE TABLE `iot_field_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_name` varchar(25) NOT NULL,
  `profile_group_id` int(11) NOT NULL,
  `visiable` tinyint(4) NOT NULL DEFAULT '1',
  `required` tinyint(4) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL,
  `form_type` varchar(25) NOT NULL,
  `form_default_value` varchar(200) NOT NULL,
  `validation` varchar(25) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `createTime` int(11) NOT NULL,
  `child_form_type` varchar(25) NOT NULL,
  `input_tips` varchar(100) NOT NULL COMMENT '输入提示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_field_setting`
-- -----------------------------
INSERT INTO `iot_field_setting` VALUES ('1', 'qq', '1', '1', '1', '0', 'input', '', '', '1', '1409045825', 'string', '');
INSERT INTO `iot_field_setting` VALUES ('2', '生日', '1', '1', '1', '0', 'time', '', '', '1', '1423537409', '', '');
INSERT INTO `iot_field_setting` VALUES ('3', '擅长语言', '2', '1', '1', '0', 'select', 'Java|C++|Python|php|object c|ruby', '', '1', '1423537693', '', '');
INSERT INTO `iot_field_setting` VALUES ('4', '承接项目', '2', '1', '1', '0', 'radio', '是|否', '', '1', '1423537733', '', '');
INSERT INTO `iot_field_setting` VALUES ('5', '简介', '2', '1', '1', '0', 'textarea', '', '', '1', '1423537770', '', '简单介绍入行以来的工作经验，项目经验');
INSERT INTO `iot_field_setting` VALUES ('6', '其他技能', '2', '1', '1', '0', 'checkbox', 'PhotoShop|Flash', '', '1', '1423537834', '', '');
INSERT INTO `iot_field_setting` VALUES ('7', '昵称', '3', '1', '1', '0', 'input', '', '', '1', '1423704462', 'string', 'OSC账号昵称');

-- -----------------------------
-- Table structure for `iot_file`
-- -----------------------------
DROP TABLE IF EXISTS `iot_file`;
CREATE TABLE `iot_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  `driver` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `iot_file`
-- -----------------------------
INSERT INTO `iot_file` VALUES ('1', '566ecaefaf3d1.txt', '566ecaefaf3d1.txt', '2015-12-14/', 'txt', 'text/plain', '251', '712b95c8fa2b2ef36ed9010c2a49e393', 'bd9de20cff667f585d4e5a21ca6b2c4fbe48093d', '0', '1450101487', 'local');
INSERT INTO `iot_file` VALUES ('2', '566ecb5839503.txt', '566ecb5839503.txt', '2015-12-14/', 'txt', 'text/plain', '255', 'f6246fbf48e1d322747d7c0ebaa8fc75', 'e180a60c1ed03677283b29db844f7546d9abd8b3', '0', '1450101592', 'local');
INSERT INTO `iot_file` VALUES ('3', '56721c429b3ce.zip', '56721c429b3ce.zip', '2015-12-17/', 'zip', 'application/x-zip-compressed', '1037', '4b54f8e34af240e9b8b5ebd648238b26', '43e3138d1933b92b1839320c4eadeac9fe385635', '0', '1450318914', 'local');
INSERT INTO `iot_file` VALUES ('4', '56933ce6a6913.txt', '56933ce6a6913.txt', '2016-01-11/', 'txt', 'text/plain', '1312', '427c1104cc365b289dc14e19c7928aed', '776ec22650113cbcb8161b8182126c0e453fc23d', '0', '1452489958', 'local');
INSERT INTO `iot_file` VALUES ('5', '56933cf59c6c3.txt', '56933cf59c6c3.txt', '2016-01-11/', 'txt', 'text/plain', '758', '9bd17a93cdedad5734fa98ac0fc142fb', '8aa70fd5619858f7f58500d6bf2ff9303712b569', '0', '1452489973', 'local');

-- -----------------------------
-- Table structure for `iot_follow`
-- -----------------------------
DROP TABLE IF EXISTS `iot_follow`;
CREATE TABLE `iot_follow` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `follow_who` int(11) NOT NULL COMMENT '关注谁',
  `who_follow` int(11) NOT NULL COMMENT '谁关注',
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='关注表';


-- -----------------------------
-- Table structure for `iot_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `iot_hooks`;
CREATE TABLE `iot_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_hooks`
-- -----------------------------
INSERT INTO `iot_hooks` VALUES ('38', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '');
INSERT INTO `iot_hooks` VALUES ('39', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'SuperLinks');
INSERT INTO `iot_hooks` VALUES ('40', 'adminEditor', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin');
INSERT INTO `iot_hooks` VALUES ('41', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SyncLogin,DevTeam,SystemInfo');
INSERT INTO `iot_hooks` VALUES ('42', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', '');
INSERT INTO `iot_hooks` VALUES ('43', 'app_begin', '应用开始', '2', '1384481614', 'Iswaf');
INSERT INTO `iot_hooks` VALUES ('44', 'checkIn', '签到', '1', '1395371353', '');
INSERT INTO `iot_hooks` VALUES ('45', 'Rank', '签到排名钩子', '1', '1395387442', 'Rank_checkin');
INSERT INTO `iot_hooks` VALUES ('46', 'support', '赞', '1', '1398264759', '');
INSERT INTO `iot_hooks` VALUES ('47', 'localComment', '本地评论插件', '1', '1399440321', 'LocalComment');
INSERT INTO `iot_hooks` VALUES ('48', 'weiboType', '微博类型', '1', '1409121894', '');
INSERT INTO `iot_hooks` VALUES ('49', 'repost', '转发钩子', '1', '1403668286', '');
INSERT INTO `iot_hooks` VALUES ('50', 'syncLogin', '第三方登陆位置', '1', '1403700579', 'SyncLogin');
INSERT INTO `iot_hooks` VALUES ('51', 'syncMeta', '第三方登陆meta接口', '1', '1403700633', 'SyncLogin');
INSERT INTO `iot_hooks` VALUES ('52', 'J_China_City', '每个系统都需要的一个中国省市区三级联动插件。', '1', '1403841931', 'ChinaCity');
INSERT INTO `iot_hooks` VALUES ('53', 'Advs', '广告位插件', '1', '1406687667', '');
INSERT INTO `iot_hooks` VALUES ('54', 'imageSlider', '图片轮播钩子', '1', '1407144022', '');
INSERT INTO `iot_hooks` VALUES ('55', 'friendLink', '友情链接插件', '1', '1407156413', 'SuperLinks');
INSERT INTO `iot_hooks` VALUES ('56', 'beforeSendWeibo', '在发微博之前预处理微博', '2', '1408084504', 'InsertFile');
INSERT INTO `iot_hooks` VALUES ('57', 'beforeSendRepost', '转发微博前的预处理钩子', '2', '1408085689', '');
INSERT INTO `iot_hooks` VALUES ('58', 'parseWeiboContent', '解析微博内容钩子', '2', '1409121261', '');
INSERT INTO `iot_hooks` VALUES ('59', 'userConfig', '用户配置页面钩子', '1', '1417137557', 'SyncLogin');
INSERT INTO `iot_hooks` VALUES ('60', 'weiboSide', '微博侧边钩子', '1', '1417063425', 'Retopic');
INSERT INTO `iot_hooks` VALUES ('61', 'personalMenus', '顶部导航栏个人下拉菜单', '1', '1417146501', '');
INSERT INTO `iot_hooks` VALUES ('62', 'dealPicture', '上传图片处理', '2', '1417139975', '');
INSERT INTO `iot_hooks` VALUES ('63', 'ucenterSideMenu', '用户中心左侧菜单', '1', '1417161205', '');
INSERT INTO `iot_hooks` VALUES ('64', 'afterTop', '顶部导航之后的钩子，调用公告等', '1', '1429671392', '');

-- -----------------------------
-- Table structure for `iot_invite`
-- -----------------------------
DROP TABLE IF EXISTS `iot_invite`;
CREATE TABLE `iot_invite` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY_KEY',
  `invite_type` int(11) NOT NULL COMMENT '邀请类型id',
  `code` varchar(25) NOT NULL COMMENT '邀请码',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `can_num` int(10) NOT NULL COMMENT '可以注册用户（含升级）',
  `already_num` int(10) NOT NULL COMMENT '已经注册用户（含升级）',
  `end_time` int(11) NOT NULL COMMENT '有效期至',
  `status` tinyint(2) NOT NULL COMMENT '0：已用完，1：还可注册，2：用户取消邀请，-1：管理员删除',
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邀请码表';


-- -----------------------------
-- Table structure for `iot_invite_buy_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_invite_buy_log`;
CREATE TABLE `iot_invite_buy_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY_KEY',
  `invite_type` int(11) NOT NULL COMMENT '邀请类型id',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `num` int(10) NOT NULL COMMENT '可邀请名额',
  `content` varchar(200) NOT NULL COMMENT '记录信息',
  `create_time` int(11) NOT NULL COMMENT '创建时间（做频率用）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户购买邀请名额记录';


-- -----------------------------
-- Table structure for `iot_invite_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_invite_log`;
CREATE TABLE `iot_invite_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY_KEY',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `inviter_id` int(11) NOT NULL COMMENT '邀请人id',
  `invite_id` int(11) NOT NULL COMMENT '邀请码id',
  `content` varchar(200) NOT NULL COMMENT '记录内容',
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邀请注册成功记录表';


-- -----------------------------
-- Table structure for `iot_invite_type`
-- -----------------------------
DROP TABLE IF EXISTS `iot_invite_type`;
CREATE TABLE `iot_invite_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY_KEY',
  `title` varchar(25) NOT NULL COMMENT '标题',
  `length` int(10) NOT NULL DEFAULT '11' COMMENT '验证码长度',
  `time` varchar(50) NOT NULL COMMENT '有效时长，带单位的时间',
  `cycle_num` int(10) NOT NULL COMMENT '周期内可购买个数',
  `cycle_time` varchar(50) NOT NULL COMMENT '周期时长，带单位的时间',
  `roles` varchar(50) NOT NULL COMMENT '绑定角色ids',
  `auth_groups` varchar(50) NOT NULL COMMENT '允许购买的用户组ids',
  `pay_score` int(10) NOT NULL COMMENT '购买消耗积分',
  `pay_score_type` int(11) NOT NULL COMMENT '购买消耗积分类型',
  `income_score` int(10) NOT NULL COMMENT '每邀请成功一个用户，邀请者增加积分',
  `income_score_type` int(11) NOT NULL COMMENT '邀请成功后增加积分类型id',
  `is_follow` tinyint(2) NOT NULL COMMENT '邀请成功后是否互相关注',
  `status` tinyint(2) NOT NULL,
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  `update_time` int(11) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邀请注册码类型表';


-- -----------------------------
-- Table structure for `iot_invite_user_info`
-- -----------------------------
DROP TABLE IF EXISTS `iot_invite_user_info`;
CREATE TABLE `iot_invite_user_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PRIMARY_KEY',
  `invite_type` int(11) NOT NULL COMMENT '邀请类型id',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `num` int(11) NOT NULL COMMENT '可邀请名额',
  `already_num` int(11) NOT NULL COMMENT '已邀请名额',
  `success_num` int(11) NOT NULL COMMENT '成功邀请名额',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邀请注册用户信息';


-- -----------------------------
-- Table structure for `iot_local_comment`
-- -----------------------------
DROP TABLE IF EXISTS `iot_local_comment`;
CREATE TABLE `iot_local_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `app` text NOT NULL,
  `mod` text NOT NULL,
  `row_id` int(11) NOT NULL,
  `parse` int(11) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `create_time` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_member`
-- -----------------------------
DROP TABLE IF EXISTS `iot_member`;
CREATE TABLE `iot_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(32) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  `last_login_role` int(11) NOT NULL,
  `show_role` int(11) NOT NULL COMMENT '个人主页显示角色',
  `signature` text NOT NULL,
  `pos_province` int(11) NOT NULL,
  `pos_city` int(11) NOT NULL,
  `pos_district` int(11) NOT NULL,
  `pos_community` int(11) NOT NULL,
  `score1` float DEFAULT '0' COMMENT '用户积分',
  `score2` float DEFAULT '0' COMMENT 'score2',
  `score3` float DEFAULT '0' COMMENT 'score3',
  `score4` float DEFAULT '0' COMMENT 'score4',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`),
  KEY `name` (`nickname`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `iot_member`
-- -----------------------------
INSERT INTO `iot_member` VALUES ('1', 'admin', '0', '0000-00-00', '', '45', '0', '1450079699', '1918707630', '1453033410', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('100', 'test', '0', '0000-00-00', '', '10', '0', '1450703702', '1022852494', '1452485216', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('101', 'luyuan', '0', '0000-00-00', '', '0', '0', '1450704396', '0', '0', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('102', 'qinhao', '0', '0000-00-00', '', '1', '0', '1451026953', '0', '1451027282', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `iot_member` VALUES ('103', 'yuhai', '0', '0000-00-00', '', '0', '0', '1451027516', '0', '0', '1', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `iot_menu`
-- -----------------------------
DROP TABLE IF EXISTS `iot_menu`;
CREATE TABLE `iot_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `icon` varchar(20) DEFAULT NULL COMMENT '导航图标',
  `module` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=301 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_menu`
-- -----------------------------
INSERT INTO `iot_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0', 'home', '');
INSERT INTO `iot_menu` VALUES ('2', '用户', '0', '2', 'User/index', '0', '', '', '0', 'user', '');
INSERT INTO `iot_menu` VALUES ('3', '用户信息', '2', '0', 'User/index', '0', '', '用户管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('4', '用户行为', '2', '0', 'User/action', '0', '', '行为管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('5', '新增用户行为', '4', '0', 'User/addaction', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('6', '编辑用户行为', '4', '0', 'User/editaction', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('7', '保存用户行为', '4', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('8', '变更行为状态', '4', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('9', '禁用会员', '4', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('10', '启用会员', '4', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('11', '删除会员', '4', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('12', '权限管理', '2', '0', 'AuthManager/index', '0', '', '权限管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('13', '删除', '12', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('14', '禁用', '12', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('15', '恢复', '12', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('16', '新增', '12', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('17', '编辑', '12', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('18', '保存用户组', '12', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('19', '授权', '12', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('20', '访问授权', '12', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('21', '成员授权', '12', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('22', '解除授权', '12', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('23', '保存成员授权', '12', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('24', '分类授权', '12', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('25', '保存分类授权', '12', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('26', '模型授权', '12', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('27', '保存模型授权', '12', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('28', '新增权限节点', '12', '0', 'AuthManager/addNode', '1', '', '', '1', '', '');
INSERT INTO `iot_menu` VALUES ('29', '前台权限管理', '12', '0', 'AuthManager/accessUser', '1', '', '权限管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('30', '删除权限节点', '12', '0', 'AuthManager/deleteNode', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('31', '行为日志', '2', '0', 'Action/actionlog', '0', '', '行为管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('32', '查看行为日志', '31', '0', 'action/edit', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('33', '修改密码', '2', '0', 'User/updatePassword', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('34', '修改昵称', '2', '0', 'User/updateNickname', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('35', '查看用户', '2', '0', 'Rank/userList', '1', '', '头衔管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('36', '用户头衔列表', '35', '0', 'Rank/userRankList', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('37', '关联新头衔', '35', '0', 'Rank/userAddRank', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('38', '编辑头衔关联', '35', '0', 'Rank/userChangeRank', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('39', '扩展资料', '2', '0', 'Admin/User/profile', '0', '', '用户管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('40', '添加、编辑分组', '39', '0', 'Admin/User/editProfile', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('41', '分组排序', '39', '0', 'Admin/User/sortProfile', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('42', '字段列表', '39', '0', 'Admin/User/field', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('43', '添加、编辑字段', '39', '0', 'Admin/User/editFieldSetting', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('44', '字段排序', '39', '0', 'Admin/User/sortField', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('45', '用户扩展资料列表', '2', '0', 'Admin/User/expandinfo_select', '0', '', '用户管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('46', '扩展资料详情', '45', '0', 'User/expandinfo_details', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('47', '待审核用户头衔', '2', '0', 'Rank/rankVerify', '1', '', '头衔管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('48', '被驳回的头衔申请', '2', '0', 'Rank/rankVerifyFailure', '1', '', '头衔管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('49', '转移用户组', '2', '0', 'User/changeGroup', '1', '批量转移用户组', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('50', '用户注册配置', '2', '0', 'UserConfig/index', '0', '', '注册配置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('51', '积分类型列表', '2', '0', 'User/scoreList', '0', '', '行为管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('52', '新增/编辑类型', '2', '0', 'user/editScoreType', '1', '', '行为管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('53', '充值积分', '2', '0', 'user/recharge', '1', '', '', '0', '用户管理', '');
INSERT INTO `iot_menu` VALUES ('54', '头衔列表', '2', '10', 'Rank/index', '1', '', '头衔管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('55', '添加头衔', '2', '2', 'Rank/editRank', '1', '', '头衔管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('56', '插件', '0', '5', 'Addons/index', '1', '', '', '0', 'cogs', '');
INSERT INTO `iot_menu` VALUES ('57', '插件管理', '56', '1', 'Addons/index', '0', '', '扩展', '0', '', '');
INSERT INTO `iot_menu` VALUES ('58', '钩子管理', '56', '2', 'Addons/hooks', '0', '', '扩展', '0', '', '');
INSERT INTO `iot_menu` VALUES ('59', '创建', '57', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('60', '检测创建', '57', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('61', '预览', '57', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('62', '快速生成插件', '57', '0', 'Addons/build', '0', '开始生成插件结构', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('64', '设置', '57', '0', 'Addons/config', '0', '设置插件配置', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('65', '禁用', '57', '0', 'Addons/disable', '0', '禁用插件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('66', '启用', '57', '0', 'Addons/enable', '0', '启用插件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('67', '安装', '57', '0', 'Addons/install', '0', '安装插件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('68', '卸载', '57', '0', 'Addons/uninstall', '0', '卸载插件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('69', '更新配置', '57', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('70', '插件后台列表', '57', '0', 'Addons/adminList', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('71', 'URL方式访问插件', '57', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('72', '新增钩子', '58', '0', 'Addons/addHook', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('73', '编辑钩子', '58', '0', 'Addons/edithook', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('74', '系统', '0', '6', 'Config/group', '0', '', '', '0', 'windows', '');
INSERT INTO `iot_menu` VALUES ('75', '网站设置', '74', '1', 'Config/group', '0', '', '系统设置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('76', '配置管理', '74', '4', 'Config/index', '0', '', '系统设置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('77', '编辑', '76', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('78', '删除', '76', '0', 'Config/del', '0', '删除配置', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('79', '新增', '76', '0', 'Config/add', '0', '新增配置', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('80', '保存', '76', '0', 'Config/save', '0', '保存配置', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('81', '排序', '76', '0', 'Config/sort', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('82', '菜单管理', '2', '5', 'Menu/index', '0', '', '权限管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('83', '新增', '82', '0', 'Menu/add', '0', '', '系统设置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('84', '编辑', '82', '0', 'Menu/edit', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('85', '导入', '82', '0', 'Menu/import', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('86', '排序', '82', '0', 'Menu/sort', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('87', '导航管理', '74', '6', 'Channel/index', '0', '', '系统设置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('88', '新增', '87', '0', 'Channel/add', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('89', '编辑', '87', '0', 'Channel/edit', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('90', '删除', '87', '0', 'Channel/del', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('91', '排序', '87', '0', 'Channel/sort', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('92', '备份数据库', '74', '20', 'Database/index?type=export', '0', '', '数据备份', '0', '', '');
INSERT INTO `iot_menu` VALUES ('93', '备份', '92', '0', 'Database/export', '0', '备份数据库', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('94', '优化表', '92', '0', 'Database/optimize', '0', '优化数据表', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('95', '修复表', '92', '0', 'Database/repair', '0', '修复数据表', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('96', '还原数据库', '74', '0', 'Database/index?type=import', '0', '', '数据备份', '0', '', '');
INSERT INTO `iot_menu` VALUES ('97', '恢复', '96', '0', 'Database/import', '0', '数据库恢复', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('98', '删除', '96', '0', 'Database/del', '0', '删除备份文件', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('99', 'SEO规则管理', '74', '0', 'SEO/index', '0', '', 'SEO规则', '0', '', '');
INSERT INTO `iot_menu` VALUES ('100', '新增、编辑', '99', '0', 'SEO/editRule', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('101', '排序', '99', '0', 'SEO/sortRule', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('102', 'SEO规则回收站', '74', '0', 'SEO/ruleTrash', '0', '', 'SEO规则', '0', '', '');
INSERT INTO `iot_menu` VALUES ('103', '全部补丁', '74', '0', 'Admin/Update/quick', '0', '', '升级补丁', '0', '', '');
INSERT INTO `iot_menu` VALUES ('104', '新增补丁', '74', '0', 'Admin/Update/addpack', '1', '', '升级补丁', '0', '', '');
INSERT INTO `iot_menu` VALUES ('105', '云市场', '0', '5', 'module/lists', '1', '', '', '0', 'cloud', '');
INSERT INTO `iot_menu` VALUES ('106', '模块安装', '105', '0', 'module/install', '1', '', '云市场', '0', '', '');
INSERT INTO `iot_menu` VALUES ('107', '模块管理', '105', '0', 'module/lists', '0', '', '云市场', '0', '', '');
INSERT INTO `iot_menu` VALUES ('108', '卸载模块', '105', '0', 'module/uninstall', '1', '', '云市场', '0', '', '');
INSERT INTO `iot_menu` VALUES ('109', '授权', '0', '3', 'authorize/ssoSetting', '0', '', '', '0', 'lock', '');
INSERT INTO `iot_menu` VALUES ('110', '单点登录配置', '109', '0', 'Authorize/ssoSetting', '0', '', '单点登录', '0', '', '');
INSERT INTO `iot_menu` VALUES ('111', '应用列表', '109', '0', 'Authorize/ssolist', '0', '', '单点登录', '0', '', '');
INSERT INTO `iot_menu` VALUES ('112', '新增/编辑应用', '109', '0', 'authorize/editssoapp', '1', '', '单点登录', '0', '', '');
INSERT INTO `iot_menu` VALUES ('113', '安全', '0', '4', 'ActionLimit/limitList', '0', '', '', '0', 'shield', '');
INSERT INTO `iot_menu` VALUES ('114', '行为限制列表', '113', '0', 'ActionLimit/limitList', '0', '', '行为限制', '0', '', '');
INSERT INTO `iot_menu` VALUES ('115', '新增/编辑行为限制', '113', '0', 'ActionLimit/editLimit', '1', '', '行为限制', '0', '', '');
INSERT INTO `iot_menu` VALUES ('116', '角色', '0', '3', 'Role/index', '0', '', '', '0', 'group', '');
INSERT INTO `iot_menu` VALUES ('117', '角色列表', '116', '0', 'Role/index', '0', '', '角色管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('118', '编辑角色', '116', '0', 'Role/editRole', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('119', '启用、禁用、删除角色', '116', '0', 'Role/setStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('120', '角色排序', '116', '0', 'Role/sort', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('121', '默认积分配置', '117', '0', 'Role/configScore', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('122', '默认权限配置', '117', '0', 'Role/configAuth', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('123', '默认头像配置', '117', '0', 'Role/configAvatar', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('124', '默认头衔配置', '117', '0', 'Role/configRank', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('125', '默认字段管理', '117', '0', 'Role/configField', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('126', '角色分组', '116', '0', 'Role/group', '0', '', '角色管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('127', '编辑分组', '126', '0', 'Role/editGroup', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('128', '删除分组', '126', '0', 'Role/deleteGroup', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('129', '角色基本信息配置', '116', '0', 'Role/config', '1', '', '角色管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('130', '用户列表', '116', '0', 'Role/userList', '0', '', '角色用户管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('131', '设置用户状态', '130', '0', 'Role/setUserStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('132', '审核用户', '130', '0', 'Role/setUserAudit', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('133', '迁移用户', '130', '0', 'Role/changeRole', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('134', '上传默认头像', '123', '0', 'Role/uploadPicture', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('135', '类型管理', '116', '0', 'Invite/index', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('136', '邀请码管理', '116', '0', 'Invite/invite', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('137', '基础配置', '116', '0', 'Invite/config', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('138', '兑换记录', '116', '0', 'Invite/buyLog', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('139', '邀请记录', '116', '0', 'Invite/inviteLog', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('140', '用户信息', '116', '0', 'Invite/userInfo', '0', '', '邀请注册管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('141', '编辑邀请注册类型', '135', '0', 'Invite/edit', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('142', '删除邀请', '135', '0', 'Invite/setStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('143', '删除邀请码', '136', '0', 'Invite/delete', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('144', '生成邀请码', '136', '0', 'Invite/createCode', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('145', '删除无用邀请码', '136', '0', 'Invite/deleteTrue', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('146', '导出cvs', '136', '0', 'Invite/cvs', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('147', '用户信息编辑', '140', '0', 'Invite/editUserInfo', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('148', '删除日志', '31', '0', 'Action/remove', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('149', '清空日志', '31', '0', 'Action/clear', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('150', '设置积分状态', '51', '0', 'User/setTypeStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('151', '删除积分类型', '51', '0', 'User/delType', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('152', '充值积分', '53', '0', 'User/getNickname', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('153', '删除菜单', '82', '0', 'Menu/del', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('154', '设置开发者模式可见', '82', '0', 'Menu/toogleDev', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('155', '设置显示隐藏', '82', '0', 'Menu/toogleHide', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('156', '行为限制启用、禁用、删除', '114', '0', 'ActionLimit/setLimitStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('157', '启用、禁用、删除、回收站还原', '99', '0', 'SEO/setRuleStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('158', '回收站彻底删除', '102', '0', 'SEO/doClear', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('159', '初始化无角色用户', '130', '0', 'Role/initUnhaveUser', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('160', '删除钩子', '58', '0', 'Addons/delHook', '0', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('161', '使用补丁', '103', '0', 'Update/usePack', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('162', '查看补丁', '103', '0', 'Update/view', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('163', '删除补丁', '103', '0', 'Update/delPack', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('164', '标签列表', '2', '0', 'UserTag/userTag', '1', '', '用户标签管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('165', '添加分类、标签', '164', '0', 'UserTag/add', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('166', '设置分类、标签状态', '164', '0', 'UserTag/setStatus', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('167', '分类、标签回收站', '164', '0', 'UserTag/tagTrash', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('168', '测底删除回收站内容', '164', '0', 'UserTag/userTagClear', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('169', '可拥有标签配置', '116', '0', 'role/configusertag', '1', '', '', '0', '', '');
INSERT INTO `iot_menu` VALUES ('170', '编辑模块', '107', '0', 'Module/edit', '1', '', '模块管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('171', '网站信息', '74', '0', 'Config/website', '0', '', '系统设置', '0', '', '');
INSERT INTO `iot_menu` VALUES ('210', '智能硬件', '0', '60', 'Product/index', '0', '', '', '0', 'wrench', 'product');
INSERT INTO `iot_menu` VALUES ('211', '所有元数据', '210', '11', 'Product/metadatas', '0', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('212', '功能类', '211', '12', '/Product/metadatas/md_type/1', '0', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('213', '传感类', '211', '13', '/Product/metadatas/md_type/2', '0', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('214', '状态类', '211', '14', '/Product/metadatas/md_type/3', '0', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('215', '异常类', '211', '15', '/Product/metadatas/md_type/4', '0', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('216', '编辑传感类元素据', '211', '16', 'Product/editMetadata', '1', '', '元数据管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('217', '产品管理', '210', '20', 'Product/index', '0', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('218', '产品添加修改', '217', '21', 'Product/addProduct', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('219', '日志配置列表', '217', '22', 'Product/listLogConfig', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('220', '日志配置修改', '217', '23', 'Product/addLogConfig', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('221', '产品元数据列表', '217', '25', 'Product/listMetadata', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('222', '产品导航', '210', '26', 'Product/wizard', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('223', '产品分类', '210', '27', 'Product/categories', '0', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('224', '产品分类编辑', '223', '28', 'Product/addCategories', '1', '', '产品管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('225', '联网模组', '210', '31', 'Product/listConnectModule', '0', '', '固件管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('226', '模组添加修改', '225', '32', 'Product/addConnectModule', '1', '', '固件管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('227', '固件维护', '210', '33', 'Product/listFirmware', '0', '', '固件管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('228', '固件添加修改', '227', '34', 'Product/addFirmware', '1', '', '固件管理', '0', '', 'product');
INSERT INTO `iot_menu` VALUES ('229', '新增管理员', '2', '0', 'User/addNewAdmin', '0', '', '用户管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('230', '接口管理', '113', '60', 'OpenAPI/apiList', '0', '', '接口安全', '0', 'book', 'OpenAPI');
INSERT INTO `iot_menu` VALUES ('290', '设备日志', '283', '7', 'Device/listDeviceLog', '0', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('289', '设备用户编辑', '283', '6', 'Device/editDeviceUser', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('288', '设备解注册', '283', '5', 'Device/detachDevice', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('287', '设备控制', '283', '4', 'Device/controlDevice', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('286', '设备添加', '283', '3', 'Device/addDevice', '1', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('285', '设备注册', '283', '2', 'Device/register', '0', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('284', '设备一览', '283', '1', 'Device/index', '0', '', '设备管理', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('283', '设备管理', '0', '55', 'Device/index', '1', '', '', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('242', 'App管理', '0', '60', 'Appmgr/Appmgr', '1', '', '', '0', 'wrench', '');
INSERT INTO `iot_menu` VALUES ('267', 'App管理', '0', '60', 'Appmgr/Appmgr', '1', '', '', '0', 'wrench', '');
INSERT INTO `iot_menu` VALUES ('244', '新增APP', '242', '21', 'Appmgr/addAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('245', 'listAPP', '242', '22', 'Appmgr/listAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('246', 'removeAPP', '242', '23', 'Appmgr/removeAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('247', '消息管理', '242', '3', 'Appmgr/listSmsMessage', '0', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('248', 'listSmsMessage', '242', '31', 'Appmgr/listSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('249', '添加消息', '242', '32', 'Appmgr/addSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('275', 'App管理', '0', '60', 'Appmgr/Appmgr', '1', '', '', '0', 'wrench', '');
INSERT INTO `iot_menu` VALUES ('269', '新增APP', '267', '21', 'Appmgr/addAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('270', 'listAPP', '267', '22', 'Appmgr/listAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('271', 'removeAPP', '267', '23', 'Appmgr/removeAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('272', '消息管理', '267', '3', 'Appmgr/listSmsMessage', '0', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('273', 'listSmsMessage', '267', '31', 'Appmgr/listSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('274', '添加消息', '267', '32', 'Appmgr/addSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('293', 'App管理', '0', '60', 'Appmgr/Appmgr', '1', '', '', '0', 'wrench', '');
INSERT INTO `iot_menu` VALUES ('277', '新增APP', '275', '21', 'Appmgr/addAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('278', 'listAPP', '275', '22', 'Appmgr/listAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('279', 'removeAPP', '275', '23', 'Appmgr/removeAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('280', '消息管理', '275', '3', 'Appmgr/listSmsMessage', '0', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('281', 'listSmsMessage', '275', '31', 'Appmgr/listSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('282', '添加消息', '275', '32', 'Appmgr/addSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('291', 'MAC文件上传', '283', '21', 'Device/index', '0', '', '设备授权', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('292', '授权维护', '283', '22', 'Device/listDeviceUser', '1', '', '设备授权', '0', '', 'device');
INSERT INTO `iot_menu` VALUES ('294', 'App管理', '293', '2', 'Appmgr/index', '0', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('295', '新增APP', '293', '21', 'Appmgr/addAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('296', 'listAPP', '293', '22', 'Appmgr/listAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('297', 'removeAPP', '293', '23', 'Appmgr/removeAPP', '1', '', 'App管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('298', '消息管理', '293', '3', 'Appmgr/listSmsMessage', '0', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('299', 'listSmsMessage', '293', '31', 'Appmgr/listSmsMessage', '1', '', '消息管理', '0', '', '');
INSERT INTO `iot_menu` VALUES ('300', '添加消息', '293', '32', 'Appmgr/addSmsMessage', '1', '', '消息管理', '0', '', '');

-- -----------------------------
-- Table structure for `iot_message`
-- -----------------------------
DROP TABLE IF EXISTS `iot_message`;
CREATE TABLE `iot_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_uid` int(11) NOT NULL,
  `to_uid` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `create_time` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '0系统消息,1用户消息,2应用消息',
  `is_read` tinyint(4) NOT NULL,
  `last_toast` int(11) NOT NULL,
  `url` varchar(400) NOT NULL,
  `talk_id` int(11) NOT NULL,
  `appname` varchar(30) NOT NULL,
  `apptype` varchar(30) NOT NULL,
  `source_id` int(11) NOT NULL,
  `find_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='thinkox新增消息表';


-- -----------------------------
-- Table structure for `iot_metadata`
-- -----------------------------
DROP TABLE IF EXISTS `iot_metadata`;
CREATE TABLE `iot_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `md_type` tinyint(4) NOT NULL,
  `md_code` varchar(16) NOT NULL,
  `md_name` varchar(32) NOT NULL,
  `md_value_type` varchar(16) NOT NULL,
  `md_scope` varchar(16) NOT NULL,
  `md_description` longtext,
  `md_owner_code` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_metadata`
-- -----------------------------
INSERT INTO `iot_metadata` VALUES ('5', '1', '1450082577', '1450082577', '1', 'POWER_ONOFF', '开关机', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('6', '1', '1452223402', '1452223402', '2', 'TEMPERATURE', '温度', '1', '1', '', 'admin');
INSERT INTO `iot_metadata` VALUES ('7', '1', '1452223456', '1452223456', '3', 'POWER_STATUS', '开关机状态', '3', '2', '', 'admin');
INSERT INTO `iot_metadata` VALUES ('8', '1', '1452654624', '1452654624', '1', 'SWITCH_MODE', '切换模式', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('9', '-1', '1452668946', '1452823288', '1', 'SWITCH_MODE', '切换模式', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('10', '1', '1452668984', '1452668984', '2', 'HUMIDITY', '湿度', '1', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('11', '1', '1452669115', '1452669183', '4', 'LOW_POWER', '电量不足', '2', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('12', '1', '1452821565', '1452821565', '1', 'POWER_ON', '开机', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('13', '1', '1452821586', '1452821586', '1', 'POWER_OFF', '关机', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('14', '1', '1452822333', '1452822333', '1', 'QUERY_POWER', '查询开关机状态', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('15', '1', '1452823240', '1452823240', '1', 'QUERY_TEMPERATUR', '查询温度', '0', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('16', '1', '1452838803', '1452838803', '2', 'PM25', '空气指标', '1', '1', '', '');
INSERT INTO `iot_metadata` VALUES ('17', '1', '1452841457', '1452841457', '1', 'OPEN_ION', '开启负离子', '0', '1', '', '');

-- -----------------------------
-- Table structure for `iot_module`
-- -----------------------------
DROP TABLE IF EXISTS `iot_module`;
CREATE TABLE `iot_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL COMMENT '模块名',
  `alias` varchar(30) NOT NULL COMMENT '中文名',
  `version` varchar(20) NOT NULL COMMENT '版本号',
  `is_com` tinyint(4) NOT NULL COMMENT '是否商业版',
  `show_nav` tinyint(4) NOT NULL COMMENT '是否显示在导航栏中',
  `summary` varchar(200) NOT NULL COMMENT '简介',
  `developer` varchar(50) NOT NULL COMMENT '开发者',
  `website` varchar(200) NOT NULL COMMENT '网址',
  `entry` varchar(50) NOT NULL COMMENT '前台入口',
  `is_setup` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否已安装',
  `sort` int(11) NOT NULL COMMENT '模块排序',
  `icon` varchar(20) NOT NULL,
  `can_uninstall` tinyint(4) NOT NULL,
  `admin_entry` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `name_2` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='模块管理表';

-- -----------------------------
-- Records of `iot_module`
-- -----------------------------
INSERT INTO `iot_module` VALUES ('1', 'Appmgr', 'App管理', '1.0.0', '0', '1', '对App应用的版本管理，消息推送管理等', 'xxxx科技有限公司', 'http://www.xxxx.com', '', '1', '0', 'mobile', '1', 'Admin/Appmgr/index');
INSERT INTO `iot_module` VALUES ('2', 'Device', '设备监控', '1.0.0', '0', '1', '用于接入设备的管理及监控', 'xxxx科技有限公司', 'http://www.xxxx.com', '', '1', '0', 'mobile', '1', 'Admin/Device/index');
INSERT INTO `iot_module` VALUES ('3', 'Home', '网站主页', '1.0.0', '0', '1', '首页模块，主要用于展示网站内容', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Home/index/index', '1', '0', 'home', '0', 'Admin/index/index');
INSERT INTO `iot_module` VALUES ('4', 'Issue', '专辑', '1.0.0', '0', '1', '专辑模块，适用于精品内容展示', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Issue/index/index', '0', '0', 'th', '1', 'Admin/Issue/contents');
INSERT INTO `iot_module` VALUES ('5', 'Metadata', '硬件元数据', '1.0.0', '0', '1', '用于智能硬件产品元数据的定义，管理', 'xxxx科技有限公司', 'http://www.xxxx.com', '', '0', '0', 'th', '1', 'Admin/Metadata/index');
INSERT INTO `iot_module` VALUES ('6', 'People', '会员展示', '1.0.0', '0', '1', '会员展示模块，可以用于会员的查找', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'People/index/index', '0', '0', 'group', '1', 'Admin/index/index');
INSERT INTO `iot_module` VALUES ('7', 'Product', '智能硬件', '1.0.0', '0', '1', '用于智能硬件产品的定义，管理', 'xxxx科技有限公司', 'http://www.xxxx.com', 'Product/index/index', '1', '0', 'wrench', '1', 'Admin/Product/index');
INSERT INTO `iot_module` VALUES ('8', 'Security', '授权管理', '1.0.0', '0', '1', '对物联网的设备，用户，API做授权管理及配置', 'xxxx科技有限公司', 'http://www.xxxx.com', '', '0', '0', 'mobile', '1', 'Admin/Security/index');
INSERT INTO `iot_module` VALUES ('9', 'Ucenter', '用户中心', '1.0.0', '0', '1', '用户中心模块，系统核心模块', '嘉兴想天信息科技有限公司', 'http://www.ourstu.com', 'Ucenter/index/index', '1', '0', 'user', '0', 'Admin/User/index');
INSERT INTO `iot_module` VALUES ('10', 'OpenAPI', '开放接口', '1.0.0', '0', '1', '提供智能设备PaaS相关的开放接口，并提供接口的管理', '帕启拉科技有限公司', 'http://www.pachila.cn', 'index/openapi', '1', '0', 'book', '1', 'OpenApi/apiList');

-- -----------------------------
-- Table structure for `iot_module_firmware`
-- -----------------------------
DROP TABLE IF EXISTS `iot_module_firmware`;
CREATE TABLE `iot_module_firmware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `firmware_name` varchar(64) NOT NULL,
  `firmware_version` varchar(32) NOT NULL,
  `file_ids` varchar(64) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_firmware_module` (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_module_firmware`
-- -----------------------------
INSERT INTO `iot_module_firmware` VALUES ('15', '15', '测试版本', '1.0.0.1', '1,2,3', '1450156456', '1450318921', '1');

-- -----------------------------
-- Table structure for `iot_picture`
-- -----------------------------
DROP TABLE IF EXISTS `iot_picture`;
CREATE TABLE `iot_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `type` varchar(50) NOT NULL,
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_picture`
-- -----------------------------
INSERT INTO `iot_picture` VALUES ('1', 'local', '/Uploads/Picture/2015-12-15/566fa107c622d.png', '', 'dcb6cf77ec3dc98fba0ba559e3fbcbb8', '7c6c4154824466fc4ce4ac9eb11634444c5e1a4b', '1', '1450156295');
INSERT INTO `iot_picture` VALUES ('2', 'local', '/Uploads/Picture/2015-12-18/5673a97bab629.png', '', '4927ef2717e7dd767020b24eb3cb5ccd', 'f4f92330efd92ce53278c1bc623763b1127707b3', '1', '1450420603');
INSERT INTO `iot_picture` VALUES ('3', 'local', '/Uploads/Picture/2015-12-19/567517612a746.png', '', '1deee7a99bd40e8373a684a87ed53541', 'e018be4c5205bacf9ea66db326c26c32f1a2b625', '1', '1450514273');
INSERT INTO `iot_picture` VALUES ('4', 'local', '/Uploads/Picture/2016-01-10/56920a7da2f0b.png', '', '6eaadd160869f740fb7fa111d96cfc17', 'b96ede86ff5f2836069b418cf4fb564d5a20c9b3', '1', '1452411517');

-- -----------------------------
-- Table structure for `iot_product`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product`;
CREATE TABLE `iot_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_category` int(11) NOT NULL,
  `product_code` varchar(16) NOT NULL,
  `product_name` varchar(32) DEFAULT NULL,
  `connect_type` tinyint(4) DEFAULT NULL,
  `logo_img` varchar(32) DEFAULT NULL,
  `logo_length` int(11) DEFAULT NULL,
  `logo_height` int(11) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `owner_code` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_FK_proudct_type` (`product_category`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product`
-- -----------------------------
INSERT INTO `iot_product` VALUES ('5', '15', 'TEST', '测试商品', '1', '1', '0', '0', '1450154658', '1452669003', '1', 'admin');
INSERT INTO `iot_product` VALUES ('8', '15', 'FLYCO_AIRCLEANER', '飞科空静', '1', '4', '0', '0', '1450159752', '1452841473', '1', 'admin');

-- -----------------------------
-- Table structure for `iot_product_category`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_category`;
CREATE TABLE `iot_product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `pid` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_category`
-- -----------------------------
INSERT INTO `iot_product_category` VALUES ('15', '家电', '0', '0', '1450082433', '1450082433', '1');
INSERT INTO `iot_product_category` VALUES ('16', '穿戴设备', '0', '0', '1450082450', '1450082450', '1');
INSERT INTO `iot_product_category` VALUES ('17', '其他智能单品', '0', '0', '1450082477', '1450082477', '1');
INSERT INTO `iot_product_category` VALUES ('18', '空气净化器', '15', '0', '1450082493', '1450082493', '1');
INSERT INTO `iot_product_category` VALUES ('19', '运动手环', '16', '0', '1450082505', '1450082505', '1');
INSERT INTO `iot_product_category` VALUES ('20', '水净化器', '15', '0', '1450082519', '1450082519', '1');

-- -----------------------------
-- Table structure for `iot_product_enum`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_enum`;
CREATE TABLE `iot_product_enum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metadata_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `enum_key` char(10) DEFAULT NULL,
  `enum_value` varchar(32) DEFAULT NULL,
  `display_value` varchar(32) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_metadata_enum_relation` (`metadata_id`),
  KEY `FK_product_enum_relation` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_enum`
-- -----------------------------
INSERT INTO `iot_product_enum` VALUES ('6', '7', '5', '1001', 'ON', '开机', '0', '0', '0');
INSERT INTO `iot_product_enum` VALUES ('7', '7', '5', '1002', 'OFF', '关机', '0', '0', '0');
INSERT INTO `iot_product_enum` VALUES ('8', '7', '8', '0001', 'ON', '开机', '0', '0', '0');
INSERT INTO `iot_product_enum` VALUES ('9', '7', '8', '0000', 'OFF', '关机', '0', '0', '0');

-- -----------------------------
-- Table structure for `iot_product_firmware`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_firmware`;
CREATE TABLE `iot_product_firmware` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `firmware_id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_product_firmware_lef` (`product_id`),
  KEY `FK_product_firware_right` (`firmware_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_firmware`
-- -----------------------------
INSERT INTO `iot_product_firmware` VALUES ('18', '8', '15', '1450318921', '1450318921', '1');
INSERT INTO `iot_product_firmware` VALUES ('17', '5', '15', '1450318921', '1450318921', '1');

-- -----------------------------
-- Table structure for `iot_product_logconfig`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_logconfig`;
CREATE TABLE `iot_product_logconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metadata_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `log_required` char(10) DEFAULT NULL,
  `log_condition_type` tinyint(4) DEFAULT NULL,
  `log_condition_value` varchar(32) DEFAULT NULL,
  `log_format` varchar(64) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_metadata_logconfig_relation` (`metadata_id`),
  KEY `FK_product_logconfig_relation` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_logconfig`
-- -----------------------------
INSERT INTO `iot_product_logconfig` VALUES ('5', '5', '5', '1', '1', '', '{$VALUE}', '1450674043', '1450674481', '1');

-- -----------------------------
-- Table structure for `iot_product_metadata`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_metadata`;
CREATE TABLE `iot_product_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `metadata_id` int(11) NOT NULL,
  `parser_type` tinyint(4) NOT NULL,
  `parser_attr_1` varchar(128) DEFAULT NULL,
  `parser_attr_2` varchar(128) DEFAULT NULL,
  `parser_attr_3` varchar(128) DEFAULT NULL,
  `ext_attr_1` varchar(128) DEFAULT NULL,
  `ext_attr_2` varchar(128) DEFAULT NULL,
  `ext_attr_3` varchar(128) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_proudct_metadata_left` (`product_id`),
  KEY `FK_proudct_metadata_right` (`metadata_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_metadata`
-- -----------------------------
INSERT INTO `iot_product_metadata` VALUES ('15', '5', '5', '1', '', '', '', '', '', '', '0', '0', '1452133352');
INSERT INTO `iot_product_metadata` VALUES ('17', '5', '6', '1', '', '', '', '', '', '', '0', '0', '1452223554');
INSERT INTO `iot_product_metadata` VALUES ('18', '5', '7', '1', '', '', '', '', '', '', '0', '0', '1452223559');
INSERT INTO `iot_product_metadata` VALUES ('19', '8', '6', '1', '', '', '', '', '', '', '0', '0', '1452823040');
INSERT INTO `iot_product_metadata` VALUES ('20', '8', '7', '1', '', '', '', '', '', '', '0', '0', '1452823050');
INSERT INTO `iot_product_metadata` VALUES ('21', '5', '8', '1', '', '', '', '', '', '', '0', '0', '1452669232');
INSERT INTO `iot_product_metadata` VALUES ('22', '5', '10', '1', '', '', '', '', '', '', '0', '0', '1452669248');
INSERT INTO `iot_product_metadata` VALUES ('23', '8', '13', '1', '', '', '', '', '', '', '0', '0', '1452823060');
INSERT INTO `iot_product_metadata` VALUES ('24', '8', '12', '1', '', '', '', '', '', '', '0', '0', '1452823072');
INSERT INTO `iot_product_metadata` VALUES ('25', '8', '14', '1', '', '', '', '', '', '', '0', '0', '1452823086');
INSERT INTO `iot_product_metadata` VALUES ('26', '8', '15', '1', '', '', '', '', '', '', '0', '0', '1452823401');
INSERT INTO `iot_product_metadata` VALUES ('27', '8', '16', '1', '', '', '', '', '', '', '0', '0', '1452838916');
INSERT INTO `iot_product_metadata` VALUES ('28', '8', '17', '1', '', '', '', '', '', '', '0', '0', '1452841491');

-- -----------------------------
-- Table structure for `iot_product_module`
-- -----------------------------
DROP TABLE IF EXISTS `iot_product_module`;
CREATE TABLE `iot_product_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_product_module_left` (`product_id`),
  KEY `FK_product_module_right` (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_product_module`
-- -----------------------------
INSERT INTO `iot_product_module` VALUES ('15', '5', '15', '0', '0', '0');
INSERT INTO `iot_product_module` VALUES ('16', '5', '15', '1450156300', '1450156300', '1');
INSERT INTO `iot_product_module` VALUES ('17', '8', '15', '1450159773', '1450159773', '1');
INSERT INTO `iot_product_module` VALUES ('18', '8', '15', '1450513715', '1450513715', '1');
INSERT INTO `iot_product_module` VALUES ('19', '8', '15', '1450514276', '1450514276', '1');
INSERT INTO `iot_product_module` VALUES ('20', '5', '15', '1452223474', '1452223474', '1');
INSERT INTO `iot_product_module` VALUES ('21', '8', '15', '1452411497', '1452411497', '1');
INSERT INTO `iot_product_module` VALUES ('22', '8', '15', '1452411519', '1452411519', '1');
INSERT INTO `iot_product_module` VALUES ('23', '5', '15', '1452669003', '1452669003', '1');
INSERT INTO `iot_product_module` VALUES ('24', '8', '15', '1452822505', '1452822505', '1');
INSERT INTO `iot_product_module` VALUES ('25', '8', '15', '1452823270', '1452823270', '1');
INSERT INTO `iot_product_module` VALUES ('26', '8', '15', '1452838815', '1452838815', '1');
INSERT INTO `iot_product_module` VALUES ('27', '8', '15', '1452841473', '1452841473', '1');

-- -----------------------------
-- Table structure for `iot_rank`
-- -----------------------------
DROP TABLE IF EXISTS `iot_rank`;
CREATE TABLE `iot_rank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '上传者id',
  `title` varchar(50) NOT NULL,
  `logo` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `types` tinyint(2) NOT NULL DEFAULT '1' COMMENT '前台是否可申请',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_rank_user`
-- -----------------------------
DROP TABLE IF EXISTS `iot_rank_user`;
CREATE TABLE `iot_rank_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `rank_id` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `is_show` tinyint(4) NOT NULL COMMENT '是否显示在昵称右侧（必须有图片才可）',
  `create_time` int(11) NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_role`
-- -----------------------------
DROP TABLE IF EXISTS `iot_role`;
CREATE TABLE `iot_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL COMMENT '角色组id',
  `name` varchar(25) NOT NULL COMMENT '英文标识',
  `title` varchar(25) NOT NULL COMMENT '中文标题',
  `description` varchar(500) NOT NULL COMMENT '描述',
  `user_groups` varchar(200) NOT NULL COMMENT '默认用户组ids',
  `invite` tinyint(4) NOT NULL COMMENT '预留字段(类型：是否需要邀请注册等)',
  `audit` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否需要审核',
  `sort` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色表';

-- -----------------------------
-- Records of `iot_role`
-- -----------------------------
INSERT INTO `iot_role` VALUES ('1', '1', 'default', '普通用户', '普通用户', '1,2', '0', '0', '0', '1', '1450079699', '1450422848');

-- -----------------------------
-- Table structure for `iot_role_config`
-- -----------------------------
DROP TABLE IF EXISTS `iot_role_config`;
CREATE TABLE `iot_role_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL COMMENT '标识',
  `category` varchar(25) NOT NULL COMMENT '归类标识',
  `value` text NOT NULL COMMENT '配置值',
  `data` text NOT NULL COMMENT '该配置的其它值',
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='角色配置表';

-- -----------------------------
-- Records of `iot_role_config`
-- -----------------------------
INSERT INTO `iot_role_config` VALUES ('1', '1', 'score', '', '{\"score1\":10,\"score2\":10,\"score3\":10,\"score4\":10}', '', '1450421156');
INSERT INTO `iot_role_config` VALUES ('2', '1', 'avatar', '', '1', '', '1450421270');
INSERT INTO `iot_role_config` VALUES ('3', '1', 'expend_field', 'expend_field', '1,2', '', '1450421321');
INSERT INTO `iot_role_config` VALUES ('4', '1', 'register_expend_field', 'expend_field', '1,2', '', '1450421332');

-- -----------------------------
-- Table structure for `iot_role_group`
-- -----------------------------
DROP TABLE IF EXISTS `iot_role_group`;
CREATE TABLE `iot_role_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色分组';

-- -----------------------------
-- Records of `iot_role_group`
-- -----------------------------
INSERT INTO `iot_role_group` VALUES ('1', '默认分组', '1450422435');

-- -----------------------------
-- Table structure for `iot_seo_rule`
-- -----------------------------
DROP TABLE IF EXISTS `iot_seo_rule`;
CREATE TABLE `iot_seo_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `app` varchar(40) NOT NULL,
  `controller` varchar(40) NOT NULL,
  `action` varchar(40) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `seo_keywords` text NOT NULL,
  `seo_description` text NOT NULL,
  `seo_title` text NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_seo_rule`
-- -----------------------------
INSERT INTO `iot_seo_rule` VALUES ('1', '整站标题', '', '', '', '1', '', '', 'OpenCenter', '7');
INSERT INTO `iot_seo_rule` VALUES ('2', '论坛版块页', 'forum', 'index', 'forum', '-1', '{$forum.title} ', '{$forum.title} ', '{$forum.title} —— ThinkOX论坛', '2');
INSERT INTO `iot_seo_rule` VALUES ('3', '微博首页', '', 'Index', 'index', '1', '微博', '微博首页', 'OpenCenter轻量化社交框架', '5');
INSERT INTO `iot_seo_rule` VALUES ('4', '微博详情页', '', 'Index', 'weiboDetail', '1', '{$weibo.title|op_t},OpenCenter,oc,微博', '{$weibo.content|op_t}\r\n', '{$weibo.content|op_t}——OpenCenter微博', '6');
INSERT INTO `iot_seo_rule` VALUES ('5', '用户中心', 'Ucenter', 'index', 'index', '1', '{$user_info.nickname|op_t},OpenCenter', '{$user_info.username|op_t}的个人主页', '{$user_info.nickname|op_t}的个人主页', '3');
INSERT INTO `iot_seo_rule` VALUES ('6', '会员页面', 'people', 'index', 'index', '1', '会员', '会员', '会员', '4');
INSERT INTO `iot_seo_rule` VALUES ('7', '论坛帖子详情页', 'forum', 'index', 'detail', '-1', '{$post.title|op_t},论坛,thinkox', '{$post.title|op_t}', '{$post.title|op_t} —— ThinkOX论坛', '1');
INSERT INTO `iot_seo_rule` VALUES ('8', '商城首页', 'shop', 'index', 'index', '-1', '商城,积分', '积分商城', '商城首页——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('9', '商城商品详情页', 'shop', 'index', 'goodsdetail', '-1', '{$content.goods_name|op_t},商城', '{$content.goods_name|op_t}', '{$content.goods_name|op_t}——ThinkOX商城', '0');
INSERT INTO `iot_seo_rule` VALUES ('10', '资讯首页', 'blog', 'index', 'index', '-1', '资讯首页', '资讯首页\r\n', '资讯——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('11', '资讯列表页', 'blog', 'article', 'lists', '-1', '{$category.title|op_t}', '{$category.title|op_t}', '{$category.title|op_t}', '0');
INSERT INTO `iot_seo_rule` VALUES ('12', '资讯文章页', 'blog', 'article', 'detail', '-1', '{$info.title|op_t}', '{$info.title|op_t}', '{$info.title|op_t}——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('13', '活动首页', 'event', 'index', 'index', '-1', '活动', '活动首页', '活动首页——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('14', '活动详情页', 'event', 'index', 'detail', '-1', '{$content.title|op_t}', '{$content.title|op_t}', '{$content.title|op_t}——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('15', '专辑首页', 'issue', 'index', 'index', '-1', '专辑', '专辑首页', '专辑首页——ThinkOX', '0');
INSERT INTO `iot_seo_rule` VALUES ('16', '专辑详情页', 'issue', 'index', 'issuecontentdetail', '-1', '{$content.title|op_t}', '{$content.title|op_t}', '{$content.title|op_t}——ThinkOX', '0');

-- -----------------------------
-- Table structure for `iot_sms_category`
-- -----------------------------
DROP TABLE IF EXISTS `iot_sms_category`;
CREATE TABLE `iot_sms_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `pid` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_sms_category`
-- -----------------------------
INSERT INTO `iot_sms_category` VALUES ('102', 'danger', '3', '3', '20151223', '20151223', '1');
INSERT INTO `iot_sms_category` VALUES ('101', 'warning', '2', '2', '20151223', '20151223', '1');
INSERT INTO `iot_sms_category` VALUES ('100', 'info', '1', '1', '20151223', '20151223', '1');

-- -----------------------------
-- Table structure for `iot_sms_message`
-- -----------------------------
DROP TABLE IF EXISTS `iot_sms_message`;
CREATE TABLE `iot_sms_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_category` int(11) NOT NULL,
  `sms_title` varchar(64) NOT NULL,
  `sms_content` varchar(200) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_sms_message`
-- -----------------------------
INSERT INTO `iot_sms_message` VALUES ('1', '102', '空气质量差', 'PM2.5 大于500，请密闭门窗，开启空气净化器', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_message` VALUES ('2', '101', '滤芯使用期限超限', '滤芯使用期限超过半年，请及时更换滤芯，否则会影响净化后的空气质量', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_message` VALUES ('3', '100', '手机App升级', '手机App新增社交功能，请马上升级，立刻拥有更好的用户体验', '1452671032', '1452671032', '1');

-- -----------------------------
-- Table structure for `iot_sms_send_log`
-- -----------------------------
DROP TABLE IF EXISTS `iot_sms_send_log`;
CREATE TABLE `iot_sms_send_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `read_status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_sms_send_log`
-- -----------------------------
INSERT INTO `iot_sms_send_log` VALUES ('1', '1', '1', '1', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_send_log` VALUES ('2', '1', '101', '0', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_send_log` VALUES ('3', '1', '102', '0', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_send_log` VALUES ('4', '1', '100', '0', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_send_log` VALUES ('5', '1', '103', '0', '1452670885', '1452670885', '1');
INSERT INTO `iot_sms_send_log` VALUES ('6', '2', '1', '1', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_send_log` VALUES ('7', '2', '101', '0', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_send_log` VALUES ('8', '2', '102', '0', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_send_log` VALUES ('9', '2', '100', '0', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_send_log` VALUES ('10', '2', '103', '0', '1452670972', '1452670972', '1');
INSERT INTO `iot_sms_send_log` VALUES ('11', '3', '1', '1', '1452671032', '1452671032', '1');
INSERT INTO `iot_sms_send_log` VALUES ('12', '3', '101', '0', '1452671032', '1452671032', '1');
INSERT INTO `iot_sms_send_log` VALUES ('13', '3', '102', '0', '1452671032', '1452671032', '1');
INSERT INTO `iot_sms_send_log` VALUES ('14', '3', '100', '1', '1452671032', '1452671032', '1');
INSERT INTO `iot_sms_send_log` VALUES ('15', '3', '103', '0', '1452671032', '1452671032', '1');

-- -----------------------------
-- Table structure for `iot_sso_app`
-- -----------------------------
DROP TABLE IF EXISTS `iot_sso_app`;
CREATE TABLE `iot_sso_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `create_time` int(11) NOT NULL,
  `config` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_super_links`
-- -----------------------------
DROP TABLE IF EXISTS `iot_super_links`;
CREATE TABLE `iot_super_links` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '类别（1：图片，2：普通）',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '站点名称',
  `cover_id` int(10) NOT NULL COMMENT '图片ID',
  `link` char(140) NOT NULL DEFAULT '' COMMENT '链接地址',
  `level` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '优先级',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用，1：正常）',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='友情连接表';


-- -----------------------------
-- Table structure for `iot_support`
-- -----------------------------
DROP TABLE IF EXISTS `iot_support`;
CREATE TABLE `iot_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appname` varchar(20) NOT NULL COMMENT '应用名',
  `row` int(11) NOT NULL COMMENT '应用标识',
  `uid` int(11) NOT NULL COMMENT '用户',
  `create_time` int(11) NOT NULL COMMENT '发布时间',
  `table` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='支持的表';


-- -----------------------------
-- Table structure for `iot_sync_login`
-- -----------------------------
DROP TABLE IF EXISTS `iot_sync_login`;
CREATE TABLE `iot_sync_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type_uid` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `oauth_token` varchar(255) NOT NULL,
  `oauth_token_secret` varchar(255) NOT NULL,
  `is_sync` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `iot_talk`
-- -----------------------------
DROP TABLE IF EXISTS `iot_talk`;
CREATE TABLE `iot_talk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) NOT NULL,
  `uids` varchar(100) NOT NULL,
  `appname` varchar(30) NOT NULL,
  `apptype` varchar(30) NOT NULL,
  `source_id` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `source_title` varchar(100) NOT NULL,
  `source_content` text NOT NULL,
  `source_url` varchar(200) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `message_id` int(11) NOT NULL,
  `other_uid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会话表';


-- -----------------------------
-- Table structure for `iot_talk_message`
-- -----------------------------
DROP TABLE IF EXISTS `iot_talk_message`;
CREATE TABLE `iot_talk_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(500) NOT NULL,
  `uid` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `talk_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天消息表';


-- -----------------------------
-- Table structure for `iot_talk_message_push`
-- -----------------------------
DROP TABLE IF EXISTS `iot_talk_message_push`;
CREATE TABLE `iot_talk_message_push` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `source_id` int(11) NOT NULL COMMENT '来源消息id',
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  `status` tinyint(4) NOT NULL,
  `talk_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk COMMENT='状态，0为未提示，1为未点击，-1为已点击';


-- -----------------------------
-- Table structure for `iot_talk_push`
-- -----------------------------
DROP TABLE IF EXISTS `iot_talk_push`;
CREATE TABLE `iot_talk_push` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '接收推送的用户id',
  `source_id` int(11) NOT NULL COMMENT '来源id',
  `create_time` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '状态，0为未提示，1为未点击，-1为已点击',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='对话推送表';


-- -----------------------------
-- Table structure for `iot_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `iot_ucenter_admin`;
CREATE TABLE `iot_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `iot_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `iot_ucenter_member`;
CREATE TABLE `iot_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(32) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  `type` tinyint(4) NOT NULL COMMENT '1为用户名注册，2为邮箱注册，3为手机注册',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `iot_ucenter_member`
-- -----------------------------
INSERT INTO `iot_ucenter_member` VALUES ('1', 'admin', 'eace7253a799c1051118be13f9e75157', 'admin@admin.com', '', '1450079699', '0', '1453033410', '1918707630', '1450079699', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('100', 'test', 'eace7253a799c1051118be13f9e75157', 'test@qq.com', '', '1450703702', '0', '1452485216', '1022852494', '1450703702', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('101', 'luyuan', 'eace7253a799c1051118be13f9e75157', '', '', '1450704396', '0', '1452482740', '1022852489', '1450704396', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('102', 'qinhao', 'eace7253a799c1051118be13f9e75157', '', '', '1451026953', '0', '1451027282', '0', '1451026953', '1', '1');
INSERT INTO `iot_ucenter_member` VALUES ('103', 'yuhai', 'eace7253a799c1051118be13f9e75157', '', '', '1451027516', '0', '0', '0', '1451027516', '1', '1');

-- -----------------------------
-- Table structure for `iot_ucenter_score_type`
-- -----------------------------
DROP TABLE IF EXISTS `iot_ucenter_score_type`;
CREATE TABLE `iot_ucenter_score_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `unit` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_ucenter_score_type`
-- -----------------------------
INSERT INTO `iot_ucenter_score_type` VALUES ('1', '积分', '1', '分');
INSERT INTO `iot_ucenter_score_type` VALUES ('2', '威望', '1', '点');
INSERT INTO `iot_ucenter_score_type` VALUES ('3', '贡献', '1', '元');
INSERT INTO `iot_ucenter_score_type` VALUES ('4', '余额', '1', '点');

-- -----------------------------
-- Table structure for `iot_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `iot_ucenter_setting`;
CREATE TABLE `iot_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `iot_url`
-- -----------------------------
DROP TABLE IF EXISTS `iot_url`;
CREATE TABLE `iot_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `iot_user_config`
-- -----------------------------
DROP TABLE IF EXISTS `iot_user_config`;
CREATE TABLE `iot_user_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `model` varchar(30) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户配置信息表';


-- -----------------------------
-- Table structure for `iot_user_role`
-- -----------------------------
DROP TABLE IF EXISTS `iot_user_role`;
CREATE TABLE `iot_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '2：未审核，1:启用，0：禁用，-1：删除',
  `step` varchar(50) NOT NULL COMMENT '记录当前执行步骤',
  `init` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否初始化',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户角色关联';

-- -----------------------------
-- Records of `iot_user_role`
-- -----------------------------
INSERT INTO `iot_user_role` VALUES ('1', '1', '1', '1', 'finish', '1');

-- -----------------------------
-- Table structure for `iot_user_tag`
-- -----------------------------
DROP TABLE IF EXISTS `iot_user_tag`;
CREATE TABLE `iot_user_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `pid` int(11) NOT NULL,
  `sort` tinyint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='标签分类表';

-- -----------------------------
-- Records of `iot_user_tag`
-- -----------------------------
INSERT INTO `iot_user_tag` VALUES ('1', '默认', '1', '0', '0');
INSERT INTO `iot_user_tag` VALUES ('2', '开发者', '1', '1', '0');
INSERT INTO `iot_user_tag` VALUES ('3', '站长', '1', '1', '0');

-- -----------------------------
-- Table structure for `iot_user_tag_link`
-- -----------------------------
DROP TABLE IF EXISTS `iot_user_tag_link`;
CREATE TABLE `iot_user_tag_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `tags` varchar(200) NOT NULL COMMENT '标签ids',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户标签关联表';


-- -----------------------------
-- Table structure for `iot_user_token`
-- -----------------------------
DROP TABLE IF EXISTS `iot_user_token`;
CREATE TABLE `iot_user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `iot_user_token`
-- -----------------------------
INSERT INTO `iot_user_token` VALUES ('1', '1', 'tho5nEaxHdCYcK0LQMIke387u26jsmRPF1ZJyvq9', '1450947728');
INSERT INTO `iot_user_token` VALUES ('2', '103', 'mEyIOerDqXsJN0HA2gWl1pjPRMfLkwVYUzBou5Zi', '1451027516');
INSERT INTO `iot_user_token` VALUES ('3', '101', 'GH8ZoPV2ckKyzD4tmbExjwslrWquv3YB6O7RJeMg', '1452482672');

-- -----------------------------
-- Table structure for `iot_verify`
-- -----------------------------
DROP TABLE IF EXISTS `iot_verify`;
CREATE TABLE `iot_verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `account` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `verify` varchar(50) NOT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

